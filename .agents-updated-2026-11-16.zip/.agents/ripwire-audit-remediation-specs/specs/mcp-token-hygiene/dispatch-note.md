# Dispatch Note — mcp-token-hygiene (attachment 1 of 2)

**Dispatched:** 2026-11-04T10:10Z, by the PM Advisor seat (dispatcher-of-record, WorkBuddy AI /
GLM-5.3) under the operator's dispatch directive of this date, verbatim: *"i will assign
deepseekv4.1-flash-1017 in hoplite cloud, please add this decision and flip on my behalf and
let's dispatch the mcp-token-hygiene first please."*
**Producer:** Deepseek-V4.1-Flash "-1017" (Hoplite cloud session; operator-assigned 2026-11-04).
Same production family as the multiquantifier producer — conventions continuity, NO re-onboarding
tier. Ship keys stay with the PM seat (§03.7): the upstream PR is NEVER yours; details below.
**Base commit:** `50bc05e84` — fork `pt-act/ripwire` main = upstream `redhat-et/ripwire` main =
`50bc05e84` (the operator synced the fork via the GitHub UI this date; pure fast-forward,
verified both sides). Branch **`lane/mcp-token-hygiene`** off `50bc05e84`. Upstream lands ~2
trains/day; if main moved before you branch, re-pin per the drift section at the end.
**Attachment 2 of 2 is your spec** (`spec-mcp-token-hygiene.md`, v1.0.0). Unlike the
multiquantifier spec, yours is PINNED, not draft: the interfaces (tokenWarningContract) and ACs
1–5 are contract. Your Phase 0 VERIFIES each anchor live on the current tree and tightens arm
wording where needed; it does not re-design.

**Manifest bookkeeping for THIS dispatch** (status planned → in_progress, execution.producer,
`spec_started` history event, the spec file's Status line) is done by the dispatcher in the same
act — you do NOT touch the manifest for the dispatch itself. Any LATER manifest mutation you
need (status transitions per VALIDATION_PROTOCOL) is drafted by you in your hand-back and
**applied through the PM seat** — the producer never flips statuses (Q10 ruling 2026-10-29).

## The finding (re-verified live by the dispatcher on `50bc05e84`, this date)

`--mcp-token=SECRET` places the shared bearer in argv, readable via `ps` for the process's
lifetime. The safer `RIPWIRE_MCP_TOKEN` env channel exists and the code even knows it — the env
fallback at `src/main.cpp:4559` carries the comment `// env fallback (avoids the secret in
argv/ps)` — but NOTHING steers operators to it. Convergence probe (this date, ~900 commits past
the spec's 2026-09-14 draft base): the gap is still real — no argv-exposure warning exists
anywhere in the tree; every `RIPWIRE_MCP_TOKEN` mention is a help parenthetical, a flag-table
comment, or the env fallback itself. No open upstream PR or issue touches this surface.

**Current anchors (all live-verified on `50bc05e84`; the spec's 2026-09-14 `main.cpp ~L3151` is
STALE and already corrected in this dispatch):**
- `src/cli.h:47` — `std::string_view mcpToken;` field decl: `--mcp-token=T (or RIPWIRE_MCP_TOKEN
  env)`. **Key provenance fact: `cfg.mcpToken` only ever holds the ARGV value; env is read
  later, at main.cpp:4557, into `hc.token` after the empty-check. So `!cfg.mcpToken.empty()` IS
  the argv-provenance test the warning gates on.**
- `src/cli.h:2908–2912` — the `--mcp-token=T` **help text block** (Phase 2 edits this
  recommendation order: env channel first).
- `src/cli.h:3366` — ViewFlag table entry `{ "--mcp-token=", &Config::mcpToken, …,
  "--mcp-token=$RIPWIRE_MCP_TOKEN" }`.
- `src/main.cpp:4550–4574` — the HTTP branch: `if( !cfg.listen.empty() )` at :4550,
  `McpHttpConfig hc;` :4552, **`hc.token = std::string( cfg.mcpToken );` at :4554**, env
  fallback `std::getenv("RIPWIRE_MCP_TOKEN")` at :4557, **`return runMcpHttp( hc );` at :4573**.
  THE WARNING'S HOME: this config assembly block, right after the :4554 assignment, gated on
  `!cfg.mcpToken.empty()` — before the accept loop; it CANNOT fire in stdio mode (the whole
  block is inside the `--listen` branch). This is the site the spec pins.
- `src/mcpserver.h:44` (token field), `:465`/`:476` (the non-loopback banner's existing
  `--mcp-token=SECRET or RIPWIRE_MCP_TOKEN` phrasing — the voice to match).

## Read-first list (in this order)

1. **Your spec** (attachment 2): the Objective, Scope, tokenWarningContract, ACs 1–5, the
   Failure Modes (warning fatigue; token echoed in an error path), Implementation Notes.
2. **In your clone** (all at `50bc05e84`): `src/main.cpp:4550–4574` (the warning's home),
   `src/cli.h:40–50` + `:2900–2915` + `:3360–3370`, `src/mcpserver.h:40–50` + `:455–480`
   (banner voice), `test/mcpremotecheck.sh` + `test/lib/gatehttp.sh` — **the HTTP-test pattern
   your gate copies** (start_server waits until the listener ANSWERS; no fixed sleeps; the curl
   shim; ephemeral port pick; mktemp + cleanup trap; the ok/no helpers).
3. **The warning-style precedent in your clone:** how existing one-line startup warnings emit —
   `rw::emitTo( stderr, … )` (grep it in `src/`, pick the closest startup-site usage as the
   shape template).

## Phase 0 (planning, before any code — small, this is a Tier-1 spec)

1. Verify every anchor above against YOUR checkout (line drift breaks nothing as long as the
   sites match by content; re-pin your working line numbers).
2. **Red baseline:** build the base binary; confirm arm (a)'s grep finds NO warning line today
   (the finding is real) and arm (d)'s docs-order is env-second today. Arms (b)/(c) are controls
   — they pass pre-change and MUST pass identically post-change (auth is untouched).
3. Pin your gate skeleton: four arms, `test/mcptokencheck.sh`, BIN resolution as
   `BIN="${1:-${RIPWIRE_BIN:-$ROOT/build/ripwire}}"` (the absorb loop invokes gates as
   `RIPWIRE_BIN="$BIN" bash "$ROOT/test/$_g.sh"` — a bare `BIN=` env var is a miss that runs a
   stale binary; this exact defect cost the multiquantifier lane a false red run).
4. Reply-in-thread (via the operator relay) with: pinned anchors, the arm wording, the exact
   warning sentence you will ship (it must match the pinned gate regex
   `ripwire: .*--mcp-token.*process list.*RIPWIRE_MCP_TOKEN`), and your red-baseline output.
   The PM confirms before Phase 1 (folds corrections cheaply, exactly as the multiquantifier
   Phase 0 ran).

## Hard constraints (from the spec; non-negotiable)

- **One line, once per process** — never per request; no opt-out flag (a warning, not a refusal).
- **The token VALUE never appears in the warning or any stderr/stdout** (arm (a) asserts absence
  of the fixture token).
- **stdout — the protocol channel — is never touched.**
- **Authentication behavior is otherwise identical** (arm (c): 401s unchanged in both channels).
- **The argv form is NOT removed** and the env form gains no new magic (out of scope: breaking
  argv, storage/rotation/TLS, the constant-time compare — do not touch any of them).
- **Red-first:** arms (a)/(d) shown RED on the pre-change binary before the implementation
  exists; controls (b)/(c) green on both sides. No PBT, no corpus sweep for this lane (Tier 1
  — the spec's Validation Strategy says focused arms suffice; there is no input-parsing surface
  here).

## Phase-1 house rules

- Warning fires at `src/main.cpp` in the `--listen` config-assembly block, gated on
  `!cfg.mcpToken.empty()`; `rw::emitTo( stderr, … )` style; one line; wording matches the gate
  regex; voice matches the `mcpserver.h:465` banner (say where the exposure lives and what the
  safer channel is — copy the voice, not the sentence).
- **Phase 2+ docs are GENERATED, never hand-edited:** edit the help text in
  `src/cli.h:2908–2912` (env channel first), rebuild, then regenerate `docs/COMMANDS.md` with
  `python3 docs/docs_commands_build.py --bin <your-built-bin>` and run its `--check`. The docs
  drift gates (`docscommandscheck`, `readmedriftcheck`, and friends) are the authority — a
  hand-edit of COMMANDS.md is a red gate, not a shortcut. `mcpserver.h`'s comment posture is a
  source comment edit, not a generated file.
- **Changelog:** new fragment `changelog.d/mcp-token-warning.md` (read any existing fragment,
  e.g. `changelog.d/self-hook.md`, for the format); `python3 scripts/changelog_assemble.py check`
  green. `changelog.d/versions.md` records `kParserVer` moves only — you have none; do not
  touch it.

## Gate registration — THE MECHANICS CHANGED UPSTREAM (measured by the dispatcher this date)

Upstream's 388-commit drift (trains 46+) landed **GEN-DOCS-MERGE**, which replaces the old
count-site recipe our previous lanes used:

- **`test/regression.sh`'s absorb loop is now one-gate-per-line** (LC_ALL=C byte order, lines
  like `    mcptokencheck \`, ending `    ; do`) — NOT the old single-line form. Insert
  `    mcptokencheck \` **after `mcpstrictschemacheck`, before `mcptoolprunecheck`** (verified
  slot at `50bc05e84`). You can normalize with `scripts/merge_main.sh --sort-list` if in doubt.
- **DO NOT touch the published gate counts (README.md / docs/EVALS.md / deck) or
  `docs/counts.tsv`.** Totals now publish from the dated snapshot `docs/counts.tsv` (taken
  2026-11-03, `gates.scripts` 753). A feature PR that adds a gate adds ONLY the gate file + its
  loop line + the changelog fragment. The live loop at base is **761**; your gate makes 762;
  drift vs snapshot goes 8 → 9, still under `MAX_DRIFT = 10` — the drift arm
  (`gendocsmergecheck`) stays GREEN. If it ever goes red on you, a snapshot refresh is a
  MAINTAINER step riding train PRs — not yours; report it in your hand-back instead.
- **Do not run `docs/counts_snapshot.py refresh`** (a maintainer step; a PR that refreshed
  unilaterally would conflict with every open PR — the exact collision class the snapshot
  system was built to kill).
- Validation battery on your tree, minimum: your gate (red→green),
  `gatecount --check`, `limits --check`, `changelog_assemble check`, `manifestcheck` (its
  deliberately-false mutation-control fixture lines are its own working parts, not a threat),
  `gendocsmergecheck`, `docscommandscheck` (after your COMMANDS.md regen),
  `mcpremotecheck` (your warning must not disturb it — it starts argv-token servers; confirm
  its stderr assertions tolerate one extra warning line), `gitframingcheck`, and the full
  regressions if your session's runtime allows; CI runs the rest on the PR.
  `test/manifestcheck.sh` needs **`bash`**, not `sh` (process substitution).

## Base drift while you work (upstream lands ~2 trains/day)

If the upstream main moves mid-lane, `scripts/merge_main.sh` (NEW, upstream-built, in your
clone at this base) does the whole mechanical absorb: it fetches and merges `origin/main`,
settles the absorb list as a byte-sorted set union including the loop-form change, recomputes
generator-owned count lines and LIMITS/TUNING, and marks binary-pinned files
(`test/printf_parity.manifest`, `docs/COMMANDS.md`, `docs/captures/*`) REGEN AFTER BUILD —
`scripts/merge_main.sh --regen-after-build <bin>` re-records them after you rebuild the merged
tree. **Also refresh your convergence probe before hand-back:** no upstream PR or issue may
have grown an argv-token warning while you worked. If one did, STOP and relay — a shrunk
residual lane beats a superseded one (twice-proven course in this pipeline).

## The one-lane-in-review interlock (standing operator directive)

**Nothing upstream-visible from this lane until PR #484 (regex-screen-multiquantifier, three
review rounds deep) concludes** — merged or explicitly declined. Concretely: work on
`lane/mcp-token-hygiene`; push the branch to the fork `pt-act/ripwire` when the lane is
complete (a fork branch is NOT upstream-visible; if your session cannot push, hand the patches
back through the operator and the PM pushes). The **upstream PR is the PM seat's act** after
hand-back validation and after #484 concludes — never yours, even if CI invites you.

## Hand-back contract

At lane completion, relay through the operator to the PM seat: (1) the lane branch pushed
(patches if you cannot push); (2) a completion report in the pipeline's 16-AC-style shape —
every AC with its command + output, the red-baseline output from Phase 0, the warning sentence
as shipped, the docs regen diff, the battery results; (3) your phase notes. The PM validates
independently (both toolchains on the Mac, per the #397/#469/#484 pattern) and files the
canonical artifacts under the spec's `validation/` on the project's bookkeeping side. Status
flips on resolution are the dispatcher's act, never yours.

## Environment notes (your cloud habitat; Mac-specific traps don't apply to you)

Authorship: every commit ships as `pt-act <psychoactive28@gmail.com>` — set per-worktree before
the first commit (a session that never set identity once shipped everything as a platform bot
identity and the badge was lost; pinned pipeline-wide). `git add` takes an explicit path list
(`src/... test/... docs/... changelog.d/...`), never `-A`/`.` — a sweep once carried private
workspace dirs into a public branch. Ephemeral ports for HTTP arms (no fixed sleeps — a request
unanswered is a named FAIL, never a PASS). The PM seat validates on macOS with both libc++ and
libstdc++ legs; your minimum is one clean build + the battery above, CI covers the rest.
