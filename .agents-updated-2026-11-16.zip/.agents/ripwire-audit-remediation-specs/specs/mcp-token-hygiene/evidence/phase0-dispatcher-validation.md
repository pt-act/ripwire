# Phase-0 dispatcher validation — mcp-token-hygiene (2026-11-04, PM seat)

Every producer claim independently verified from this seat before the ACCEPTED-WITH-
CORRECTIONS verdict. Evidence summary (commands run on this host against the real base):

## Branch integrity
- `lane/mcp-token-hygiene` fetched from fork; merge-base = 50bc05e84 EXACTLY (correct base).
- 2 commits, pt-act <psychoactive28@gmail.com> authorship correct:
  e1ffb2237 (gate skeleton) + 3fdd90508 (arm-(d) sharpening). Diff stat: test/mcptokencheck.sh
  only (+155). Interlock respected (no source, nothing upstream-visible).

## Proxy claim verified, then superseded by a fresh-base re-derivation
- `git show 0e0f67c7:src/main.cpp` vs `50bc05e84` awk-extracted McpHttpConfig blocks:
  diff EMPTY — the hc-block is byte-identical; the producer's proxy reasoning holds.
- Fresh 50bc05e84 build (worktree mth-base-r1, guarded launcher, disk 9.2GiB): BUILD-CLEAN
  in 11m06s (mth-base-build.done marker; log mth-base-validate.log).
- Producer's gate run against the fresh base binary: matrix reproduced EXACTLY —
  (a) FAIL "expected exactly 1 warning line, got 0" + PASS secret-absent; (b) PASS no-warning
  + PASS 200; (c) PASS 401 missing + PASS 401 wrong; (d) PASS name-grep + FAIL
  "docs do not state the process-list exposure" (after the guard fix; see defect).

## Producer catches ratified (measured at base)
- Arm (d) vacuous-class: grep -c RIPWIRE_MCP_TOKEN docs/COMMANDS.md @50bc05e84 = 1 (the
  spliced help text) — the original single-grep verifier discriminates nothing.
- Sharpened arm discriminates: grep -ci 'process list' = 0 at base.
- The `ps `-grep evasion: "drops it" matched at COMMANDS.md:99 — producer's 3fdd90508 fix
  to the exact phrase is correct.
- Splice defect: cli.h:2909–2911 = "…mandatory for a non-loopback bind" + fresh
  "shared bearer token gating…" (two descriptions); propagates to COMMANDS.md:5077.

## Dispatcher defect (the ONLY blocking finding)
- As-shipped gate line 65 `env "${envs[@]}"` under `set -u`: macOS /bin/bash 3.2.57 crashes
  with empty array (`envs[@]: unbound variable`), arms (a)/(c). CASCADE: the dying background
  subshell inherits the EXIT trap → cleanup() deletes shared $TMP → arm (b) false-fails
  (b.out: No such file or directory). 4 fail-lines, ONE root cause. Reproduced 2×.
- Guard fix `env ${envs[@]+"${envs[@]}"}`: verified safe on bash 3.2 (GUARD-OK) and inert on
  bash 5; post-fix run yields the true matrix above. The producer's bash-5 sandbox is blind
  to this class; the repo's regression loop runs gates under bash=3.2 on this host.

## Sentence + placement rulings (verified)
- Trimmed sentence 145 bytes; matches pinned regex `ripwire: .*--mcp-token.*process
  list.*RIPWIRE_MCP_TOKEN` (python re-verified). Original 193-byte draft's trailing clause
  cut (remediation-advice; grants permission for the warned channel; grows a
  token-budget-gated surface).
- Banner order: the [token required] banner prints INSIDE runMcpHttp (mcpserver.h ~:546,
  after bind); the pinned main.cpp placement is upstream — warning fires FIRST. The
  producer's "after the banner" prose is impossible and corrected in the verdict.

## Register-state fact (measured)
- manifestcheck against the unregistered skeleton: FAIL "(REGISTRY) test/mcptokencheck.sh
  exists (CI runs it) but test/regression.sh neither lists nor invokes it" — the branch head
  is registry-RED by interim design; registration lands WITH-BEFORE Phase 1 (fold into the
  skeleton commit by rebase for a clean history).

## Battery expectations for the Phase-1 hand-back (analysis basis noted in the verdict relay)
- mcpcontractcheck (E) / mcpframehonestycheck (K2): start argv-token servers with
  stderr=subprocess.STDOUT but only read the merged pipe on failure/exit paths — the
  warning is banner-class there; verify green.
- helpbudgetcheck: tier-1 token budget — the Phase-2 help rewrite must not grow tier 1.
- Help-table records gates referencing --mcp-token in SKIP lists (argvdiffcheck :96,
  flagsurfacecheck :46, compactlegendcheck :449, emptyvaluerefusecheck :44) — none
  compare --help bytes on the mcp-token entry; no pin conflicts expected.

Verdict: ACCEPTED WITH CORRECTIONS; Phase 1 CLEARED. Full event: manifest.yml
spec_revised 2026-11-04T14:35:00Z.
