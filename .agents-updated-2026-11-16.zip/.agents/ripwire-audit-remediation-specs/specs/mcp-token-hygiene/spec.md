# MCP Token Hygiene

## Header

```yaml
id: mcp-token-hygiene
type: unit
version: 1.0.0
manifest: ../../manifest.yml
```

## Objective

Stop encouraging bearer-token exposure through the process list, closing audit finding #7 (Low). `--mcp-token=SECRET` places the shared bearer in argv, readable by any local user via `ps` for the process's lifetime; the safer `RIPWIRE_MCP_TOKEN` env channel already exists but nothing steers operators to it. (Anchor refresh 2026-11-04: the argv read is `--mcp-token=` in `src/cli.h:47`/`:3366`; the http-config assembly — the warning's true home — is `src/main.cpp:4553-4573` (`hc.token = cfg.mcpToken` at `:4554`, env fallback at `:4557`, `runMcpHttp` at `:4573`). The 2026-09-14 draft anchor `main.cpp ~L3151` is stale — verify every anchor live in Phase 0.)

## Scope

**In scope:**
- A one-time stderr warning at MCP HTTP startup when the token was supplied via `--mcp-token` (argv): names the exposure (visible in the process list to other local users) and the safer channel (`RIPWIRE_MCP_TOKEN` or a reverse proxy's auth), in the existing `rw::emitTo( stderr, … )` style.
- No warning when the token comes from the environment; no behavior change to authentication itself.
- Docs: the `--listen`/`--mcp-token` section of the reference docs and `mcpserver.h`'s header posture comment updated to recommend the env var.
- A new gate `test/mcptokencheck.sh` registered in `test/regression.sh` in the same commit.

**Out of scope:**
- Removing the argv form (a breaking change; the warning is the remediation for this cycle).
- Token storage, rotation, or TLS termination (documented "reverse-proxy it" posture unchanged).
- The constant-time compare (already correct — do not touch).

## Interfaces

### Produces

#### tokenWarningContract
- **Shape:** behavioral contract — HTTP MCP startup with `--mcp-token=<v>` emits exactly one stderr line matching `ripwire: .*--mcp-token.*process list.*RIPWIRE_MCP_TOKEN` (wording pinned in the gate); startup with `RIPWIRE_MCP_TOKEN` set and no argv token emits no such line; authentication behavior is otherwise identical.
- **Location:** `src/main.cpp` (flag parse / `runMcpHttp` config assembly).
- **Invariants:** the token value itself never appears in the warning (or any log); the warning fires once per process; stdout (the protocol channel) is never touched.
- **Examples:** `ripwire . --listen 8080 --mcp-token=hunter2` → one warning, server starts; `RIPWIRE_MCP_TOKEN=hunter2 ripwire . --listen 8080` → no warning.
- **Consumers:** security-threatmodel-docs

### Consumes

None — root spec.

## Acceptance Criteria

1. **argv token warns**: run with `--mcp-token` against a fixture root on a free port. **Verifier:** `test/mcptokencheck.sh` arm (a) greps stderr for the pinned warning regex and asserts the token string `hunter2`-fixture never appears in stderr/stdout.
2. **env token silent**: same run with the env var instead. **Verifier:** arm (b) asserts no warning line and a successful authenticated request (curl with the Bearer header returns 200).
3. **Auth unchanged**: wrong/missing token still 401 in both channels. **Verifier:** arm (c) asserts 401s.
4. **Docs updated**: the reference docs recommend the env channel first AND state the process-list exposure the warning names. **Verifier:** arm (d) asserts BOTH — the `RIPWIRE_MCP_TOKEN` recommendation and the exposure phrase `process list` — in `docs/COMMANDS.md`. *(Phase-0 fold 2026-11-04: the original single-grep verifier was VACUOUS at base — the string already sat in the spliced help text, count=1; the discriminating assertion pair is the producer's, verified red at base by the dispatcher: `process list` count=0.)*
5. **Gate registered**: in `test/regression.sh`; `./test/manifestcheck.sh` passes. **Verifier:** run it.

## Implementation Notes

- (Phase-0 fold, 2026-11-04) **Portability: the gate must not use a bare `"${array[@]}"` expansion under `set -u`.** The env-array `start_server` helper crashes on macOS bash 3.2 whenever the array is empty (arms (a)/(c) — `envs[@]: unbound variable`), and the crash cascade MUTILATES the gate: the dying background subshell inherits the EXIT trap, its cleanup() deletes the shared `$TMP`, and arms (b) then fail with missing tmp-file errors — the gate reads 4 fail-lines that are all ONE defect. Use the guard idiom `env ${envs[@]+"${envs[@]}"}` (verified safe on bash 3.2 and inert on bash 5), or per-arm inline env prefixes matching the tree's `mcpremotecheck` pattern. Dust this on BOTH the host's `/bin/bash` (3.2) and bash 5 before push.
- (Phase-0 fold, 2026-11-04) **The `docs/COMMANDS.md` text at base carries a splice your Phase-2 rewrite already fixes** — `--mcp-token=T`'s help entry reads two descriptions spliced mid-sentence ("…mandatory for a non-loopback bind" then a fresh "shared bearer token gating…"), propagated to `docs/COMMANDS.md:5077` by the generator. Rewrite the block as ONE coherent entry (env-first recommendation + the exposure sentence), then regen. RULING: fixing the splice is IN SCOPE for your Phase-2 help rewrite — the rewrite naturally owns it; no separate lane/fragment needed. Mention the splice fix in the changelog fragment's body.
- Keep the warning to one line; `mcpserver.h` already prints a loud banner for non-loopback binds — this warning belongs at startup config assembly, before the accept loop, and must not fire for stdio mode (no token there at all). **Ordering on stderr (Phase-0 pin): the warning (main.cpp, before `runMcpHttp`) necessarily fires BEFORE `runMcpHttp`'s startup banner (`[token required]`) renders** — the banner prints inside `runMcpHttp` after the listen/bind (mcpserver.h ~:546), so the warning beats it on stderr. Any docs/relay prose that claims the reverse order is wrong and must not ship. Sibling MCP gates that merge stderr into a compared stream (`mcpcontractcheck` (E), `mcpframehonestycheck` (K2)) only read the merged pipe on failure paths (startup-fail or exit paths), and those arms do not start with the expectation that the pipe contains no warning lines — the warning is banner-class there; verify them green post-change, do not pre-worry them.
- The docs regenerate from the binary's `--help` where applicable; follow the existing doc-drift gates rather than hand-editing generated files.

## Failure Modes

### Warning fatigue on legitimate argv use
- **Trigger:** ephemeral local testing where ps exposure is acceptable.
- **Expected handling:** one line, once, no repetition per request; no opt-out flag (it is a warning, not a refusal).
- **Validator check:** arm (a) counts exactly one line.

### Token echoed in an error path
- **Trigger:** a startup failure message that prints config.
- **Expected handling:** no diagnostic prints the token value; gate arm (a) asserts absence.
- **Validator check:** arm (a) absence grep.

## Dependencies

None.

## Consumers

- **Spec:** security-threatmodel-docs — documents the recommended token channel and the warning's meaning. **Constraints:** renaming the env var or the flag breaks the doc's verbatim guidance.

## Status

**Status:** approved
**Last updated:** 2026-11-04T18:05:00Z (Phase 1+2+3 hand-back VALIDATED by the validator-of-record (PM seat): every AC claim independently reproduced with measured discrimination on both toolchains (fresh libc++ 11m19s + gcc leg 36m56s, the build incl. the validator fix); the full owed battery ALL GREEN; one validator-found defect — the dropped period after "gets a 401" splicing two sentences in the regen'd docs — fixed as disclosed validator commit `0f1039b44` (d8cd267a1 amended pre-push per the #484 clean-history rule; 93aae229 precedent), re-verified green on both legs, pushed; final lane head 0f1039b44, 3 commits, 7 files, +188/−5. Completion-verification.md is the evidence record. The producer's four Phase-0 corrections all folded and verified. Upstream PR: the PM seat's act, gated on PR #484 concluding per the one-lane-in-review interlock.)
**Updated by:** validator-of-record (PM seat, WorkBuddy AI / GLM-5.3, per VALIDATION_PROTOCOL step 2 / Q10 option (a)) — producer Deepseek-V4.1-Flash "-1017" (Hoplite cloud session); base 50bc05e84; lane/mcp-token-hygiene @ 0f1039b44

## Validation Strategy

Tier 1 — focused testing sufficient. Components assessed: startup config assembly (a boolean provenance check — focused arms (a)/(b) cover both channels), the warning emitter (single-line, value-free — arm (a) covers), and the unchanged auth path (arm (c) covers). No PBT-suitable component identified: no input parsing, no crypto, no state machine.

## Progress Tracking

- [x] Phase 1: Token-provenance tracking in flag parsing + one-line startup warning *(done: `!cfg.mcpToken.empty()` IS the provenance test — verified in source by the dispatcher; warning at main.cpp `--listen` config assembly, gate arm (a) red-at-base/green-at-lane discriminated by the validator 2026-11-04)*
- [x] Phase 2: Docs and --help recommendation updated; doc-drift gates green *(done: help block env-first + splice healed — one residual period-splice found by the validator in hand-back verification, fixed as disclosed validator commit `d8cd267a1` per the 93aae229 precedent; docs regen + helpbudget/docscommands/showcase/compactlegend ALL PASS on the fixed tree)*
- [x] Phase 3: test/mcptokencheck.sh arms (a)–(d), registered in regression.sh *(done: registered at 762-loop slot after mcpstrictschemacheck in the skeleton commit 9e29ae35 per same-commit discipline; bash-3.2 guard folded; ALL PASS both toolchains (gcc leg pending-completion at validation time))*
