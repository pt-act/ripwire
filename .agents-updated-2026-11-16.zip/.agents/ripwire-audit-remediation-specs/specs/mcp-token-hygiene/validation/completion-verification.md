# Hand-back verification — mcp-token-hygiene Phase 1+2 (2026-11-04, PM seat acting as validator-of-record)

Producer hand-back: lane/mcp-token-hygiene @ 7bd29ea4 (2 commits: 9e29ae359 skeleton WITH
registration per same-commit discipline, 7bd29ea4a implementation); validation folded the
third commit (0f1039b44, the disclosed validator fix below) — final head 0f1039b44, 3
commits, 7 files, +188/−5. Interlock verified: zero
upstream PRs for this branch (GitHub-queried). Base exact (merge-base 50bc05e84). The
producer's disclosed debt — sandbox snapshot-wipes (5× in Phase 0, ~12× in Phase 1+2, restore
interval 1–2 min) killed every fresh build, so the built-tree battery was owed — closed
entirely by this seat on two fresh builds (libc++ 11m19s; gcc leg per the cr3 flags).

## THE FIVE AC CHECKS, ALL INDEPENDENTLY REPRODUCED (not read from the hand-back)

1. AC1 argv-token warns: gate arm (a) on the LANE binary → PASS "emits exactly one warning
   line" + PASS "secret never appears in stderr/stdout". DISCRIMINATION MEASURED: same gate
   against the fresh-built BASE binary → "expected exactly 1 warning line, got 0" FAIL. The
   arm cannot be greened without the implementation. Warning line = the pinned 145-byte
   sentence; matches WARN_RE; emitRaw literal form; secret NEVER in any stream.
2. AC2 env silent + auth works: arm (b) PASS no-warning + PASS 200 with Bearer on the env
   channel. Control green on BOTH binaries (auth path untouched).
3. AC3 auth unchanged: arm (c) PASS 401 missing + PASS 401 wrong, green on both binaries.
   Independent curl probes confirm.
4. AC4 docs (sharpened two-assertion form): arm (d) both PASS on the lane tree AFTER the docs
   regen; FAIL on base ("docs do not state the process-list exposure") — discriminating.
5. AC5 gate registered: absorb loop at head = 762 (761 base + mcptokencheck at the verified
   slot after mcpstrictschemacheck / before mcptoolprunecheck); manifestcheck ALL PASS;
   gatecount --check green (8 sites → snapshot 753; live loop names 762; drift 9 ≤ 10);
   gendocsmergecheck ALL PASS.

## VALIDATOR-FOUND DEFECT 12, FIXED AS DISCLOSED VALIDATOR COMMIT 0f1039b44 (93aae229 precedent)

The Phase-2 help rewrite dropped the period after "gets a 401" (base had it), so the docs
regen rendered "a missing/wrong token gets a 401 Required for a non-loopback bind" — the
boundary-splice class the rewrite itself was fixing ("are one sentence again" claims the
changelog). One byte (cli.h:2909) restores the boundary; docs/COMMANDS.md regenerated from
the fixed binary. helpbudgetcheck arm (I) CANNOT catch this class (row-final "401" is a
digit, not dangling punctuation). All post-fix gates re-run green (gate, helpbudget,
docscommands; docs_commands --check; COMMANDS.md join verified: "…gets a 401. Required for a
non-loopback bind. Prefer RIPWIRE_MCP_TOKEN: …"). The fix commit d8cd267a1 was AMENDED once
pre-push (dropped an advisory trailer per the #484 clean-history rule) and landed as
0f1039b44; pushed 7bd29ea4a..0f1039b44 — fork head confirmed live
(refs/heads/lane/mcp-token-hygiene = 0f1039b4429026f9e78e054a9a78e7a29a3afd4f, ls-remote).

## PRODUCER CLAIMS VERIFIED TRUE (measure-for-measure)

- All four Phase-0 corrections folded: (1) bash-3.2 guard applied at start_server line 69
  with an explanatory comment — verified inert on bash 5 by the producer, safe on 3.2 by this
  seat; (2) placement comment says warning prints BEFORE the banner — live-verified by this
  seat: stderr line 1 = warning, line 2 = "[token required]" banner; (3) 145-byte sentence
  shipped VERBATIM (byte-compared against the pinned line); (4) registration folded into the
  skeleton commit (9e29ae35 carries gate + regression.sh together) — previously
  registry-RED branch now green from commit one.
- The "776 gates" in the hand-back is NOT the loop: the loop at head is 762 (correct);
  776 = script_gates_registered (the tool's registered-suite accounting, binary-pinned in
  COMMANDS.md — 761 loop + 15 by-name suite members at base). The tier-1 "79 vs 82 chars"
  claim verified byte-for-byte (111 vs 114 with newline).
- emitRaw over emitTo RULIED CORRECT (an improvement): the warning is a literal-no-args
  string; emitRaw is the primitive the existing banners use (mcpserver.h:474); emitTo's
  "{}"-parsing is surplus for a fixed line.
- Changelog fragment: Security section (legal), body names the splice fix, formatter-clean,
  changelog_assemble check PASS (54 fragments), changelogfragcheck gate ALL PASS.

## OWED BATTERY — ALL GREEN (fresh libc++ build of 7bd29ea4; post-fix incremental rebuild; gcc leg)

- mcptokencheck ALL PASS ×2 runs (deterministic pass-set) on the lane libc++ binary;
  discrimination red on base.
- manifestcheck ALL PASS · gatecount/limits/gendocsmerge checks green (753-snapshot basis)
- mcpremotecheck ALL PASS (its argv-token servers tolerate the warning — banner-class, as predicted)
- mcpcontractcheck ALL PASS (stdio≡HTTP byte-identity holds with the warning in the merged
  stream — failure-path-only reads confirmed)
- mcpframehonestycheck ALL PASS (K2, 2m39s)
- helpbudgetcheck ALL PASS (tier 1 ~5357/7000 tokens, 182 rows; tier 2 complete)
- docscommandscheck ALL PASS (post-regen, mutation control green)
- showcasecapturecheck + mcpattrparitycheck ALL PASS; compactlegendcheck ALL PASS (clean
  9m10s re-run; first shared-CPU run was alarm-killed inconclusive, re-run clean)
- argvdiffcheck / flagsurfacecheck / emptyvaluerefusecheck ALL PASS (the --mcp-token SKIP family)
- changelogfragcheck ALL PASS
- Live ordering probe: warning line 1, banner line 2 (warning-before-banner pinned)
- gcc leg (g++-14 -B/usr/bin, the proven cr3 flags): BUILD-CLEAN 36m56s — the build included
  the period fix (applied to the tree before the gcc binary linked). Same gate set ALL PASS on
  build-gcc/ripwire: mcptokencheck ALL PASS; mcpremotecheck + helpbudgetcheck + docscommandscheck
  ALL PASS (36s sweep); mcpcontractcheck + mcpframehonestycheck ALL PASS (2m39s). The gcc leg
  completed at validation time — no findings appended (none arose).

## OPERATIONAL FINDING (recorded for the operator)

The Hoplite producer sandbox's snapshot-restore interval has degraded to 1–2 minutes
(5 wipes in Phase 0, ~12 in Phase 1+2). It can no longer complete an 11-minute build. Both
validation sessions' entire built-tree debt has been carried by the PM seat. The producer
remains able to: edit + commit + push (all its commits are correct), run syntax-level
checks, and run the bash-level gate suite. It cannot: build, regenerate binary-pinned docs,
or run the runtime battery. RECOMMENDATION: treat the producer sandbox as an EDIT seat;
route built-tree verification through the PM seat (this pattern, twice-proven) or restore a
stable sandbox before dispatching any build-dependent spec (remaining Tier-B specs
markitdown-bridge-hardening and parsepool-gate-guard are both build-dependent).
