# Validator Verdict — mcp-token-hygiene

## Header

spec_id: mcp-token-hygiene
validator: WorkBuddy AI / GLM-5.3 (PM seat, acting as validator-of-record under VALIDATION_PROTOCOL step 2 / Q10 option (a))
producer: Deepseek-V4.1-Flash `-1017` (Hoplite cloud session; manifest `execution.producer`, operator-assigned)
lane: `lane/mcp-token-hygiene`, worktrees `/Users/rna/ripwire-scratch/mth-lane-r1` (validation) + `mth-base-r1` (base discrimination), base `50bc05e84` (fork main = upstream main)
validated: 2026-11-04, 15:05–18:05 UTC
verdict: **PASS — approved; one validator-found defect (#12, one byte) fixed as a disclosed
validator commit `0f1039b44` (d8cd267a1 amended pre-push per the #484 clean-history rule;
93aae229 precedent)**

Everything below was **re-run or re-measured by this seat**, not read from the producer's
hand-back. Logs under `/Users/rna/ripwire-scratch/logs/` (mth-* prefix); the evidence companion
is `completion-verification.md` in this directory.

---

## 1. What this seat independently reproduced

The producer's disclosed debt — its Hoplite sandbox snapshot-wiped ~12× this round (restore
interval 1–2 min), killing every fresh build — was closed entirely by this seat on two fresh
builds of the lane tree: libc++ 11m19s (+ the post-fix incremental rebuild 9m46s) and the gcc
leg (g++-14 `-B/usr/bin`, the proven cr3 flags, BUILD-CLEAN 36m56s, the build including the
validator fix). The base half of every discrimination probe is the Phase-0 fresh build
(`mth-base-r1`, 11m06s).

| # | claim (producer hand-back) | validator reproduction | result |
|---|---|---|---|
| 1 | Branch integrity: base exact, interlock held | merge-base = 50bc05e84 exact; 2 commits (9e29ae359 skeleton WITH registration, 7bd29ea4a implementation), 6 files +186/−3 at hand-back; pt-act authorship; zero upstream PRs for the branch (GitHub-queried — fork branch only, not upstream-visible) | **CONFIRMED** |
| 2 | AC1: argv-token warns (exactly one line, secret never in any stream) | Gate arm (a) on the fresh LANE libc++ binary: PASS both sub-arms. Same gate against the fresh BASE binary: "expected exactly 1 warning line, got 0" — **red at base**. The warning line is the pinned 145-byte sentence (byte-compared), matches WARN_RE, `emitRaw` literal form | **CONFIRMED, discriminated** |
| 3 | AC2/AC3: env-channel silent + auth unchanged | Arm (b) no-warning + 200-with-Bearer PASS on BOTH binaries; arm (c) 401-missing + 401-wrong PASS on both; independent curl probes agree | **CONFIRMED, controls green on both sides of the change** |
| 4 | AC4: docs updated (the sharpened two-assertion form) | Arm (d) both assertions PASS on the lane tree after docs regen; at base the exposure assertion FAILs ("docs do not state the process-list exposure") — the Phase-0 fold's discriminating pair verified again post-implementation | **CONFIRMED, discriminated** |
| 5 | AC5: "manifestcheck PASS, 776 gates" | The 776 is **script_gates_registered** (COMMANDS.md:1244, binary-pinned — 761 loop + 15 by-name suite members at base), NOT the loop. The live absorb loop at head = **762** (761 + mcptokencheck at the verified slot after mcpstrictschemacheck, before mcptoolprunecheck) — exactly right. manifestcheck ALL PASS; gatecount --check green; gendocsmergecheck ALL PASS (snapshot 753, drift 9 ≤ MAX_DRIFT 10) | **CONFIRMED, with the 776→loop explanation recorded (§3)** |
| 6 | The four Phase-0 corrections folded | (i) bash-3.2 guard `env ${envs[@]+"${envs[@]}"}` at start_server with comment — safe on 3.2 (this seat, both binding-set runs), inert on bash 5 (producer-verified); (ii) placement comment: warning BEFORE the banner — live probe: stderr line 1 warning, line 2 `[token required]`; (iii) the 145-byte sentence shipped verbatim; (iv) registration in the skeleton commit — branch registry-green from commit one | **CONFIRMED** |
| 7 | tier-1 row 3 chars shorter; mcpserver.h posture comment; changelog fragment | tier-1 111 vs 114 bytes verified byte-for-byte; posture comment present (2 lines); fragment in the Security section, body names the splice fix, formatter-clean, changelog_assemble check PASS (54 fragments) | **CONFIRMED** |
| 8 | emitRaw over emitTo for the warning line | `emitRaw` is the primitive the existing banners use (mcpserver.h:474); a literal no-args line needs no `{}`-parsing — ruled an improvement, not a deviation (the spec's `emitTo` wording dates from the 2026-09-14 draft) | **RULED CORRECT** |

## 2. Verdict on the five ACs

| AC | pinned contract | validator verdict |
|---|---|---|
| AC1 | argv token warns: one pinned line, secret never echoed | **MET** — red-at-base/green-at-lane on the fresh binary pair |
| AC2 | env token silent, auth works | **MET** — 200-with-Bearer, green on both binaries |
| AC3 | auth unchanged (401s both channels) | **MET** — controls green on both binaries |
| AC4 | docs recommend env-first AND state the process-list exposure | **MET** — the sharpened two-assertion arm, discriminating at base, green post-regen (post period-fix join verified: "…gets a 401. Required for a non-loopback bind. Prefer RIPWIRE_MCP_TOKEN: …") |
| AC5 | gate registered; manifestcheck passes | **MET** — 762-loop registration at the verified slot; manifestcheck + the drift family ALL PASS under GEN-DOCS-MERGE (zero count-site edits, correct) |

## 3. The 776-vs-762 explanation (ruling on the hand-back's one confusing claim)

The producer's "776 gates" is the tool's **registered-suite accounting** (`script_gates_registered`,
binary-pinned in COMMANDS.md: 761 loop members + 15 by-name suite members at base), not the
absorb loop. The lane's live loop at head is **762** (761 + mcptokencheck) — exactly what the
GEN-DOCS-MERGE mechanics require (a feature PR adds gate file + loop line + changelog fragment;
never count-site or snapshot edits; drift 9 ≤ 10 green). Not a defect; recorded here because a
future reader diffing "776" against the loop would otherwise suspect a registration error.

## 4. Validator-found defect 12, fixed as disclosed validator commit `0f1039b44`

**The Phase-2 help rewrite dropped the period after "gets a 401" (base had one), so the regen'd
COMMANDS.md rendered the boundary-splice class the rewrite itself was fixing:** "a
missing/wrong token gets a 401 Required for a non-loopback bind" — two sentences fused,
"Required" uncapitalized at the seam. `helpbudgetcheck` arm (I) cannot catch this class (a
row-final "401" is a digit, not dangling punctuation). One byte (cli.h:2909) restores the
boundary; docs/COMMANDS.md regenerated from the fixed binary (the same two lines the regen
always moves).

Fixed as the disclosed validator commit **d8cd267a1 → amended to `0f1039b44`** pre-push (dropped
an advisory trailer per the #484 clean-history rule; 93aae229 precedent — asking the producer
to burn a Hoplite session on one byte is operationally silly, and the producer's sandbox cannot
regen binary-pinned docs anyway). Commit message discloses the finder, the probes (the regen'd
docs entry vs the binary's tier-2 seed + the arm-(I) blind-spot note), and the fix. Re-verified
green on both legs post-fix (gate, helpbudget, docscommands, docs_commands --check); pushed
`7bd29ea4a..0f1039b44`; fork head confirmed live by ls-remote
(`0f1039b4429026f9e78e054a9a78e7a29a3afd4f`).

**Final lane state: 3 commits (2 producer + 1 validator doc-fix), 7 files, +188/−5 against
base 50bc05e84.**

## 5. Anomalies, recorded as notes not defects

1. **compactlegendcheck first run inconclusive** — shared CPU with the post-fix incremental
   rebuild inside a 300 s alarm; killed mid-run. Clean no-load re-run (background, 9m10s, rc=0):
   ALL PASS. Disclosed; not a finding.
2. **gcc link "looked stalled" ~15 min at 98%** — the LTO link recompiles + relinks silently; live
   check confirmed `cmake --build` alive and `main.cpp.o` mtime advancing. Let it finish:
   BUILD-CLEAN 36m56s.
3. **The producer sandbox operational fact (the load-bearing note for the operator):** the
   Hoplite session's snapshot-restore interval has degraded to 1–2 minutes (5 wipes in Phase 0,
   ~12 in Phase 1+2). It cannot complete an 11-minute build. Both validation sessions' entire
   built-tree debt was carried by the PM seat — twice-proven pattern. The producer remains
   fully able to edit + commit + push (all its commits are correct) and run syntax/bash-level
   checks. RECOMMENDATION: treat the producer sandbox as an EDIT seat; route built-tree
   verification through the PM seat, or restore a stable sandbox before dispatching any
   build-dependent spec — **the remaining Tier-B pair (markitdown-bridge-hardening,
   parsepool-gate-guard) are both build-dependent.**

## 6. Resolution action list (executed in this act)

- [x] `verdict-validator.md` (this file) + `completion-verification.md` (evidence) filed
- [x] Validator defect #12 fixed as disclosed validator commit `0f1039b44`; pushed; fork head verified
- [x] Full owed battery green on both toolchains (libc++ fresh + incremental; gcc leg) — table in
      `completion-verification.md`
- [x] Status flip `in_progress → approved` performed by the validator-of-record (the producer never
      flips statuses; Q10 (a)); spec.md Status line flipped in the same act
- [x] Manifest: `spec_approved` history event (2026-11-04T18:05:00Z) + `execution.validator`
      recorded; selfcheck **ALL MACHINE-RUN CHECKS PASS** post-flip

## 7. Hand to the operator (the merge round — gated)

The lane is **merge-ready**: `0f1039b44` on `origin/lane/mcp-token-hygiene` (fork pt-act/ripwire),
3 commits, +188/−5 across 7 files. The upstream PR (against redhat-et/ripwire) is the PM seat's
act per the #397/#469/#484 pattern — **gated on PR #484 concluding (merged or explicitly
declined) per the one-lane-in-review interlock**. When the gate clears: open the PR, carry the
review round, absorb the merge via `scripts/merge_main.sh --regen-after-build` (the GEN-DOCS-MERGE
mechanics — NOT the retired hand recipe). No five-file absorb is owed at open time (upstream
drift-check at validation time: the lane's files are untouched by the current drift).
