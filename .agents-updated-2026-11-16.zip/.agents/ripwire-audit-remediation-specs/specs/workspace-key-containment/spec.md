# workspace-key-containment — per-member containment for `paths[]` workspace keys on every tier

## Header

```yaml
id: workspace-key-containment
type: unit
version: 0.1.0
manifest: ../../manifest.yml
```

## Objective

Close **SBE-F1** (filed by the SBE producer at Phase 0, PM-reproduced live with identical verdicts on
base and lane binaries — `../stdio-bare-edit-escape/findings/SBE-F1-paths-key-containment.md`):

a multi-root `paths[]` request replaces `path` with a **synthetic workspace key**
(`mcpWorkspaceKey`, `src/mcpindex.h:947` — the members' real paths joined by `\x1f`, in label
byte-order at `src/workspace.h:165`, each with a trailing separator: `"root1\x1froot2\x1f"`). That key
is not a filesystem path, but every containment gate judges it with `mcpPathInsideRoot`
(`src/mcp.h:678`) — a **component prefix test on the string** — so admission is decided by whichever
member sorts first, and one member decides for all of them:

- **first sorted member inside the root** → the whole key passes → the request is ADMITTED, no matter
  that a later member is entirely outside (the escape);
- **first sorted member outside** → the whole key fails → a mixed workspace refused by an accident of
  alphabetical order (the reason-fix direction: the same verdict post-fix, for a reason that survives
  the order moving).

Tier split, grounded at the mechanism (the finding's own bullet conflated the two): on the **stdio**
pinned tier an all-inside workspace is always admitted at base (the first-sorted member is inside, so
the prefix passes — PM probe P4), while on the **HTTP** arm `mcpCanonRoot( key )` never canonicalizes
(a `\x1f`-joined string is not a path; realpath fails and the input returns unchanged), so
`!= policy.pinnedRoot` holds for EVERY key — HTTP blanket-refuses `paths[]`, all-inside included.

Measured on the pinned tier (`paths pmv-sbef1-probe.sh`): `[R/a, RR/z]` (a sorts first, inside) serves
with the **outside file silently rewritten** — no refusal, no disclosure — while `[R/a, T/O1]` (O1
sorts first, outside) is refused. Identical verdicts on the base and SBE-fixed binaries: pre-existing,
not SBE's doing, not closed by SBE (SBE's disclosure covers the bare tier only). This is the same
silence class as SRI-F1, surviving on the tier an operator chooses **because** it pins — the more
serious placement of the two.

## Scope

**In scope:**
- The two key-blind containment gates — **at base `fc0e35967` numbering** (corrected at dispatch
  2026-11-08; earlier records cite `:2030`/`:1991`, which are SBE-LANE numbers, shifted +81 by the
  mechanism this lane now sits beside): the stdio startup-root pin (`src/mcp.h:1950`,
  `isMcpEditVerb && !mcpPathInsideRoot( policy.defaultRoot, path )`) and the HTTP pinned-workspace
  arm (`src/mcp.h:1919`, `mcpCanonRoot( path ) != policy.pinnedRoot`).
- Per-member containment: for a registry key, EVERY member root must be inside the pinned/assumed
  root; a violation refuses **naming the offending member**.
- The per-member disclosure arm on the bare tier (mirroring SBE's `_out_of_workspace`, extended to
  name the offending member when a mixed workspace is admitted where admission is intended).
- A gate owning the behavior with the SBE-F1 escape row as its red baseline (live at the dispatch
  base; the release-fold anchor diff at 2026-11-08 is EMPTY, so the red baseline survives the current
  upstream head without rebase).

**Out of scope:**
- The multi-root capability itself (A11, `multirootcheck.sh:446–462`) — per-member containment
  keeps it: an all-inside workspace stays admitted on every tier — post-fix, on HTTP too (at base
  the HTTP arm blanket-refuses every key; AC-2 repairs precisely that, and the stdio all-inside
  case already passes at base, probe P4).
- The bare tier's permissive contract (SBE's lane owns its disclosure shape; this lane extends it,
  does not re-litigate it).
- Read verbs' path freedom (unchanged, documented, contract-protected on every tier).

## Interfaces

### Produces

- **workspaceKeyAdmission** *(DRAFT v0.1.0 — pinned at the planning cycle at dispatch)*: the
  per-member containment contract at both key-blind gates; under the pre-pinned shape, a `paths[]`
  request is admitted iff every member root is inside the tier's root, refusals name the offending
  member, and the `-32602` wording family is reused.

### Consumes

- *(none — provenance is SBE-F1's finding file within `../stdio-bare-edit-escape/findings/`, not a
  spec dependency.)*

## Acceptance Criteria

*(DRAFT v0.1.0 — the planning cycle at dispatch pins the final set. The measured facts below are the
starting shape.)*

1. **DRAFT — the escape is closed on the pinned tier.** `ripwire <R> --mcp` with `paths:[R/a, RR/z]`
   (in-root member sorts first): the outside file is NOT rewritten; the request is refused `-32602`
   **naming the offending member**; the victim's bytes unchanged. **Red at base today** (the SBE-F1
   probe is the red baseline — served silently at base).
2. **DRAFT — the HTTP tier's blanket key-refusal is repaired with it.** At base, the HTTP pinned
   arm (base numbering `mcp.h:1919`; lane-era records say `:1991`) compares `mcpCanonRoot( key )` to `pinnedRoot` — and a key never canonicalizes
   (realpath of a `\x1f`-joined string fails, the input returns unchanged), so **every** `paths[]`
   request is refused on HTTP, **even when every member is inside the pinned workspace**. Post-fix, an
   all-inside workspace (two subdirs of the pinned root) is ADMITTED — A11 genuinely restored on the
   tier where the blanket refusal lives (the fixture runs with `--allow-remote-edits`, the orthogonal
   opt-in, unchanged). NOTE the tier split, grounded at the mechanism: on the STDIO pinned tier an
   all-inside workspace is already served at base (the label-first member, being inside, satisfies the
   string prefix — PM probe P4) — the stdio accident admits escapes and refuses mixed workspaces for
   the wrong reason, but never falsely refuses an all-inside pair. The finding's "refused even if
   every member is inside" bullet is TRUE of the HTTP arm, not the stdio arm.
3. **DRAFT — argv-swap invariance.** `[RR/z, R/a]` and `[R/a, RR/z]` produce the SAME verdict on
   every tier (the label sort, not argv order, decides — and now it cannot decide admission).
4. **DRAFT — the in-tree precedent regression.** `hardenRequestRoot` (`src/mcpindex.h:962–978`)
   already iterates member roots for the git-trust boundary; the fix adopts the same lookup-
   then-iterate shape rather than inventing a third shape, and the gate asserts its tier-split
   comment stays coupled to the mechanism (the SRI-F1 origin class, closed at source).
5. **DRAFT — the bare tier's disclosure extends to mixed workspaces.** Where admission is intended
   (bare tier, outside member present), the `_out_of_workspace` note names the offending member —
   SBE's A4 arm generalizes from both-outside to any-outside.
6. **Registration + docs per house mechanics**: gate + loop line + changelog fragment, one commit;
   count sites untouched (GEN-DOCS-MERGE).
7. **The battery green on the fixed tree** — both toolchains + ASan per the SBE precedent (a `src/`
   change rides the sanitizer requirement).

## Implementation Notes

- The fix reuses `hardenRequestRoot`'s lookup-then-iterate: `mcpWorkspaceRegistry().find( key )`,
  then `for( const WorkspaceRoot& root : wsIt->second ) mcpPathInsideRoot( tierRoot, root.real )`.
  The in-tree comment already states the rule ("a registered multi-root workspace KEY is not a
  directory, so each of its member roots is probed instead").
- The two gate sites (base numbering): stdio pin `mcp.h:1950` (edit-verb containment) and HTTP pin `mcp.h:1919`
  (the pinned-workspace comparison). Judging the key as a path at either site is the defect.
- The `mcpWorkspaceKey` dedupe-collapses-to-one case (`ws.size() == 1` returns the plain path,
  `mcpindex.h:952–955`) needs no per-member loop — single-path behavior is unchanged (back-compat).
- Upstream sensitivity: A11 is a documented decision (`multirootcheck.sh:446–462`); the PR story
  leads with the measured escape and the false-refusal twins (both fixed by one shape), not with
  capability changes.

## Failure Modes

### The fix over-blocks legitimate multi-root workspaces

- **Trigger:** a workspace whose every member is inside the tier's root.
- **Expected handling:** admitted (AC-2) — the fix's whole point is that the label sort stops
  deciding; the gate must assert this direction explicitly or it has only moved the accident.

### The membership registry and the key drift apart

- **Trigger:** a refactor changes the key format or the registry's lifecycle.
- **Expected handling:** the lookup-then-iterate fails CLOSED (key not found → refuse with the
  shipped wording), never falls back to judging the key as a path.

### The comment drifts from the mechanism again

- **Trigger:** the SRI-F1 origin class.
- **Expected handling:** the gate pins behavior, not comments; the tier-split comment travels in the
  same commit by review convention.

## Dependencies

- *(none — independent. Provenance is SBE-F1's finding file, not a spec dependency.)*

## Consumers

- *(none declared — audit-validation-standalone may consume the closure the way it consumes the
  security fixes; settled when this spec's planning cycle runs.)*

## Status

**Status:** approved  # TERMINALLY VALIDATED & APPROVED 2026-11-10T19:35:00Z by the validator-of-record (PM seat; VALIDATION_PROTOCOL step 2 / Q10 (a)); manifest event #55 the custody record; verdict-phase3.md + Addenda 1–2 the chain. Flip executed on the pinned timing (fixup landing + PM delta re-verify): all THREE required prose fixes verified landed — d883c4f8d (gate header + hand-back §3) and b995315d0 (the W2 failure string, message-only, the one-line diff exactly the string); PM discrimination at the final head, zero compilation: banked base rc=1 6 FAIL (W1×2/W2×2/W3×1/W7×1) / 8 PASS with the W2 message now printing "must give the SAME REFUSED verdict" over both-served evidence (true in both print modes); asan rc=0 14/14; gateexitcheck rc=0; selfcheck green. Phase-0 rulings stand accepted (AC-2 rejected → AC-2′; AC-1b added; AC-5 dropped). Lane head `b995315d0`, clean, 6 commits, UNPUSHED; remote lane branch still at the dispatch base (ship keys unexercised); #484 interlock holds. Upstream at approval `b8032471f` — containment anchors byte-identical except workspace.h cloneKeys; cli.h drift is help text, the one-listener sentence intact; re-pin at PR time. Next: rank-1 = audit-validation-standalone (Phase 0 opens on the owed premise repair). Prior note (the dispatch, superseded): DISPATCHED 2026-11-08T11:35:00Z by the PM seat (dispatcher-of-record) on the rotation pre-declared at event #52 — rank-1, unblocked by the SBE fold (event #53, 11:33Z). Base `fc0e35967` pinned fresh at dispatch: fork main synced ff-verified, lane branch `lane/workspace-key-containment` pushed and remote-verified; drift 30 commits / 4 trains (#574 MERGED + #576/#578/#579); anchor diff EMPTY; gatecount at fresh base 776 marked = 776 loop (the release refresh equalized — this lane's own gate will read 777-vs-776, the by-design mid-lane state). Earlier-cited SBE-LANE line numbers corrected to base numbering this act (stdio `:1950`, HTTP `:1919`). First added 2026-11-08T10:30:00Z by the PM seat as an engineering decision under the standing directive (never route engineering menus to the operator).
**Last updated:** 2026-11-08T12:40:00Z
**Phase 0 fold (2026-11-08T12:40:00Z, producer).** All five anchors re-derived at `fc0e35967` by this seat's own probes; the dispatcher's renumbering (stdio `:1950`, HTTP `:1919`, predicate `:678`, key `mcpindex.h:947`, sort `workspace.h:164`) is CORRECT on every count, and erratum #3 is confirmed at source (`grep -c '_out_of_workspace' src/mcp.h` → **0**). Two corrections to the note: the sort key is the member's **label** (shortest unique whole-segment suffix of the real path), not its path; and the closest precedent is `mcpExplicitNoRootReason` (`mcp.h:614–642`), which already does lookup-then-iterate **in mcp.h**, not only `hardenRequestRoot`. **SBE-F1 reproduced on all four stdio rows** (escape + argv-swap SERVED *and* wrote the outside file; reason-fix refused; all-inside control served) and both HTTP rows (every key refused; dedupe-collapse served). **Two rulings, both against the pre-pinned ACs:** (1) **AC-2 REJECTED** — making an all-inside `paths[]` workspace ADMITTED over HTTP would break the documented "one listener = ONE workspace" contract (`mcp.h:513`), an unadvertised startup shape (`cli.h:5113`), A11's stdio-only reality (`multirootcheck.sh` has zero `--listen`), and — decisively — the catalog's honesty invariant, since `pinnedRootHasGit`/`pinnedRootIsGitDir` are resolved ONCE and "fixed for the listener's life" (`mcpserver.h:500–511`); replaced by **AC-2′**: keep the refusal, fix its misdirecting sentence when `path` is a key. (2) **AC-5 DROPPED** — it would write a second per-member disclosure loop for a mechanism SBE already shipped in the lane this one sits beside. (3) **AC-1b added** — on a multi-root stdio start `defaultRoot` **is itself the key** (`mcp.h:3047–3056`), so a naive member-vs-root containment fix would refuse everything and become an outage. Full evidence, the instrument facts (token-forced `--allow-remote-edits`, the required `Accept` header, disk budget) and two self-corrected probe errors are in `validation/phase0-handback.md`. No code written at this fold.
**Updated by:** WorkBuddy AI / GLM-5.3 (PM seat — the dispatch act: fork main synced to fc0e35967 (ff-verified), lane branch pushed, dispatch note written; manifest event #54 spec_started in the same round)

## Validation Strategy

Tier 2 — untrusted-agent-input surface with a `src/`-level admission change: **blocking gate**.
*(SUPERSEDED AT PHASE 0 — this section was the dispatcher's pre-pin, drafted from the finding's
proposal; the producer's Phase-0 fold ruled the HTTP verdict-flip row below invalid on documented
contract (mcp.h:513–514, cli.h:5113–5116, mcpserver.h:500–511) and replaced it with AC-2′ — see
`validation/phase0-handback.md` §3. The PM verified all three cites at source and ACCEPTED the
ruling at the Phase-3 fold. The section is retained, with the HTTP row corrected, so no reader
implements the rejected direction from here.)* Discrimination duty — the stdio verdict-flip row,
the reason-fix and control rows, the sorted-first variable moved BOTH ways, and argv-swap
invariance:
- **the ESCAPE row** (stdio pinned, `[R/a, RR/z]` — in-root member sorts first, one outside): served
  silently at base → REFUSED `-32602` naming the outside member, victim byte-identical post-fix;
- **the HTTP KEY-SENTENCE row** (AC-2′, replaces the drafted all-inside admission — the refusal
  STAYS; `--listen` is one workspace pinned at startup, and the catalog's root properties are
  resolved once for the listener's life): the key refusal's misleading "run a second server for
  the other tree" at base → the one-workspace condition stated when `path` is a key; the plain-path
  sentence byte-identical;
- **the reason-fix row** (stdio, `[R/a, T/O1]` — outside member sorts first): refused at base (by the
  label accident) and still refused post-fix (by per-member containment, naming `T/O1`) — same
  verdict, now for a reason that survives the variable moving;
- **the stdio all-inside control** (`[R/a, R/b]`): admitted on BOTH sides (the fix must not
  over-block; A11 preserved where it already worked);
- **argv-swap invariance** (both orders of the escape row): identical verdicts — the
  label sort may build the key, but it may no longer decide admission;
- **the multi-root-OUTAGE trap** (AC-1b, added at Phase 0): a server started on `[R/a, R/b]` must
  still serve its own workspace key — naive member-vs-key containment would turn a working start
  into an outage.
Both toolchains + ASan per the SBE precedent.

## Progress Tracking

- [x] Planning cycle (at dispatch): pin the literal set, the AC set, the PBT question — the
      measured facts in this draft are the starting shape — **done at Phase 0, and it changed two
      ACs**: AC-2 REJECTED → replaced by AC-2′ (the HTTP key-refusal is the documented contract,
      not a defect to flip), AC-5 DROPPED (it would duplicate SBE's per-member mechanism in a lane
      that sits beside SBE). AC-1b added (multi-root-started stdio must not become an outage).
      Evidence and full argument: `validation/phase0-handback.md` §3–§6.
- [x] Phase 1: implementation per the pinned shape — `7521a7a70`. Per-member containment at the
      stdio gate (containment decided BEFORE the prefix test); the HTTP sentence branched on key
      membership with the refusal kept (AC-2′). The helper reuses the lookup-then-iterate shape
      (AC-4) and carries the key-pinned branch that keeps AC-1b (a multi-root-started server still
      edits its own workspace).
- [x] Phase 2: gate + registration + changelog (one commit) — `workspacerootcheck.sh` in the same
      commit as the mechanism, loop `776 -> 777`, changelog entry present.
- [x] Phase 3: documents + battery + hand-back — `validation/phase3-handback.md`. Three self-fixes
      landed on the gate itself after the battery found them: a dead duplicate `ok()`/`no()` pair,
      `gateexitcheck` arm (B) rejecting the gate's terminal region, and a changelog row count that
      disagreed with the gate's own `EXPECTED_ROWS`. Battery: clang 21 / gcc 14 / ASan all 14/14;
      base `fc0e35967` 6 FAIL / 8 PASS.
- [x] PM review fixup 1 (`d883c4f8d`, prose): the gate header and the §3 row both misdescribed W2's
      base behaviour — "GREEN both sides" / "served one order, refused the other". At base BOTH
      orders serve the escape (argv-invariant; the label sort canonicalizes argv), so W2 is red ×2
      because the shared verdict IS the escape. Both corrected from the Phase-0 probe canon.
- [x] PM review fixup 2 (`b995315d0`, one line): W2's failure message asserted "argv-swap changed the
      verdict" while printing `→ served … → served` — the §11 class a third time, in the string a
      red run prints. Now states the requirement ("must give the SAME REFUSED verdict"), true in
      both print modes. Message-only; delta re-verify at `logs/wkc-fixup3-delta-reverify.md`
      (8/8 contract items, base profile unchanged, no rebuild owed, all seven meta-gates rc=0).

