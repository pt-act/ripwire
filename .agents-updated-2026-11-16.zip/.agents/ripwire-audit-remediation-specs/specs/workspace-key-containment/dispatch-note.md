# Dispatch Note — workspace-key-containment (attachment 1 of 2)

**Dispatched:** 2026-11-08T11:35:00Z, by the PM seat (dispatcher-of-record, WorkBuddy AI /
GLM-5.3) on the rotation pre-declared at manifest event #52 — rank-1 of the next dispatch
rotation, unblocked by the SBE fold (event #53, 11:33Z). No new operator round-trip: the
rotation was bought with the node decision itself (event #52, the standing-directive
correction round).
**Producer:** the LOCAL seat (Deepseek-V4.1-Flash "-1017", WorkBuddy AI on this Mac — the
rotation's standing producer; the SBE round was terminally validated 2026-11-08,
`../stdio-bare-edit-escape/validation/verdict-phase3.md` + Addendum 2). **Ship keys stay
with the PM seat (§03.7): the upstream PR is NEVER yours; nothing upstream-visible until
#484 concludes.**
**Base commit:** `fc0e35967` — fork `pt-act/ripwire` main = upstream `redhat-et/ripwire`
main (synced by the dispatcher this act, ff-verified: origin 0-ahead of upstream; the drift
`e4432b48a..fc0e35967` = 30 commits / 4 trains: #574 (release: 0.6.10 prep) MERGED
`ac869640e`, #576 hoist-batch-1, #578 js-capture-cold, #579 exemplar-e3a). Branch
**`lane/workspace-key-containment`** at `fc0e35967`, pushed by the dispatcher and
remote-verified — attach your worktree there (suggest `wkc-r1`).
**Attachment 2 of 2 is your spec** (draft v0.1.0 — its Progress list opens with the
planning cycle at Phase 0; the draft's ACs are the starting shape, not the contract).

**Manifest bookkeeping for THIS dispatch** (status planned → in_progress,
`execution.producer` + `base_commit`, history event #54, the spec Status line) was executed
by the dispatcher in the same round — you do NOT touch the manifest. Any LATER manifest
mutation you need is drafted in your hand-back and **applied through the PM seat** — the
producer never flips statuses (Q10 ruling 2026-10-29).

## The lane, in one line

Close **SBE-F1**: a `paths[]` workspace key is `root1\x1froot2\x1f` (`mcpWorkspaceKey`,
`mcpindex.h:947`) — a STRING, not a path — and both containment gates test that string with
path-shaped predicates, so a mixed workspace `[R/a, RR/z]` is admitted or refused by
whichever member sorts first (`workspace.h:163–165`, byte-order; argv cannot change it).
On the **pinned stdio tier** the label-first member being in-root lets the edit silently
rewrite the out-of-root member's file — no refusal, no disclosure. **Your touch set is
`src/mcp.h` (+ `src/mcpedit.h` wording only if a refusal sentence changes) + a gate +
registration + changelog: a `src/`-bearing Tier-2 lane.**

## Enumerated instrument errata (read first — your Phase 0 greps depend on them)

1. **LINE NUMBERING.** Every gate cite in this note and the spec is **base `fc0e35967`
   numbering**. The SBE-era records cite `mcp.h:2030`/`:1991` — those are **SBE-LANE**
   numbers (SBE's mechanism adds +81 lines to mcp.h ABOVE the gates; at base WITHOUT SBE
   the gates sit 81 lines lower). Corrected at dispatch in the node block and the spec.
2. **PR #574 IS MERGED** (`ac869640e`, 02:50:34Z — the release-prep train). An earlier PM
   note said "closed unmerged" — a state-vs-mergedAt mis-read, corrected. Irrelevant to
   your lane (the anchor diff is empty), but do not re-import the stale claim.
3. **This lane sits BESIDE SBE, not on it.** The upstream base does NOT contain SBE's
   mechanism. If your mental model has `_out_of_workspace` in the pin gates — it is not
   there. SBE is a local approved lane behind the #484 interlock; nothing in your tree
   knows about it. (The WKC fix must therefore not depend on SBE landing first; where the
   finding's text references the bare-tier disclosure, that arm is **scaffolding for the
   PR story**, conditioned on both lanes landing.)

## The anchors, live-verified by the dispatcher at `fc0e35967` (11:34Z)

- **The stdio gate:** `src/mcp.h:1950` —
  `else if( isMcpEditVerb( name ) && !mcpPathInsideRoot( policy.defaultRoot, path ) )`
  → `-32602 "path outside workspace; start the server on that root or pass an absolute
  in-root path"`. The pin block it lives in (`:1944` `if( !pathsUsageError &&
  policy.pinnedRoot.empty() && !policy.defaultRoot.empty() )`) fires on the STARTUP-ROOT
  tier; `path` at that point is the RAW request `path` string — for a `paths[]` request it
  is the workspace KEY, which is why the prefix test `mcpPathInsideRoot` decides admission
  on the key's first bytes (= the first-sorted member's path).
- **The HTTP gate:** `src/mcp.h:1919` —
  `else if( mcpCanonRoot( path ) != policy.pinnedRoot )` → -32602 "path is outside this
  server's workspace (this listener serves one fixed workspace, pinned at startup) — omit
  `path` …". Same key-blindness: `mcpCanonRoot` (`src/mcp.h:573`) is `os::realpath` with
  fallback-to-input — a `\x1f` key never resolves, never equals `pinnedRoot`, so EVERY
  workspace request over HTTP is blanket-refused at base, including all-inside ones.
- **The predicate:** `src/mcp.h:678` `mcpPathInsideRoot( canonRoot, candidatePath )` —
  the working tree's own path-prefix test (canonicalizes the candidate at `:684`; do not
  fork a second predicate — reuse this one per member).
- **The key builder:** `src/mcpindex.h:947` `mcpWorkspaceKey` — sorted-label key; the
  lookup-then-iterate precedent you are told to reuse is **`hardenRequestRoot`
  (`src/mcpindex.h:966–978`, called at `:1213`)**: resolve the registry entry for the key,
  iterate its member roots, harden each. Your fix is that shape with containment instead
  of hardening.
- **The sort:** `src/workspace.h:163–165` — members sort by label byte-order BEFORE the
  key is built ("argv order can never leak into output, §2.1"). This is what makes
  "sorted-first decides" deterministic and gate-able.
- **Drift map on your surface (`e4432b48a..fc0e35967`):** the five anchor files
  (`mcp.h`, `mcpindex.h`, `workspace.h`, `mcpedit.h`, `mcpverbs.h`) have an EMPTY diff —
  zero re-pins needed; the registration loop moved 775 → 776 upstream (one gate added by
  the release; **gatecount at base says marked 776 == loop 776 — parity**; your own
  registration makes it 777-vs-776, the by-design mid-lane state manifestcheck reports
  as INFO).

## The fix shape, pre-pinned (the node block; your Phase 0 pins literals, not shape)

**Per-member containment at BOTH key-blind gates:**

- **stdio (`mcp.h:1950`):** for an edit verb whose `path` IS a registry key, resolve the
  workspace entry and require **EVERY member root** inside `policy.defaultRoot`; refuse
  `-32602` **naming the offending member**, reusing the shipped sentence family at the
  site. The single-root non-key path is untouched. Read verbs untouched (D4 half —
  "a request may name any path" is the read contract; "the incident was an edit verb").
- **HTTP (`mcp.h:1919`):** same per-member test against `policy.pinnedRoot`; an
  all-inside workspace becomes ADMITTED (the AC-2 verdict flip — at base it is
  blanket-refused, which is the finding's HTTP-side defect direction), a mixed one
  refused naming the offending member.

**The three verdict-flip rows your gate must own (red at base, green post-fix):**

1. stdio pinned tier, `[R/a, RR/z]` (label order puts R first): at base **silently
   applies** to RR/z's file (SBE-F1 repro — PM probe `pmv-sbef1-probe.sh` P1–P3) →
   post-fix **refused -32602 naming RR/z**, victim byte-identical.
2. HTTP pinned tier, all-inside `[R/a, R/b]`: at base **blanket-refused** (the key never
   canonicalizes) → post-fix **admitted** (A11 multi-root capability repaired on HTTP).
3. stdio, all-inside `[R/a, R/b]`: **admitted at base AND post-fix** (the control — this
   lane must not over-block what already works; PM probe P4 is the evidence it passes
   today).

Plus: **argv-swap invariance** (`[RR/z, R/a]` and `[R/a, RR/z]` — same verdict, same
named member), the **hardenRequestRoot-precedent regression** (the git-trust boundary's
own multi-root behaviour unchanged — `mcpindex.h:1213` call site's contract), and
**refusal-disclosure symmetry**: a refused edit never says "applied" (the SBE lesson,
`oc.ok`-gating — at base the HTTP refusal site already skips `try{}`, assert it stays
skip-flagged so no byte is written).

**Tier-split facts, PM-measured (verdict-phase3.md §10; do not re-derive, cite):** the
finding's "refused even when every member is inside" direction is **HTTP-only**; on stdio
an all-inside pair is always admitted at base. Your spec already carries this split —
Phase 0 pins the exact literals (refusal sentences per site, the member-naming phrasing)
by grepping the shipped wordings at both gate sites.

## Hard constraints (the SBE/SRI round's earned rules)

- **The anaconda-ld trap:** pin `PATH=/usr/bin:/bin:/usr/sbin:/sbin:/usr/local/bin` for
  EVERY cmake build/link on this host — `/opt/anaconda3/bin/ld` (ld64-530, 2022) dies
  `unsupported tapi` on warm relinks, mutation-independent.
- **Mutant/matrix discipline:** if you run mutants — the condition-not-the-binding rule
  (mutate an if-init's *condition*, keep the binding); `cmp` the mutated source against
  pristine before building (a drifted needle = a no-op mutant = a false control); after
  ANY restore, REBUILD and verify `--version`, or the gate silently measures the last
  mutant; `… | tail` steals `$?` — capture rc from the command, not the pipe.
- **Registration same-commit:** gate file + loop line + changelog fragment in ONE commit
  (GEN-DOCS-MERGE discipline; the absorb loop is file+python counted, never inline-regex).
- **ok() canonical from commit one** (the gateexitcheck G1 contract: record a failed
  PASS-line write into the accumulator, return 0 unconditionally); source
  `test/lib/clean-env.sh` if (and only if) your gate builds a git fixture; binary fixtures
  need a nulbytecheck allowlist row with reason.
- **Every gate row meaningful only as a pair where vacuity is possible** — the A4 lesson
  twice over: a "cannot emit" row is green at base only vacuously; if your gate has one,
  say so in its header and mark it readable-only-with-its-presence-row.
- **`--version` is the binary stamp instrument** (`built_from=` composes at runtime; a
  `strings` probe answers empty).
- **Sweep-audit BEFORE any push** (not needed until ship keys, but the habit is now
  standing): new files vs the FULL absorb list — nulbyte, gitenvhermetic, gateexit,
  bashsource all interrogate your files on first CI contact; the SBE/SRI lanes each paid
  one round to learn this.

## The battery (Tier-2 contract)

Both toolchains (clang 21 / gcc 14) + ASan per AGENTS.md — the `src/` change rides the
sanitizer requirement; the at-risk neighbours this round: `multirootcheck` (A11's owner —
your fix must keep its all-inside rows green), `mcpeditracecheck` (the served-predicate
counter — your HTTP all-inside admission ADDS a served path it has never seen over HTTP;
verify it does not misclassify), `hardenRequestRoot`'s dependent gates
(`gitframingcheck`'s multi-root fixtures), and the SRI lane's `auditregresscheck` A2 arms
(the pinned-tier refusal wordings you are extending per-member — they pin the EXACT
shipped sentences; if you must change wording at `:1919`, the SRI A2 rows are the
canon to keep green or consciously re-pin through the PM seat).

## Deliverables (the SBE cadence)

Phase 0: anchors re-verified (your own probes), literals pinned, ACs finalised →
hand-back. Phases 1–3: mechanism one-commit (gate+registration+changelog with it),
battery green both toolchains + ASan, meta-gates green, hand-back. Then the PM
verification round, then terminal validation on the §11-class discipline (every
measurement claim in your hand-back gets re-measured by this seat's instruments before any
verdict — including commit counts and PR states; the round you just closed taught that
lesson to BOTH seats). Ship keys with the PM seat; the #484 interlock holds until it
concludes.
