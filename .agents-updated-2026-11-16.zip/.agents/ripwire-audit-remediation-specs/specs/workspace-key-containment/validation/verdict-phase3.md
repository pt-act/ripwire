# Verdict — workspace-key-containment, Phase-3 hand-back validation

**Validator:** PM seat (GLM-5.3), validator-of-record. **Round:** 2026-11-09T05:45Z.
**Producer:** local seat (Deepseek-V4.1-Flash **-1017**). **Base:** `fc0e35967` (lane-pinned; upstream
has since drifted to `10705350b`, 43 commits — discriminator run this round,see §8). **Lane:**
`lane/workspace-key-containment` @ `b870c8918` (4 commits: `7521a7a70` mechanism, `a6b55575b` dead-pair
drop, `d95c5ecec` row-counter/gateexitcheck fix, `b870c8918` changelog count fix), tree clean, UNPUSHED —
remote lane branch verified at the dispatch base `fc0e35967`: ship keys unexercised. **Compiled
NOTHING on this host** (the operator reported the machine freezing under the producer's parallel clang
instances — see §9); every measurement below rides the producer's stamp-verified binaries and the
banked base binary, per the SBE phase-3 precedent.

---

## 1. Method

Per VALIDATION_PROTOCOL: every load-bearing claim in `validation/phase3-handback.md` reproduced with
PM-owned instruments before this verdict. Instruments: the banked base binary
(`logs/wkc-bin-BASE-fc0e35967`, `built_from=fc0e35967`), the producer's three fixed binaries (build21
`fc0e35967+dirty`, buildgcc `7521a7a70` GNU 14.2.0, asan `b870c8918`); the lane's gate at HEAD;
`--version` stamps on every binary before and after; the sentence probe (`grep` for the shipped and
new literals in the binaries themselves); the count tools; direct source reads at the cited lines
(`mcp.h:513`, `cli.h:5113`, `mcpserver.h:500–511`, `mcpserver.h:471–478`, `mcp.h:614–620`).

## 2. The Phase-0 rulings — ACCEPTED, and the dispatcher's pre-pin was the wrong one

The producer rejected the pre-pinned **AC-2** (all-inside `paths[]` ADMITTED over HTTP), replaced it
with **AC-2′** (refusal stays; the key refusal's sentence states the one-workspace condition), added
**AC-1b** (multi-root-started stdio must not become an outage), and dropped **AC-5** (would duplicate
SBE's per-member mechanism in the lane beside it). Verified at source by this seat: `mcp.h:513–514`
(the contract sentence names `paths` explicitly), `cli.h:5113` (`--listen serves ONE workspace`),
`mcpserver.h:500–511` (`pinnedRootHasGit`/`pinnedRootIsGitDir` resolved ONCE, "fixed for the listener's
life" — per-request admission would make the catalog's git-verb advertising stale against the tree
actually being served; a correctness break, not a preference), and `grep -c '_out_of_workspace'
src/mcp.h` → **0** (erratum #3 at source: this base has no SBE mechanism to extend — AC-5 was
impossible as drafted).

The ruling is better engineering than the dispatcher's pre-pin, argued on four independent grounds,
and the gate implements it exactly. The spec's Validation Strategy section (dispatcher-written) still
carried the rejected HTTP direction; **corrected by this seat this round**, superseded-notice kept
(§10). Credit where due: rejecting a pre-pinned shape at Phase 0, with the evidence trail, is the
process working.

## 3. Discrimination — REPRODUCED, all four binaries (PM runs)

| binary (PM-run, stamp verified) | gate verdict |
|---|---|
| base `fc0e35967` (banked) | **rc=1, 6 FAIL / 8 PASS — W1×2, W2×2, W3×1, W7×1** |
| build21 (`fc0e35967+dirty`, the mechanism) | **rc=0, 14/14 ALL PASS** |
| buildgcc (`7521a7a70`, GNU 14.2.0 — real gcc, §6) | **rc=0, 14/14 ALL PASS** |
| asan (`b870c8918`, 4 sanitizers) | **rc=0, 14/14 ALL PASS, 0 sanitizer reports** |

Sentence probe at the binaries: base carries the shipped sentence and NEITHER new literal; all three
fixed binaries carry the shipped sentence, the member-naming clause ("this `paths` request includes a
member outside it:") and the true HTTP condition ("a `paths` workspace is not that workspace") — the
red baseline is real, not a wording accident.

## 4. THE FINDING: the W2 base description is wrong in two prose spots — right arithmetic, wrong reason

The hand-back §3 table says W2's base behaviour is *"served one order, refused the other"*, and the
gate header says W2 is *"GREEN both sides by design"*. **Both are disproved by this seat's base run
AND by the producer's own phase-0 probe S2**: at base, `[R/a, RR/z]` → served and `[RR/z, R/a]` →
served — **the escape is argv-INVARIANT at base** (the label sort builds ONE key from either order;
that is the determinism rule making a security decision, which is the finding's own thesis). The W2
rows are therefore red at base ×2 because the *shared* verdict is the escape — which is exactly what
the rows exist to catch — not because the orders differ. Post-fix both orders refuse naming RR/z
(PM-verified on all three fixed binaries). The hand-back table and its own gate header also contradict
each other (the table lists W2×2 as base failures three lines Below the header's "green both sides").

Nothing downstream is corrupted: the failing-set composition (W1×2/W2×2/W3×1/W7×1) is exactly right
in both the hand-back and corrected changelog; the gate ARMS are correct (they assert same-verdict-
and-both-refused, fail honestly at base, and print both verdicts in the failure text); the changelog's
description is composition-only and accurate. This is the §11 class one more time — prose disagreeing
with the artefact's own measured log — and it was caught the same way: reading the row output against
the claim.

**Required pre-push fix 1 — gate header (`test/workspacerootcheck.sh`, the W2 line):** replace
"GREEN both sides by design" with the true base behaviour, e.g.: *"RED at base ×2 — both orders
SERVE the escape (the label sort canonicalizes argv; the shared verdict is the defect), refuse naming
the same member post-fix"*.

**Required pre-push fix 2 — hand-back §3, the W2 table row:** replace "served one order, refused the
other" with e.g. *"both orders SERVED the escape — argv-invariant at base (phase-0 probe S2); red ×2
because the shared verdict is the escape, not because the orders differ"*.

(The gate's W2 failure-text already prints both verdicts honestly — no code change needed or wanted.)
**NOT** required: the changelog (checked — accurate).

## 5. Genuinely new gate tech, verified from the consumer side

The declared-row guard (EXPECTED_ROWS=14, floor 12 on curl-less hosts) is the only one in the tree
(`grep -l EXPECTED_ROWS= test/*.sh` → one file). Two mechanics verified by this seat directly:
(a) **the `rows+=` string-append trap** — reproduced: untyped `x+=1; x+=2` → `012`; `declare -i` →
`3`. The `d95c5ecec` fix (`rows+=1` under `declare -i`, invisible to gateexitcheck's BUMP regex) is
load-bearing, not style. (b) **gateexitcheck arm (B) acceptance of the fixed terminal shape** — this
seat ran gateexitcheck at the lane head: **rc=0 ALL PASS**, and manifestcheck names the registration
exactly (791 = 777 + 14, loop names 777, snapshot 776 — the by-design mid-lane delta, INFO not FAIL).
The W3 self-caught self-comparison (`sha f` = `sha f`, unconditionally true) and its in-gate recorded
correction: read, confirmed, commended — an arm that cannot fail is worse than a missing one.

## 6. Toolchain forensics — every claim independently re-derived

- **`/usr/bin/g++` is Apple clang 16, not gcc**: verified (`--version` prints "Apple clang version
  16.0.0"; 77-link hardlink class). **`std::ranges::find_last_if`** verified absent under it
  (PM probe: `no member named 'find_last_if' in namespace 'std::ranges'` — rc=1) and present under
  `/usr/local/bin/g++-14` 14.2.0 (the facility itself: the name resolves in my probe; my probe's own
  rc under gcc-14 was a return-type misuse in MY five-line test, not the facility — the discriminator
  stands: clang-16 cannot name it, gcc-14 can). `src/forfilesyms.h:400` uses it; the lane's 4 commits
  touch it ZERO times (git log -- src/forfilesyms.h → empty). "1 error generated" is clang phrasing —
  confirmed by the probe's own wording.
- **The buildgcc stamp** `built_from=7521a7a70` (GNU 14.2.0): the gcc leg evidence-valid at mechanism
  content — the two later commits are test/changelog-only (`git diff 7521a7a70..HEAD -- src/` = 0
  lines).
- **The "wedged" misreads and the 702s-floor disclosure**: accepted as instrument errors, both
  corrected in `logs/wkc-gcc-toolchain-erratum.md`, both now banked as host rules (§9). The
  token-forcing cite verified at source (`mcpserver.h:471–478`).

## 7. Blast radius — verified on PM runs (ASan binary, 0 sanitizer reports)

`multirootcheck` ALL PASS (A11's owner — the all-inside capability intact), `mcprobustcheck` ALL PASS
(D-2's shipped stdio sentence byte-identical), `mcpeditracecheck` ALL PASS; plus the producer's
grep-found `paths[]` consumer set (depsprecisecheck, mcpcontractcheck, agentloopopencodecheck,
archhonestcheck, gitchildoptscheck, hopcontextcheck, mcpframehonestycheck, mcpw3fixcheck,
seedboundscheck, mcpremotecheck — all rc=0, logs on disk). The helper's single call site and the
read-verb freedom (D4) read at source. The dispatch note's `gitframingcheck` lead was false (git
pathspecs, not MCP paths) — recorded honestly by the producer; noted, not a defect.

## 8. Upstream drift since dispatch — measured, not blocking

Upstream moved `fc0e35967 → 10705350b` overnight (43 commits, trains through #589). The anchor-file
diff is **22 lines, entirely in `workspace.h`'s cloneKeys merge block — none of this lane's six
anchors**: the escape is live at the new head, the lane rebase is conflict-free on every lane surface,
and `forfilesyms.h` is untouched. No action owed before the push pipeline; re-pin to the then-current
head at PR time per the fresh-base discipline.

## 9. Host rules banked this round (the operator's freeze complaint, root-caused)

The operator reported the machine near-frozen while the producer ran multiple clang instances. The
causal chain is in the producer's own erratum: a healthy clang ASan compile on darwin shows one
driver PID with NO child processes start-to-finish (cc1 runs in-process) — the producer's
gcc-calibrated discriminator read that as "wedged" twice, false wedge reads invite re-launches,
killed tasks leave orphaned drivers, and one ASan `main.cpp` TU alone costs 12–25+ min at -O2 on
this 8-core box. **Standing rules:** (1) heavy builds (full batteries/ASan) are serialized or moved
off-host — the operator's VM-with-16GB plan is adopted as the default for the next full battery;
(2) "no child process" is not evidence of a stall for clang; elapsed-vs-measured-cost and
newest-`.o` mtime are the instruments; (3) `/usr/bin/g++` and `/usr/bin/gcc` are clang stubs — a gcc
claim requires `/usr/local/bin/g++-14 --version`.

## 10. Disclosures, both directions

- **PM:** the spec's Validation Strategy section carried the producer-rejected HTTP direction until
  this round (dispatcher-authored pre-pin, never reconciled after Phase 0 — the read-back discipline
  applies to my artifacts too); corrected this round with the superseded notice retained. My first
  `find_last_if` probe misused the algorithm's return type (gcc-14 rc=1 was my test's defect; the
  discrimination between clang-16 and gcc-14 is unaffected). The phase-0 hand-back was read at the
  phase-3 fold rather than at phase-0 time — the relay discipline slipped one phase; the rulings were
  correct and are now accepted, but hand-backs get relayed at their phase boundary going forward.
- **Producer:** the W2 prose pair (§4, the required fixes); the two "wedged" misreads and the
  probe-vs-real-flags budget error (disclosed, corrected, banked); the changelog fifteen/fourteen
  error (caught in-lane by the producer's own read-back — the SBE §11 lesson demonstrably
  transferred); phase-0's two self-corrected probe rows (mislabelled dedupe row; read-verb
  misread — both recorded honestly).

## 11. VERDICT

**ACCEPTED — with two required pre-push prose fixes (§4): the W2 base-behaviour descriptions in the
gate header and the hand-back §3 table row.** The mechanism, the gate's arms, the battery, the counts,
the meta-gates, the toolchain story, and the blast radius are all verified on PM instruments; the
Phase-0 rulings are accepted as the lane's correct engineering. **The flip to approved executes on
the fixup's landing + PM delta re-verify** (two-line probe, the SBE §11 pattern). Lane head stays
`b870c8918`+fixup, clean, unpushed; the #484 interlock holds; ship keys stay with this seat.

**Next in the rotation (this seat's ruling, no menu):** with WKC's dependencies closed and every AVS
dependency satisfied (SRI approved, retired-spec amendment), **rank-1 = `audit-validation-standalone`**
— the program-terminal ship verdict, dispatching after the WKC flip, with its Phase 0 opening on the
OWED premise repair (2 of its 4 consumed PBT bundles never existed; bounds rebuilt around upstream CI
+ live contracts; baseline its inputs FIRST). Rationale: deferring the terminal node defers the
program for no measured reason; the premise repair is exactly Phase-0-shaped work; the alternates
(markitdown, parsepool, rendered-dom) unblock side chains only.

---

## Addendum 1 — fixup `d883c4f8d` verified; a THIRD required fix ruled (2026-11-10T19:20Z, PM seat)

**Both §4 fixes verified landed**: diff `b870c8918..d883c4f8d` = +5/−1, one file (the gate), all six
lines comment-only — executable-line identity EMPTY by direct hunk read, `src/` drift 0, so the
three banked binary legs remain the evidence of record (asan stamp re-read: `b870c8918`). The
producer re-measured the canon before editing (probe log `S1/S2: SERVED=1 REFUSED=0 WROTE=YES`) and
independently re-measured on the banked base binary; this seat re-ran its own battery at the head,
zero compilation: base rc=1 **6 FAIL = W1×2/W2×2/W3×1/W7×1** / 8 PASS; asan rc=0 ALL PASS;
gateexitcheck rc=0 (the rewritten header accepted from the consumer side); selfcheck green
(specs=17); no machine-local path in the shipped gate (the producer caught their own
absolute-scratch-path slip PRE-commit — provenance discipline applied to their own fix; commended).

**§4's parenthetical SUPERSEDED — the flip holds on a THIRD required pre-push fix.** The producer's
hand-back §9 carried open the observation that the W2 first-failure message's lead-in
("argv-swap changed the verdict") contradicts its own printed evidence; this seat's own base run
captured it: `FAIL (W2) argv-swap changed the verdict: [R/a,RR/z] → served, [RR/z,R/a] → served`.
The `no` on gate line 143 fires in TWO modes — verdicts differ (claim true) or verdicts
same-but-served (claim FALSE) — and the second mode is precisely the base/regression path the
shipped gate exists to diagnose. This seat's §4 read ("the failure-text already prints both verdicts
honestly — no code change needed or wanted") was incomplete: the printed verdicts were honest, the
framing clause wasn't; the producer's §9 is one layer deeper than this seat's sweep. **Ruled
REQUIRED**: the message must state the requirement ("must give the SAME REFUSED verdict"), making it
true whenever it prints; suggested wording in the relay (`relay-to-producer-wkc-fixup2-verdict.md`).
The lane is unpushed and unflipped — this is the cheapest the fix will ever be; shipping a
self-contradicting diagnostic behind an approved state is the §11 class with an extra step.

**Delta re-verify contract (fix #3):** the one-line diff is exactly the message string (the `no`
call and every verdict semantic unchanged); base profile identical; no rebuild owed (the binaries do
not read the gate); gateexitcheck + selfcheck green at the new head. **On landing + this seat's
re-verify: the three-place flip + manifest event.** The producer's recording-not-patching outside
the reviewed scope, then flagging the evidence back for the scoping seat to decide, is the
observation protocol working exactly as designed. #484 OPEN @ `367dbfe45` at this writing; the ruled
push posture unchanged.

---

## Addendum 2 — fix #3 verified at `b995315d0`; the flip EXECUTED (2026-11-10T19:35Z, PM seat)

Fix #3 landed while the fixup-2 relay was being written — the producer reached the same ruling from
their own re-measurement ("that parenthetical was about the arms' assertions; the printed string is
a §11 defect") and fixed it before the relay arrived: `b995315d0`, message-only, the one-line diff
exactly the W2 failure string ("must give the SAME REFUSED verdict" — true in both print modes).
Verified by this seat at the final head, ZERO compilation: base rc=1 **6 FAIL =
W1×2/W2×2/W3×1/W7×1** / 8 PASS with the new message printing over both-served evidence; asan rc=0
14/14; gateexitcheck rc=0; selfcheck green; stamps unchanged (asan `built_from=b870c8918` — no
rebuild owed, the binaries do not read the gate). Hand-back §9 re-read: "One observation that WAS
open, now fixed". No machine-local path in the shipped gate.

**The flip executed on the pinned condition** — three places, selfcheck green pre+post (the
two-place invariant held): manifest `status: approved` with the terminal chain + the prior dispatch
note retained; history event #55; spec Status → approved. **workspace-key-containment APPROVED.**

Upstream drift at approval, measured by this seat on the producer's watch: `fc0e35967 → b8032471f`
(187 commits) — the containment anchors mcp.h/mcpindex.h/mcpserver.h/mcpedit.h BYTE-IDENTICAL
(this seat's first four-file probe over-included mcpverbs.h — 145 lines of ONE-SIDE-REACH verb
work, not a lane anchor; instrument error, disclosed); workspace.h cloneKeys-only (6dc02304d,
+11); cli.h 32 lines of help text at :812/:1126 — the one-listener sentence at :5113 INTACT (the
AC-2′ contract cite survives; its number shifts ~+9 at re-pin). The producer's merge-compat run
at the upstream head green (upstream's own gateexitcheck rc=0 with our gate + loop line classified
OK 1/1, counts 782/783 — the same +1 mid-lane shape one release later); their tree-membership
false-alarm disclosed and accepted as the instrument class it is. #484 OPEN @ `367dbfe45`, quiet
8 days — the interlock holds; the push pipeline stays gated per the ruled posture.

**Next per the standing ruling: rank-1 = `audit-validation-standalone`**, dispatching on the fresh
base (`b8032471f` — the producer's watch pre-cleared the anchors; re-verify at dispatch per
fresh-base discipline), Phase 0 opening on the owed premise repair.
