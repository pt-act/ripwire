# Phase 0 Hand-back — workspace-key-containment

**Producer:** the LOCAL seat (Deepseek-V4.1-Flash "-1017", WorkBuddy AI on this Mac).
**Base:** `fc0e35967` — fork main = upstream main, verified here (`origin/lane/workspace-key-containment`
is byte-identical to `fc0e35967`, checked before the worktree was created, not read from the note).
**Worktree:** `~/ripwire-scratch/wkc-r1`, branch `lane/workspace-key-containment`, clean at base.
**Status:** Phase 0 complete. **Two ACs cannot be implemented as drafted**; one is refuted on
documented contract and on correctness, one duplicates a mechanism that lives in a lane beside this
one. Rulings below, with evidence. **No code written yet.**

---

## 1. Anchors — all five re-derived here, none taken from the note

The dispatcher's erratum #1 (line renumbering) is **CORRECT on every count**. Verified at base:

| anchor | note says | I measure | verdict |
|---|---|---|---|
| stdio pin gate | `mcp.h:1950` | `:1950` — `else if( isMcpEditVerb( name ) && !mcpPathInsideRoot( policy.defaultRoot, path ) )` | ✔ |
| HTTP pin arm | `mcp.h:1919` | `:1919` — `else if( mcpCanonRoot( path ) != policy.pinnedRoot )` | ✔ |
| containment predicate | `mcp.h:678` | `:678` — `mcpPathInsideRoot( canonRoot, candidatePath )` | ✔ |
| key builder | `mcpindex.h:947` | `:947` — `mcpWorkspaceKey`, members joined with `\x1f`, trailing separator | ✔ |
| member sort | `workspace.h:163–165` | `:164–166` — `std::sort` by `a.label < b.label` | ✔ (off by one; see §2) |

Erratum #3 is also **correct and load-bearing**: `grep -c '_out_of_workspace\|mcpEditOutOfAssumedRootNote' src/mcp.h` → **0**.
This tree knows nothing about SBE's mechanism. That single fact kills AC-5 as drafted (§5).

**Two corrections to the dispatch note**, both material:

1. **The sort is by `label`, not by path.** `WorkspaceRoot` carries `{ arg, real, label }`
   (`workspace.h:40–45`); members sort by **`label`** — the *shortest unique whole-segment suffix* of
   the real path (`workspace.h:186–210`, "basename when unique"). The key is then built from **`real`**
   in that label order. So "whichever member sorts first" means *whichever member's label sorts first*,
   and a gate fixture cannot assume that equals the path order. My probe fixtures were built with
   single-segment labels (`a`, `b`, `z`, `O1`) precisely so label order is visible and controllable.
2. **The predicate is `mcpPathInsideRoot` at `:678`, NOT "the working tree's own path-prefix test" at
   some other address** — but there is a *second*, independently useful precedent the note misses:
   `mcpExplicitNoRootReason` (`mcp.h:614–642`) **already does lookup-then-iterate over
   `wsIt->second` right here in `mcp.h`**, judging each member. See §4.

---

## 2. The escape is real — reproduced here, on all four rows the spec needs

Base binary `logs/wkc-bin-BASE-fc0e35967`, `built_from=fc0e35967` (clang 21.1.8). Probe:
`logs/wkc-p0-probe.sh`; raw output `logs/wkc-p0-probe-BASE.out`.

### STDIO pinned tier — `ripwire <R> --mcp`

| row | request | at base |
|---|---|---|
| **S1 escape** | `paths:[R/a, RR/z]`, edit `uniq_z` (lives only in RR/z) | **SERVED, DISCLOSED=0, victim WRITTEN** |
| **S2 argv-swap** | `paths:[RR/z, R/a]`, same request | **SERVED, victim WRITTEN** — identical to S1 |
| **S3 reason-fix** | `paths:[R/a, T/O1]` (outside member sorts FIRST) | **REFUSED -32602** with the shipped sentence |
| **S4 all-inside control** | `paths:[R/a, R/b]` | **SERVED** (must stay served) |

SBE-F1 is confirmed exactly as filed: one member decides for all of them, and the member that decides
is the one whose **label** sorts first. S1 and S2 are identical because the label sort makes argv order
irrelevant — that is the determinism contract (`workspace.h:164`, "argv order can never leak into
output, §2.1") producing a security decision by accident.

### HTTP pinned tier — `--listen=… <R> --allow-remote-edits --mcp-token=…`

| row | request | at base |
|---|---|---|
| **H1 all-inside** | `paths:[R/a, R/b]` | **REFUSED** — "path is outside this server's workspace …" |
| **H2 escape** | `paths:[R/a, RR/z]` | **REFUSED** — same sentence |
| **H3 dedupe-collapse** | `paths:[R, R]` → collapses to the plain pinned root | **SERVED** (back-compat holds) |

H1/H2 confirm the note's tier split: HTTP refuses **every** key, because `mcpCanonRoot` of a `\x1f`
string never resolves and so never equals `pinnedRoot`. **But that is not a defect — see §3.**

---

## 3. RULING — AC-2 as drafted is REJECTED; the HTTP refusal is the contract, not a bug

AC-2 asks this lane to make an **all-inside** `paths[]` workspace **ADMITTED** over HTTP, calling the
blanket refusal "the finding's HTTP-side defect direction" that "repairs A11". I am rejecting that
verdict flip, on four independent grounds. This is the lane's central engineering decision and it goes
against the pre-pinned shape, so it is argued in full.

**(a) The refusal is the documented contract, in three places.**
`src/mcp.h:513–514` — *"the listener serves exactly ONE workspace fixed at startup ('one listener = ONE
workspace'). A tools/call whose `path`/`paths` names a DIFFERENT tree is refused with a clean …"* That
sentence names `paths` explicitly. Changing it is a contract change, not a bug fix, and it would need to
land as one.

**(b) Multi-root HTTP is not an advertised shape.** `src/cli.h:5113–5116`:
`--listen serves ONE workspace fixed at startup — pass the repo root`. The `cfg.roots.size() >= 2`
branch at `mcpserver.h:482` is reachable only through positional roots, which I measured is **not** how
`--listen` is meant to be driven. A11 (Decision A, 2026-07-11) is a **stdio** capability:
`test/multirootcheck.sh` contains **zero** `--listen` references (`grep -c listen` → 0). There is no
HTTP multi-root contract to repair and no capability to "restore".

**(c) Admission would make the listener's own policy STALE — a correctness break, not a preference.**
`mcpserver.h:500–511` resolves `policy.pinnedRootHasGit` and `policy.pinnedRootIsGitDir` **once**, and
the comment is explicit: *"Resolved ONCE, here — the answer is fixed for the listener's life (the
workspace is pinned at startup)"*. Those two flags are what make the catalog *"neither advertise a verb
this tree makes refuse nor omit one it would have answered."* Admit a different workspace per request
and the catalog starts describing a tree the listener is not answering about: `tools/list` advertises
git-verb availability computed from root A while the call executes against workspace B. AC-2 as drafted
buys an admission at the cost of the catalog's honesty invariant — on the transport where the catalog is
the client's only discovery surface. I measured what AC-2 wants to enable and it *works*
(`logs/wkc-p0-probe7-BASE.out`: an all-inside workspace resolves `uniq_b` → `b/vb.c` coherently), so
this is not a "it wouldn't work" objection; it is that it would work *while the surrounding policy
silently stopped being true*.

**(d) The "defect direction" is a language artifact of a correct test.** The key is opaque; the test is
"does this canonicalize to the pinned tree". It never can. Given (a)–(c), the correct reading is not
"the test is wrong" but "a `paths[]` request is not a shape this transport serves".

### What IS defective about the HTTP arm — a narrow, honest fix (the AC that replaces AC-2)

The refusal is right; its **sentence misdirects**. Today an all-inside `paths:[R/a, R/b]` refusal says
*"run a second server for the other tree"* — but there is no other tree, both members are under this
listener's own root. A caller is told to do something that would not help.

**Replacement AC-2 (AC-2′):** at `mcp.h:1919`, when the refused `path` **is a registry key**, keep the
refusal and the `-32602` code, and state the actual condition: this listener serves one workspace and a
`paths` workspace is not it — naming that a `paths` request is stdio-shaped. Single-path refusals keep
the shipped sentence **byte-identically** (no gate pins it — checked — but `mcprobustcheck.sh` D-2
pins the *stdio* sentence exactly, so I will not touch that one at all).

This keeps: the documented contract, the once-resolved catalog policy, and A11's stdio-only reality.
It adds: a sentence that stops pointing at a wall. It is gate-able with a red baseline (today's message
is provably the wrong one) and costs one branch.

---

## 4. Fix shape for AC-1 (accepted) — and which precedent to reuse

Pre-pinned shape CONFIRMED for stdio: for an edit verb whose `path` is a registry key, require **every**
member root inside `policy.defaultRoot`; refuse `-32602` naming the offending member.

**Precedent correction:** the note points at `hardenRequestRoot` (`mcpindex.h:966`). That is a
*hardening* precedent (it *does* things to each member), and its shape is right — lookup, then iterate —
but there is a closer one **in this file**: `mcpExplicitNoRootReason` (`mcp.h:614–642`) does exactly
lookup-then-iterate and returns a **refusal reason** per member:

```cpp
const auto wsIt = mcpWorkspaceRegistry().find( path );
if( wsIt == mcpWorkspaceRegistry().end() ) { return judge( path ); }
for( const WorkspaceRoot& r : wsIt->second )
    if( std::string why = judge( r.real ); !why.empty() ) { return why; }
return {};
```

I will adopt **this** control flow (it is a judgment per member, which is what containment needs), keep
`hardenRequestRoot`'s naming in the comment as the sibling instance, and put the helper beside
`mcpExplicitNoRootReason` so the two per-member judges sit together. No third shape invented.

**A trap the note does not mention, and that a naive fix walks into:** on a multi-root **stdio** start,
`defaultRoot` is *itself the key* (`mcp.h:3047–3056`, `defaultRoot = mcpCanonRoot( key )`). A fix that
contains each requested member against `defaultRoot` would then compare *member paths against a key*
and refuse everything — turning AC-1 into a total outage for multi-root stdio. Measured:
`logs/wkc-p0-probe4-BASE.out` — a server started on `[R/a, R/b]` currently **serves** the same key (K1)
and a plain member path (K2). **The fix must therefore special-case `defaultRoot` being a key**: when
the tier root is itself a registry key, containment means "every requested member is one of the pinned
members" (or the pinned members' subtree), not "inside a path". I will pin the exact relation in Phase 1
and gate it — this row is the reason the lane needs a sixth arm.

**Read verbs stay untouched.** `mcp.h:1950` is already gated on `isMcpEditVerb`; I verified a read verb
with a mixed key is SERVED at base (`probe4` K3). **That is correct behaviour (D4 read freedom), not a
finding** — I flag it because the raw probe output reads like an escape and a reviewer will ask.

---

## 5. RULING — AC-5 is OUT OF SCOPE for this lane; it would duplicate SBE's mechanism

AC-5 asks this lane to extend "SBE's `_out_of_workspace`" to mixed workspaces on the bare tier. As
errata #3 correctly says and I verified (`grep -c` → 0), **that mechanism does not exist at this base**.
The disclosure *primitive* does (`mcpEnvelopeNoteField`, `mcp.h:664`; siblings `_assumed_root`,
`_memory_stop`, `_history_cut` at `:1748–1750`) — so it is *possible* to write it. That is precisely why
it must not be written here:

- SBE already implemented exactly this, as a **per-member loop** in `mcpEditOutOfAssumedRootNote`
  (approved, `7721f6707`). Writing a second per-member loop in the same file, on the same envelope, for
  the same condition, in a lane that sits **beside** SBE and will merge after it, is a guaranteed
  conflict and a permanent duplicate.
- This lane's own deliverable is *admission*, and on the pinned tiers admission is a refusal. The bare
  tier is the one tier that stays permissive, and it is SBE's lane.
- The spec's own Scope already says the bare tier is out of scope ("SBE's lane owns its disclosure
  shape; this lane extends it") — AC-5 contradicts the Scope section. The Scope is right.

**Ruling:** AC-5 is dropped from this lane and must NOT be re-added by pointing at "the finding's
text". If both lanes land, SBE's A4 arm (already per-member) covers a mixed workspace on the bare tier
without this lane writing a line. I will record this as the hand-back's one scope reduction.

---

## 6. The AC set I am proceeding with (finalised)

| AC | status | what the gate must own |
|---|---|---|
| **AC-1** | ACCEPTED | stdio escape `[R/a, RR/z]`: RED at base (S1 served + written), GREEN post-fix (refused `-32602` naming `RR/z`, victim byte-identical) |
| **AC-1b** (new) | ADDED by me | **multi-root-started stdio**: a server started on `[R/a, R/b]` still serves its own key and its members (no outage). This is the trap in §4 |
| **AC-2′** | REPLACES AC-2 | HTTP: the refusal STAYS; when `path` is a key the sentence states the one-workspace condition instead of "run a second server for the other tree". Red at base (wrong sentence), green post-fix. D-2's stdio sentence untouched |
| **AC-3** | ACCEPTED, extended | argv-swap invariance: both orders → same verdict, **and the same named member** |
| **AC-4** | ACCEPTED, re-pointed | reuse `mcpExplicitNoRootReason`'s lookup-then-iterate (§4), not a third shape |
| **AC-5** | **DROPPED** | see §5 |
| **AC-6** | ACCEPTED | gate + loop line + changelog, one commit (GEN-DOCS-MERGE) |
| **AC-7** | ACCEPTED | both toolchains + ASan |

**Reason-fix row (S3)** and **all-inside control (S4)** stay as the spec's Validation Strategy has them;
S4 is the row that proves the fix did not over-block, and it is currently green at base so it must be
green on both sides.

---

## 7. Instruments — and one instrument fact that will bite this lane

- **`--allow-remote-edits` forces a bearer token even on loopback** (`mcpserver.h:471–478`); my first
  HTTP probe died on it. Any gate activating HTTP edit rows needs `--mcp-token=`.
- **The listener enforces `Accept: application/json, text/event-stream`** (else `-32600 Accept must list
  …`). The canonical client is `test/lib/gatehttp.sh` + `mcpserver.h`'s own contract; I will source the
  existing lib rather than hand-rolling curl (my probe hand-rolled it and paid two rounds for it).
- **Disk is the binding constraint on this host**: 5.8 GiB free at 98 % when I started; **7.1 GiB** now.
  A full clang base build took **25 m 35 s** (not the ~11 m this host usually manages) and that is the
  budget the three-toolchain battery must fit in. I am building **one leg at a time** and keeping the
  banked binaries (`logs/wkc-bin-BASE-fc0e35967`) rather than caching three build trees.
  If a later leg cannot fit, that is a **disclosed gap**, not a silent skip.
- `PATH=/usr/local/opt/llvm@21/bin:/usr/bin:/bin:/usr/sbin:/sbin:/usr/local/bin` for every build — the
  anaconda `ld` trap is real and I have not hit it once this round.

---

## 8. Self-corrections in this Phase 0 (kept, not quietly fixed)

1. **My own probe row was mislabelled and the probe refuted it.** I first wrote an H3 row called
   "single-root path (non-key back-compat)" passing `paths:[R/a, R/a]`. It was **refused** — correctly,
   because it dedupes to `R/a`, a *different tree* from the pinned `R`. The label was wrong, not the
   binary. Replaced with the true dedupe-collapse case (`paths:[R,R]` → SERVED) and the correction is in
   the probe's own comment.
2. **I briefly read `probe4` K3 as a second escape** (a key-pinned server serving `[R/a, RR/z]`) and
   started to call it a finding. It is a **read verb**, which is deliberately ungated (`is_mcpEditVerb`
   guard at `:1950`) — D4 read freedom. Confirmed by re-running the same request as an **edit** verb,
   which is refused (`probe5`, victim byte-identical). Recorded because the raw output reads like an
   escape and a reviewer deserves the reasoning, not just the verdict.

---

## 9. What I need from the PM seat

**Nothing blocking.** The two rulings (AC-2 rejected → AC-2′; AC-5 dropped) are engineering decisions
under the standing directive, made on measured evidence and taken here, not routed. They will appear in
the spec Status at hand-back for the PM's delta re-verify like any other measurement claim.

**One flag for the record:** rejecting a pre-pinned shape is the kind of act that should be visible
early rather than at Phase 3, which is why this hand-back exists before any code. If the dispatcher
disagrees with §3 or §5, the disagreement is cheapest now.

Next: Phase 1 implementation under AC-1 / AC-1b / AC-2′, gate in the same commit, then the battery.
