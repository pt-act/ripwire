# Phase 3 Hand-back — workspace-key-containment

Lane `wkc-r1`, branch `lane/workspace-key-containment`, base `fc0e35967`, head `b870c8918`.
Four commits. Everything below is measured on this host this round; where a claim rests on an
instrument that failed, the failure is disclosed with the claim.

---

## 1. What shipped

    b870c8918  docs(changelog): the gate has fourteen rows, not fifteen
    d95c5ecec  test(workspacerootcheck): make the row counter invisible to gateexitcheck's classifier
    a6b55575b  test(workspacerootcheck): drop a dead duplicate ok()/no() pair
    7521a7a70  fix(mcp): decide `paths` containment per member, not by the first-sorted one

    changelog.d/workspace-key-containment.md |  32 ++++
    src/mcp.h                                |  87 +++++++++-
    test/regression.sh                       |   1 +
    test/workspacerootcheck.sh               | 282 +++++++++++++++++++++++++++++++
    4 files changed, 396 insertions(+), 6 deletions(-)

Loop count `776 -> 777` (one gate line, alphabetically between `withprofilecheck` and
`worktreeleakcheck`). GEN-DOCS-MERGE satisfied: gate file + loop line + changelog in one lane.

### The changelog had the §11 defect and I caught it here, not later (`b870c8918`)

The Security entry said *"six of its fifteen rows fail … the remaining nine are the controls"*. The
gate declares `EXPECTED_ROWS=14` and the base run measured exactly **6 FAIL / 8 PASS**. Both numbers
were off by one. This is the SBE §11 failure mode repeating in a different lane — a prose count
disagreeing with the artefact's own declared constant — and it was caught the same way: reading the
measured log against the claim rather than against my memory of writing it. Prose-only, 3 lines,
changelog only; no code re-verified for this commit.

## 2. Mechanism (AC-1, AC-4)

New helper `mcpOutOfWorkspaceMember( tierRoot, requestedKey )` at `src/mcp.h:706`, placed
**after** `mcpPathInsideRoot` (`:678`) because it calls that predicate — the first placement
above it failed to compile (`use of undeclared identifier`), which is the ordering constraint,
not a style choice.

It returns the first member of the requested key that is not contained, or "" when every member is.
Two branches, and the second is the load-bearing one:

- **tierRoot is ITSELF a key** (multi-root stdio, `mcpStdioPolicy`; multi-root `--listen`,
  `mcpserver.h:482-487`): compare by member **identity** (`req.real == have.real`), not by
  containment. A member-vs-key containment test here would refuse a server its own workspace and
  turn a working start into an outage — AC-1b, and the gate's W6 is that trap.
- **tierRoot is a plain path**: per-member `mcpPathInsideRoot`. This is the SBE-F1 fix.

The stdio gate at `:2009` now decides containment **before** the prefix test:

    const std::string outMember = mcpOutOfWorkspaceMember( policy.defaultRoot, path );
    if( !outMember.empty() ) { -32602 … "this `paths` request includes a member outside it: " + outMember }
    else if( !mcpPathInsideRoot( policy.defaultRoot, path ) ) { … the shipped sentence, byte for byte … }

A plain non-key path therefore never reaches the new clause and keeps the shipped string
(`mcprobustcheck` D-2 pins it); the gate's W5 asserts that as an **exact** string, not a substring,
because a substring test would pass a message that merely appended to the shipped sentence.

HTTP (AC-2′): the refusal stays — §2b pins one listener to one workspace, and
`pinnedRootHasGit`/`pinnedRootIsGitDir` are resolved once, "fixed for the listener's life"
(`mcpserver.h:500-511`) — but when `path` is a key the sentence states the one-workspace condition
instead of misdirecting to a second server.

## 3. Discrimination — the number that matters

    clang 21.1.8 (build21)      rc=0   14/14   ALL PASS
    gcc 14.2.0    (buildgcc)    rc=0   14/14   ALL PASS
    base fc0e35967              rc=1   FAIL=6  PASS=8

The six base failures, by arm:

| arm | base behaviour |
|---|---|
| W1 x2 | `[R/a, RR/z]` **served and wrote the outside file**, twice (verdict + byte-identity) |
| W2 x2 | **both orders SERVED the escape** — argv-invariant at base (probe S2); red x2 because the *shared* verdict is the escape, not because the orders differ |
| W3 x1 | `[R/a, T/O1]` refused **by sort accident** with no member named |
| W7 x1 | HTTP key refusal misdirects to "a second server for the other tree" |

The 8 base greens are **all** either back-compat controls (W4 all-inside served at base, W5 shipped
sentence, W6 own-key served) or rows whose base behaviour was correct for an unrelated reason
(W3's byte-identical half is green because base's accidental refusal still wrote nothing; W7's
plain-path half is green because base prints the shipped sentence there). **No arm is vacuous** —
each green row either must be green on both sides by design or is paired with a red row that
explains it. This is the A4 distinction from SBE applied deliberately rather than by accident.

## 4. Blast radius

The dispatch note named `gitframingcheck` for multi-root fixtures. Measured: its "paths" are git
**pathspecs** (`-- <relpath>`), not MCP `paths[]` — a false lead, recorded so the next seat does not
re-chase it. The gates that actually drive `paths[]` were found by grep and run:

    depsprecisecheck rc=0 (19 references — the largest consumer)   mcpcontractcheck rc=0 (6)
    agentloopopencodecheck rc=0  archhonestcheck rc=0  gitchildoptscheck rc=0
    hopcontextcheck rc=0  mcpframehonestycheck rc=0  mcpw3fixcheck rc=0  seedboundscheck rc=0

plus the four from the mechanism round: `multirootcheck`, `mcprobustcheck`, `mcpeditracecheck`,
`mcpremotecheck` — all rc=0.

Why this set is sufficient rather than merely convenient: the helper's only call site is
`src/mcp.h:2017`, inside the `isMcpEditVerb` branch opened at `:2009`. Read verbs never reach it
(D4 read freedom is intact), and the HTTP side branches only on registry membership of an
already-key-shaped `path`. The blast surface is exactly "edit verbs carrying `paths[]`".

## 5. Meta-gates — and the two defects they found in MY gate

All six green at head: `gatecountcheck` rc=0, `gendocsmergecheck` rc=0, `bashsourcecheck` rc=0,
`nulbytecheck` rc=0, `gateexitcheck` rc=0, `manifestcheck` rc=0. Counts reconcile as designed:
**snapshot 776 / loop 777**, the by-design mid-lane delta the dispatch predicted.

Two of my own defects, both found by instruments rather than by rereading the file:

**(a) A dead duplicate `ok()`/`no()` pair** (`a6b55575b`). Defined at 49-50 without the row counter,
redefined at 57-58 with it. Behaviour was right (bash keeps the second) but half the file read as if
row counting were optional.

**(b) `gateexitcheck` arm (B) rejected the gate** (`d95c5ecec`): *"terminal region exits 1 with
`rows=0`; the extraction is not runnable in isolation"*. Root cause: `recorder_var()` takes a gate's
failure accumulator to be the **first** variable a FAIL-printing helper bumps (`X=1` or
`X=$(( X + 1 ))`). My helpers bumped `rows` with the `$(( ))` spelling first, so the classifier read
`rows` as the accumulator, sliced my terminal region, ran it with `rows=0`, and my declared-row guard
correctly exited 1 — **indistinguishable from outside from a broken exit.** Fixed with `rows+=1`
under `declare -i rows=0`, so BUMP sees `fail` and `rows` stays a plain counter.

`declare -i` is not cosmetic: `+=` on an untyped variable **string-appends**, which measured as
`emitted 011111111111111` — the guard failing a gate that had emitted every row. That intermediate
state was caught by re-running the gate, not by reasoning about it.

This gate is the **only** one in the tree with a declared-row guard (`grep -l 'EXPECTED_ROWS='
test/*.sh` -> one file), so there was no house precedent to copy. The classifier is the contract and
it is now met. I am flagging (b) explicitly because it is a new-gate shape interacting with a
suite-wide meta-gate, i.e. the same class the fork matrix caught three times in the SBE lane.

## 6. Toolchains

**gcc.** The first "gcc leg" was not gcc: `/usr/bin/g++` on this host is a 77-link stub to **Apple
clang 16.0.0**, which lacks C++23 `std::ranges::find_last_if` used by `src/forfilesyms.h` — a file
this lane never touches. The tell was the wording ("1 error **generated**" is clang's). A three-way
probe settled it: Apple clang 16 rc=1 (reproducing the build-log text verbatim), llvm@21 rc=0,
Homebrew gcc-14 rc=0. Rebuilt against `/usr/local/bin/g++-14`:

    ripwire 0.6.10 (dev, GNU 14.2.0, emit=std::print, built_from=7521a7a70)

`--version` is the instrument here, exactly as the project rule says — a `strings`/`built_from` probe
would have answered empty and told me nothing.

**ASan.** Configure with **both** compilers pinned. My first attempt pinned only CXX, leaving
`CMAKE_C_COMPILER=/usr/bin/cc` -> Apple clang 16, so every C dependency (tree-sitter `parser.c`,
`scanner.c`) carried clang-16's ASan while the link used llvm@21's runtime:

    Undefined symbols: ___asan_version_mismatch_check_apple_clang_1600

The symbol names the culprit. With both pinned, configure rc=0 and `_RIPWIRE_ASAN_PROBE_PASSED`
populates (21.1.8 / SDK 23.6.0 / `libclang_rt.asan_osx_dynamic.dylib`).

A measurement note that matters for how you read the ASan row: with both heavy legs running, the
start-up probe **timed out at its 10 s limit** and CMake refused to configure, advising
"raise RIPWIRE_ASAN_PROBE_TIMEOUT only if this host is simply very busy". The host was busy. I did
**not** raise the timeout; I re-ran on a quiet machine and it passed at the default. Load, not a
runtime defect — measured, not assumed.

## 7. Disclosures

- **AC-7 is satisfied on all three legs** — clang 21, gcc 14, ASan — with the ASan numbers in §8.
  §7 keeps the earlier reservation because the *estimate* I would have written off a probe was
  wrong by a wide margin (see below); the reservation is about method, not about the outcome.
- **Both build-harness notes above were instrument defects, not lane defects**, and both produced a
  false red I had to disprove before proceeding. I am recording them because the §11 class applies
  to harness claims too, not only to prose claims.
- **I twice called the ASan build "wedged" when it was compiling normally**, because I read "no
  `clang -cc1` child" as an orphan signal. That signal is correct for **gcc** (which forks
  `cc1plus`) and **wrong for clang on darwin**, which runs cc1 in-process and shows one driver PID
  with no children from start to finish. I had written the wrong discriminator into my own erratum
  and then acted on it; it is corrected there. The lesson generalises: a probe calibrated on one
  toolchain does not transfer to the next, and "no child process" is not evidence of a stall.
- **The probe under-estimated the job.** I timed a single TU directly and got 702 s, then used that
  as the expected cost. The real ASan leg runs
  `-O2 -fno-omit-frame-pointer -fsanitize=address,undefined,integer,float` — four sanitizers at
  `-O2`, materially heavier than my one-sanitizer `-O1` probe. Write budgets off the **real build
  flags**, never off a convenient probe of the same file.
- **No push, no PR.** Ship keys stay with the PM seat; the #484 interlock holds.

## 8. ASan result — GREEN

    ./asan/ripwire --version
      -> ripwire 0.6.10 (dev, Clang 21.1.8, emit=std::print, built_from=b870c8918)

    LSAN_OPTIONS=suppressions=lsan_suppressions.txt ./asan/ripwire .
      -> rc=0, zero AddressSanitizer / runtime-error / LeakSanitizer reports

    workspacerootcheck.sh asan/ripwire   -> rc=0, 14/14, ALL PASS, 0 sanitizer reports
    multirootcheck.sh     asan/ripwire   -> rc=0, 70/70, 0 sanitizer reports
    mcprobustcheck.sh     asan/ripwire   -> rc=0, 49/49, 0 sanitizer reports

`multirootcheck` and `mcprobustcheck` were run under ASan as well, not only the new gate, because
the `src/` change rides the sanitizer requirement and those two are the neighbours that exercise the
multi-root and edit-refusal surfaces the helper touches.

### Consolidated battery

| leg | binary | gate | result |
|---|---|---|---|
| clang 21.1.8 | `build21/ripwire` | workspacerootcheck | rc=0, 14/14 |
| gcc 14.2.0 | `buildgcc/ripwire` | workspacerootcheck | rc=0, 14/14 |
| ASan (4 sanitizers) | `asan/ripwire` | workspacerootcheck | rc=0, 14/14, 0 reports |
| ASan | `asan/ripwire` | multirootcheck | rc=0, 70/70, 0 reports |
| ASan | `asan/ripwire` | mcprobustcheck | rc=0, 49/49, 0 reports |
| base `fc0e35967` | `logs/wkc-bin-BASE-fc0e35967` | workspacerootcheck | **rc=1, 6 FAIL / 8 PASS** |

---

## 9. Pre-push fixup on the PM's review (`d883c4f8d`) — the W2 base behaviour

The PM accepted Phase 3 with two required prose fixes. Both were applied and **re-measured
independently before editing**, per the doctrine the verdict banks: the Phase-0 probe log is the
canon for the gate's header comments, and Phase-3 prose had drifted from it.

**What Phase 0 actually measured** (`logs/wkc-p0-probe-BASE.out`):

    S1 escape   [R/a, RR/z]  SERVED=1 REFUSED=0 DISCLOSED=0 WROTE=YES
    S2 argv-swap[RR/z, R/a]  SERVED=1 REFUSED=0 DISCLOSED=0 WROTE=YES

**Independently re-measured this round** on the banked base binary, fresh fixture, hash captured
before each request:

    [R/a, RR/z] -> SERVED, wrote YES
    [RR/z, R/a] -> SERVED, wrote YES

So at base **both orders serve the escape**. W2 is red x2 because the *shared* verdict is the defect
— exactly what the rows exist to catch — not because the two orders disagree. The label sort builds
one key from either order, so argv cannot move the answer; invariance ("same verdict, same named
member") is a **POST-fix** property and was never one at base.

**Fix 1** — the gate's ARMS header: "GREEN both sides by design" replaced with the measured base
behaviour and a note that the probe log, not Phase-3 recollection, is the canon for that line.

**Fix 2** — §3's W2 table row: "served one order, refused the other" replaced with "both orders
SERVED the escape — argv-invariant at base (probe S2); red x2 because the shared verdict is the
escape, not because the orders differ".

**Provenance discipline on my own fix:** I first wrote the canonical evidence as an absolute scratch
path (`logs/wkc-p0-probe-BASE.out`) into the shipping gate header. That is a host-specific path in a
file that goes upstream — wrong, and caught before commit. The header now cites "the Phase-0 probe S2
measurement" without a machine-local path.

### Re-verify after the fixup — nothing moved

    build21 (clang 21.1.8)   rc=0  14/14
    buildgcc (gcc 14.2.0)    rc=0  14/14
    asan (4 sanitizers)      rc=0  14/14
    base fc0e35967           rc=1  FAIL=6  PASS=8   (W1 x2, W2 x2, W3 x1, W7 x1 — unchanged)

Prose-only, proven one grade beyond hunk-read: the executable-line diff against `b870c8918` with
comments stripped is **empty**, and `src/` drift is zero — so the clang-21 / gcc-14 / ASan legs
remain the evidence of record. Meta-gates at the head, all rc=0: `gatecountcheck`,
`gendocsmergecheck`, `bashsourcecheck`, `nulbytecheck`, `gateexitcheck` (arm B: 760/792),
`manifestcheck`. Counts: snapshot 776 / loop 777 (by-design mid-lane).

### One observation that WAS open, now fixed (`b995315d0`)

W2's *first* failure message read `argv-swap changed the verdict: [R/a,RR/z] -> served,
[RR/z,R/a] -> served` — the printed verdicts show **no change**, so the sentence asserts a conclusion
its own evidence contradicts. Same class as the header defect, one layer down: the wrong reason
surviving in the string a red run actually prints.

I first left it, on the review's "no code change wanted" scope. That parenthetical was about the
arms' **assertions**, and re-reading it against the measurement showed the string is not an
assertion defect but a §11 one — the same class the review had just required fixing twice, and the
sentence it prints at base is the artefact a future reader would trust. Since the lane is still
unpushed, the correction costs nothing now and is expensive after a PR exists. **Fixed.**

Now: `argv-swap must give the SAME REFUSED verdict: … → $v1, … → $v2`. Stating the *requirement* is
true in both print modes — at base it reports the two served verdicts it observed; post-fix it
reports a genuine refusal mismatch. The sentence no longer has a mode where it lies.

Verified message-only, and the measurement re-run:

    executable-line diff vs d883c4f8d   188 lines both sides, 1 differing — that string literal
    predicate and $v1/$v2 computation   byte-identical
    base fc0e35967                      rc=1  FAIL=6  PASS=8   (W1x2, W2x2, W3, W7 — unchanged)
    build21 / buildgcc / asan           rc=0  14/14 each
    gateexitcheck                       rc=0  0 FAIL; (B) 760/792, (C) 32/32 — unchanged

The base run now prints base's own truth:

    FAIL  (W2) argv-swap must give the SAME REFUSED verdict: […/R/a,RR/z] → served, […/RR/z,R/a] → served

**Flip condition is now satisfied on my side**: both required fixes plus this one have landed, the
delta re-verify is unchanged on all three toolchains, the meta-gate is green, and the lane is clean.
