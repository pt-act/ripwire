# Finding SBE-F1 — a `paths[]` workspace key is judged as a PATH, and only its FIRST member decides

**Filed:** 2026-11-07, by the SBE producer seat, from live probe measurements on
`built_from=e4432b48a` (base) and the SBE-fixed binary — **identical on both**.
**Origin class:** pre-existing. NOT caused by SBE. Not closed by SBE either (SBE discloses on the
bare tier; this is a **pinned**-tier admission defect).
**Lane disposition:** OUT of `stdio-bare-edit-escape` scope. Needs its own node.

> **Correction notice.** An earlier draft of this file claimed the pinned tiers *falsely refuse*
> a legitimate all-in-workspace `paths[]` edit. **That is wrong, and I disproved it with my own
> probes** (a disjoint in-root pair is served on both tiers). The defect is the mirror image and
> is more serious: the pinned tiers can **silently ADMIT** a workspace one of whose members is
> entirely outside the root. The draft, its four probes and their retraction are kept in §6 —
> the wrong hypothesis is part of the record, because the reason I believed it is the reason
> this defect survives.

## The finding

A multi-root `paths[]` request replaces `path` with a **synthetic workspace key**
(`mcpWorkspaceKey`, `src/mcpindex.h:947`): the members' real paths joined by `\x1f`, in
**label byte-order**, each with a trailing separator:

```
"root1\x1froot2\x1f"
```

That key is not a filesystem path. Every containment gate nevertheless calls
`mcpPathInsideRoot( root, path )` on it, and that function (`src/mcp.h:678`) is a **component
prefix test on the string**:

```cpp
return canonCandidate.size() > prefix.size() && canonCandidate.compare( 0, prefix.size(), prefix ) == 0;
```

Applied to a key, the prefix test asks one question — *does the key START WITH the root?* — and
the key starts with **whatever member sorted first**. So:

- **first sorted member inside the root** → the whole key passes → **the request is admitted**,
  no matter that a later member is entirely outside;
- **first sorted member outside** → the whole key fails → refused, even if every member is inside.

One member decides for all of them. The order cannot be fixed by the caller: members are sorted
by label at `src/workspace.h:163` ("argv order can never leak into output, §2.1"), so both
argument orders produce the same key — and the same verdict.

## Measured

Fixed and base binaries agree in every row, so this is not SBE's doing.

**The escape (pinned tier, silent):**

| launch | `paths` | outside member served? | refusal? | disclosure? |
|---|---|---|---|---|
| `ripwire R --mcp` | `[R/a, RR/z]` (`a` sorts first, inside) | **yes, file rewritten** | **none** | **none** |
| `ripwire R --mcp` | `[RR/z, R/a]` (same, argv order swapped) | **yes** | **none** | **none** |
| bare `--mcp`, cwd=R | `[R/a, RR/z]` | yes | none | **yes — `_out_of_workspace` names RR/z** |

That last row is the asymmetry that matters: **SBE's disclosure covers the bare tier only.** On
the startup-root tier the same escape is admitted with a completely clean envelope — the exact
"silence" class SRI-F1 named, surviving on the tier everyone assumed was safe.

**Containment follows the sorted-first member, demonstrated by flipping which member sorts first:**

| members (labelled by basename) | sorted first | pinned-tier verdict |
|---|---|---|
| `[R/a, R/b]` — both inside | `a` (inside) | SERVED |
| `[R/a, T/O1]` — mixed | `O1` (outside) | REFUSED |
| `[T/O1, T/O2]` — both outside | `O1` (outside) | REFUSED |
| `[R/a, RR/z]` — mixed | `a` (inside) | **SERVED ← the escape** |

The fourth row is the defect and the second row is the false refusal, from **one** cause: `O1`
sorts before `a` (uppercase precedes lowercase in byte order), `z` sorts after `a`. The verdict
tracks the alphabet, not the workspace.

## Why the earlier hypothesis was wrong, and why that is instructive

My first probes used members `[R/d1, OUT]` with `OUT` under the same temp root, and I read the
refusals as key-blind false-refusal. Two things were wrong with that reading:

1. `OUT` happened to sort **first** in one run and the members were **nested** in another
   (`R/d1` inside `R` is a hard error: "nested roots are not allowed", `src/workspace.h:117`) —
   so I was measuring the nesting guard, not containment.
2. I asserted a direction from *two* samples without varying the one variable that matters —
   which member sorts first. Once I varied it, the picture inverted.

The lesson is the banked one this project keeps re-learning: a probe that produces a clean,
plausible story from two points is a **suspect instrument** until the driving variable has been
moved both ways.

## Severity

**High** — higher than the finding it sits beside. It is a **silent cross-workspace write on a
tier documented as pinned**, reachable by any client that sends `paths` with two disjoint roots
whose basenames happen to sort with the in-root one first. It also means SRI-F1's fix (SBE) is
incomplete as a *class* fix: it closed the silence on the soft tier while the hard tier kept the
silence, and the hard tier is the one an operator chose *because* it pins.

No authentication or transport precondition beyond what the pinned tier already grants. Edits
remain gated by `--allow-remote-edits` over HTTP; over stdio a startup root is the normal shape.

## There is already an in-tree precedent for the fix

`hardenRequestRoot` (`src/mcpindex.h:967`) faced this identical question for the git-trust
boundary and states the rule outright:

> A registered multi-root workspace KEY is not a directory, so each of its member roots is
> probed instead.

It looks the key up in the registry and iterates `root.real`. SBE's own helper
`mcpEditOutOfAssumedRootNote` (`src/mcp.h:722–740`) independently re-derived the same shape for
the disclosure path. **The correct pattern is in the file twice.** The containment gate at
`src/mcp.h:2030` is the one that never adopted it — and the HTTP arm at `:1988` compares
`mcpCanonRoot( path ) != policy.pinnedRoot`, which has the same key-blindness.

## Proposed shape (for the spec to pin, not this lane)

1. **Per-member containment, all of them** — for a registry key, every `root.real` must be
   inside the workspace root; refuse naming the offending member. Reuse `hardenRequestRoot`'s
   lookup-then-iterate shape rather than inventing a third.
2. **Both refused tiers**: the stdio startup-root pin (`mcp.h:2030`) and the HTTP pin
   (`mcp.h:1988`), which are separately key-blind.
3. **The gate must assert on a pinned tier**, with the sorted-first variable moved both ways —
   one case where the in-root member sorts first and one where it does not. A single-order gate
   would have passed on this codebase exactly as my first probes did.
4. **Consider closing the silence even where admission is intended** — if upstream keeps the
   bare tier's permissive contract, SBE's `_out_of_workspace` disclosure is the right shape and
   should be extended to any tier on which an out-of-root member is admitted.

## Boundary

- **Not in SBE's diff.** `86757666d` touches only the disclosure path and the tier comment; the
  pinned-tier containment gate is byte-identical to base. Verified by running the decisive probe
  on both binaries — identical verdicts.
- **Does not invalidate SBE's gate.** A4 uses a workspace whose members are *both* outside the
  assumed root, and SBE's helper iterates every member, so A4's disclosure is correct (measured:
  `_out_of_workspace` present, naming the out member). A4 is not vacuous.
- **No upstream exposure** until the #484 interlock concludes.
