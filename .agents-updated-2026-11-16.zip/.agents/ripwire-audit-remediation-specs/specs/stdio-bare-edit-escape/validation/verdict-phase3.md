# Verdict — stdio-bare-edit-escape, Phase-3 hand-back validation

**Validator:** PM seat (GLM-5.3), validator-of-record. **Round:** 2026-11-07T23:30Z.
**Producer:** local seat (Deepseek-V4.1-Flash **-1017**). **Base:** `e4432b48a` (upstream main, live-verified
this round: #484 still OPEN, #574 unmerged, latest release v0.6.9 — evidence frame stable).
**Lane:** `lane/stdio-bare-edit-escape` @ `e6009f79e` (+`86757666d`), working tree clean, NOT pushed —
remote lane branch verified still at the dispatch-time `e4432b48a`: **ship keys unexercised by the producer.**

---

## 1. Method

Per VALIDATION_PROTOCOL step 2: every load-bearing claim in `validation/phase3-handback.md` was
reproduced with PM-owned instruments before this verdict. The instruments: the banked base binary
(`sbe-bin-BASE-e4432b48a`, `built_from=e4432b48a`) and the producer's three fixed binaries (gcc-14, ASan,
llvm@21); the lane's own gate at lane HEAD; PM-built probe scripts (`pmv-sbef1-probe.sh`); the three count
tools (`gatecount_build`, `counts_snapshot`, `pargates --shard-plan`); `otool -L`, `nm`; the five suite
sweep-audits, run by this seat rather than trusted from the producer's logs (which predate commit 2).

## 2. The Shape-2 pin — ACCEPTED

The dispatch note's Shape-1 recommendation is overturned on evidence, not preference. Grounds verified:

- **Q1/Q2 asymmetry measured true** (PM probe + phase0 record agree): the SAME `paths[]` edit is served
  bare and refused `-32602` on the startup-root tier — because a workspace key is `root1\x1froot2\x1f`,
  not a path (`mcpWorkspaceKey`, `src/mcpindex.h:947–960`; label sort at `src/workspace.h:165–167`), so a
  key-blind Shape-1 arm refuses every workspace by construction.
- **Shape 1 is a restructure, not a line**: member resolution happens inside the verb, after the gate
  site (`:1898` rebind precedes `:2030`; the edit lands per-member in `runEditVerb`). Confirmed by read.
- **The A11 cost is real**: `multirootcheck` A1 (Decision A/A11, `:446–462`) asserts `paths[]` edit
  success — verified present, and the lane's fix keeps it green (§4 below).
- **The vacuity trap is real and the pin avoids it**: `mcpeditracecheck`'s served-predicate counting
  `applied=false` as served read and confirmed; the fixed binary passes it NON-vacuously (edit applies).

The pinned literal was superseded in wording by the implementation ("[out-of-workspace edit: …]") — the
verdict accepts the implemented sentence as the pin's realization: it carries every content obligation the
Phase-0 pin demanded (names the assumed root, states the write was applied, reuses the shipped remedy
sentence) and is what the gate now pins. Noted, not a defect.

## 3. Discrimination — REPRODUCED, both directions

| binary (PM-run) | gate verdict |
|---|---|
| base `e4432b48a` (banked, clean stamp) | **rc=1, 6 FAIL rows: (A1)×3, (A3)×2, (A4)×1** — every control row green |
| gcc-14 fixed | **rc=0, 14/14 ALL PASS** |
| ASan fixed | **rc=0, 14/14 ALL PASS** |
| llvm@21 fixed (`+dirty` stamp) | **rc=0, 14/14 ALL PASS** |

The base-red set is **exactly** the hand-back's claim, enumerated by my own run. The `+dirty` llvm@21
stamp is explained and benign: built from the working tree before the commit landed (identical content —
the banked `sbe-bin-FIXED` carries the same stamp, and the producer's §8 table washed the stamp in
reporting; a hygiene nit, disclosed below in §9).

ARM-BINDING: the base run doubles as the M1-mutant signature a fortiori — base contains no disclosure
mechanism at all (≡ M1's total-removal mutant) and fails exactly the disclosure arms, leaving A2/A5/A6
green. The producer's `M1.out` (the one mutant artifact on disk) matches this signature row-for-row.

## 4. Blast radius — 7/7 GREEN on PM instruments (gcc-14 binary, direct)

`multirootcheck` 17s · `mcpeditracecheck` 40s · `mcpcontractcheck` 30s · `mcpeditpresencecheck` 13s ·
`editroundtripcheck` 51s · `mcpframehonestycheck` 237s · `mcpattrparitycheck` **414s rc=0** — all
`ALL PASS`, all under concurrent mutant-build load.

**mcpattrparitycheck budget-timeout diagnosis: independently CONFIRMED by a fourth instrument.** The
producer's three (direct 258s green; `-j1 --budget-scale 3` 276s vs the 300s cap; the `-j2` 300.7s fail)
plus this seat's 414s direct rc=0 under contention: a wall-time ruler under load, not a divergence.
`DEFAULT_TIMEOUT_SEC = 300` verified in-tree.

## 5. Gate mechanics — verified by read and by harness

14 assertions enumerated from the lane's own `:1–137`; both halves asserted (A2's absence arm at the same
strength as A1's presence — the `mcp-token-hygiene` vacuity lesson held); canonical `ok()`/`no()` shape;
the e6009f79e hardening diff read: A5's byte-identity half now measures `$TMP/C/side.c`, the file `r5`'s
edit names — the fixed-point flaw it repaired is real and the fix is test-only (1 file, +9/−4). Both
asserted at base-green correctly. Real-harness run by this seat:
`gates=1 pass=1 skip=0 fail=0 wall=4.6s tree_writes=0` (`pargates --only assumedrooteditdisclosure`).

## 6. Mechanism and lane diff — verified clean

Lane diff vs base is exactly four files, +242/−1: `src/mcp.h` (+82: the tier-guarded helper with
per-member workspace loop, `outOfWorkspaceNote` beside R2a's `assumedRootNote`, the
`_out_of_workspace` splice beside `_assumed_root`/`_memory_stop`, the `oc.ok`-gated assignment so a
REFUSED edit never says "the write was applied", and the D4 tier-split comment extended to all three
tiers), the gate, the one alphabetically-correct `test/regression.sh` line, the changelog fragment. The
pinned-tier gate at `:2030` has **no hunk** — byte-identical to base, as SBE-F1's boundary demands.
**Zero `DISLOSE`/`DISCLOSE` occurrences in the diff** — the note is a plain `std::string` spliced by
`textResult`, so a release build cannot compile it out (the both-flavour concern verified dead).

## 7. Meta-gates — PM's own sweeps, at lane HEAD (post-hardening)

`nulbytecheck` ALL PASS · `gitenvhermeticcheck` ALL PASS (187 gates; the gate's header documents why it
builds no git fixture and owes no `clean-env.sh` sourcing) · `gateexitcheck` ALL PASS (canonical union
incl. the new gate) · `bashsourcecheck` ALL PASS · `manifestcheck` PASS. The producer's sweep logs
predate commit 2 — this re-sweep closes that gap.

## 8. Counts — reconciled, three sites never conflated

From a PM-built true-base worktree at `e4432b48a`: gatecount `--check` loop names **775** (773 marked,
base drift +2 inherited) — the hand-back's claim; rc=0. At lane HEAD: loop names **776**, marked docs 773
untouched, **marginal contribution exactly +1**; rc=0; `counts_snapshot` advisory-stale exactly as at
base (rc=1 is its design — `check` reports, `refresh` is the fold's act). `pargates --shard-plan` totals
**790 = 776 loop + 14** pargates-own members — the **same structural offset as the old base**
(776−762=14 @ `50bc05e84`): pargates' self-listing difference is inherited structure, not this lane's
drift. Lane = first-ever 776/762-equivalent. No count site touched.

## 9. Battery and instruments — verified to the byte

- **ASan**: `nm` carries `___asan_init` (undefined-ref — this seat's first `-gU` probe was the wrong
  instrument shape, caught and corrected); `otool -L` names llvm@21's own libc++ **and**
  `libclang_rt.asan_osx_dynamic.dylib` — one release, headers and dylib matched; the SRI lesson held.
  PM's own direct run through the escape fixture: **exit 0, exactly 301 stderr bytes, zero sanitizer
  lines, and the stderr text read in full is the benign
  `[math degraded] edit-check: no git HEAD baseline` notice.** Gate on ASan: 14/14, 0 sanitizer reports.
- **Toolchain claims**: gcc-14 (Homebrew 14.2.0) present and built; **llvm@22 absence confirmed**
  (17/19/21 installed); llvm@21-with-own-libc++ per `sbe-build21.sh`.
- **Host halt-condition PROBED, not trusted**: zero system-SDK libc++ headers carry `find_last_if`;
  llvm@21's do (`__algorithm/ranges_find_last.h`); `src/forfilesyms.h:400` uses it. The premise holds —
  a system-toolchain base build would halt here; it is the host, not the lane.

## 10. SBE-F1 — reproduced LIVE, disposition: filed for its own node

PM probe `pmv-sbef1-probe.sh` on the pinned tier, unique symbols per member:

| row | members | verdict |
|---|---|---|
| P1 base | `[R/a, RR/z]` | **SERVED, outside file REWRITTEN, no refusal, no disclosure** |
| P1 fixed | same | identical — SERVED, silent |
| P2 fixed | `[RR/z, R/a]` argv swap | identical — label order decides, argv cannot |
| P3 fixed | `[R/a, T/O1]` O1 sorts first | REFUSED `-32602` containment |
| P4 fixed | `[R/a, R/b]` both inside | SERVED |
| bare, fixed | same `[R/a, RR/z]` | SERVED **and `_out_of_workspace` names RR/z** |

The defect is exactly as filed: `mcpPathInsideRoot` is a component-prefix test on the string
(`mcp.h:678–690`), the key starts with the label-first member (`workspace.h:165–167`), one member
decides for all. **Pre-existing on base (this seat confirms both binaries identical), NOT SBE's doing,
NOT closed by SBE** (the pinned tier's code path is byte-identical in the lane). The quietness asymmetry
(the SBE disclosure covers the soft tier while the PINNED tier stays silent on the same request) is
PM-measured and is the strongest argument in the filing. Boundary verified: A4 is NOT vacuous (SBE's
helper iterates every member). Textual grounds for the next node read in-tree: the per-member precedent
exists twice (`hardenRequestRoot`, `src/mcpindex.h:962–978`, quoted; SBE's own helper re-derived it), the
stdio containment gate at `mcp.h:2030` and the HTTP arm's `mcpCanonRoot(path) != policy.pinnedRoot` at
`:1991` are the key-blind sites. **Proposed spec id: `workspace-key-containment`** (SBE-F1 → node deps
`[]`; the SRI-F1 disposition pattern: on the operator's word).

## 11. REQUIRED PRE-PUSH FIXES — two measurement-wrong doc claims (lane artifacts)

Both discovered by this seat's base-run enumeration; both are one-line corrections, doc-only, no code or
gate mechanics affected; **owed on the lane before any push**:

1. `changelog.d/stdio-bare-edit-escape.md`, closing sentence: "*The first five assertions fail on the
   previous build and pass on this one*" — **measured false; SIX assertions fail at base** ((A1)×3,
   (A3)×2, (A4)×1). Commit 86757666d's own message says six.
2. `test/assumedrooteditdisclosurecheck.sh` lines 24–25 (the header): "*assertions (A1) and (A2) FAIL
   there*" — **A2's rows PASS at base** (an in-root edit is applied and carries no disclosure on base
   too — the defect is silence, so the absence half is green there); the failing assertions are
   (A1), (A3), (A4). The header contradicts its own next line ("the refusal/absence arms pass").

Suggested wording ships with the relay (`relay-to-producer-sbe-phase3-verdict.md`), but the producer
holds the pen — the lane's files are the producer's hand.

## 12. Process disclosures (both seats, per the standing symmetry)

- **Producer**: the mutant artefactual record holds **M1 only** (`sbe-mutant/` has one `.out`; the
  build log ends `make Terminated: 15` mid-run) while §3 claims "six mutants were run". M1's signature is
  verified and matches; M2–M6 were claimed without artifacts. This seat's own six-mutant re-run
  **completed 2026-11-07T23:49Z with ZERO evaluable rows and disproved the "six ran" claim outright**:
  (a) **M4 as scripted cannot compile** — its mutation replaces the `if( const auto wsIt = …; … )`
  binding with `if( false )`, deleting `wsIt`'s declaration while the loop body still names
  `wsIt->second` (`error: use of undeclared identifier 'wsIt'`, build log line 147) — the mutation
  script is defective for M4, so a full six-mutant run never happened in the producer's session either
  (their own M1 cycle died to the same erratic-termination hazard, then `make Terminated: 15`, with only
  M1's output surviving);
  (b) the other five cycles died at the **warm relink step, mutation-independent**
  (`ld: unsupported tapi file type '!tapi-tbd' … libc++.tbd` — including M6 the comment-only control,
  which cannot change codegen; the cold build had linked fine) — an instrument failure of this host's
  environment, not a property of any mutant;
  (c) **custody kept**: the worktree restored byte-identical (script-verified; PM re-verified
  `status --porcelain` empty), and the relink failures' side effect — `build21/ripwire` destroyed —
  was PM-remedied by restoring the banked content-equivalent binary (`sbe-bin-FIXED-e4432b48a`,
  `+dirty`-stamped; gate re-verified 14/14 on the restored binary; the PM's verdict-time runs
  pre-dated the destruction and stand as evidence).
  The matrix is ruled **non-blocking for the verdict** (the base-binary run is the M1-equivalent, and
  arm binding is carried by the two-direction discrimination + the gate's per-arm greps), but the two
  substantive takeaways are recorded for the lane: the mutant **script** owes an M4 repair (declare
  `wsIt` before a plain `if`, or replace the whole block) before any future use, and **§3's "six
  mutants were run" is retracted to "M1 measured"** in any downstream telling.
- **Producer hygiene nit**: §8's table reports the llvm@21 leg's stamp as `built_from=e4432b48a`; the
  binary says `+dirty` (pre-commit build of identical content). Cosmetic in a hand-back; restated here
  so the record never silently carries a washed stamp.
- **PM**: this seat's first SBE-F1 probe round died on a self-inflicted ambiguity flaw (`alpha` defined
  in both members — the reply was `symbol ambiguous`, downstream of admission), re-run with unique
  symbols per member; and the `__asan_init` probe first used `nm -gU` (defined-globals only — wrong shape
  for an undefined ref), corrected to plain `nm`. Both disclosed per the instrument-error rule.
- **PM correction to Phase-0's Q2 row, non-material**: Q2's "$T/B" key contains a `\u202f` character
  between `A` and `/B` — the boundary refusal there is explained by the resulting NON-directory key
  (canonicalization of that non-path fails), not by the label sort; the finding's OWN decisive rows
  (§10 above) are unaffected and were re-measured clean.

## 13. VERDICT

**ACCEPTED — validation PASSES, with the two §11 doc fixes REQUIRED on the lane before any push.**

The implementation is verified correct and total against the pinned Shape-2 contract; the discrimination
is real in both directions on PM instruments; the battery is green on all three toolchains with the ASan
leg verified to the byte; the blast radius is 7/7 with the mcpattrparity budget diagnosis confirmed by a
fourth instrument; meta-gates and count accounting are clean and fully reconciled. The two §11 items are
measurement-wrong claims in shipped lane artifacts — the exact class this project writes down, never
waves through — so the *status flip to approved* is HELD until the producer's one-commit fixup is
re-verified (minutes). No ship act rides this verdict: the lane stays local, the push question stays
behind the #484 interlock per the operator's standing word.

**Fold plan:** fixup lands → PM re-verifies the two lines → three-place flip (spec/manifest history
event #52 `spec_approved`) → the push question goes to the operator with the menu (hold behind #484 /
queue behind the SRI lane branch / amend-in-place).

*Chain of custody:* phase0-report.md (pin) → 86757666d (mechanism+gate+register+changelog, one commit) →
e6009f79e (A5 retarget, test-only) → phase3-handback.md → THIS VERDICT (every claim re-run by the
validator's own instruments; failures disclosed §12; SBE-F1 filed §10 with its disposition).

---

## Addendum — the post-mortem fold, re-verified (PM, 2026-11-08T01:30Z)

The producer's close-out ("Post-mortem folded") was itself verified claim-by-claim; every load-bearing
item reproduced by this seat's instruments:

- **Retraction folded everywhere it was owed**: hand-back §3 now opens "CORRECTION — 'six mutants were
  run' was FALSE. One was."; the spec status narrative and the Progress box carry it. No status flip by
  producer hands — the spec correctly remains `in_progress`.
- **The tapi-tbd root cause CONFIRMED**: `/opt/anaconda3/bin/ld` is **ld64-530 (Sep 2022)**, FIRST on
  PATH (which -a; position 17), shadowing `/usr/bin/ld` **ld-1115.7.3 (Dec 2024)**; the 2022 linker
  cannot parse modern `.tbd` stubs. The producer's mutant script now pins PATH; PM's own PATH-pinned
  builds link clean (two full cycles, build rc=0 both). **Standing host rule banked: keep anaconda off
  PATH for any link on this box.**
- **The M4 repair and the A4 vacuity it exposed — reproduced end-to-end by PM** (`pmv-m4repro.sh`, the
  condition-not-binding mutation, uniqueness-guarded): with the per-member branch dead, the gate runs
  **rc=1 with exactly ONE red row — the new A4 unit-separator row — while the OLD A4 substring arm
  PASSES in the same run**: direct, single-run proof both that the old arm was satisfiable by the key's
  embedded member path (the vacuity, measured) and that the new arm binds the per-member branch.
  Restore+rebuild returns 15/15; final state verified: `built_from=83a99a098`, `mcp.h` byte-identical
  to HEAD, porcelain clean.
- **The producer's repaired-mutant artifacts are on disk and read**: `M4.out` (00:47Z) rc=1, exactly the
  US row; `M6.out` control (00:36Z) ALL PASS — the control now builds green under the PATH-pinned
  script, closing the "M6 was never evaluated" gap.
- **The hardened 15-row gate re-run by PM on four binaries**: base rc=1 with the same six rows
  (A1×3/A3×2/A4×1) and the new US row correctly GREEN at base (base's silence and the mutant's key-dump
  are different signatures — the discrimination table holds); build21 (83a99a098) 15/15, gcc 15/15,
  ASan 15/15, all rc=0.
- **Lane integrity**: `83a99a098` is test-only (+9, one file); `git diff 86757666d..HEAD -- src/` is 0
  lines; tree clean; remote lane branch untouched at the dispatch base — so the gcc/ASan legs at
  86757666d content remain valid evidence for the src-level verdict.
- **§11 STANDS UNPAID — the only outstanding item**: both wrong strings are still in the lane tonight
  (`changelog.d/stdio-bare-edit-escape.md:23` "first five assertions…"; gate header `:25`
  "(A1) and (A2) FAIL there"). The producer's close-out acknowledges the debt. The approval fold remains
  HELD on exactly this; nothing has flipped.

**Verdict UNCHANGED: ACCEPTED — two required pre-push doc fixes; the fold is immediate on their landing.**

---

## Addendum 2 — §11 CLOSED, the fold executed (2026-11-08T11:33Z, PM seat)

The fixup landed at `7721f6707` ("docs: correct the red-baseline measurement in the SBE gate and
changelog", 10:47:27Z, prose only) and this seat DELTA-VERIFIED it before flipping, with its own
instruments, nothing read back:

- **Discrimination re-proven at the head, both directions:** banked BASE `built_from=e4432b48a`
  → rc=1, **6 FAIL of 15 = (A1)×3, (A3)×2, (A4)×1**, 9 green — including (A4)'s key-shape row,
  green only vacuously at base, exactly as the producer's extra disclosure states; lane binary
  (stamp `83a99a098`) → **rc=0, 15/15 ALL PASS**.
- **Prose-only proven one grade beyond hunk-read:** the executable-line diff of the gate between
  `83a99a098` and `7721f6707` (comment lines stripped) is EMPTY, and `git diff 83a99a098..7721f6707
  -- src/` = 0 — so the gcc/ASan battery legs at `86757666d` content remain the evidence of record.
- **Both wrong strings grepped GONE tree-wide**; `bash -n` clean; the new wording matches §11's
  composition (six rows, per-arm set A1/A3/A4, A2 green and why).
- **Counts + meta-gates at the head, PM-run:** gatecount `--check` rc=0 (8 marked sites / 773;
  loop 776), gendocsmergecheck rc=0, nulbytecheck rc=0, bashsourcecheck rc=0 (binary-arg re-run —
  this seat's first call missed the binary arg, rc=2, a mis-shaped instrument re-run clean, the
  same shape-symmetry the producer disclosed for `_selfcheck.py`'s path). The producer's `rev-*`
  outputs match file-for-file, mtimes all postdating the commit.
- **The producer's beyond-the-two catch sustained:** the A4 vacuity disclosure describes real
  behaviour — my own base run shows that row green while its presence row is red.

**The fold is executed: status → approved (manifest, spec Status block — three places), history
event #53, this note the chain-of-custody delta. The #484 interlock still holds — head
`7721f6707` on no remote, remote lane branch at the dispatch base minutes before the flip.
Approval verdict: STANDING ACCEPTED, all required items paid.**
