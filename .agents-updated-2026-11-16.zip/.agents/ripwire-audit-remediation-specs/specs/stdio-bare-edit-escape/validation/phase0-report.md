# Phase-0 report — stdio-bare-edit-escape

**Producer:** local seat (Deepseek-V4.1-Flash "-1017"), 2026-11-07.
**Base:** `e4432b48a` — verified by instrument, not by memory: `./build21/ripwire --version` →
`ripwire 0.6.9 (dev, Clang 21.1.8, emit=std::print, built_from=e4432b48a)`. `strings` was not used
(it answers EMPTY on this host; `--version` is the instrument).
**Worktree:** `~/ripwire-scratch/sbe-r1` off `lane/stdio-bare-edit-escape`.
**Status of this report:** Phase 0 complete, shape **pinned** — with one finding that changes the
dispatcher's recommendation, and one host halt-condition, both declared below rather than absorbed.

---

## 1. What was measured, and on what

All five rows below are one run of `~/ripwire-scratch/logs/sbe-probe-base.py` and
`sbe-probe2.py` against the binary above, each in its own `mktemp` fixture, each in a fresh
short-lived server. Fixture shape: `A/` = launch cwd, `B/` and `C/` = sibling trees.

| # | launch | request | verdict | victim bytes |
|---|---|---|---|---|
| **P1** | `ripwire --mcp`, cwd=`A` | `path:"../B"` edit | **SERVED** | **changed** |
| **P2** | `ripwire B --mcp` | `path:"../A"` edit | `REFUSED(-32602)` | unchanged |
| **P5** | `ripwire --mcp`, cwd=`B` | `path:"."` edit | SERVED | changed |
| **Q1** | `ripwire --mcp`, cwd=`A` | `paths:[B,C]` edit | **SERVED** | **changed** |
| **Q2** | `ripwire B --mcp` | `paths:[B,C]` edit | **REFUSED(-32602)** | unchanged |
| **Q3** | `ripwire --mcp`, cwd=`A` | `path:B` (plain, absolute) | SERVED | changed |

**P1 is the red baseline and it reproduces SRI-F1 exactly**: the response is
`envelope_keys=['_fresh','_index','content']`, `applied='replace_symbol_body'`, `root='../B'`, and
the victim's bytes change. No refusal, no disclosure, and the receipt echoes the out-of-root target
as `root` — the honest-output gap the finding names.

**P2 and P5 are the controls**: the startup-root tier already refuses the out-of-root edit with the
exact shipped wording (`path outside workspace; start the server on that root or pass an absolute
in-root path`), and an in-root edit on the bare tier still applies. The instrument discriminates in
both directions, so P1 is a measurement and not a broken ruler.

### 1.1 The finding that changes the recommendation — Q2

`paths:[B,C]` is served on the bare tier (Q1) and **refused on the startup-root tier** (Q2) with the
same `path outside workspace` sentence. The cause is mechanical: `mcp.h:1898` rebinds `path` to
`mcpWorkspaceKey(...)`, which is `root1\x1froot2\x1f` (`mcpindex.h:947-961`) — a synthetic key, never
a filesystem path — and `mcpPathInsideRoot` (`mcp.h:678`) judges it as a path, so containment fails
by construction.

That is a **pre-existing, tier-asymmetric defect that is not this lane's**, and it bears directly on
the shape pin: `multirootcheck.sh:446-462` records Decision A/A11 (2026-07-11) — "MCP EDIT verbs
accept `paths`, multi-root writes to the REAL disk file" — and asserts that a cross-workspace edit
via `paths[]` **returns success**. Today that assertion holds only on the bare tier, i.e. **only by
riding the escape**. On the pinned tier Decision A11 is already broken.

---

## 2. The shape pin

**Pinned: Shape 2 — the honesty floor.** Implemented as a disclosure field on the edit receipt, not
as a new envelope sibling.

The dispatcher recommended Shape 1 and flagged it as a recommendation, not a pin. Phase-0 evidence
overturns that recommendation on implementability, not on strength:

1. **Shape 1 as drafted is not a one-line arm.** The drafted predicate
   `isMcpEditVerb( name ) && !mcpPathInsideRoot( policy.assumedRoot, path )` refuses every `paths`
   workspace, because a workspace key is not a path (§1.1). Writing it correctly requires judging
   containment *per member root*, and the member that the edit actually lands in is resolved later,
   inside `runEditVerb` — after the gate site at `mcp.h:1944`. Honest Shape 1 therefore moves the
   admission decision into the resolver: a scope expansion the spec did not budget and the dispatch
   note did not anticipate.
2. **Shape 1 would complete the destruction of a documented decision on its last surviving tier.**
   A11 is honored today only on the bare tier (Q1 vs Q2). A key-blind arm takes that away, so the
   lane would ship a capability regression and call it parity.
3. **Blast radius is four gates, one of them silently vacuous.** Every one of these runs a *bare*
   launch (so `assumedRoot` = the repo root, per `pargates.py:704` running gates with `cwd=root`)
   and edits a `mktemp` corpus, i.e. outside it:

   | gate | what it needs | under a key-blind Shape 1 |
   |---|---|---|
   | `multirootcheck` | A1 asserts `paths[]` edit **succeeds** | FAIL (and A11 contradicted) |
   | `mcpframehonestycheck` | (J) "still APPLIES (the rule does not over-reach)"; (K) `outSet` must APPLY | FAIL |
   | `mcpreloadasancheck` | M2 needs `insert_after_symbol` / `replace_symbol_body` to return `ok` | FAIL |
   | `mcpeditracecheck` | F1 needs the edit to apply | **passes VACUOUSLY** — `applied=false` counts as `served`, so a broken edit reads as a green F1 |

   The fourth is the worst: `mcpeditracecheck.sh:145` treats "refused" and "serialized correctly" as
   the same outcome. Shape 1 would silently convert an apply-expectation into a no-op and the suite
   would not say so.

**Why Shape 2 is the right pin and not a retreat.** The harm SRI-F1 names is not that the edit is
possible — the bare tier is the *soft* tier by design (`mcp.h:524-533`: `assumedRoot` is "the softest
default", consulted only when a request omits `path`). The harm is that the edit is **silent**: no
refusal *and* no disclosure, while the receipt dresses an out-of-workspace write as routine by echoing
it as `root`. That is precisely the class the honesty rules own — every truncation and degrade in this
codebase is disclosed. Shape 2 closes the named harm completely, costs no capability, and leaves the
A11 question where it belongs (a separate finding, §4).

**What Shape 2 must be, to be total** (the spec's own Failure Modes demand this):
- The disclosure rides the **edit receipt**, beside the existing conditional siblings
  (`seamDisclosureJson`, `post_check_unavailable`, `root`) at `mcpedit.h:1415-1445` — receipts
  already vary their key set by condition, so this is the idiomatic site and it leaves the envelope
  key set untouched (no parity risk for `mcpattrparitycheck`).
- It is emitted on **every** out-of-root edit on the assumedRoot tier, and **absent** on every in-root
  edit. Both sides asserted — presence-only is the vacuity `mcp-token-hygiene` already caught once.
- It names the assumed root and the fact, in the honest-output voice the codebase already uses.

**Literal (pinned):**

```
"out_of_workspace":"this edit's target is outside the workspace this server assumed at launch (<assumedRoot>) — the write was applied; start the server on the tree you mean to edit to have it pinned"
```

The wording reuses the shipped remedy sentence ("start the server on that root", `mcp.h:1952`) rather
than inventing a second vocabulary — the dispatch note's refusal-reuse constraint, applied to a
disclosure. The `-32602` family is deliberately **not** reused verbatim: these are different speech
acts (a refusal vs a disclosure), and borrowing the refusal sentence for a served edit would be a lie
in the other direction.

---

## 3. Anchors, re-pinned live at `e4432b48a`

The spec and dispatch note cite the pre-drift numbering. Live values, each read this Phase 0:

| what | spec/note said | **live** |
|---|---|---|
| the pin gate | `1944` | **`1944`** ✓ unchanged |
| the gate's refusal | `1950` | **`1952`** |
| HTTP/pinned-tier refusal | `1921` | **`1921`** ✓ |
| `mcpStdioPolicy` assumedRoot block | `3074-3082` | **`3074-3076`** |
| `paths` → workspace key rebind | — | **`1898`** |
| `mcpPathInsideRoot` | — | **`678`** |
| `mcpEnvelopeNoteField` | — | **`664`** |
| `_assumed_root` envelope splice | — | **`1748`** |
| edit arm (`oc.ok ? textResult(oc.resultJson)`) | — | **`1838`** |
| `mcpWorkspaceKey` | — | **`mcpindex.h:947`** |
| edit receipt assembly | — | **`mcpedit.h:1415-1445`** |

The D4 comment and the mechanism do sit together (`1940-1944`), as the note says. They must travel
with the new disclosure in one commit.

---

## 4. Findings filed, not absorbed

**SBE-F1 — a `paths` workspace key fails containment on the pinned tiers.** `mcp.h:1898` rebinds
`path` to a synthetic `\x1f`-joined key; `mcpPathInsideRoot` judges it as a path and refuses. Measured:
Q2 refuses while Q1 serves. Consequence: Decision A/A11 (`multirootcheck.sh:446-462`) is honored only
on the bare tier today, and `multirootcheck` A1 is green only because the escape exists.

This is **out of scope for this lane** — it lives on the pinned tier, which the spec lists as out of
scope, and fixing it is its own design question (per-member-root containment, decided where the target
resolves). It is filed here because it is (a) a real defect, (b) the reason Shape 1 cannot be a
one-line arm, and (c) the thing that would have made Shape 1 look correct while quietly deleting A11.
**It needs a node of its own; do not fold it into this lane.**

---

## 5. Host halt-condition (declared, worked around, and it matters for the battery)

**The new base does not compile with this host's system toolchain.** `src/forfilesyms.h:400` (added by
the 265-commit drift, one of the 14 new gates' headers) uses `std::ranges::find_last_if`, C++23. Every
system SDK on this host predates it:

```
MacOSX.sdk, 14.5, 15, 15.2  →  no __algorithm/ranges_find_last.h, 0 occurrences of find_last_if
Apple clang 16.0.0 (system), Homebrew llvm 19.1.6, llvm 21.1.8  →  all fail with the system libc++
```

The first build died at `rc=2` with exactly one error, `no member named 'find_last_if'`.

**Workaround in use:** Homebrew **llvm@21.1.8 with its own libc++** (`-nostdinc++ -isystem
/usr/local/opt/llvm@21/include/c++/v1`, `-L…/lib -Wl,-rpath,…/lib`). That builds the tree clean:
`build rc=0`, 0 errors, and the resulting binary reports `built_from=e4432b48a`. Script:
`~/ripwire-scratch/logs/sbe-build21.sh`.

**Why this matters beyond my scratch:** the local `build/` is now a *non-default toolchain* build. CI's
macOS legs use macos-26 / Xcode 26.6 (`ci.yml:421`), whose libc++ is new enough, so this is a host
limitation and not a repo defect. But any local verdict I hand back is a verdict about
llvm@21-built code. If the PM's own validation builds with the system toolchain, it will halt at the
same line — that is expected and is not a lane defect. Flagging it so the halt is not misread as a red.

---

## 6. What the pin commits this lane to

- **Shape 2**, receipt-level disclosure, on the assumedRoot tier's out-of-root edits only.
- Gate asserts **both** sides: present out-of-root, absent in-root, across all three edit verbs; plus
  the pinned-tier refusals stay green (P2) and the in-root bare-tier edit still applies (P5).
- Red baseline for the gate is P1 today: an assertion that the out-of-root edit's receipt carries the
  disclosure **fails at base** (it carries no such field) and passes after the fix.
- The `.docx`-style meta-gate duties are pre-loaded: canonical `ok()`, `clean-env.sh` if any git
  fixture is built, sweep-audit before every push, GEN-DOCS-MERGE same-commit.
- **No `multirootcheck` / `mcpframehonestycheck` / `mcpreloadasancheck` / `mcpeditracecheck` edit is
  needed under this pin** — that is the concrete cost difference between the two shapes, and it is
  the reason the pin is defensible.

Phase 1 proceeds under this pin.
