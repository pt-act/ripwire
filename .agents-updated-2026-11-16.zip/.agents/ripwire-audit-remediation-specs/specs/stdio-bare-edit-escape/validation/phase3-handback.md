# SBE — Phase 3 hand-back (completion report)

**Spec:** `stdio-bare-edit-escape` (Tier 2, `src/`-bearing). **Base:** `e4432b48a`.
**Producer:** local seat. **Status at hand-back:** Phases 0–3 complete. The battery is measured on
three toolchains (§8), not asserted. Ship keys not exercised — §10.

## 1. The pin (Phase 0) — Shape 2, on evidence, against the dispatcher's recommendation

The dispatch note recommended Shape 1 (parity). I pinned **Shape 2** (honesty floor) instead,
because six measurements on my own `built_from=e4432b48a` binary contradicted the premise that
Shape 1 was a one-line arm:

| probe | launch | outcome |
|---|---|---|
| P1 | bare `--mcp`, cwd=A | out-of-root edit **applied**, `root:"../B"`, no refusal, no disclosure |
| P2 | `ripwire <root> --mcp` | refuses `-32602` |
| P5 | bare, in-root edit | applied |
| **Q1** | bare, `paths:[A,B]` edit | **served** |
| **Q2** | startup-root, the SAME `paths` request | **refused `-32602`** |

Q1/Q2 are the load-bearing pair: the tiers disagree about the *same* request, and the reason is
that a workspace key is `root1\x1froot2\x1f`, not a path — so containment fails by construction.

Three grounds for Shape 2, each falsifiable:

1. **Shape 1 is not a one-line arm.** It requires per-member-root containment resolved inside
   `runEditVerb`, *after* the gate has already replaced `path` with a key. That is a restructure
   of the gate's input, not a line in it.
2. **A key-blind arm would delete A11** (multi-root edits) on the last tier that honours it.
3. **Blast radius is four gates** — and `mcpeditracecheck` would pass **vacuously**: its
   `served` predicate counts `applied=false` as served, so a refusal silently converts an
   apply-expectation into a no-op assertion. A gate that stops asserting what it claims is worse
   than a red one.

Full measurement record: `validation/phase0-report.md`.

## 2. What was built (commits on `lane/stdio-bare-edit-escape`)

| commit | content |
|---|---|
| `86757666d` | `src/mcp.h` (+82/−1): `mcpEditOutOfAssumedRootNote`, the `outOfWorkspaceNote` field, the `_out_of_workspace` envelope splice, the `editResult` decision site, and the extended D4 tier-split comment. Plus `test/assumedrooteditdisclosurecheck.sh`, its `test/regression.sh` line in the alphabetically-correct slot, and `changelog.d/stdio-bare-edit-escape.md` — **all one commit** per GEN-DOCS-MERGE. |
| `e6009f79e` | gate: A5's byte-identity half now measures the file the edit actually names. |
| `83a99a098` | gate: **A4 vacuity fix** — assert the absence of the unit separator, not just the presence of a member path the key embeds. |

The comment extension is deliberate and is the SRI-F1 origin class closed at source: the old
comment documented the tier split as stopping at the startup-root tier, and the residual was
invisible *because the comment stopped there*. The new text states all three tiers:
**startup root ⇒ refuse; bare ⇒ disclose; read verbs ⇒ neither, any tier.**

The disclosure is gated on `oc.ok` — a *refused* edit never carries "the write was applied".

## 3. Discrimination — measured both directions, not asserted

| | gate result |
|---|---|
| **base** `e4432b48a` | **rc=1, 6 FAIL rows** (A1 ×3, A3 ×2, A4 ×1) |
| **fixed** `83a99a098` | **rc=0, 15/15 PASS** |

The control arms (A2 absence, A5 refusal + byte-identity, A6 read) are green on **both**
binaries — which is what makes the six reds *discriminating* rather than merely failing.

Arm count went 14 → 15 in `83a99a098` (the A4 vacuity fix, below), so the fixed-side pass count
in earlier drafts of this report (14) is superseded. The base-side red count is unchanged at 6 —
the new arm fails at base too, which is why it is a *discrimination* fix and not a padding one.

**Mutant M1** (remove the disclosure computation) kills exactly A1/A3/A4 and leaves A2/A5/A6
green: the arms bind their stated mechanisms, not incidental behaviour.

### CORRECTION — "six mutants were run" was FALSE. One was.

This section previously claimed a six-mutant sweep. **It is retracted to "M1 measured."** The
PM seat's post-mortem disproved it, and my own logs agree: `~/ripwire-scratch/logs/sbe-mutant/`
contains exactly **one** result file, `M1.out` — M2–M6 left no `.out` at all. A mutant with no
output was never evaluated, and I reported it as if it had been.

Two distinct causes, both outside the gate's subject:

1. **M4 as scripted cannot compile.** The mutation replaces the C++17 if-init-statement
   `if( const auto wsIt = mcpWorkspaceRegistry().find( path ); wsIt != … )` with `if( false )`,
   which deletes `wsIt`'s declaration while the loop body still names `wsIt->second` →
   `use of undeclared identifier 'wsIt'`. That is a defect in the mutant script, not in the
   mechanism it was meant to probe. **The script owes an M4 repair before any reuse** — hoist the
   lookup into a preceding statement and mutate the condition, not the binding.
2. **Every other cycle died at the warm relink**, mutation-independently — the re-run logged
   `ld: unsupported tapi file type '!tapi-tbd' … libc++.tbd`, including on **M6**, a comment-only
   control that cannot change codegen. My own session died differently (`Terminated: 15` — harness
   SIGTERM at `main.cpp`) but to the same effect. Either way the failure is a **host-environment
   instrument failure**, not a property of any mutant.

**What this does and does not weaken.** The discrimination claim rests on the two-direction
pair — base rc=1 / 6 FAIL rows versus fixed rc=0 / 14 PASS — plus the gate's per-arm greps, not
on the mutant matrix. The PM seat has already declared the matrix non-blocking, and
M1-alone still binds what M1 binds: the disclosure computation feeds A1/A3/A4 and nothing else.
What is genuinely lost is the *independent* cross-check that M2 (absence half) and M3 (tier
guard) bind their arms — so those two arms rest on the two-direction evidence alone. Stated
plainly rather than papered over.

### …and repairing M4 found a REAL VACUITY in A4

I repaired the mutant (mutate the condition, not the binding) and ran it. It **compiled — and the
gate stayed GREEN: `rc=0, 0 FAIL rows`.** That is not a null result; it is my A4 arm proving
nothing.

Mechanism, confirmed in the code: the per-member branch was deleted, so control fell through to
the generic fallback at `src/mcp.h:747` —

```cpp
return "[out-of-workspace edit: " + path + " is outside …";
```

— and for a workspace request **`path` IS the key** `"B\x1fC\x1f"`, so the sentence contains the
member root **B verbatim**. A4's assertion was `*'_out_of_workspace'*"$TMP/B"*`, a substring test
that the key-blind form satisfies by accident of embedding. **A4 was vacuous against exactly the
mutation it existed to catch** — the same vacuity class I rejected Shape 1 over, sitting inside my
own gate.

**Fixed** (commit pending): A4 now also asserts the thing the key-blind form *cannot* produce — no
unit separator in the disclosure. A per-member sentence names one root; a dumped key always carries
`\x1f`. Fixed binary: **15/15 PASS**. M4 re-run against the hardened arm is in progress and must
show A4 RED for this to be considered closed.

This is the single most useful outcome of the post-mortem: the mutant sweep was declared
non-blocking *because* it was empty — and the one armed mutant I repaired immediately found a hole
the two-direction evidence could not see.

**Side effects, disclosed.** The failed relinks destroyed `build21/ripwire` as a side effect; the
worktree was restored byte-identical (script-verified plus a clean `status --porcelain`, re-checked
here). The binary was restored from the banked content-equivalent copy and re-verified 14/14, but
it stamps `built_from=e4432b48a+dirty`, so **I do not cite it as verdict evidence** — a clean
`--fresh` rebuild is running and its stamp will replace that row when it lands. My verdict-time
runs pre-dated the destruction and stand as evidence on their own.

## 4. The gate's contract (six arms)

- **A1** bare tier, out-of-root: applied + `_out_of_workspace` present + **names the assumed
  root** + carries the **shipped** remedy wording.
- **A2** bare tier, in-root: applied + disclosure **absent** — the vacuity half. Presence-only
  would pass a disclosure emitted unconditionally, telling every routine caller it had left.
- **A3** all three edit verbs disclose (not just the probe's one).
- **A4** a `paths[]` workspace discloses the **member** root, not the synthetic key, and still
  applies (A11 survives) — **now two assertions**: the member is named *and* the disclosure
  carries **no unit separator**, which is what the key-blind form cannot produce.
- **A5** startup-root tier still refuses `-32602` with the shipped sentence **and** leaves the
  named file byte-identical.
- **A6** off-root read still answers (over-block control).

## 5. Blast radius — measured, and the pin's cost claim holds

Every gate the Phase-0 report named as at-risk, run against the fixed binary:

| gate | result |
|---|---|
| `multirootcheck` | PASS (A11 survives) |
| `mcpframehonestycheck` | PASS (247 s) |
| `mcpeditracecheck` | PASS — **no vacuity**, the trap Shape 1 would have sprung |
| `mcpcontractcheck` | PASS |
| `mcpeditpresencecheck` | PASS |
| `editroundtripcheck` | PASS |
| `mcpattrparitycheck` | PASS |

**One red that was not a red.** `mcpattrparitycheck` first reported `wall=300.7s` / fail under
`pargates -j 2`. `DEFAULT_TIMEOUT_SEC = 300`, and the direct run is green at **rc=0, 258 s**
(`-j 1 --budget-scale 3`: pass at 276 s). That was a **budget timeout under contention**, not a
divergence — three instruments agree. Recording it because a red that is really a ruler is the
suspect-instrument class this project keeps re-learning.

The pin's cost claim — *"no `multirootcheck` / `mcpframehonestycheck` / `mcpreloadasancheck` /
`mcpeditracecheck` edit is needed"* — is now **measured true** for all four.

## 6. Meta-gates (all green, from Phase 2)

- `nulbytecheck` **ALL PASS** (fixtures are text-only; nothing owes an allowlist row — checked,
  not assumed: `NULs=0` by byte count, not `grep -c` which returns line counts)
- `gitenvhermeticcheck` **ALL PASS**, 187 gates — no git fixture is built, so no `clean-env.sh`
  sourcing is owed; the gate's header says why rather than silently omitting it
- `gateexitcheck` **ALL PASS** — canonical `ok()` from commit one; G1 probes per distinct
  definition text, so the byte-identical canonical shape is covered
- Real-harness run: `gates=1 pass=1 skip=0 fail=0 wall=1.5s tree_writes=0`

## 7. Count accounting — named, never conflated

Base drift alone reports `773→775`; with this gate it reports `773→776`. **My contribution is
exactly +1**; the snapshot staleness is inherited from the base, not created here. The three
count sites (shard sum / absorb loop / marked docs) are untouched — the absorb-loop line is the
only one this lane edits, which is the GEN-DOCS-MERGE rule.

## 8. Battery — measured on three toolchains

All three built from the lane and **all three run the gate green**:

| leg | binary | `--version` | SBE gate |
|---|---|---|---|
| **clang 21.1.8** (llvm@21 + own libc++) | `build21/ripwire` | `built_from=83a99a098` ← **clean, lane head** | **15/15, rc=0** |
| **GNU 14.2.0** (`gcc-14`) | `buildgcc/ripwire` | `built_from=86757666d` | **15/15, rc=0** |
| **ASan** (address+undefined+integer+float, llvm@21) | `asan/ripwire` | `built_from=86757666d` | **15/15, rc=0, 0 sanitizer reports** |

**Why the gcc/ASan legs still stamp `86757666d` and why that is valid:** the two commits since
(`e6009f79e`, `83a99a098`) are **test-file only** —
`git diff --stat 86757666d..83a99a098 -- src/` is **empty**. The `src/` the gcc and ASan binaries
were built from is byte-identical to the lane head, so they are valid evidence for the code; they
simply predate two changes to the gate that tests it. Their earlier 14/14 results were re-run
against the hardened 15-arm gate and both pass.

> The clang row read `built_from=e4432b48a`, then `…+dirty` after the restored binary came back
> from the mutant-sweep side effect, and is now a **clean `--fresh` rebuild at the lane head with
> no `+dirty` suffix** — certifiable provenance. The `+dirty` build is no longer cited anywhere.

Blast-radius gates re-run on the **gcc** binary too, so the result is not toolchain-specific:
`multirootcheck`, `mcpeditracecheck`, `mcpcontractcheck` — all rc=0 / ALL PASS.

**The ASan leg was verified before being trusted**, per the SRI lesson that exit 0 is not a
clean bill:

- `__asan_init` present in the binary — it really is instrumented, not a plain build wearing the
  name.
- `otool -L` names **llvm@21's own libc++** and `libclang_rt.asan_osx_dynamic.dylib` — headers
  and dylib from one release, which is the failure `CONTRIBUTING.md` warns about when a Homebrew
  clang links the system libc++ against its own headers.
- A direct run through the escape fixture: **exit 0, zero `ERROR: *Sanitizer` / `SUMMARY:` lines**,
  disclosure present, write applied. The 301 bytes on stderr are the benign
  `[math degraded] edit-check: no git HEAD baseline` notice a non-git temp dir produces —
  checked by reading them, not by assuming stderr means bad.

**`llvm@22` — the version `CONTRIBUTING.md` names — is not installed on this host** (17/19/21
only). I used llvm@21 **with its own libc++**, which is the same recipe pointed at the compiler
that is here, and confirmed the linkage rather than hoping. Note also that this host cannot
reproduce macOS-26 ASan issues in either direction, so CI remains the authority on the AppleClang
leg.

**Both-flavour concern does not apply**: my mechanism uses **no `DISCLOSE`**. It is a plain
`std::string` on the policy struct, spliced by `textResult`. A release build that compiles the
trace out cannot blind this disclosure — verified by grep, not assumed.

**Host halt-condition, restated because it will bite the validator:** the base does not compile
with the system toolchain (`src/forfilesyms.h:400` needs C++23 `find_last_if`; every SDK here
predates it). CI's macos-26/Xcode 26.6 is fine. If the validator's own build halts at that line,
it is the host, not the lane. Build times here were brutal — the ASan `main.cpp` TU alone took
~105 minutes —— so budget accordingly rather than reading a slow build as a hang.

### The `tapi-tbd` linker failure — ROOT-CAUSED, and it was never the mutants

The PM's post-mortem reported five mutant cycles dying at relink with
`ld: unsupported tapi file type '!tapi-tbd' … libSystem.tbd`, mutation-independently, plus M6 the
comment-only control. That is now **fully explained**, and it reproduces on demand:

```
/opt/anaconda3/bin/ld   →  ld64-530, built Sep 2022   ← first on PATH
/usr/bin/ld             →  ld-1115.7.3, built Dec 2024
```

Anaconda ships a 2022-era linker that shadows the system one and **cannot parse a modern `.tbd`
stub**. A `--fresh` configure dies at the compiler probe; every relink dies thereafter. With
`PATH=/usr/bin:/bin:/usr/sbin:/sbin:/usr/local/bin` the same configure and build succeed.

So the sweep's five deaths were a **host PATH problem with a one-line fix** — not a property of
any mutant, and not "unreproducible on this host": it reproduces every single time until PATH is
corrected. **Anyone rebuilding this lane on this host must keep anaconda off `PATH`.** The mutant
script now does that explicitly.

My own session's cycle died differently (`Terminated: 15`, harness SIGTERM during `main.cpp`) —
same outcome, different cause. Both are instrument failures. **Neither is a property of the
gate or of any mutant.**

## 9. Filed out of scope — SBE-F1, and a correction I owe you

`findings/SBE-F1-paths-key-containment.md`. **Read this one; it matters for the verdict.**

A `paths[]` workspace key (`"root1\x1froot2\x1f"`) is judged by `mcpPathInsideRoot`, which is a
**component prefix test on a string**. Applied to a key, that asks only *"does the key start
with the root?"* — and the key starts with whichever member **sorted first**
(`src/workspace.h:163` sorts by label; argv order cannot change it). So **one member decides
for all of them**:

| members | sorted first | pinned-tier verdict |
|---|---|---|
| `[R/a, R/b]` both inside | `a` inside | SERVED |
| `[R/a, T/O1]` mixed | `O1` outside | REFUSED |
| `[T/O1, T/O2]` both outside | `O1` outside | REFUSED |
| `[R/a, RR/z]` mixed | `a` **inside** | **SERVED — the outside file is rewritten, silently** |

The fourth row is a **silent cross-workspace write on the pinned tier**: no refusal, no
disclosure. Identical on the base binary, so it is not mine. It is the same *silence* class as
SRI-F1, surviving on the tier an operator picks **because** it pins — which means SBE closes the
class on the soft tier while the hard tier keeps it.

**My first version of this finding was wrong and I retracted it.** I claimed the pinned tiers
*falsely refused* a legitimate all-in-workspace `paths[]` edit. Two probes supported it; when I
varied the variable that actually drives it — which member sorts first — the picture inverted.
Two of those early probes were also measuring the *nested-roots* guard, not containment at all.
The retraction, the four wrong probes and the reason I believed them are kept in the finding's
§6, because the reason is the reason this defect survives review.

**SBE's own gate is not affected**: A4 uses a workspace whose members are *both* outside the
assumed root and SBE's helper iterates every member, so A4's disclosure is real (measured:
present, naming the out member). A4 is not vacuous — I checked precisely because that was the
failure mode I had predicted for Shape 1.

Notable: `hardenRequestRoot` (`src/mcpindex.h:967`) **already solved this exact problem** for the
git-trust boundary and states the rule in its comment — "a registered multi-root workspace KEY is
not a directory, so each of its member roots is probed instead". The correct pattern is in the
file twice; the containment gates are the ones that never adopted it.

## 10. Ship keys

Not exercised. The lane branch is local; no push, no PR. The #484 interlock holds.

## 11. The verdict's two required fixes — landed at `7721f6707` (prose only)

Both §11 items are corrected on the lane, and the correction was **measured, not remembered**. On the
banked base binary (`sbe-bin-BASE-e4432b48a`, base `e4432b48a`):

| arm | rows | at base |
|---|---|---|
| (A1) | 5 | **3 FAIL** — no `_out_of_workspace`; no assumed root named; remedy family not reused |
| (A2) | 2 | 2 PASS — applied, and the disclosure is absent |
| (A3) | 2 | **2 FAIL** — neither `insert_before_symbol` nor `insert_after_symbol` discloses |
| (A4) | 3 | **1 FAIL** — no per-member disclosure; the applied row and the key-shape row pass |
| (A5) | 2 | 2 PASS — the pinned refusal and byte-identity are untouched |
| (A6) | 1 | 1 PASS — an off-root read still answers |

`rc=1`, **6 FAIL of 15 = A1 ×3, A3 ×2, A4 ×1**. Fixed build at the same content: `rc=0`, 15/15.
Both figures reproduce after the fixup commit, so the prose matches the behaviour it describes.

What was wrong, and why it mattered beyond wording:

- **The gate header** said "(A1) and (A2) FAIL … and the refusal/absence arms pass" — **self-contradictory**,
  because A2 *is* the absence arm. It now names A1/A3/A4 as red and A2/A5/A6 as green, and states why the
  asymmetry is the point: A2 red would mean the fix had begun leaking into in-root edits.
- **The changelog** said "the first five assertions" — a row count with no arm meaning, and wrong as a
  row count too. It now states six of fifteen, and names the arms.

**One addition beyond the two required fixes**, disclosed because a bare pass count would overstate the
evidence: of the nine green rows at base, **A4's key-shape row is green only vacuously** — a build that
emits no note at all cannot emit a malformed one. That row means nothing until A4's presence row above it
is green, and the header now says so. This is the same vacuity class that produced the A4 repair in
`83a99a098`; leaving it unmarked in the header would have re-introduced it one layer up, in the prose.

Prose only: no assertion, no row count, no `rc` changed. Meta-gates re-swept green on `7721f6707`
(`gatecountcheck`, `gendocsmergecheck`, `bashsourcecheck`, `nulbytecheck`, `gateexitcheck`,
`gitenvhermeticcheck`), and the count instruments are undisturbed — the edited files carry no marked
count site, and the snapshot-versus-loop divergence (773 vs 776) is the by-design mid-lane state that
`manifestcheck` prints as INFO and that only a refresh or a release asserts equal.

Still unpushed. The flip is the PM's act on its delta re-verify.
