# stdio-bare-edit-escape — pin the bare stdio edit tier

## Header

```yaml
id: stdio-bare-edit-escape
type: unit
version: 0.1.0
manifest: ../../manifest.yml
```

## Objective

Close **SRI-F1** (filed by the security-regression-integration Phase 0, 2026-11-06, reproduced
independently by both seats — see `../security-regression-integration/findings/stdio-bare-edit-escape.md`):
a bare `ripwire --mcp` launch serves the **assumedRoot** tier (`src/mcp.h:3074–3082`, the R2a
"softest default"), which is the one stdio edit-pin gate tier the pin never enters — the gate at
`src/mcp.h:1944` tests `!policy.defaultRoot.empty()`, and the bare launch leaves `defaultRoot`
empty. On that tier an edit verb whose `path` names any directory outside the launch cwd is
**silently applied**: the response envelope carries no refusal and no disclosure, and the result
echoes the out-of-root target as `"root"` — an honest-output gap in its own right. The pinned
tiers (positional startup-root stdio, both HTTP forms) already refuse `-32602`.

This spec closes the bare-tier gap, in one of two shapes the planning cycle pins with upstream's
review in the loop:

- **Shape 1 (parity — the strong fix):** the assumedRoot tier joins the same edit-pin gate —
  `isMcpEditVerb( name ) && !mcpPathInsideRoot( policy.assumedRoot, path )` → the same `-32602`
  refusal wording family the pinned tiers use. Read verbs stay unrestricted on every tier.
- **Shape 2 (honesty floor — the weaker fix):** the tier stays permissive, but the edit result
  envelope DISCLOSES explicitly (assumed root + out-of-workspace fact), so no caller can read
  an out-of-workspace edit as in-workspace routine.

## Scope

**In scope:**
- The bare-stdio tier's **edit-verb** admission only (the three edit verbs; read verbs keep the
  documented "a request may name any path" contract on every tier — s-r-i's AC-1b relies on it).
- The chosen shape's mechanism, its refusal/disclosure literals, and the condition the gate
  asserts (per the planning cycle's pinning).
- A gate owning the bare tier's behavior with the SRI-F1 repro as its red baseline (the escape
  is red at base today; the fix turns it green under shape 1, turns it green-as-disclosed under
  shape 2 with the envelope greppable).
- Registration in `test/regression.sh` same-commit; changelog fragment; `--help`/docs wording
  per AGENTS.md if any user-facing text changes.

**Out of scope:**
- The pinned tiers (startup-root stdio, both HTTP forms) — working as shipped; asserted by
  s-r-i's A2a/A2h arms.
- Read verbs' path freedom (unchanged, documented).
- Any caps/token/auth work (other lanes own those surfaces).

## Interfaces

### Produces

- **bareStdioEditAdmission** *(DRAFT — shape + literals pinned in the planning cycle at
  dispatch)*: the behavioral contract for the bare tier's edit verdict — under shape 1, the
  refusal (`-32602` + the pinned wording, victim bytes unchanged); under shape 2, the
  disclosure envelope fields on every out-of-root edit (and their absence on in-root edits).
  Exported as the pinned strings this spec's gate greps; the s-r-i suite stays the owner of the
  pinned tiers and does not consume this.

### Consumes

- *(none — an independent finding beyond the 2026-09 audit's five; no other spec's interface is
  load-bearing here. Provenance: SRI-F1's finding file, not a spec dependency.)*

## Acceptance Criteria

*(DRAFT v0.1.0 — pinned at the planning cycle. The draft below carries the finding's measured
facts as the starting shape.)*

1. **DRAFT — the escape is closed on the bare tier per the pinned shape.** `ripwire --mcp`
   launched in dir A; scripted `analyze` + `replace_symbol_body` against dir B: shape 1 →
   refused `-32602` with the pinned wording, B's sha256 unchanged; shape 2 → applied, but the
   envelope DISCLOSES the out-of-workspace edit explicitly (fields pinned in the planning
   cycle). **Red at base today** (SRI-F1's two-seat repro is the red baseline).
2. **DRAFT — the pinned tiers keep refusing** (regression): startup-root stdio and both HTTP
   forms still refuse `-32602`, victims unchanged — the fix must not disturb the pinned tiers.
3. **DRAFT — read verbs still answer any path on every tier**: an off-root read via bare stdio
   still answers (the documented read contract; the fix must not over-block).
4. **Registration + docs per house mechanics**: the gate file + loop line + changelog fragment
   in the same commit; count sites untouched (the GEN-DOCS-MERGE discipline).
5. **The battery green on the fixed tree** — both toolchains per the #397/#469/#484 pattern;
   ASan/LSan per AGENTS.md (a `src/` change rides the sanitizer requirement).

## Implementation Notes

- The mechanism sites: `src/mcp.h:1941–1947` (the pin gate + the tier-split comment — the
  comment itself must move/extend to document the bare tier's new behavior; SRI-F1's origin is
  exactly a comment/mechanism split); `:3074–3082` (`mcpStdioPolicy`'s assumedRoot block, R2a).
  Shape 1 adds the assumedRoot arm inside the existing gate; shape 2 extends the edit-result
  assembly (`src/mcpedit.h`) with the disclosure.
- The refusal wording should REUSE the pinned-tier family ("path outside workspace; …") — a
  new wording doubles the grep surface for no value.
- Upstream sensitivity: the D3/D4/X7 design comment is upstream's own words; the PR story
  must address it head-on with the Phase-0 evidence (the pin's tier comment vs the silent
  escape), not slip the arm past it.

## Failure Modes

### The fix over-blocks legitimate multi-tree workflows

- **Trigger:** an agent host deliberately edits a sibling tree via bare stdio.
- **Expected handling:** shape 1's refusal names the existing remedy (start on the root you
  want to edit); upstream may rule shape 2 for exactly this reason — then the disclosure must
  be total (every edit result on the bare tier carries root attribution).

### The disclosure is silently droppable (shape 2)

- **Trigger:** a future refactor rebuilds the envelope and drops the disclosure field.
- **Expected handling:** the gate greps the disclosure on the out-of-root path AND its absence
  on the in-root path — mutation-style coverage, not presence-only.

### The comment drifts from the mechanism again

- **Trigger:** the SRI-F1 origin class — a comment documenting intent the code outgrows.
- **Expected handling:** the gate pins the behavior, not the comment; the comment and mechanism
  travel in the same commit by review convention.

## Dependencies

- *(none — independent. Provenance is SRI-F1's finding file within
  `../security-regression-integration/findings/`, not a spec dependency.)*

## Consumers

- *(none declared yet — audit-validation-standalone may consume the closure the way it consumes
  the five security fixes; settled when this spec's planning cycle runs.)*

## Status

**Status:** approved  # TERMINALLY VALIDATED & APPROVED 2026-11-08T11:33:00Z by the validator-of-record (PM seat; VALIDATION_PROTOCOL step 2 / Q10 option (a)) — the flip on the pinned timing (event #52: on the §11 landing). The §11 fixup was DELTA-VERIFIED by PM instruments before the flip: base rc=1, 6 FAIL (A1×3, A3×2, A4×1), 9 green incl. the A4 key-shape row (vacuous at base, as disclosed); lane rc=0 15/15; prose-only proven by executable-line identity 83a99a098..7721f6707 = EMPTY, src/ drift 0; counts + meta-gates green at the head. Lane head `7721f6707`, clean, UNPUSHED — the #484 interlock holds; the lane branch is the upstream-PR candidate behind it. THE CHAIN: Phase 0 pinned Shape 2 (honesty floor) on six live measurements against the dispatcher's Shape-1 rec (validation/phase0-report.md). Implementation `86757666d` (mcp.h +81/−1, gate, registration, changelog — one commit); gate hardened `e6009f79e` (A5 names the file it actually names) and `83a99a098` (A4 unit-separator row — the repaired-M4 vacuity). Discrimination: base rc=1 / 6 FAIL rows, re-proven at the head; fixed rc=0 / 15 PASS on llvm@21.1.8, GNU 14.2.0 and ASan (0 reports); blast 7/7; counts base 775/lane 776/marked 773. Out of scope and filed: findings/SBE-F1-paths-key-containment.md — a pinned-tier SILENT cross-workspace write via a `paths[]` key judged as a path (pre-existing at base, measured identical on both binaries; the first version of that finding claimed the opposite direction and was retracted in-file) — became the 17th node `workspace-key-containment` (manifest event #52), dispatched next in this rotation. Ship keys NOT exercised: no push, no PR.
**Last updated:** 2026-11-08T11:05:00Z
**§11 fold (2026-11-08T11:05:00Z, producer):** the verdict's two required pre-push doc fixes are **LANDED** at
`7721f6707` — prose only, no assertion or `rc` moved. Both claims were re-measured against the banked base binary
before rewriting: base `rc=1`, **6 FAIL of 15 = A1 ×3, A3 ×2, A4 ×1**, A2/A5/A6 green. The header's "(A1) and (A2)
FAIL" was self-contradictory (A2 is the absence arm) and the changelog's "first five assertions" was a row count with
no arm meaning. One finding beyond the two: **A4's key-shape row is green at base only vacuously** — marked in the
header as readable only alongside A4's presence row. Both directions reproduced post-commit (base 6 FAIL / fixed
15 PASS), six meta-gates green, counts undisturbed. **The flip is the PM's act on its delta re-verify**; this spec
does not self-declare it. Lane head `7721f6707`, still unpushed — the #484 interlock holds.
**Post-mortem fold (2026-11-08):** the "six mutants were run" claim is **RETRACTED to "M1 measured"** — my own log directory held exactly one `.out`, and M4 as scripted could not compile (the mutation deleted the if-init binding `wsIt` while the body still used it). Two causes, both instrument failures. M4 repaired; **repairing it found a real vacuity in A4** (the generic fallback prints the synthetic key, which embeds each member path verbatim, so A4's substring grep passed with the per-member branch deleted). Fixed in `83a99a098`: A4 now also asserts NO unit separator. Lane head `83a99a098`, clean binary, base 6 FAIL / fixed 15 PASS, M4 red on exactly that arm. **Root cause of the `tapi-tbd` relink deaths: `/opt/anaconda3/bin/ld` (ld64-530, 2022) shadows `/usr/bin/ld` (ld-1115.7.3) and cannot parse a modern `.tbd`** — reproducible on demand; keep anaconda off `PATH` for any build on this host. The verdict itself is unchanged: ACCEPTED + the two required pre-push doc fixes.
**Updated by:** WorkBuddy AI / GLM-5.3 (PM seat, dispatcher-of-record — the dispatch act: fork main synced to e4432b48a (ff-verified), lane branch pushed, dispatch note written; manifest event #51 spec_started in the same round)

## Validation Strategy

Tier 2 — untrusted-agent-input surface with a `src/`-level behavioral change: **blocking
gate**. Discrimination duty: the bare-tier arm is RED at base (the SRI-F1 repro is the
contract's red baseline) and green post-fix per the pinned shape; the pinned-tier arms stay
green on both sides (regression coverage); the read-verb over-block control stays green. Both
toolchains per the standing PM validation pattern. The admission predicate is a pure function
of (policy, name, path) — the truth table is small enough for focused arms; a PBT layer is the
planning cycle's call, not a default.

## Progress Tracking

- [x] Planning cycle (at dispatch): pin the fix shape (parity vs honesty floor — upstream's
      call, carried in the dispatch note with the SRI-F1 evidence), the refusal/disclosure
      literals, the AC set — **Shape 2 pinned on measured grounds**, `validation/phase0-report.md`
- [x] Phase 1: implementation per the pinned shape — `86757666d`
- [x] Phase 2: gate + registration + changelog — same commit; gate hardened in `e6009f79e`
- [x] Phase 3: documents + battery + hand-back — `validation/phase3-handback.md`; battery green on
      clang 21 / GNU 14 / ASan; out-of-scope defect filed as `findings/SBE-F1-*`
- [x] Post-mortem fold: "six mutants were run" **retracted to "M1 measured"**; the mutant script's
      M4 repaired and its two other defects fixed; **repairing M4 exposed a real A4 vacuity** in
      this lane's own gate, closed in `83a99a098` (A4 now asserts the absence of the unit
      separator). Fixed side 15/15; M4 now red on exactly that arm.
- [x] **The verdict's §11 fixes — landed `7721f6707`, prose only.** Both measurement-wrong claims
      corrected against a fresh enumeration of the base run, not against memory: `rc=1`, 6 FAIL of
      15 = **A1 ×3, A3 ×2, A4 ×1**, with A2/A5/A6 green. The gate header no longer says "(A1) and
      (A2) FAIL" (A2 *is* the absence arm — it contradicted its own next line); the changelog no
      longer says "the first five assertions" (a row count with no arm meaning, and wrong as a
      count). One addition beyond the two required items, because a bare pass count overstates the
      evidence: A4's key-shape row is green at base **only vacuously** (a build that emits no note
      cannot emit a malformed one), now marked in the header as readable only as a pair with A4's
      presence row. No assertion, row count or `rc` changed; both directions reproduce after the
      commit; six meta-gates re-swept green; count instruments undisturbed (no marked site in
      either edited file). Detail: `validation/phase3-handback.md` §11.
