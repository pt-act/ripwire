# Dispatch Note — stdio-bare-edit-escape (attachment 1 of 2)

**Dispatched:** 2026-11-07T17:13:38Z, by the PM seat (dispatcher-of-record, WorkBuddy AI /
GLM-5.3) under the operator's word of this date, verbatim: *"We accept your
recommendations, please proceed!"* (accepting the rank-1 dispatch recommendation
`stdio-bare-edit-escape`, the scratch reclaim — executed 17:09Z, ~889M freed — and the
upstream-PR hold behind #484).
**Producer:** the LOCAL seat (Deepseek-V4.1-Flash "-1017", WorkBuddy AI on this Mac — the
rotation's standing producer; the SRI round was completed 2026-11-07, terminal validation
in `../security-regression-integration/validation/verdict-terminal.md`). Build-capable,
bash-3.2-native. **Ship keys stay with the PM seat (§03.7): the upstream PR is NEVER
yours.** Fork PR #8 opens on your lane branch when the first matrix run is due — the PM's
act, the SRI pattern (the two-run consistency pair rides your pushes; the PR run is the
one that displays).
**Base commit:** `e4432b48a` — fork `pt-act/ripwire` main = upstream `redhat-et/ripwire`
main = `e4432b48a` (fork main synced by the dispatcher this act, ff-verified:
`upstream/main..50bc05e84` = 0 before the push; `50bc05e84..e4432b48a` = 265 commits, 3
trains: #569 reg-reader, #564 graph-form-endpoints, #568 frame-high-confidence). Branch
**`lane/stdio-bare-edit-escape`** off `e4432b48a` (pushed by the dispatcher; remote
verified — attach your worktree `sbe-r1` there).
**Attachment 2 of 2 is your spec** (draft v0.1.0 — its Progress list opens with the
planning cycle: pin the fix shape, the literals, the AC set; the draft's ACs are the
starting shape, not the contract).

**Manifest bookkeeping for THIS dispatch** (status planned → in_progress,
`execution.producer` + `base_commit`, the `spec_started` history event, the spec file's
Status line) is the dispatcher's act in the same round — you do NOT touch the manifest for
the dispatch itself. Any LATER manifest mutation you need is drafted in your hand-back and
**applied through the PM seat** — the producer never flips statuses (Q10 ruling 2026-10-29).

## The lane, in one line

Close SRI-F1 on the bare stdio tier: `ripwire --mcp` without a startup root serves the
**assumedRoot** tier (`src/mcp.h:3074–3082`, R2a) — the one tier the edit pin's gate never
enters, because the gate at `src/mcp.h:1944` arms on `!policy.defaultRoot.empty()` and the
bare launch leaves `defaultRoot` empty. On that tier, an edit verb whose `path` names any
directory outside the launch cwd is **silently applied** — no refusal, no disclosure, and
the result envelope echoes the out-of-root target as `"root"`. **Your touch set is
`src/mcp.h` + `src/mcpedit.h` (+ a gate + registration + changelog): a `src/`-bearing
Tier-2 lane.** The SRI lane's test-only constraint is LIFTED here — this lane exists
because a `src/` fix IS the deliverable.

## The anchors, live-verified by the dispatcher at `e4432b48a` (17:14Z)

- **The gate:** `src/mcp.h:1944` `if( !pathsUsageError && policy.pinnedRoot.empty() && !
  policy.defaultRoot.empty() )` — the pin gate, entered on the STARTUP-ROOT tier only.
  Above it, `:1940–1943` carry the D4 half of the upstream design comment ("a request may
  name any path" — read verbs; "the incident was an edit verb" — the tier-split's intent).
  **The comment and the mechanism must travel in the same commit** — SRI-F1's origin is
  exactly a comment/mechanism split.
- **The tier:** `src/mcp.h:3074` `if( defaultRoot.empty() )` — the assumedRoot block
  (R2a, the 2026-08-12 usage mine; the R2a cluster at `:525`, `:554–555`, `:584`,
  `:1310–1316`; the READ-side openers at `:651`/`:655–656` answer with the "
  [assumed root: …]" disclosure — NOT our surface, do not touch).
- **The refusal family:** `src/mcpedit.h` — the `-32602` sites at `:174`, `:1224`,
  `:1237`, `:1247`, `:1287`, `:1323`, `:1349`, `:1382` (the drift's one mcpedit.h change
  is a comment at `:980`, so the `:174`-area sites are unchanged and the later ones
  shifted at most by that +2; Phase 0 re-pins the exact live wording at each site you
  grep).
- **The drift on our files, mapped (the dispatcher's diff read, `50bc05e84..e4432b48a`):**
  `src/mcp.h` = 3 changes, NONE touching our anchors — memory_recall's default 8→6 (the
  `:1345` tool-description area), `pathText` + `redactPtr` (the `:2619` area), plus
  upstream's own churn in the R2a cluster's comment block (`:525` wording, unchanged
  semantics); `src/mcpedit.h` = the one `:980` comment (+2 lines). The registration loop
  grew **761 → 775 members** (+14: cppextqualcheck, deadcodescopecheck, fordocbodycheck,
  forexemplarcheck, forfilesymscheck, forregrowcheck, fortailwidecheck,
  graphformendpointscheck, hopcontextcheck, qualendpointcheck, recallwindowcheck,
  rustrootscheck, warmpeakcheck, xfaliashopcheck — each verified in-list; the count via
  the consecutive-backslash structural parse, grounded at 761 on the old base).
- **The live contract baseline (the SRI lane's own gate pins it):** the bare-tier escape
  is RED at base — SRI-F1 reproduced by both seats (the finding file:
  `../security-regression-integration/findings/stdio-bare-edit-escape.md`; the pinned-tier
  refusals with the exact `-32602` wording are the `A2` rows of that lane's
  `report/report.txt`). Your gate inherits ALL THREE: bare-tier red→green (the fix's
  discrimination), pinned-tiers stay-green (the fix must not disturb the startup-root +
  HTTP tiers), read-verbs stay-open (the over-block control).

## The two-shape decision — your Phase 0's central call

The spec carries two candidate fix shapes; the planning cycle pins ONE, drafting both with
the reasoning; the pin lands in the Phase-0 fold. **Dispatcher's recommendation, for the
record (not a pin):**

- **Shape 1 (parity — the strong fix):** the assumedRoot tier joins the same edit-pin
  gate — `isMcpEditVerb( name ) && !mcpPathInsideRoot( policy.assumedRoot, path )` → the
  same `-32602` refusal family already shipped. Recommended because (a) the D4 comment
  itself already says the incident was an EDIT verb — parity extends the documented intent
  across tiers rather than against it; (b) the escape is silent — no refusal AND no
  disclosure — which the honest-output rules (AGENTS.md: every truncation/deviation
  disclosed) treat as the worst class; (c) the four-step remedy story is one line: start
  the server on the root you mean to edit.
- **Shape 2 (honesty floor — the weaker fix):** the tier stays permissive but the edit
  envelope DISCLOSES the out-of-workspace edit explicitly on every occurrence (and its
  absence on in-root edits, mutation-covered). Keep it as the fallback if upstream's
  review rules the multi-tree workflow legitimate — the PR story then carries that
  ruling, not a silent retreat.
- **Whichever pins: the gate must cover both sides of it** — shape 1: refusal + bytes
  unchanged + pinned-tier regression + read-verb control; shape 2: disclosure PRESENT
  out-of-root, ABSENT in-root (both asserted — presence-only is the vacuity the
  mcp-token-hygiene round caught once already).

## Hard constraints (non-negotiable, banked from the SRI/CI rounds)

- **D3/D4/X7 head-on.** The upstream design comment is upstream's own words at the gate
  site. Shape 1 addresses it in the PR story directly (D4's edit-verb precedent) and the
  comment family extends WITH the mechanism in the same commit — never a silent slip past
  upstream's intent.
- **Refusal wording REUSE.** A new wording doubles the grep surface for no value. Pin the
  exact live wording at the `mcpedit.h` `-32602` sites during Phase 0 and reuse its shape.
- **`ok()` canonical from commit one — the gateexitcheck lesson.** Every `ok()` helper:
  record a failed write of its PASS line into the accumulator AND return 0 —
  `ok(){ printf '  PASS  %s\n' "$1" || { fails=$(( fails + 1 )); printf '  FAIL  could
  not write the PASS line for: %s\n' "$1"; }; return 0; }`. The SRI lane paid a full CI
  round to learn this; you get it free.
- **`test/lib/clean-env.sh` sourced if you build any git fixture** (gitenvhermeticcheck).
- **No NUL-bearing fixtures without a binary-allowlist row + reason** (nulbytecheck;
  text-only fixtures owe nothing).
- **Sweep-audit before EVERY push:** new files vs gatecount + bashsource + manifestcheck +
  nulbyte + geh + gateexit (the banked caution after class 3). The suite invokes gates via
  `bash test/$_g.sh` — direct exec rc=126 here.
- **Both-toolchain battery + ASan** — a `src/` change rides the sanitizer requirement
  (AGENTS.md; libc++ plain-flavour host build ~11m, gcc leg ~37m,
  `LSAN_OPTIONS=suppressions=lsan_suppressions.txt`). Disk is ~16Gi free — keep asks
  small, surface early if a build looks thin.
- **GEN-DOCS-MERGE same-commit registration:** gate file + loop line in the
  alphabetically-correct slot + changelog fragment in ONE commit; the three count sites
  (shard sum / absorb loop / marked docs) untouched — name the accounting when you cite
  counts, never conflate them.
- **The planning cycle runs FIRST** (draft v0.1.0 — the multiquantifier precedent): pin
  the shape, the literals, the AC set; phase-log it; then code.
- **No upstream exposure.** Fork-internal only; the #484 interlock (probed OPEN five
  times today, 16:45Z latest) holds until it concludes.

## Red-baseline duty

The red-at-base discrimination runs on YOUR OWN built binary at `e4432b48a` — the SRI
round's standard (`built_from=e4432b48a` via `--version`, the instrument; `strings` probes
answer EMPTY). A starting sketch is parked at `~/ripwire-scratch/logs/sbe-red-baseline.sh`
(the dispatcher's sketch: bare `--mcp` in dir A, scripted `analyze` +
`replace_symbol_body` against sibling dir B, asserting B's sha256 unchanged and NO refusal
in the response — which at base is FALSE, i.e. the escape applies and the script exits
RED; after the fix the same script asserts refused `-32602` + B byte-identical = GREEN —
one script, both sides). Mutant discrimination to seal the gate (mutation-scale, in your
scratch only, NEVER committed): six suggested sites — the gate's `defaultRoot.empty()`
condition inverted; the refusal wording key string; the assumedRoot block's empty-case;
the read-verb opener at `:651` (a CONTROL mutant — proves your arms bind the right site);
the envelope's `"root"` echo; one `mcpedit.h` funding site. Six, the SRI count.

## Phase cadence (the standing pattern)

Phase 0 (anchors re-pinned live + the shape decision drafted/pinned + red baseline on
your own build) → Phase 1 (implementation per the pinned shape) → Phase 2 (gate +
registration + changelog, same-commit) → Phase 3 (docs if any user-facing text changed +
full battery + hand-back). Hand-back contract: completion report + verdict-ready evidence
+ phase-log + pushed lane branch. The PM seat validates every claim on its own builds and
carries the CI matrix read; the fork PR + watchers are the PM's acts.

## Host/environment facts for your scratch

- Builds need ABSOLUTE `-S`/`-B`, plain flavour (NO NDEBUG — the degrade gates need
  `DISCLOSE` alive). No `timeout` on this host; foreground Bash dies ~2 min — run long
  gates with a background task + watcher; `ps/top/lsof` blocked → `pgrep`/`stat`; logs in
  `~/ripwire-scratch/logs/`, never `/tmp` (wiped 4×); each Bash call is a fresh shell — a
  multi-step sequence is ONE call.
- **Scratch reclaim executed before this dispatch** (17:09Z): sri-mutant + sri-base
  removed, ~889M freed. Your worktree `sbe-r1` is fresh off the pushed branch; sri-r1 (the
  SRI lane worktree holding the asan build) STAYS until the upstream-PR question resolves.
- GNU-only BRE `grep -q 'a\|b'` matches nothing under BSD grep → `grep -qE`. Host
  `python3` lacks PyYAML; `/usr/bin/python3` for suite scripts.

**Good hunting. The lane is yours. — PM**
