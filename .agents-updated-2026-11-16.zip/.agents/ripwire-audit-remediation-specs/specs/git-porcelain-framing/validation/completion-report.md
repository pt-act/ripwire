# Completion Report — git-porcelain-framing

## Header

spec_id: git-porcelain-framing
producer: WorkBuddy AI / Step-5-Preview (StepFun) — the ACTING stopgap producer seat (local Mac
          session), per the bank's seat registry; the canonical opencode producer seat is
          DeepSeek-V4.1-Flash on the VM worktree. StepFun ≠ GLM and ≠ DeepSeek, so the lineage
          rule leaves the PM (GLM-5.3) eligible to validate this round either way. (An earlier
          draft of this header named DeepSeek — the canonical seat, not the one that ran; the
          work above and below is the stopgap seat's, and the correction matters because the
          lineage ruling reads this field.)
started: 2026-10-23 15:12 UTC
completed: 2026-10-23 20:25 UTC (round 1); the post-delivery CI round closed 2026-10-23 ~23:50 UTC
spec_version: 1.0.0

**Delivery:** branch `lane/git-porcelain-framing-v2` in `/Users/rna/ripwire-scratch/gpf-r1`,
base = upstream `main` @ `9b73bcc8`, six commits pushed to `pt-act/ripwire` and opened as
**PR #433** against `redhat-et/ripwire` (`https://github.com/redhat-et/ripwire/pull/433`).
CI then found six reds on the pushed lane (see the Post-Delivery Record below); seven
remediation commits follow, on the same branch and the same PR.

| commit | subject |
| --- | --- |
| `51093507` | infra: the NUL-framed sibling of `readByteSafeLine`, for `git log -z` streams |
| `5ea40f8a` | gitmine: the shared NUL-framed record reader, and all five consumers on it |
| `97f49d6c` | gitmine: THE MERGE FIX — a name-bearing merge emits a prefix empty the first draft read as a boundary |
| `4c0aa673` | test: the git-log FRAMING gate — a committed filename can never be read as commit metadata |
| `fa474048` | git-porcelain-framing: the dead code goes, and the churn memo's scheme moves to 4 |
| `26f25897` | docs: CHANGELOG `[Unreleased]` — the fix, with its cache consequence |
| `26361fbd` | fix(gitmine): the lookahead hand-over is a copy, and the dead ternary goes |
| `0ced8976` | fix(gitmine): the walkers' abandon contract rides the field read, per byte |
| `8cab2253` | test(gitframingcheck): the one-line verdict wraps — gateexitcheck G2 reads a single physical line |
| `5c81ca55` | test(gitframingcheck): pin TZ=UTC — the CI digest/golden drift was the host's timezone, not git |
| `6a6f4038` | test(crashsweep): the S2 registry names the one shared reader, not the five consumers |
| `ef2ba396` | test(deckcheck): `--dashdash` is a fixture's filename, not a flag |
| `b3a64534` | docs: CHANGELOG `[Unreleased]` — the framing fix's walkers stop at their next unit again |

**Provenance note (read this before the criteria):** every "Evidence" line below was produced in the
producer's own scratch tree. Under §H that is a *claim*, not evidence — the producer's environment is
iterated-to-green by construction. The claims are stated so the validator can reproduce or refute each
one in its own verify tree. Where a negative control exists it is named.

## Artifacts Produced

- `src/infra/stdinline.h` (+27): `readNulSafeField` — the NUL-framed sibling of `readByteSafeLine`; a zero-length field is a successful read, only end-of-stream-with-nothing returns false. A **clang-format-gated** file (see Known Deviations).
- `src/gitmine.h` (+489/−220): `NulFieldStream` (L789, one field of lookahead), `kGitLogMarker` (L803), `gitLogRecordsCmd` (L832, the one shared command carrying train-28's `--no-ext-diff --no-textconv`), `forEachGitLogRecord` (L843); all five consumers migrated to visitors at L1710 / L1793 / L1986 / L2191 / L2546; dead `gitLogRecords`, `GitLogWalk::records`, `markWalkUnread`, `noteWalkExit` removed.
- `src/quality.h`: `kQChurnCacheScheme` 3 → 4 (the walk's parse changed under a key that cannot see it).
- `test/gitframingcheck.sh` (new, 35 arms): the gate.
- `test/gitframingcheck_golden.txt` (new): the pre-change golden for arm (d).
- `test/regression.sh`: `gitframingcheck` registered in the absorb loop (703 → 704 gates).
- `test/churnjoincheck.sh`: F6 completeness arm re-derived to both reader families.
- `README.md`, `docs/EVALS.md`, `present/deck5_ripwire_build.js`: generator-rewritten gate-count sites.
- `CHANGELOG.md`: `[Unreleased]` entry.

## Acceptance Criteria Self-Check

1. **Criterion:** "Spoof fixture neutralized: in the fixture repo, churn/ownership output attributes `__C__x|1694000000` to its real commit and real author. **Verifier:** `test/gitframingcheck.sh` arm (a) greps `--owners`-family output for the fixture path and asserts the true author email, and asserts no `__C__x` author row exists."
   - Claim: **met**
   - Evidence: `test/gitframingcheck.sh:260-275`. `grep -o '="x"' owners.xml | wc -l` = **0** (occurrences, not lines — the XML answer is one line); all 11 indexed files carry `top="real@x.com"`; `attr_of owners.xml '__C__x|1694000000.cpp' top` = `real@x.com`. Negative control: the same arm run against the pre-change binary (`rsh-r1` @ `bb2b25e6`) yields **5** `="x"` rows and **8 of 11** ownership rows — the forgery measured where it happened.
   - Whole-gate control, re-run against the **current 35-arm** gate on the pre-change binary: **12 FAIL / 24 PASS**, exit 1. The 12 failures are exactly the framing-defect arms; the other 23 pass, including all four of arm (c2)'s assertions — the pre-change binary never had the pathspec seam, so (c2) discriminates the seam defect from the pre-change baseline rather than merely re-asserting the fixed behaviour.
   - Provenance: `Executed in: scratch@gpf-r1 (repo@9b73bcc8 + lane@26f25897, build-verify)`

2. **Criterion:** "Newline filename round-trips: the `a\nb` fixture file is attributed as one path. **Verifier:** arm (b) asserts exactly one record carrying the full name (fixture expectations stored beside the fixture)."
   - Claim: **met**
   - Evidence: `test/gitframingcheck.sh:280-288`. `a<LF>b.cpp` churn = **1**, owned by `real@x.com`, and `grep -cE '<f p="(a|b\.cpp)"'` = **0** (no phantom rows for the split halves). Note: both the pre-change and the fixed binary resolve this name — the old line reader's `\n`-strip happened to survive this particular spelling, so the arm is a round-trip pin, not a red control. The red control for the line frame's real failure is criterion 1.

3. **Criterion:** "Exact-marker file survives: a file named exactly `__C__` is parsed as a path, not a commit boundary. **Verifier:** arm (c)."
   - Claim: **met**
   - Evidence: `test/gitframingcheck.sh:293-298`. `__C__ 1694000000.cpp` (the file sorting immediately after `__C__`) keeps `top="real@x.com"`, and `__C__.cpp` keeps its true author. Structural pin: the raw-stream digest arm (`:354`) counts **13** NUL-delimited marker-spelled fields = 11 record openers + 2 marker-spelled *paths* (c1's mid-list `__C__` and the collision merge's bare first path) — the exact-marker file is counted as a path, never as an opener.

4. **Criterion:** "Honest-tree output unchanged: `--owners`/churn/co-change output on the ripwire checkout is byte-identical pre/post change. **Verifier:** golden diff arm (d) over `git -C . log`-derived verbs listed in the gate."
   - Claim: **partially met** — see Known Deviation 2.
   - Evidence: `test/gitframingcheck.sh:324-335` + `test/gitframingcheck_golden.txt`. The golden was recorded from the **pre-change binary** over a small deterministic honest tree (5 commits: base → side → main → a name-bearing merge with author≠committer → a follow-up; HEAD `28829e0ce` under the gate's now-pinned `TZ=UTC`) across `--owners --detail=1`, `--hotspots`, `--cochange`, with `root="…"` normalized to `root="FIXTURE"`. The fixed binary reproduces it byte-identically, three consecutive runs. What is *not* done: the golden is not over the ripwire checkout itself.
   - Notes: the golden's purpose (prove ordinary trees are untouched) is met on the tree it covers; the spec's chosen corpus is not the one used.

5. **Criterion:** "Single parser: `grep -n '__C__' src/gitmine.h` shows marker recognition only inside the shared helper. **Verifier:** arm (e) count/location grep."
   - Claim: **met**
   - Evidence: `test/gitframingcheck.sh:337-352`. Comment-stripped count of `__C__` in `src/gitmine.h` = **2** — `kGitLogMarker` (L803) and the shared command's `--format=` (L832) — and **zero** `tformat:` occurrences in code. The five consumer bodies carry no marker literal.

6. **Criterion:** "Gate registered: in `test/regression.sh`; `./test/manifestcheck.sh` passes. **Verifier:** run it."
   - Claim: **met** (with a caveat on *how* it was run)
   - Evidence: `test/regression.sh` absorb loop lists `gitframingcheck` between `gitenvhermeticcheck` and `githardencheck`; `gatecountcheck` ALL PASS (704 = loop length, generator and the three marked sites agree); `bash -n test/gitframingcheck.sh` clean. `manifestcheck.sh` was verified **arm by arm** (all 714 gates listed; the `bash -n` leg; the gate-count-drift leg) because the full run exceeds this sandbox's per-process time cap — it is slow (714 greps under broker overhead), not red.
   - Notes: a full single-invocation `manifestcheck.sh` run is left to the validator's environment.

## Interfaces Delivered

- Name: **gitRecordFraming**
  - Shape: delivered as `forEachGitLogRecord` + `NulFieldStream` + `gitLogRecordsCmd` (the advisory name `gitLogRecords()` was never binding — see Known Deviation 6). One helper yields `(commitMeta, [path, …])` records parsed from NUL-delimited `git log` output; every `--name-only`/`--format` consumer is a visitor over it. Command: `git log -z -c --name-only --format=%x00__C__%x00%ae%x00%at%x00%ct`, fields and paths NUL-terminated and RAW (`core.quotepath=false`).
  - Location: `src/gitmine.h:789-940`; the five consumer call sites at `src/gitmine.h:1710, 1793, 1986, 2191, 2546`.
  - Consumer-facing behavior: any POSIX-legal filename round-trips byte-exact (pinned by arms b, c and the digest); marker recognition requires a **whole-field** match, so a filename can never be parsed as metadata (arm a); a parse failure degrades honestly — non-zero exit, no fabricated rows, `git unavailable / no history` on stderr (arm 8, exercised with a shimmed git that rejects `-z`).

- Name: **pbtEvidenceBundle**
  - Shape: **not delivered.** `specs/git-porcelain-framing/evidence/` holds only `layout-pin.md`; there is no property-test harness, seed set, or `pbt-git-framing.log`. See Known Deviation 3.

## Known Deviations

1. **Fixtures are built at runtime, not committed under `test/fixtures/`; no `\r`-named file.** The spec's Scope names four committed fixture files including one containing `\r`. The gate instead constructs an 11-commit hostile fixture (and a 5-commit honest one) at fresh `mktemp` paths every run. **Reason:** the tool memoizes its history walks under `$TMPDIR/ripwire` keyed on (repo, HEAD, window) with a **path-derived repo key**, so a fixed fixture path would let a previous run's cached churn answer this run's questions — every number in the gate would be remembered rather than computed. The runtime fixture is load-bearing, not convenience. On the `\r` file specifically: a `\r` in the *middle* of a name round-tripped under the old line frame as well (it is not a boundary-relevant byte), while a name *ending* in `\r` was trimmed by the old frame's trailing-`\r` strip — a minor defect class the gate does not pin. The gate pins `\n`, which was a real defect. **Awaiting the operator's adjudication**; disclosed in the PR body.
2. **The golden (criterion 4) is over a small deterministic honest tree, not the ripwire checkout.** Same root cause as deviation 1 (the memo cache makes a repo-self golden depend on the machine's cache state), plus a checkout's own history is not reproducible across clones. The property the criterion names — ordinary trees are untouched — is met on the tree that is covered.
3. **Phase 4 (PBT harness + evidence bundle) is not delivered.** The spec's Validation Strategy is Tier 2 with ≥20,000 generated filename cases and ≥1,000 generated streams. The lane ships the deterministic gate, which pins the same three properties (round-trip integrity, no injected metadata, determinism) over a fixed hostile corpus — a strictly weaker domain than the generated one.
4. **The disclosed `__C__` collision is not fixed** (by design, pinned not papered over): a merge whose FIRST combined path is a file literally named `__C__` still reads as pathless — its prefix empty is followed by the marker-spelled path, which the boundary rule cannot tell from a real record boundary. Observable: that merge's files lose their attribution and a pathless phantom record is emitted that every consumer no-ops on. The two churn miners disagree there **by design** (`--for` = 3, `--hotspots` = 4) and the gate pins the disagreement. Full fix = a format sentinel change; follow-on spec.
5. **Two defects were caught at final verification and fixed before the push** — neither is a spec deviation, both are recorded here because they changed the commit graph after the initial build: (a) `--quality-delta` gated on the orphaned `markWalkUnread`/`noteWalkExit` (a helper that lost its last caller is a gating dead-code finding on this tree) — removed, and the commit message that had falsely claimed "needed no removal commit" was corrected; (b) the shared command placed `extraArgs` **before** `-z --name-only --format=…`, so `gitFileAuthors`' single-file pathspec made git read those flags as *paths* and answer in its default format — `--owners=SYM` exited 1 with "git unavailable / no history" on a healthy repo while the all-files form beside it was correct. Fixed by moving `extraArgs` to the end of the command (a pathspec is only a pathspec when it comes last), pinned by new gate arm (c2).
6. **The advisory interface name `gitLogRecords()` was not used** — `forEachGitLogRecord` was delivered instead, because the five consumers are visitors (one record in memory at a time) rather than collectors, and the name should say so.

## State Management

### Progress Tracking

- Spec file: `specs/git-porcelain-framing/spec.md`
  - All boxes checked: **no** — Phases 1, 2, 3 checked; **Phase 4 unchecked** (PBT harness + evidence bundle not delivered, Known Deviation 3).
- Phase log: `specs/git-porcelain-framing/phase-log.md`
  - Exists: **yes** (written with this report — the phases were not all straightforward; the deviations above are narrated there per phase).

### Memory Bank

- File: `.agents/memory_bank/active/PROGRESS.md`
  - Action: **appended** (direct write to the canonical bank)
  - Content summary: one dated block recording the six commits, the push, PR #433, the verification numbers, the two late-caught defects, the disclosed collision, and the spec deviation.
  - **Convention conflict, flagged for the operator:** Orion-OS `VALIDATION_PROTOCOL.md` §C *requires* the producer to write `PROGRESS.md` and `current_focus.md` as part of every production run; the seat registry's duty is worktree-copy + PM merge, with no direct canonical writes from a parallel seat. This run followed the protocol and wrote the canonical bank directly, concurrently with the PM seat's own entries. No damage resulted (appends only; the PM's entries are intact), but that is luck, not design. **Needs an operator ruling on which convention governs.**
- File: `.agents/memory_bank/active/current_focus.md`
  - Action: **appended** (same conflict as above)
  - Content summary: the resumption-point block naming PR #433 as the live artifact, the next actions (watch CI, the deviation ruling), and the push-credential recipe.
- File: `.agents/memory_bank/active/open_questions.md` — Action: **skipped**. Rationale: nothing blocked progress; the one open question (the deviation ruling) is a scope question for the operator and is recorded in the PR body and in this report rather than as a bank question.

### Progress Entry

The protocol-shaped entry (the fuller entry already appended to `PROGRESS.md` is the one of record;
this is its canonical four-field form, not a second append):

```markdown
### 2026-10-23

- **Implemented:** git-porcelain-framing — the shared NUL-framed `git log` record reader with all five
  consumers migrated, the one-field-lookahead merge fix, `test/gitframingcheck.sh` (35 arms) + golden +
  registration (703→704 gates), dead code removed, `kQChurnCacheScheme` 3→4. Pushed as
  `lane/git-porcelain-framing-v2`; PR #433 open against upstream main.
- **Decided:** `extraArgs` rides at the END of the shared git command (a pathspec is only a pathspec when
  it comes last); the orphaned K51 helpers go in the commit that took their callers; runtime mktemp
  fixtures instead of committed `test/fixtures/` (the `$TMPDIR/ripwire` memo's path-derived key makes a
  fixed fixture path serve cached churn).
- **Blocked:** Phase 4 (PBT evidence bundle) not delivered; the fixture/golden corpus deviation awaits the
  operator's ruling; the bank-write convention conflict (protocol §C vs seat registry) awaits ruling.
- **Next:** independent validation round in the validator's own verify tree; the CI style red (a
  clang-format-gated file, `src/infra/stdinline.h`) is producer-owned and rides PR #433 as an ordinary
  iteration.
```

## Handoff Notes

- **The lane's base is `9b73bcc8`** (upstream main after PR #397 merged) — not the `0e0f67c7` the spec's Status block names, and not the `004b4c6b` an earlier bank block named. Train 28's `--no-ext-diff --no-textconv` hardening is an ancestor and is folded into the shared command.
- **Reproducing the gate:** `RIPWIRE_BIN=<binary> bash test/gitframingcheck.sh`. It needs no network and builds its own fixtures. Expected at push time: 35 PASS; after the review round's arm (c2) and arm (f) additions the gate reports **14 arms / 39 assertions, ALL PASS** (see the Finalize Pass below for the measured runs). The pre-change negative control is `rsh-r1`'s build at `bb2b25e6` (12 arms red); the lane's own pre-fix control is the `b3a64534` build (arm (f) red — also in the Finalize Pass).
- **Negative controls the producer ran:** (a) the pre-change binary over the hostile fixture — 12 FAIL / 24 PASS on the current gate (criterion 1); (b) a shimmed git that rejects `-z` (arm 8 — the reader must degrade honestly); (c) the seam control, recorded as mutation → expected failure → observed failure → revert: with `extraArgs` placed *before* the command's options, `--owners=twinned` on a healthy one-commit repo exited 1 with `git unavailable / no history` (arm (c2)'s first two assertions fail); after moving `extraArgs` to the end, the same four assertions pass on both the fixed and the pre-change binary. **The producer did not run a control that reintroduces the line-prefix marker match into the shared reader** — that is the control §H asks the validator to choose and perform.
- **The 26-gate affected-family battery** (mergechurncheck, churnjoincheck, churndecaycheck, churnjsonstampcheck, cochangeboostcheck, cochangecliocheck, cochangesurprisecheck, gitchildoptscheck, gitenvhermeticcheck, githardencheck, gitignorecheck, gitquotepathcheck, gitstampcheck, historyoraclecheck, hotspotsincecheck, mergescoutcheck, mergescoutlonglinecheck, ownerhopcheck, ownerscheck, qchurncheck, qchurnmemocheck, qsnapcachecheck, qsnapprefetchcheck, qsnapproducercheck, qschemetripcheck, evictioncheck) was run by the producer in its scratch tree — 26/26. Scratch output; a claim, not evidence.
- **Environmental preconditions:** macOS has no `timeout`; `manifestcheck.sh` in full exceeds the sandbox's per-process cap; `ownerscheck` is in `regression.sh`'s absorb loop and is the gate that caught the pathspec seam.
- **Live at report time:** superseded by the Post-Delivery Record below — CI found six reds on the
  pushed lane, all now remediated on the same branch and the same PR. The earlier note here
  misdiagnosed the style red as clang-format on `src/infra/stdinline.h`; it was clang-tidy
  (`bugprone-use-after-move`) on `src/gitmine.h`. The correction is part of the record.

## Post-Delivery Record — the CI round on PR #433 (2026-10-23 evening)

The pushed lane's CI came back with **six distinct reds**, none of them the framing defect itself.
Each is recorded here with its cause and its fix; the fixes are the seven commits `26361fbd` …
`b3a64534` above.

1. **style (620001) — clang-tidy 22, `bugprone-use-after-move`, on `src/gitmine.h`** (NOT clang-format,
   and NOT on `src/infra/stdinline.h` — the first "Live at report time" note said both, wrongly).
   The walk loop's hand-over of the held lookahead reads as a second use of a moved-from object: the
   slot is moved in one iteration and again in a later one, with the reassignment between them that
   no analyzer can correlate with the `haveLookahead` flag. A swap relocates the finding (it reads
   the slot too); the fix is a copy, plus the removal of a `haveLookahead ? … : …` at the
   empty-field check that could never take its true branch. **Local verification status: NOT
   verified locally** — the llvm@22 keg that ran this gate earlier in the session is no longer on
   the machine (no Cellar keg, no bottle for this platform, the data volume at 99%), so the tidy
   and format legs rest on CI plus manual conformance (include order, paren spacing; the project's
   `.clang-format` sets `ColumnLimit: 0`). Disclosed rather than papered over.
2. **deckcheck — `CHANGELOG.md:156: --dashdash`.** The CHANGELOG's framing entry enumerates the
   hostile fixture's file names, one of which is `--dashdash.cpp`. Fixed with an allowlist row
   naming the fixture file; rewording the prose to dodge the scanner was rejected as making the
   docs vaguer to satisfy a regex.
3. **crashsweepcheck S2 — six violations.** The five-consumers-to-one-reader refactor left five
   registry rows stale and one new popen site unregistered. The registry now names the shared
   reader. Verified locally: crashsweepcheck ALL PASS (28 arms, the four S2 probes included).
4. **gateexitcheck G2.** Arm 5's `files=11` verdict was a single physical line carrying
   `&& ok … || no …`. Wrapped. Verified locally: gateexitcheck ALL PASS.
5. **gitframingcheck — digest drift + honest-tree golden drift.** Diagnosed as git-version drift
   at first; **disproved** by building git 2.56.0 from source and reproducing the pinned digest
   byte-for-byte under it. The real variable was the machine's TIMEZONE: the fixture's naive
   `GIT_AUTHOR_DATE` strings read in the local zone, so CI (UTC) and the recording Mac (WEST)
   produced different streams (`a823b914…` vs `9a112638…`). The gate now pins `TZ=UTC`, the digest
   pin is the UTC reading, and the golden was re-recorded under UTC from the pre-change binary —
   the recording procedure first proven by reproducing the committed golden byte-for-byte under
   the machine's own zone. Verified: ALL PASS under ambient Tokyo / UTC / default zones × git
   2.52.0 / 2.56.0. The pin lives in the gate, not in the shared `test/lib/clean-env.sh`, because
   that file's other fixtures were derived non-UTC and shifting them is separate work — the same
   latent defect in those gates is named in the commit message as follow-up.
6. **memguardcheck B21 — a real regression from the lane.** The old line readers checked the
   abandon flag per LINE; the migrated field reader checked it only between FIELDS, so a stream
   whose fields never arrive (the shim's bare lines) parked the read inside one unterminated field
   for the full 6s stream (the arm's limit is 4s; the pre-fix binary took 2s). The flag is now
   polled per byte inside `readNulSafeField`; the arm refuses in about a second. **One further
   memguard finding, NOT the lane's:** arms B8/B8b fail on THIS Mac — and fail the same way on the
   pre-change binary (`rc=0` instead of the expected exit 5, the time-gated soft stop / complete-
   under-limit outcomes the gate's own commentary names as host-dependent; the fixture was
   calibrated on a 10-core Linux host). They are a host trait of this machine, not a regression,
   and the discriminator that proves it is the pre-change control.

**The verification lesson, recorded because it cost a round:** the producer's 26-gate
"affected-family" battery passed 26/26 while missing crashsweepcheck, deckcheck, gateexitcheck and
memguardcheck entirely — four of the six reds. A green battery over a hand-picked family is not
evidence about the tree. The full `test/pargates.py` suite is the verification of record; its run
over the final state is in flight at the time of this edit and its result is recorded here when it
lands.

## Finalize Pass — the producer's countersign and the last open slot (2026-10-25)

The PM seat's validation round (`validation/verdict.md`, approved_for_push) left this seat a
**countersign debt**: `7d8b0a54` is PM-produced code, and under the lineage rule the PM's verdict
cannot seal its own work. This section discharges that debt with the producer's own measurements
on the final tree (`cc6b312f`, freshly built, 21m49s, exit 0), and closes the report's last open
slot — the full-suite result.

### The countersign of `7d8b0a54` (+ its one-token rider `cc6b312f`)

**Read.** The diff is exactly what the message and the CodeRabbit replies describe, and the
producer's reading AGREES on the three load-bearing decisions:

1. **The lookahead decides every empty by state** — empty + MARKER (or end of stream) is a record
   boundary whatever is pending (which is also what closes the collision phantom without
   swallowing the next record); empty + non-marker while the marker or metadata is still owed is
   DATA delivered to the state machine (the legitimate empty `%ae`); only a record owing no
   metadata reads a non-boundary empty as a merge prefix. The producer's original one-field
   lookahead was sound for the shapes it was built against; the empty-email shape was the hole.
2. **`parseEpochField` returns nullopt for a degraded read** (empty, non-digits, leftover bytes),
   distinct from a genuine zero — the honest-output-correct split, because epoch 0 is 1970 and
   can be real while a failed parse is an unknown position. The walk counts degraded reads in
   `GitLogWalk::epochUnparsed`, the same sink channel as `unread`/`notRun`.
3. **`gitFileAuthors` keeps only the epoch half of its carried-over guard** — the email half
   discarded real history once the frame learned to deliver empty-email records intact.

**Ran — and reproduced the defect independently.** On the final binary: `gitframingcheck`
**ALL PASS — 14 arms / 39 assertions / 0 failures, exit 0**, arm (f) green. The producer then
built the lane's pre-fix state (`b3a64534`) from source in a fresh worktree
(`gpf-prefix-r1`, 13m36s, exit 0) and ran the SAME gate against it: **36 PASS / 3 FAIL, exit 1** —
and the three failures are exactly arm (f)'s assertions: `--owners=emptyMailFn` exits 1 with
`git unavailable / no history`, the record lost its path, the churn row is absent. The red-first
control is therefore not taken on the PM's word; it reproduces on this seat's own build.

**Also measured on the final tree:**

- `ripwirepubliccheck` (the `cc6b312f` one-token fixture repair — the only failure in CI's
  `7d8b0a54` run): **ALL PASS, 17 assertions, exit 0**.
- `crashsweepcheck`: **ALL PASS** (28 assertions — the S2 registry legs included).
- `gateexitcheck`: **ALL PASS** (22 assertions).
- `--quality-delta 9b73bcc8..HEAD`: **`gating="0"`**, regressions=2, both
  `origin="new-symbol"` (`forEachGitLogRecord` complexity/verbosity), minor=0, exit 0 — the same
  shape the PM measured; new-symbol rows never gate.

### Two findings that are NOT the lane's — both proven by control

1. **memguardcheck B8/B8b** (93 PASS / 2 FAIL on the final tree): `rc=0 memory_stop=crawl` where
   the gate expects exit 5 — the time-gated soft stop the gate's own commentary names as
   host-dependent, calibrated on a 10-core Linux host. **Control:** fails identically on the
   pre-change binary (this seat, pre-compaction) and on the PM's verify tree (verdict item 3).
   A host trait of this Mac, not a regression.
2. **affectedcheck (8f)** (101 PASS / 2 FAIL on the final tree): `--for --legend=compact/full`
   "an owner row is reachable and the clause is missing". **Root-caused to the gate script, not
   the product:** the arm greps `grep -q 'modscope\|MODULE SCOPE'` — GNU-only BRE alternation.
   BSD grep (macOS) reads `\|` as a literal pipe, so the pattern matches nothing; Linux CI's GNU
   grep honors it. Proven directly: the dumped answer from the failing run CONTAINS both
   `modscope` and `MODULE SCOPE` (the answer is byte-identical to the pre-fix binary's apart
   from the root-path length in `est_tokens=`), and `grep -qE 'modscope|MODULE SCOPE'` matches.
   **Control:** the pre-fix binary fails the same two arms. A latent macOS-portability defect in
   the repo's test suite, invisible to CI because CI is Linux. **Recommended follow-up (NOT
   landed here — the lane stays scoped and nothing ships without the handshake):** the one-line
   fix is `grep -qE`; the same GNU-only pattern class may live in other gates and a tree-wide
   sweep for `\|` alternation under `grep -q` is worth its own small change.

### The open slot — the full suite

The report's closing lesson was that a hand-picked family is not evidence about the tree. The
full-suite evidence available for the final tree:

- **CI's own run on `7d8b0a54`** (the run that carried all of the fix except the one-token
  rider): **179 gates, 176 pass, 2 skip, 1 fail** — the single failure is ripwirepubliccheck arm
  5b, the exact red `cc6b312f` repaired and this seat re-verified ALL PASS above. No other gate
  failed on any of the five sharded legs.
- **This seat's family re-run on the final tree** (above): every CI-red family by name, plus the
  two non-lane findings proven by control.
- **The gap, disclosed:** **no CI run was ever created for `cc6b312f`** — the push that advanced
  PR #433's head to the final tip produced no `pull_request` run in either repo (verified: the
  run list for the lane branch stops at `7d8b0a54`; the tip's only status context is CodeRabbit).
  The suite is CI-owned, so the authoritative full-suite verdict on the FINAL tree does not exist
  yet. Re-triggering it (close/reopen the PR, or an empty commit) is a ship-key action — the PM's
  or the operator's call, recommended here so it is not forgotten.
- **Local full-suite run:** launched on this seat's tree at the time of this edit; its result is
  recorded here when it lands. **Read it with the host's false-failure classes in hand** — this
  seat established, mid-run, that a full local run on macOS cannot be a clean verdict source by
  construction: (1) the GNU-only BRE alternation (`grep -q 'a\|b'`) is a widespread convention in
  this repo's gates — 720 gate files, dozens carrying the pattern — and BSD grep reads `\|` as a
  literal pipe, so load-bearing alternations fail here and pass on Linux CI (affectedcheck's (8f)
  is the proven instance); (2) host traits (memguardcheck's time-gated arms); (3) deckcheck
  deadlocks on this Mac (observed twice); (4) -j6 contention. The four gates this seat pulled out
  of the run's X column and re-ran alone (churndecaycheck, blindspotcheck, chaconecheck,
  churnjoincheck) all passed 29/0, 73/0, 10/0, 79/0 — the X's are noise of the classes above, not
  findings. A local X is evidence only after the gate is re-run alone AND fails there AND fails
  the same way on the change's absence.
