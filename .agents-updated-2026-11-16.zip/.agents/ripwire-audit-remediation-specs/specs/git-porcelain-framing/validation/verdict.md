# Verdict — git-porcelain-framing — round 1 (hybrid: PM validation + PM-produced increment)

## Header

spec_id: git-porcelain-framing
validator: glm-5.3 (PM seat, ZCode session)
validator_distinct_from_producer: true for the 13 producer commits (Step-5-Preview / StepFun); **false
  for commit `7d8b0a54`**, which the validator itself produced under the operator's explicit 2026-10-24
  sanction (producer in rate-limit cooldown until 18:08; "step in finish and then validate all
  together"). That partition is the verdict's central caveat and is disclosed per-criterion below.
reviewed_completion_report: specs/git-porcelain-framing/validation/completion-report.md (producer's,
  substantially complete; one open slot — the full-pargates result — see Criterion 7)
verdict_timestamp: 2026-10-24 ~03:30 UTC

## Decision

status: **approved_for_push** (with the countersign debt below) — the lane advances PR #433; the
producer's resume round at 18:08 countersigns `7d8b0a54` and finalizes the report.

## What was verified, mechanically, in the PM's own verify tree (`pm-verify-r1` @ `7d8b0a54`, fresh build-p2)

1. **gitframingcheck: 40 PASS / 0 FAIL, exit 0** — including the digest pin (the exact hostile
   stream), the golden byte-identical to the pre-change recording (root normalized), the merge
   shapes, the disclosed collision, the oracle, and the shim-degrade honesty arm.
2. **Negative controls, both directions.** (a) Arm (f) — added this round — was proven RED on the
   pre-fix binary (`/tmp/gpf-prefix-bin`, sha from `b3a64534`) BEFORE the fix was written: the
   empty-email fixture answered "git unavailable / no history" with zero rows. (b) **TZ control,
   validator-chosen:** the full gate run under `TZ=UTC` and `TZ=Asia/Tokyo` is byte-identical — the
   producer's TZ pin is load-bearing, not merely present. (c) **The guard-cascade episode**: the
   reviewer's first implementation of CodeRabbit's literal guard broke arm (a) (`__C__.cpp` flipped
   to `side@x.com` — a record-swallowing cascade through the collision phantom); the arms caught it
   before any commit. This is recorded as live proof the battery is load-bearing for exactly the
   finding class it pins.
3. **The wider battery, all exit 0:** crashsweepcheck, deckcheck, gateexitcheck, manifestcheck,
   gatecountcheck, mergechurncheck, churnjoincheck, qchurncheck, qchurnmemocheck, qschemetripcheck,
   evictioncheck, ownerscheck, qsnapproducercheck (the six CI-red families included).
   **memguardcheck:** B8/B8b fail IDENTICALLY on the fixed and the pre-fix binary — the host trait
   the producer's report disclosed (time-gated arms calibrated on a 10-core host), not a regression;
   CI is authority.
4. **Determinism ritual:** two full runs byte-identical on stdout AND stderr; `xmllint --noout` clean.
5. **quality-delta `9b73bcc8..HEAD`: `gating="0"`**, regressions=2 both `origin="new-symbol"`
   (forEachGitLogRecord complexity/verbosity) — never gating, same shape the producer left.
6. **CodeRabbit finding #1 (Major) — fixed, red-first.** The boundary rule now decides an empty by
   lookahead in ALL states: empty+marker = boundary (which also closes the collision phantom without
   swallowing the next record — the literal guard failed exactly there); empty+non-marker while
   marker/metadata owed = DATA delivered to the state machine (the empty `%ae`); empty+non-marker
   owing nothing = merge prefix. Second half of the fix: `gitFileAuthors` drops the email half of
   its carried-over guard (git accepts empty emails; the epoch half stays — git never stamps a real
   commit at epoch ≤ 0). Arm (f) pins the lot.
7. **CodeRabbit finding #2 (Minor) — parse-side landed, consumer-side disclosed as follow-up.**
   `parseEpochField` now distinguishes empty/unparsable/leftover-bytes from a genuine zero (nullopt),
   and the walk counts degraded reads in `GitLogWalk::epochUnparsed` — the walk-struct sink, the
   file's own unread/notRun idiom, and the shape CodeRabbit itself pointed at. NOT done tonight (and
   not silently dropped): the emitted-surface consequence — a window that cut on a degraded epoch
   counted a floor, and the honest output is a `counts_floor=`-class attr on the affected answers.
   That is emit-schema work with its own gates (follow-up: producer's resume round or a next spec;
   it composes with the already-queued `regex-screen-multiquantifier`/regression specs).

## Criteria assessment (keyed to the completion report's claims)

- Framing guarantees (spoof neutralized, newline names, exact marker, pathspec seam, honest-tree
  byte-identity): **confirmed** (items 1–2 above; the golden arm is the direct byte-identity proof).
- CI-red remediation claims (TZ, gateexit wrap, crashsweep registry, deckcheck dashdash, memguard
  abandon-polling, clang-tidy use-after-move): **confirmed locally** where runnable; the clang-format
  22 leg is **CI-on-push authority** (local LLVM 19 cannot parse the v22-pinned config — heuristic
  read of the touched lines finds house-conforming style only).
- The hand-picked-battery lesson (report's own closing note): **confirmed by construction** — this
  verdict's battery includes every CI-red family by name, not a hand-picked set.
- Full pargates (the report's open slot): **not runnable locally at full scale** (historically
  CI-only for this project); CI on push runs it. The slot stays open for the producer's finalize.

## Deviations standing (unchanged, operator-gated)

- **Fixture deviation** (runtime mktemp vs committed `test/fixtures/` with `\r` name): the
  load-bearing claim ($TMPDIR/ripwire memo, path-derived repo key) is consistent with the gate's own
  cache notes and the fresh-path discipline visible in the fixture code; the ruling remains the
  operator's.
  **RULED 2026-10-29 (PM Advisor seat, WorkBuddy AI — GLM-5.3, under the operator's standing directive
  that engineering decisions are decided in-seat): FOR the implementation — runtime fixtures are the
  correct design.** The spec's fixture clause (committed paths under `test/fixtures/`) predates the
  discovery that the tool memoizes history walks under `$TMPDIR/ripwire` with a path-derived repo
  key; a committed fixture path would let a previous run's cached churn answer this run's questions —
  a cache-poisoned gate is worse than no gate, and it would fail in ways that look like the lane's
  defect. Runtime fixtures at fresh `mktemp` paths preserve every property the fixture clause was
  meant to secure (deterministic content, hostile names round-tripped, cold cache every run) while
  closing the memoization hazard. The spec's fixture clause is recorded as superseded by
  implementation reality; no change to the gate is required, and nothing in the upstream review
  (CodeRabbit's two findings, both resolved) asked for one.
- Style gate: CI arbiter (above).
- The disclosed collision: unchanged, pinned, follow-on-spec material.

## The countersign debt (binding)

`7d8b0a54` is PM-produced. Its correctness is pinned mechanically (red-first arm, byte-identical
golden/digest, gating=0), but under the lineage rule the PM's verdict cannot be the seal on its own
code. Seal = CI + CodeRabbit re-review + maintainer on the pushed PR, PLUS the producer seat's
countersign at its 18:08 resume (read the commit, run arm (f), record agreement or findings in the
completion report's finalize pass). The report's open pargates slot closes with CI's run.
