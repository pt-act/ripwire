# Resolution Report — git-porcelain-framing

**Resolved:** 2026-10-30, terminal on upstream-merge evidence.
**Resolved by:** WorkBuddy AI / GLM-5.3 (PM Advisor seat), acting as dispatcher-of-record under the
operator's 2026-10-29 standing directive (decisions in-seat with rationale, recorded).
**Path:** same as the regex-screen-hardening precedent (Q10 ruling, option (a)): the upstream merge
IS the validation evidence; the producer never flipped status (VALIDATION_PROTOCOL step 2 held
throughout); this report is the dispatcher's terminal act, with the spec-file and manifest Status
lines flipped in the same act (the selfcheck pins file-manifest agreement).

## The evidence chain, end to end

1. **Producer completion (round protocol held):** `validation/completion-report.md` (16/16 ACs,
   red-first arms, the countersign debt discharged 2026-10-25); `validation/verdict.md`
   (approved_for_push). Lane head at handoff: PR #433 `b8d4a732` — 19 commits, all pt-act,
   four upstream train-merges absorbed mechanically along the way (730 gates at the last).
2. **Maintainer integration:** PR #469 (`community/pr433`) — our 19 commits unchanged through
   `b8d4a732`, plus his merge `f65c2a93` (train 41b), `83c8f096` (collision-disclosure comment
   correction + fragment credit), `fafb3f26` (arm (g), the marker-*prefix* mutant our fixture could
   not see) — co-authored with pt-act.
3. **The review round that closed the open questions:** CodeRabbit posted three Minor findings on
   the integration branch (00:17Z, 2026-10-30); this seat verified each against the PR tip (ALL
   PASS on the built tip, incl. arm (g)) and answered with measurement (replies `4420227197`,
   `4420227351`, `4420227552`): F3 vacuity (REAL_GIT unexported — both states byte-identical),
   F2 the cache consequence (exit-0-with-bytes is the only shape that bypasses both the unread
   classification and the qchurn cache refusal — measured: poisoned empty walk cached, later healthy
   runs served), F1 consumer map (epochUnparsed's counter dies at the raw stream).
4. **The maintainer implemented the fixes himself, inside #469, before merging** (both co-authored
   with pt-act, credits intact):
   - `b66e26e6` — F3: `export REAL_GIT`, **plus a premise arm proving the shim delegates a plain
     call and a second arm proving the shim actually saw and rejected a `-z` call** — the
     discrimination upgrade this seat's SR-2026-10-30-gate-scenario-discrimination records as the
     rule; convergent with our scoped follow-up lane.
   - `90acd0f1` — F2: the marker-less walker rule, verbatim the shape our F2 reply scoped
     (`data arrived, no marker opened a record, not abandoned, git exited 0 → unread`), with
     `gitLogNameOnlyRaw` carrying `unread` so `--for`'s `churn=`/`amp=` answer `history_unread="1"`
     and the failed walk is not cached — i.e. **the E2 cache-poisoning chain measured in our reply
     is dead on main**. Arm 9 pins it with a control pair (unshimmed `--for` prints `churn=` and no
     `history_unread` — the shim's verdict proven against a healthy answer, not assumed).
   - `0666a5e8` — F1 by the review-note route: `epochUnparsed` kept, the comment corrected to say
     no consumer reads it yet, and the deferral registered in `src/historyread.h`'s NOT COVERED
     (naming `--cochange` / `--rank-by=churn` / `--owners` as the answer-changing lane, tracked
     for a later release). Our thread's offer to take that work stands; his disposition is
     upstream-owned until then.
   - `84d7ac9c` and the re-merge `850cafaa` (train 42a) completed the integration; the upstream
     review rounds on #469 (his + CodeRabbit's) supersede nothing — the producer's verdict was
     already the go; they ADDED to it.
5. **The merge:** `d044662a` (merge of #469 into main), 2026-10-30T08:45:42Z, by joyful-ii-V-I.
   **CI on the merge head `850cafaa`: success.** #433 closed by it. The changelog fragment
   `changelog.d/433-git-log-framing.md` is on main, credited `thanks @pt-act`, carrying the hostile
   fixture, the `kQChurnCacheScheme` 3→4 bump, the field-read abandon contract, and the disclosed
   collision (pinned, full fix owned by the follow-on spec material). Ships in the next release per
   the maintainer, with changelog and release-notes credit.

## Downstream effects

- `audit-validation-standalone`'s `gitRecordFraming` consumption is satisfied (its replay source now
  parses under the merged reader on main).
- The disclosed collision (merge whose first combined path is `__C__`) stays DISCLOSED, pinned by
  the gate, full fix = the format-sentinel change (follow-on spec material, unchanged).
- The deferred emit-surface work (epoch floor + `history_unread` broadening to `--cochange` /
  `--rank-by=churn` / `--owners`) is **upstream-registered** in `historyread.h` NOT COVERED — NOT
  an open item on this DAG; a contribution opportunity this seat has offered to take when the
  maintainer wants it off their list (reply posted on #433, `6521104913`).

## Standing-state note

The lane's FROZEN discipline held to the end: after the 2026-10-30 thread replies, this seat pushed
nothing; every fix on main arrived through the maintainer's branch. The scoped follow-up lane
(export fix → walker rule → arm 9) is moot-landed: implemented upstream as `b66e26e6` + `90acd0f1`.
The seat's next opportunity is the NOT COVERED deferral, upstream-owned until assigned.
