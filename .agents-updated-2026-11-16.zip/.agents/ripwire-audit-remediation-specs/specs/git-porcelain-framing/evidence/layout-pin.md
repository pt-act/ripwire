# Phase 1 — NUL-framed byte-stream prototype, layout pin, and two findings

Spec `git-porcelain-framing` · producer round 1 · base commit `0e0f67c7` · 2026-10-14

This is the Phase-1 record: the exact `git log` byte streams (old and new), the pinned layout, and
two findings the prototype surfaced that change how the fixture and the helper must be built.

## The five consumers, three command shapes

`src/gitmine.h` has **15 `__C__` sites** across **five consumers** and **three command shapes**:

| # | consumer | line | command shape | marker test |
|---|---|---|---|---|
| 1 | `gitLogFileSets` | 1493–1532 | `--format=tformat:__C__` | **exact** `s == "__C__"` (L1518) |
| 2 | `gitLogNameOnlyRaw` | 1620–1661 | `--format=tformat:__C__%x20%ct` | prefix `s.rfind("__C__",0)==0` (L1641) |
| 3 | `gitFileCommitCountsInDayWindow` | 1820–1892 | `--format=tformat:__C__%x20%ct` | prefix (L1872) |
| 4 | `gitLogDecayedFileWeights` | 2050–2130 | `--format=tformat:__C__%x20%ct` | prefix (L2108) |
| 5 | `gitFileAuthors` | 2386–2501 | `--format=tformat:__C__%ae\|%at` | **5-byte** prefix `s.compare(0,5,"__C__")==0` (L2464) |

Shapes 2–4 are identical (`__C__` + space + committer epoch, epoch parsed from `c_str()+6`); shape 5 is
`__C__` + author email + `|` + author timestamp; shape 1 is the bare marker.

## The old byte stream is catastrophically ambiguous

Fixture: one commit, `true.author@example.com`, files `normal.txt`, `__C__`, `__C__x|1694000000`,
`__C__ 1694000000`, `a\nb`, `a\rb`.

Shape B (`--format=tformat:__C__%x20%ct`, `cat -v`):

```
__C__ 1694001600\n
\n
__C__\n                      <- the FILE named "__C__"   -> parsed as a commit boundary
__C__ 1694000000\n           <- the FILE named "__C__ 1694000000" -> parsed as a marker, epoch forged
__C__x|1694000000\n          <- the FILE named "__C__x|1694000000" -> prefix-matches the marker
"a\nb"\n                     <- the file a<LF>b, C-quoted -> never resolves to its real path
"a\rb"\n
normal.txt\n
```

Shape C (`--format=tformat:__C__%ae|%at`) is worse: `__C__x|1694000000` is read as a **header** with
email `x` and timestamp `1694000000`, so **every path after it is attributed to the forged author**.
That is audit finding #4 (Medium) reproduced exactly.

## The new byte stream, and the pinned layout

Command: `git -c core.quotepath=false log -z -c --name-only --format='%x00__C__%x00<fields>'`

Shape B tokens (`%x00__C__%x00%ct`), 3 commits incl. an empty one:

```
[0] b''                      <- EMPTY FIELD = record delimiter
[1] b'__C__'                 <- marker, full field
[2] b'1693699200'            <- committer epoch
[3] b''                      <- next record delimiter (the empty commit emitted no paths, no '\n')
[4] b'__C__'
[5] b'1693612800'
[6] b'\nb.txt'               <- FIRST path of the commit: git prefixes it with one '\n'
[7] b''
[8] b'__C__'
[9] b'1693526400'
[10] b'\n__C__'             <- the FILE named "__C__" — a path, NOT a marker
[11] b'__C__ 1694000000'    <- the FILE named "__C__ 1694000000" — a path
[12] b'__C__x|1694000000'   <- the FILE named "__C__x|1694000000" — a path, no forged metadata
[13] b'normal.txt'
[14] b''
```

### The layout, pinned

```
<format output, fields NUL-separated>  \0  [ \n  <path1> ]  \0 <path2> \0 ... <pathN> \0
```

1. **`-z` makes the name list NUL-terminated and RAW** (no C-quoting): a path may contain `\n`, `\r`,
   `"`, `\` and any non-NUL byte, and it round-trips byte-exact.
2. **git terminates the commit header with `\0`**, then emits **one `\n` before the first path** of a
   commit that has paths (an empty commit emits neither the `\n` nor any path).
3. **An empty field can only come from the format.** Paths are never empty, so `\0\0` is an
   unambiguous record delimiter and a path can never be mistaken for one.

### Why the empty-field delimiter is SOUND (and a bare `__C__` marker is not)

A bare full-field `__C__` marker is *not* sufficient on its own: a repo can contain a file named
exactly `__C__`, which also produces a bare `__C__` field — and as a non-first path it is
indistinguishable from a marker. The empty field closes this: the format emits the delimiter, then
`__C__`; **the field immediately after a delimiter is always the format's marker, never a path.** A
path named `__C__` is therefore always seen as a path (`\n__C__` as the first path, or a bare `__C__`
*after* another path — never after a delimiter). Verified above at tokens [10] and [11].

### Reading rule the helper must implement

- Split on NUL. An empty field starts a record.
- Read the marker field, then the shape's fixed metadata fields.
- The next field is the first path **with exactly one leading `\n` stripped** (git's separator); a
  record with no path field is a path-less commit.
- Every subsequent non-empty field up to the next empty field is a path.

## Finding 1 — the fixture must contain INDEXED (code) files

The spec's fixture is "files named `__C__`, `__C__x|1694000000`, a filename containing `\n`, and one
containing `\r`". Built literally (extension-less names), ripwire indexes **zero** files:
`--owners` on such a repo answers `git unavailable / no history`, and the map reports `files=0
unindexed="txt:2"`. `resolveGitPath` only resolves **indexed** files, so an unindexed hostile name is
invisible to every miner — and the arms would pass vacuously on the baseline.

**The attack needs the hostile name to sort BEFORE an indexed file.** `git log --name-only` emits
paths in byte order, and a forged header takes effect for every path that follows it. So the fixture
must pair each hostile name with an indexed code file that sorts **after** it. `__C__` (0x5F…) sorts
before lowercase `a…`, so a file `Alpha.cpp` (0x41…) sorts before `__C__` — that is how the exact-match
flush is made observable on co-change.

## Finding 2 — the `\n` separator is a git implementation detail

The `\0` header terminator and the `\n` path separator are not documented `--format` behaviour; they
are what `git log -z --name-only` emits here. The gate must **pin them** (arm: a two-commit fixture
whose first path is asserted exactly) and record the **minimum git version** in its header, so a
different git that changes the separator fails loudly instead of silently corrupting the first path.
