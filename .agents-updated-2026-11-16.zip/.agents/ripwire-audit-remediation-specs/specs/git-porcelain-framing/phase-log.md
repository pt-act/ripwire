# Phase Log — git-porcelain-framing

Working document: decisions and deviations per phase. Not narration; the completion report is the
summary of record.

## Phase 1 — NUL-framed byte-stream prototype + fixture repo + layout pin

- **Decision:** the reader is a *sibling* of `readByteSafeLine`, not a delimiter parameter on it. The two delimiters answer different questions ("where does this line end" vs "is this field the record boundary"), and a caller that confused them would read a hostile filename as commit metadata. Kept as `readNulSafeField` in `src/infra/stdinline.h` with the same parity contract (one `fgetc` per byte, EOF as an int sentinel distinct from every byte value, the only narrowing explicit through `unsigned char`).
- **Layout pin (empirical, git 2.52.0):** `git log -z -c --name-only --format=%x00__C__%x00%ae%x00%at%x00%ct` emits, for a regular commit, `NUL marker NUL author NUL at NUL ct NUL \n first-path NUL path… NUL` — i.e. **no trailing `%x00`**, the last field runs to the stream's end. A merge emits **one extra empty field** (the prefix empty) before its combined diff's bare paths.
- **Deviation (carried into the completion report):** fixtures are built at runtime at fresh `mktemp` paths rather than committed under `test/fixtures/`. Reason: the `$TMPDIR/ripwire` memo's path-derived repo key.

## Phase 2 — Shared helper; both parser families migrated

- **Decision:** one command shape (`gitLogRecordsCmd`) for all five consumers, with `extraArgs` riding **at the end**. This was not the first cut: the first cut placed `extraArgs` before `-z --name-only --format=…`, which made git read the flags after a `--` pathspec as *paths* and answer in its default format. Measured: `--owners=SYM` exited 1 with "git unavailable / no history" on a healthy one-commit repo while the all-files form beside it was correct. Fixed before push; pinned by gate arm (c2).
- **Decision:** the boundary rule carries **one field of lookahead** — an empty field ends the record and opens the next iff the field after it is the marker (or the stream ends). Any other empty is a merge's prefix empty, skipped but counted; the count also decides the first path's `\n` strip (a regular commit's first path carries git's separator, a merge's arrives bare).
- **Decision:** `markWalkUnread`/`noteWalkExit` are removed in the same lane that took their callers, not left for a later tidy. On this tree a helper that lost its last caller is a gating `--quality-delta` finding.
- **Deviation:** the advisory interface name `gitLogRecords()` was not used; `forEachGitLogRecord` was delivered (visitors, not collectors).

## Phase 3 — The gate, the golden, the registration

- **Decision:** the gate's fixture carries both merge shapes — a name-bearing merge whose first combined path is an *ordinary* file (the lookahead is load-bearing) and the **disclosed collision** (first combined path literally `__C__`), pinned rather than papered over.
- **Decision:** the golden is recorded from the **pre-change** binary, not the fixed one — that is what makes it evidence of "no behavior change on honest trees" rather than a self-consistency check.
- **Deviation:** the golden's corpus is a small deterministic honest tree, not the ripwire checkout itself (memo-cache reproducibility; same root cause as the Phase-1 fixture deviation).
- **Registration:** `gitframingcheck` added to `regression.sh`'s absorb loop; the published count is the generator's build product, so `docs/gatecount_build.py` rewrote the three marked sites 703 → 704.

## Phase 4 — PBT harness + evidence bundle

- **Not delivered.** The deterministic gate pins the same three properties over a fixed hostile corpus; the spec's generated domain (≥20,000 filename cases over bytes 0x01–0xFF, ≥1,000 generated streams) is strictly stronger and remains outstanding. Recorded as Known Deviation 3.

## Post-delivery — the CI style red (2026-10-23 evening)

PR #433's style job came back red. **Root cause: the clang-tidy leg, not clang-format** —
`bugprone-use-after-move` on `lookahead` in `forEachGitLogRecord` (`src/gitmine.h:880`, `:888`),
two moves of the same slot in different loop iterations that no reader can prove are separated by a
reassignment. `scripts/formatcheck.sh` was clean over all 9 gated files under clang-format 22
(including `src/infra/stdinline.h`, the gated file commit 1 extended — so the initial guess that the
red was a clang-format patch-version difference was wrong).

**The finding was dead code, not a bug and not noise to NOLINT.** The top of the loop consumes the
held lookahead and clears the flag before any field is examined; the only writers (the boundary and
merge-prefix branches) each assign a fresh value before the next iteration. So when the empty field
asks "what follows me?", the slot is provably empty and the field after it is always the next one on
the stream. The `haveLookahead ? ( next = std::move( lookahead ), … ) : fields.next( next )` ternary
could never take its true branch — defensive code for an invariant the loop does not have, whose move
of `lookahead` is exactly what made the slot's lifetime unreadable to the check.

**Decision:** remove the dead branch (the project rule is "a finding is a bug to fix, not a line to
NOLINT"; here the fix is deletion, and the invariant is now stated in a comment so it is not
"restored"). **Behavior-preserving, and measured rather than asserted:** the framing gate's output is
byte-identical before and after (same 35 arms, same digest pin, same golden).

**Process note:** the fix landed as an additive seventh commit on the pushed lane rather than a
fixup-fold into the commit that introduced it. The lane is public and CodeRabbit has already reviewed
it; folding would mean force-pushing over reviewed history, and the PM seat's read of the convention
expected "ordinary PR iteration" here. The trade-off is recorded rather than hidden: commit `5ea40f8a`
is red on this check for anyone bisecting, and the seventh commit is the fix.

## Post-delivery — the CI round: six reds, and the one that was not what it looked like (2026-10-23 evening)

PR #433's CI came back with six reds: the style leg (clang-tidy 22, `bugprone-use-after-move` on
`src/gitmine.h`), deckcheck (`--dashdash` in the CHANGELOG), crashsweepcheck S2 (six registry
violations from the five-to-one reader refactor), gateexitcheck G2 (a one-line verdict),
gitframingcheck (digest + golden drift) and memguardcheck B21 (the abandon-contract narrowing —
a real regression from the lane). Each is fixed on the lane as an additive commit; the causes and
the controls are in the completion report's Post-Delivery Record.

**The diagnosis worth keeping: the digest drift was the TIMEZONE, not the git version.** The first
hypothesis — CI's 2.55/2.56 against the 2.52 the pin was recorded on — was disproved by building
git 2.56.0 from source and reproducing the pinned digest byte-for-byte under it. The fixture's
dates are naive strings, and git reads a naive `GIT_AUTHOR_DATE` in the machine's zone: the same
fixture reads `a823b914…` under WEST and `9a112638…` under UTC, on both versions. CI is UTC; the
recording Mac was not. The gate pins `TZ=UTC` now, the digest pin is the UTC reading, and the
golden was re-recorded under UTC from the pre-change binary — the recording procedure proven
first by reproducing the committed golden byte-for-byte under the machine's own zone. **Generalizable
lesson: a gate fixture that hardcodes naive dates is a machine-portability defect wearing a
version-drift costume; the discriminator is to hold the version fixed and move the zone, not the
reverse.** The same latent defect lives in the other naive-dated fixtures (mergechurncheck and
its 2026-06 dates) — deliberately NOT fixed here, because shifting their epochs re-derives their
literals, and that is a separate change with its own blast radius.

**A second host finding, not the lane's:** memguardcheck's B8/B8b fail on this Mac — and fail the
same way on the pre-change binary (`rc=0` where the gate expects exit 5; the time-gated soft stop
the gate's own commentary names as a host outcome). The discriminator that keeps it out of the
lane's account is the pre-change control. The lesson generalizes too: **a gate that fails on your
machine is not evidence about your change until you have run it against the change's absence.**

**Process note, same shape as the seventh-commit decision:** the fixes landed as seven additive
commits on the pushed lane (one per red, each naming the red it clears) rather than as fixups —
the lane is public and reviewed, and folding would mean force-pushing over reviewed history. Two
of the seven are red-on-one-leg intermediates by construction (the copy fix is green on the style
leg and red on B21 until the abandon commit lands; the reverse for the base), which is the same
trade the seventh commit already recorded.

## 2026-10-25 — the producer's resume: countersign discharged, report finalized, one CI gap found

The producer resumed after the 2026-10-24 cooldown to find the lane at `cc6b312f` (its own seven
commits plus the PM seat's review-round fix `7d8b0a54` and its one-token rider `cc6b312f`) and a
validation verdict (`validation/verdict.md`, approved_for_push) carrying a **countersign debt**:
`7d8b0a54` is PM-produced, so under the lineage rule the PM's verdict cannot seal it.

**The countersign, with the producer's own measurements on a fresh build of the final tree:**
- Read: the diff matches its message and the CodeRabbit replies; the reading AGREES on all three
  load-bearing decisions (state-decided empties; nullopt-vs-zero epoch split with the
  `epochUnparsed` sink; the ownership guard keeping only its epoch half).
- Ran: `gitframingcheck` ALL PASS (14 arms / 39 assertions), arm (f) green.
- **Red control, independently built:** a fresh worktree at `b3a64534` (13m36s) fails the same
  gate 36/3 — exactly arm (f)'s assertions (`--owners=emptyMailFn` exits 1 "git unavailable /
  no history", path lost, no churn row). The defect reproduces on this seat's own build.
- Also on the final tree: `ripwirepubliccheck` ALL PASS (17), `crashsweepcheck` ALL PASS (28),
  `gateexitcheck` ALL PASS (22), `--quality-delta` `gating="0"` (2 new-symbol regressions).

**Two findings proven NOT the lane's, by control — the discriminator is always the change's
absence:** memguardcheck B8/B8b (the host-dependent time-gated soft stop — fails identically on
the pre-change binary here and in the PM's verify tree) and affectedcheck (8f), which
**root-caused to the gate script**: `grep -q 'modscope\|MODULE SCOPE'` is GNU-only BRE
alternation, and BSD grep reads `\|` as a literal pipe — the dumped failing answer contains both
strings and `grep -qE` matches. A latent macOS-portability defect in the repo's test suite,
invisible to Linux CI; the one-line fix (`grep -qE`) plus a tree-wide sweep for the pattern class
is recommended as follow-up, not landed (the lane stays scoped; nothing ships without the
handshake).

**Deckcheck deadlocks on this Mac** (second observation; blocked 25+ min with no children). Its
legs are covered without the full run: CI green at `7d8b0a54` (that run's only failure was the
ripwirepubliccheck arm `cc6b312f` repaired), the rider touches only a test file (not a prose
source), and the token leg was verified clean by faithful simulation (317 tokens, no unknowns,
no rot).

**The CI gap — the round's one genuinely new fact:** **no `pull_request` run was ever created for
`cc6b312f`.** The push that advanced PR #433's head produced no run in either repo (the lane
branch's run list stops at `7d8b0a54`; the tip's only status context is CodeRabbit). CI's own run
on `7d8b0a54` measured 179 gates / 176 pass / 2 skip / 1 fail — the single failure being the
ripwirepubliccheck arm the rider repaired and this seat re-verified ALL PASS. The authoritative
full-suite verdict on the FINAL tree therefore does not exist yet; re-triggering it is a
ship-key action (PM/operator). A local full pargates run was launched on the final tree in
parallel; its result lands in the completion report's open slot.

**Artifacts:** `validation/completion-report.md` gained the Finalize Pass (countersign, the two
control-proven findings, the slot); the PR body carries the 13-commit table and the post-review
record. The countersign debt is **discharged**; the remaining move is the PM's (re-trigger CI,
then the handshake). Nothing was pushed by this seat.

---

## 2026-10-30 — PR #469 (maintainer integration branch): all three CodeRabbit findings verified and answered

**Event:** joyful-ii-V-I opened PR #469 (`community/pr433`, head `fafb3f26` = our 19 commits through
`b8d4a732` + his merge `f65c2a93` + `83c8f096` (collision-disclosure comment correction, fragment
credit) + `fafb3f26` (arm (g): a merge whose first combined path *starts with* the marker keeps its
files)). CodeRabbit posted three Minor findings at 00:17Z. This seat verified each against the PR
tip (worktree `pr469-r1`, Release build green, `gitframingcheck` ALL PASS incl. arm (g)) and
answered all three on-thread as pt-act: F3 → `4420227197`, F2 → `4420227351`, F1 → `4420227552`.

- **F3 (REAL_GIT unexported, gate:98) — CONFIRMED, accepted as ours (origin `4c0aa673`).** The
  unexported assignment makes the shim's `exec "$REAL_GIT"` an `exec ""` — every non-`-z` call dies
  127, the tool loses git entirely, and the arm's assertions pass byte-identically in BOTH
  environments (measured on the PR binary: stdout AND stderr identical, down to the ignore-probe
  degrade line). The arm cannot discriminate its design scenario from the weak one. Fix = the
  one-liner; carried in the follow-up lane; arm (g)'s parent-shell use unaffected.
- **F2 (marker-less exit-0 streams read as success) — CONFIRMED + the cache consequence CodeRabbit
  did not name: the qchurn cache stores the lie.** Measured end-to-end on the branch binary: a
  delegating shim (only `log -z` faked to line format) yields rc=0, no `churn=`, no
  `history_unread`, writes the poisoned empty blob; a healthy rerun on the same cache root SERVES it
  (byte-identical output, blob mtime unchanged); cold control prints `churn="1"`. Control pair: an
  exit≠0-all-calls shim produces `history_unread="1"` + NO blob — K51 works exactly as designed on
  every shape except exit-0-with-bytes. Scope ruled in-seat: the walker rule alone suffices
  (`!anyRecordVisited && sawBytes && exit==0 → unread`) because gitLogNameOnlyRaw already
  propagates unread/notRun/exitCode, so K51's cache refusal and history_unread="1" engage
  automatically; the other consumers' verbs already refuse on empty. Also recorded: pre-existing
  (the old line frame had the same exit-0 rule AND fabricated a phantom commit record), so the new
  frame strictly dominates — not a #433 regression.
- **F1 (epochUnparsed not propagated) — CONFIRMED, owned as the PR body's disclosed follow-up.**
  Consumer map recorded in-thread (day-window counts exclude degraded-epoch commits = a floor;
  decayed mining gives them FULL weight = the worst of the set; ownership skips them;
  gitLogFileSets unaffected — window enforced git-side; the counter dies at gitLogNameOnlyRaw —
  RawCommitStream has no such field, and its serialization is kQChurnCacheScheme-gated cache
  schema, i.e. a scheme bump for the raw-stream half). Ruled: stays follow-up, composable with
  F2's walker rule.

**Follow-up lane scoped (NOT started; FROZEN holds — the branch is the maintainer's, mid-review):**
the export one-liner → the marker-less walker rule → its red-first delegating-shim arm (needs the
export first — the findings compose) → optionally the epoch-floor emits. One lane, one review
round, sequenced after his #469 merge.

**Artifacts:** `ripwire-scratch/logs/cr469-verification.md` (full analysis), `cr469-reply-f{3,2,1}.md`
(posted bodies, read end-to-end per SR-2026-10-18), PROGRESS.md + current_focus.md + day-log
2026-10-30 entries; two new standing requirements recorded (gate-scenario discrimination;
measure-on-the-reviewed-tree) and two ADs (the marker-less unread rule; the walker-rule-alone
scope). Nothing pushed to any lane.

---

## 2026-10-30 (later) — MERGED UPSTREAM. Spec APPROVED on the merge evidence. Lane CLOSED.

**The merge:** PR #469 merged as `d044662a` (2026-10-30T08:45:42Z, joyful-ii-V-I): our 19 commits kept
as written + his review fixes co-authored with pt-act (`b66e26e6` REAL_GIT export + premise arms;
`90acd0f1` the marker-less walker rule + arm 9 with its control pair; `0666a5e8` the epochUnparsed
review-note + NOT COVERED registration) + train-42a re-merge `850cafaa` + arm (g) `fafb3f26`. **CI
success on the merge head. #433 closed by it.** Changelog fragment on main credited; ships next
release with changelog + release-notes credit. The maintainer's thank-you (`6520447759`) credits the
NUL-framed reader's robustness contract and names the one follow-up (history_unread on --cochange /
--rank-by=churn / --owners) as tracked for a later release.

**Notable — the scoped follow-up lane was implemented by the maintainer inside #469:** the F3 export
fix and the F2 walker rule this seat scoped in its 2026-10-30 thread replies landed as his two
review-fix commits, each *exceeding* our scope (premise arms; the unshimmed control in arm 9). The
scoped lane is moot-landed; nothing was owed from our side. The F1 emit-surface work alone remains
— upstream-registered (historyread.h NOT COVERED), NOT an open DAG item; this seat's offer to take
it stands on the #433 close reply (`6521104913`).

**The flip:** spec `in_progress` → `approved`, manifest status + `spec_approved` history event,
resolution report at `validation/resolution-report.md` (evidence chain: completion-report +
verdict → maintainer integration → the three answered CodeRabbit findings → his fix commits with
convergent shapes → CI green → merge). Same Q10 path as regex-screen-hardening; the producer never
flipped status; the dispatcher (this seat, under the operator's standing directive) performed the
terminal act. `_selfcheck.py`: **ALL MACHINE-RUN CHECKS PASS** (15 specs).

**Terminal state:** the lane's ship-key discipline held to the last — after the 2026-10-30 thread
replies this seat pushed nothing; every fix arrived through the maintainer's branch. Residuals both
carried forward honestly: the disclosed `__C__`-merge collision (pinned; format-sentinel follow-on
spec material) and the upstream-registered NOT COVERED deferral. Done.
