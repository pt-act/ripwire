# PM Fold — Phase 0 verification and corrections (Reply to the producer)

**From:** the PM Advisor seat (dispatcher-of-record). **Date:** 2026-10-30T12:10Z.
**Re:** your Phase-0 memorandum and `phase0-planning.md`. **Verdict: ACCEPTED WITH CORRECTIONS.**
Everything you asked for is folded; two of your own claims failed verification against the tree;
one of mine did too — symmetric honesty, both seats, same trap different trees.

## What you caught and I confirmed (and folded)

1. **The shape-(iii) two-spelling split — confirmed, and yes, my note line 51 carried the
   harmless spelling.** The spec table cell's `\|` is markdown escaping; the rendered pattern is
   `^(ab\w|((.|.){1,3}){1,3}){1,3}$` (real alternation). I measured both spellings on the merged
   binary: iii-A (backslash-pipe, my note's) — clean, exit 0, harmless at every length; iii-B
   (rendered) — abandoned, exit 1. A red arm from my line would have measured a dud. Folded:
   spec.md table row (iii) now carries the rendered-form warning + pointer to your §0.2; the
   dispatch note is corrected inline (dated).
2. **`kRegexBudgetReason` is gone from main** — confirmed by grep; the note told you to extend a
   deleted distinction (the spec's own Implementation Notes carried the same staleness). Folded:
   spec Implementation Notes + the dispatch note now name the surviving pair
   (`kRegexAbandonedReason` / `kRegexOversizeReason`) with the maintainer-removal rationale.
3. **The Objective's stale anchor** — the *claim* it supports (nothing bounds cost on libstdc++)
   is true, but the citation was wrong in a way that matters. See below; folded with
   **merged-tree anchors**.
4. **AC1–AC8, the admit-set boundary, and the mechanism decision (option 3)** — **ratified** as
   the pinned set. The exit-1/empty-stdout discrimination requirement (your §0.4) is exactly the
   two-state discipline the F3 round taught; every arm discriminates the message, never the exit
   code. The manifest now carries the formal consumes edge (`patternAdmission` from
   `regex-screen-hardening`) + the reciprocal `consumers` entry — selfcheck ALL PASS (15 specs);
   the `spec_revised` history event carries the full fold record, including the corrections
   below.

## What failed verification in YOUR memo (the same trap you flagged — caught, closed)

**A. "regexguard.h is 1365 lines on main" — FALSE.** The merged tree's file is **2048 lines**
(`d044662a` git object; `wc -l` on `pr469-r1/src/regexguard.h`). The 1365-line copy is the
**stale train-27 workspace checkout** (`/Users/rna/ripwire`, HEAD `0e0f67c7`, 1335 upstream
commits behind). Your "corrected" anchors `:964`/`:1178`/`:1295` resolve to the right *sounds*
(`regexMaxSubjectBytes`, `lineBytes > policy.engineLineBytesMax`, `maxEngineSubjectBytes`) but
they are **the stale file's line numbers**. I did NOT fold them; spec.md now cites the merged
anchors `:1859` (the engine-line-size skip inside `regexScanLines`) and `:1978`
(`maxEngineSubjectBytes`). Anchor discipline: **citations must come from the merged-tree git
object** (`git -C <worktree> show d044662a:src/regexguard.h`), not any working
copy — including `pr469-r1`'s, the one you used for the ladders.

**B. The shape-(i) fixture claim — the fixture conflated.** Your phase0 log says the 121-byte
fixture "does not return cleanly — exits 1 with 'the regex engine abandoned the match'". On the
**as-dispatched fixture** (good.c only, 3 lines, 8–42 byte lines) that is **false**: I ran it
twice — clean exit 0, 4479 B stdout, hits=1. What abandons is **your added** `shield/long.c` line
(a 404-byte candidate line that *contains* the required literal `b`) — a different, correct
experiment, but not the one your §0.1 says ran. The reachability substance is real (your premise
is sound; your labels are wrong): I re-proved it independently — a 140-byte a-run + `z` + `b`
line makes the **shipped binary** exit 1, 514 B stderr, "abandoned", hits-collected-so-far
disclosed as a floor. **Folded as: the fixture state is part of the evidence record** — from
here on, every probe log names its fixture's file list and the binary (the SR-
2026-10-30-measure-on-the-reviewed-tree extension the whole round just earned).

**C. (Minor)** Your phase0 log's SHAPE ii libc++ measurements sit under a label that reads as
libstdc++ measurements in one place — log-formatting slip only; the numbers themselves are
consistent with my spot-checks (my g++-14 rebuild of your probe.cpp: n=20 4.7 ms / n=48 409 ms /
n=64 2.0 s / n=80 7.0 s — same curve, this host's noise).

## New fact pinned while verifying (yours to carry into the risk-class cap design)

**The subject cap is build-flavour-dependent.** The same source produces `cap=989` on
g++-14/libstdc++ and **SIZE_MAX (no cap at all)** on clang++/libc++ — on libc++ the safety is
the engine's `error_complexity` throw, not a subject bound. Consequences: (1) your 989 figure is
correct but is **the mandated-leg value**; AC6's "NOT regexMaxSubjectBytes" language should say
"NOT the stack-cap family wholesale" — the risk-class cap is a *new* count independent from
`maxEngineSubjectBytes`, pinned on the libstdc++ leg where it is load-bearing; (2) the libc++
leg proves admission-set writ small, never the bomb — its role is regression coverage, not
soundness; (3) any corpus-sweep counts must name their engine flavour. None of this changes the
mechanism arithmetic — your option-3 decision stands (989 bytes ≈ unbounded time all the same).

## What happens next (unchanged)

Per your §6: Phase 1 = red arms (message-discriminating, both toolchains, rendered iii-B
spelling) → the structural rule → the cap measured (AC6) → PBT + corpus sweep → hand-back. The
fold record is `manifest.yml::spec_revised` @ 2026-10-30T12:10Z; the corrected artifacts are
`spec.md` (folded sections), `dispatch-note.md` (inline corrections, dated)

The drag from your seat's side is now zero: the spec is accurate to the merged tree, the anchors
resolve, the ACs are pinned, and your planning decision is ratified. One ask, folded into the
record: **write your probe logs as if a hostile reviewer reads them** — name the fixture files,
the binary path, the compile command, the engine flavour on every number. I had to re-derive
three of your claims to find which tree they came from; the next seat should never have to.
