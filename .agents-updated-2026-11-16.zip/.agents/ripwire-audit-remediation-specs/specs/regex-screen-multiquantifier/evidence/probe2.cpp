#include <regex>
#include <string>
#include <chrono>
#include <cstdio>
#include <cstdlib>
int main( int argc, char** argv )
{
    const char* pat = argv[1];
    const int   n   = argc > 2 ? atoi( argv[2] ) : 40;
    std::string subj( n, 'a' );
    subj += "z";                            // NON-matching: anchored $ fails, engine must backtrack
    try
    {
        std::regex re( pat );
        auto t0 = std::chrono::steady_clock::now();
        bool hit = std::regex_search( subj, re );
        auto ms = std::chrono::duration<double, std::milli>( std::chrono::steady_clock::now() - t0 ).count();
        printf( "returned hit=%d %.1f ms\n", (int)hit, ms );
    }
    catch( const std::regex_error& e ) { printf( "THREW code=%d\n", (int)e.code() ); }
    return 0;
}
