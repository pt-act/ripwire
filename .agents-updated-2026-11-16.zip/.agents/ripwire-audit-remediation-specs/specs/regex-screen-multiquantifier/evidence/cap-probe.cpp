#include "regexguard.h"
#include <cstdio>
#include <string>
#include <chrono>
int main( int argc, char** argv )
{
    const std::string pat = argv[1];
    const int n = atoi( argv[2] );
    auto c = rw::compileGuardedRegex( pat, rw::kRegexEcmaScript );
    if( c.refusal ) { printf( "SCREEN-REFUSED\n" ); return 0; }
    const std::size_t cap = c.regex.maxEngineSubjectBytes( 8 * 1024 * 1024 );
    // subject CONTAINS the required literal 'b' (so the prefilter passes) but still does not MATCH
    std::string subj( n, 'a' ); subj += "bc";
    printf( "cap=%zu len=%zu  ", cap, subj.size() ); fflush( stdout );
    auto t0 = std::chrono::steady_clock::now();
    auto v  = c.regex.search( subj );
    auto ms = std::chrono::duration<double, std::milli>( std::chrono::steady_clock::now() - t0 ).count();
    const char* vn[] = { "Miss", "Hit", "Exhausted", "Skipped" };
    printf( "verdict=%s %.1f ms\n", vn[ (int)v ], ms );
    return 0;
}
