#!/usr/bin/env python3
"""phase1-pbt.py — property-based testing for the multi-quantifier screen (AC4).

WHAT THIS PROVES, and what it deliberately cannot:

  P1 NO CRASH.          Every generated pattern exits 0 or 1. A signal death is a finding.
  P2 NO HANG.           Every generated pattern returns inside the cap. A pattern the screen ADMITS may still
                        hang the ENGINE on a hostile subject — that is the disclosed residual, not a bug — so the
                        subject here is BENIGN and short, and P2 is about the SCREEN's cost, not the engine's.
  P3 VERDICT IS A FUNCTION OF (pattern). Two runs of the same pattern give identical exit status AND identical
                        stderr bytes. This is AC5 and it is the property that forbids a wall-clock bound.
  P4 ONE REFUSAL VOCABULARY. When a pattern is refused, exactly one of the two lead-ins appears, never both,
                        never neither. Refusal and abandonment are indistinguishable by exit status, so the
                        lead-in IS the contract.
  P5 MONOTONE ADMISSION. Every pattern the BASE binary refuses, this build also refuses. This is AC4's
                        "newly-admitted must remain 0" and the single most important property here: a widened
                        screen may eat working patterns (disclosed, permitted) but must never release a bomb.

The patterns are SEEDED (default 20261031) so a failure is reproducible, and generated as grammar walks over the
constructs this screen reads: atoms, classes, shorthands, quantifiers (bounded and not), groups (capturing,
non-capturing, nested), alternation, anchors. That is the input space the two clauses actually decide over.

Usage:
  ./phase1-pbt.py --bin build/ripwire [--base /path/to/prechange/ripwire] [--cases 10000] [--seed N]
Exit 0 when every property holds; 1 otherwise, printing the first counterexample per property.
"""
import argparse, itertools, os, random, shutil, subprocess, sys, tempfile

ATOMS = ['a', 'b', 'c', 'z', '0', '1', '.', r'\d', r'\w', r'\s', r'\S', r'\D', r'\W',
         '[a-c]', '[^a]', '[0-9]', r'\.', r'\+', r'\|']
QUANT = ['', '', '', '*', '+', '?', '{2}', '{1,3}', '{0,2}', '{2,}', '{1,}']

def gen_atom(rng):
    a = rng.choice(ATOMS)
    return a + rng.choice(QUANT)

def gen_group(rng, depth):
    """A group body: 1-3 items, optionally alternated. Depth bounds nesting."""
    if depth <= 0:
        return gen_atom(rng)
    n = rng.randint(1, 3)
    parts = [gen_piece(rng, depth - 1) for _ in range(n)]
    body = ''.join(parts)
    if rng.random() < 0.45:
        body += '|' + ''.join(gen_piece(rng, depth - 1) for _ in range(rng.randint(1, 2)))
    opener = rng.choice(['(', '(?:'])
    return opener + body + ')' + rng.choice(QUANT)

def gen_piece(rng, depth):
    if depth > 0 and rng.random() < 0.4:
        return gen_group(rng, depth - 1)
    return gen_atom(rng)

def gen_pattern(rng):
    n = rng.randint(1, 5)
    p = ''.join(gen_piece(rng, rng.randint(0, 3)) for _ in range(n))
    if rng.random() < 0.3:
        p = '^' + p
    if rng.random() < 0.3:
        p = p + '$'
    return p

def run(binary, corpus, pattern, timeout):
    """(exit_code, stderr_bytes) or ('TIMEOUT', b'') — never raises."""
    try:
        r = subprocess.run([binary, corpus, '--regex=' + pattern, '--no-cache'],
                           capture_output=True, timeout=timeout)
        return r.returncode, r.stderr
    except subprocess.TimeoutExpired:
        return 'TIMEOUT', b''

LEAD_REFUSED   = b'refused, nothing was scanned:'
LEAD_ABANDONED = b'refused, no hit is reported:'

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--bin', required=True)
    ap.add_argument('--base', default=None, help='pre-change binary, for P5; skipped when absent')
    ap.add_argument('--cases', type=int, default=10000)
    ap.add_argument('--seed', type=int, default=20261031)
    ap.add_argument('--timeout', type=float, default=10.0)
    args = ap.parse_args()

    tmp = tempfile.mkdtemp(prefix='pbt-')
    try:
        # A BENIGN, SHORT subject: P2 is about the screen's cost, and the engine residual is disclosed in
        # docs/LIMITS.md rather than asserted here. One file, few bytes, no long runs.
        open(os.path.join(tmp, 'subject.c'), 'w').write('int plain() { return 0; }\n')

        rng = random.Random(args.seed)
        fails = {}          # property -> first counterexample
        counts = {'total': 0, 'refused': 0, 'admitted': 0, 'abandoned': 0}

        def fail(prop, detail):
            fails.setdefault(prop, detail)

        for i in range(args.cases):
            pat = gen_pattern(rng)
            counts['total'] += 1

            rc, err = run(args.bin, tmp, pat, args.timeout)

            # P1 no crash
            if rc == 'TIMEOUT':
                fail('P2-no-hang', f'{pat!r}: still running after {args.timeout}s on a benign subject')
                continue
            if rc >= 128:
                fail('P1-no-crash', f'{pat!r}: signal death, exit {rc}')
                continue

            # P4 one vocabulary
            has_r, has_a = LEAD_REFUSED in err, LEAD_ABANDONED in err
            if has_r and has_a:
                fail('P4-one-lead-in', f'{pat!r}: BOTH lead-ins present')
            if rc == 1 and not (has_r or has_a):
                fail('P4-one-lead-in', f'{pat!r}: exit 1 with neither lead-in: {err[:160]!r}')
            if rc == 0 and (has_r or has_a):
                fail('P4-one-lead-in', f'{pat!r}: exit 0 but a refusal lead-in is on stderr')
            counts['refused'] += 1 if has_r else 0
            counts['abandoned'] += 1 if has_a else 0
            counts['admitted'] += 1 if rc == 0 else 0

            # P3 determinism — sampled, because two runs per case doubles the cost
            if i % 10 == 0:
                rc2, err2 = run(args.bin, tmp, pat, args.timeout)
                if (rc2, err2) != (rc, err):
                    fail('P3-deterministic', f'{pat!r}: run1=({rc},{err[:60]!r}) run2=({rc2},{err2[:60]!r})')

            # P5 monotone admission
            if args.base:
                brc, berr = run(args.base, tmp, pat, args.timeout)
                base_refused = (LEAD_REFUSED in berr)
                now_refused  = has_r
                if base_refused and not now_refused:
                    fail('P5-monotone', f'{pat!r}: REFUSED by the base binary, ADMITTED now — a bomb was released')

        print(f'patterns: {counts["total"]}')
        print(f'  refused (structural): {counts["refused"]}   admitted: {counts["admitted"]}   engine-abandoned: {counts["abandoned"]}')
        print(f'  seed={args.seed} cases={args.cases} engine-flavour={os.uname().machine}')
        if args.base:
            print(f'  P5 base binary: {args.base}')
        else:
            print('  P5 SKIPPED (no --base): monotone admission NOT tested this run')
        print()
        if fails:
            for prop in sorted(fails):
                print(f'  FAIL  {prop}: {fails[prop]}')
            print('\nFAILURES ABOVE')
            return 1
        print('  PASS  P1 no crash on any generated pattern')
        print('  PASS  P2 no hang on a benign subject')
        print('  PASS  P3 verdict deterministic on the sampled set')
        print('  PASS  P4 exactly one refusal lead-in, never both, never neither')
        if args.base:
            print('  PASS  P5 monotone admission (nothing the base refused is admitted now)')
        print('\nALL PASS')
        return 0
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

if __name__ == '__main__':
    sys.exit(main())
