#include <regex>
#include <string>
#include <chrono>
#include <cstdio>
#include <cstring>
int main( int argc, char** argv )
{
    const char* pat = argv[1];
    const int   n   = argc > 2 ? atoi( argv[2] ) : 40;
    std::string subj( n, 'a' );            // NON-MATCHING: no trailing 'b'
    try
    {
        std::regex re( pat );
        auto t0 = std::chrono::steady_clock::now();
        bool hit = std::regex_search( subj, re );
        auto ms = std::chrono::duration<double, std::milli>( std::chrono::steady_clock::now() - t0 ).count();
        printf( "  returned hit=%d  %.1f ms\n", (int)hit, ms );
    }
    catch( const std::regex_error& e ) { printf( "  THREW error_complexity/code=%d (engine budget)\n", (int)e.code() ); }
    return 0;
}
