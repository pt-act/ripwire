#include <chrono>
#include <cstdlib>
#include <cstdio>
#include <regex>
#include <string>
int main( int argc, char** argv )
{
    const std::string pat = argv[1];
    const int lo = std::atoi( argv[2] ), hi = std::atoi( argv[3] ), step = std::atoi( argv[4] );
    for( int n = lo; n <= hi; n += step )
    {
        const std::string subj = std::string( n, 'a' ) + "c";
        const auto t0 = std::chrono::steady_clock::now();
        bool hit = false;
        try { std::regex re( pat ); hit = std::regex_search( subj, re ); }
        catch( const std::regex_error& ) { std::printf( "  n=%3d  ENGINE THROWS error_complexity\n", n ); std::fflush( stdout ); continue; }
        const double ms = std::chrono::duration<double, std::milli>( std::chrono::steady_clock::now() - t0 ).count();
        std::printf( "  n=%3d  %11.2f ms\n", n, ms ); std::fflush( stdout );
        if( ms > 60000 ) return 0;
    }
    return 0;
}
