// Measure the ENGINE directly (no ripwire, no screen): the only honest way to price a pattern the
// screen ADMITS, because the CLI may skip the file when no required literal is present.
#include <chrono>
#include <cstdio>
#include <regex>
#include <string>
int main( int argc, char** argv )
{
    const std::string pat = argv[1];
    for( int n = 10; n <= 400; n *= 2 )
    {
        for( int shape = 0; shape < 2; ++shape )
        {
            const std::string subj = shape == 0 ? std::string( n, 'a' ) : std::string( n, 'a' ) + "c";
            const auto t0 = std::chrono::steady_clock::now();
            bool matched = false;
            try { matched = std::regex_search( subj, std::regex( pat ) ); }
            catch( const std::regex_error& e ) { std::printf( "  n=%4d %-8s ENGINE THROWS error_complexity\n", n, shape ? "a*c" : "a*" ); continue; }
            const double ms = std::chrono::duration<double, std::milli>( std::chrono::steady_clock::now() - t0 ).count();
            std::printf( "  n=%4d %-8s %9.2f ms  %s\n", n, shape ? "a*c" : "a*", ms, matched ? "HIT" : "no hit" );
            if( ms > 20000 ) return 0;
        }
    }
    return 0;
}
