#include "regexguard.h"
#include <cstdio>
#include <iostream>
#include <string>
int main(){ std::string line; while( std::getline( std::cin, line ) ){ if( line.empty() ) continue;
  const std::optional<std::string> r = rw::screenRegexPattern( line );
  std::printf( "%s\n", r ? r->c_str() : "ADMIT" ); } return 0; }
