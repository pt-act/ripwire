# Phase 0 — Planning Cycle (producer)

**Spec:** `regex-screen-multiquantifier` (draft v0.1.0 → pinned here)
**Producer:** WorkBuddy AI / Deepseek-V4.1-Flash (`-1017` session), dispatched 2026-10-30
**Base:** `d044662a` (fork `pt-act/ripwire` main synced to it; verified identical to upstream main this date)
**Status of this document:** the planning outcome the dispatch note's Phase 0 requires — interfaces and ACs
pinned, mechanism chosen, admit-set analysis answered — BEFORE the first gate arm is written red.
**Evidence:** `evidence/phase0-shape-cost.log` (all numbers below are from it; probes archived beside it).

---

## 0. What this cycle changed about the dispatch note

Three of the note's pre-change facts are **correct but incomplete**, and one is **not reproducible as
written**. None of them changes the spec's objective; two of them change the *mechanism choice*, which is
exactly what this cycle exists to settle. Recorded here first, because a producer that inherits a wrong
premise writes arms that prove nothing.

### 0.1 "All three family shapes ADMITTED live ... all returned fast on a small fixture"

The admission half is **confirmed** — I reproduced it on the merged binary (`pr469-r1 @ fafb3f26`,
`git diff` proving `src/regexguard.h` byte-identical to `d044662a`):

| shape | pattern | screen verdict |
| --- | --- | --- |
| i | `a*a*a*a*a*b` | **ADMITTED** at the screen |
| ii | `^(a)*(a)*(a)*(a)*(a)*$` | **ADMITTED** at the screen |
| iii | `^(ab\w\|((.\|.){1,3}){1,3}){1,3}$` | **ADMITTED** at the screen |

The "returned fast" half is **true of the fixture and false of the family**, and it is the more dangerous
statement of the two:

- ~~On shape (i) the note's own fixture ... does not return cleanly — it exits 1 with `the regex engine
  abandoned the match`.~~ **WITHDRAWN 2026-10-31 (PM fold claim B — the PM was right and I was wrong).**
  At **default flags** the as-dispatched fixture is **clean**: exit 0, `hits="1"`, no stderr. I had run it
  with `--no-prefilter` and did not write the flag down — my earlier `/Users/rna/ripwire-scratch/regexprobe/`
  probe dir had also accumulated my own subdirectories, so "run on `.`" was not the as-dispatched fixture
  either. Both errors are the same class the PM named, and both are now closed by
  `evidence/phase0-reachability.log`, which builds a fresh one-file fixture per row, names the flag, and
  names the binary and engine flavour on every line.
- **The reachability substance survives, from a better vehicle.** The prefilter does **not** shield the
  family: a line whose only `b` *precedes* the a-run (`b_then_a.c`) or sits *mid-run* (`b_mid.c`) passes
  `holdsRequired()` — which asks only "is the literal present", and it is — and then abandons. Measured
  with the prefilter at its **default**: both abandon (exit 1, empty stdout); the control
  `a_then_b_then_c.c` stays clean. That is the real arm vehicle.
- The family's defining property is cost that grows with the **subject length**. A fixed small fixture
  cannot exhibit it by construction. Measured ladders (libstdc++, non-matching subject):

  | shape | n=20 | n=48 | n=80 | n=96 |
  | --- | --- | --- | --- | --- |
  | i `a*a*a*a*a*b` | 5.4 ms | 498 ms | 9.2 s | **29.5 s** |
  | ii `^(a)*…(a)*$` | 2.3 ms | ~85 ms | **984 ms** | (not run) |
  | iii-B `(.|.){1,3}` nested | 0.0 ms | — | does not return from n=30 | — |

  Shape (i) doubles roughly **every 6.1 bytes** — 29.5 s at a **97-byte** line.

### 0.1b A third conflation, found while fixing the two above: the word "refused"

The stderr sentence for an **engine abandonment** begins *"ripwire: --regex='…' refused, no hit is
reported: the regex engine abandoned the match …"*. So the literal token `refused` appears in an
abandonment as well as in a structural refusal. Any grep for `refused` — mine did exactly that in a first
draft — reports abandonments as refusals. **The discriminating tokens are `abandoned` (abandonment only)
and `catastrophic backtracking` / `overlapping` (structural refusal only).** Combined with §0.4 below
(exit code is also non-discriminating), this means an arm has exactly one reliable signal: the message.
Recorded in `evidence/phase0-reachability.log` §preamble and in AC1.

### 0.2 Shape (iii) is written in two incompatible spellings, and they are different patterns

This is the one **not reproducible as written**, and it is the kind of defect that would have made a red
arm lie.

- `spec.md:37` is **inside a markdown table cell**, so `\|` there is *escaped markdown for a literal pipe*.
  The rendered pattern is `^(ab\w|((.|.){1,3}){1,3}){1,3}$` — real alternation `(.|.)` inside a bounded
  `{1,3}`. This is the family member the spec's own rationale describes.
- `dispatch-note.md:51` is **prose, not a table cell**, so its `\|` is a *literal backslash and pipe in the
  regex*. The pattern is `^(ab\w|((.\|.){1,3}){1,3}){1,3}$` — it matches a literal `|` character.

The two behave completely differently:

| spelling | screen | libstdc++ cost | classification |
| --- | --- | --- | --- |
| note's (backslash-pipe) | admitted | 0.0 ms at every n | **harmless** — not a bomb |
| spec's rendered (real pipe) | **not refused**; abandoned by the engine on libc++ | **does not return from n=30** | **the real family member** |

**A red arm written from the note's literal spelling would have been green on the pre-change binary** —
it would have "proven" the gap while measuring a harmless pattern. The pinned arm uses the spec's rendered
form. `probe2.cpp` in `evidence/` carries both, labelled.

### 0.3 Two stale code citations in `spec.md`

**CORRECTED 2026-10-31 after the PM fold (`pm-fold-phase0.md` claim A) — my first pass at this was
itself wrong, in the same way it was accusing the spec of being wrong.** Both of my "corrected"
anchors came from the **stale train-27 workspace checkout** at `/Users/rna/ripwire` (HEAD `0e0f67c7`,
1335 commits behind), where `regexguard.h` is 1365 lines. The **merged-tree git object** is 2048 lines:

```
git show d044662a:src/regexguard.h | wc -l   ->  2048
git show d044662a:src/regexguard.h | shasum -a 256
  -> d498a260d6ce3560c71b1a0ee36d615dd8796305e181fa5948a47b016528b739   (== pr469-r1's file)
wc -l < /Users/rna/ripwire/src/regexguard.h  ->  1365   (STALE)
```

**And the citation I called nonexistent exists.** `d044662a:src/regexguard.h:1657` is the return
statement of `regexMaxSubjectBytes`: `return cost.visitsPerByte == 0 ? SIZE_MAX : ...`. The spec's
Objective cites `:1657` for "the guard's per-file budget counts *lines*, not *work*, and is checked
*before* the engine is handed a line". Line 1657 is not the budget — the *skip that consults the
bound* is at `:1859` (`else if( isCandidate && lineBytes > policy.engineLineBytesMax )`) and the
bound's own accessor is at `:1978` (`maxEngineSubjectBytes`). So the spec's citation was pointing at
the wrong *thing*; my "does not exist" was pointing at the wrong *tree*. The PM's folded anchors
(`:1859`, `:1978`) are correct and verified against the merged object.

**Anchor discipline (adopted, and logged as a standing rule):** citations are read from the
merged-tree git object — `git show <sha>:src/...` — never from any working copy, including a scratch
worktree's. A working copy is a claim about a tree; the object is the tree.

1. **The `:1657` citation** now resolves (it exists) but named the wrong site; the sites that carry the
   Objective's claim are `:1859` (the per-line skip against `engineLineBytesMax`) and `:1978` (the bound).
2. **`kRegexBudgetReason`** — **does not exist anywhere in `src/`** (this one holds; confirmed by grep
   against the merged object). It was the per-file match budget's reason string, and that budget was
   **removed in upstream review** (`specs/regex-screen-hardening/validation/resolution-report.md:40`:
   *"A stopped `--regex` scan has ONE cause"*). The vocabulary on `main` is `kRegexAbandonedReason`
   (engine gave up mid-match) and `kRegexOversizeReason` (subject never handed to the engine). A
   producer told to "extend `kRegexBudgetReason` vs `kRegexAbandonedReason`" would be extending a
   distinction the maintainer deliberately deleted.

Both are corrected in §5 below and were folded into `spec.md` by the PM seat on 2026-10-30.

---

## 1. Mechanism decision: **option 3 — both** (structural rule + risk-class cap)

The spec explicitly leaves this to Phase 0. The decision, and the measurement that forces it:

**A subject cap alone cannot close shape (i).** The tree's existing cap is
`maxEngineSubjectBytes()` → `engineLineBytesMax`, computed **989 bytes** for `a*a*a*a*a*b` on an 8 MiB
stack (measured via the real `compileGuardedRegex`). That value is calibrated for **stack safety** — the
question "will this crash?" — which is a different question from "how long will this take?". Shape (i)
is exponential at ~6.1 bytes per doubling, so a 989-byte subject is ~146 doublings past the 29.5 s point
already measured at 97 bytes. **The existing cap bounds the subject and bounds nothing about the cost.**

Therefore:

- **The structural rule (mechanism 1) is the load-bearing mechanism.** It must catch the clear cases:
  adjacent quantified atoms whose character sets can overlap, flat or grouped, with no unbounded-outer-`|`
  for the first screen to see.
- **The risk-class cap (mechanism 2) is the backstop**, and it must be a **new, much smaller cap
  independent of `regexMaxSubjectBytes`** — sized so that the exponential's base case is bounded (a
  subject short enough that even the worst admitted shape terminates in bounded time), not sized for
  stack safety. Its value is a Phase 1 measurement, not a guess; the ceiling it must satisfy is
  "worst admitted shape at the cap returns in bounded time on libstdc++", and that is an AC (§3, AC6).

Choosing mechanism 1 alone would be defensible (refusal is a safe failure) but would leave the
false-positive budget to carry the whole family, and the spec names that class as the primary risk.
Choosing mechanism 2 alone is **not available** — the arithmetic above.

---

## 2. Admit-set analysis (the work, per the spec)

The rule must not eat working patterns. The contract set, all of which must stay **admitted** and
byte-identical in verdict:

| pattern | why it must survive |
| --- | --- |
| `(a\|b)+` | ordered alternation under repetition — disjoint branches, single atom |
| `(abc)+` | one literal atom repeated — no ambiguity |
| `TODO\|FIXME` | top-level alternation, no quantifier |
| `foo.*bar` | `.*` is *one* quantifier, not adjacent to another |
| `(\s*\w+){1,20}` | the spec's own bound-and-repeat control; **outer is bounded**, inner classes are disjoint (`\s` vs `\w`) |

**The soundness boundary I am pinning:** the rule refuses when two or more quantified atoms *adjacent in
the same repetition scope* have character sets that are **not provably disjoint**. "Provably disjoint" is
decided on width-one atoms only, reusing the discipline the first screen already applies to alternation
branches (`regexguard.h` character-set proofs). Where disjointness cannot be proven, the rule refuses —
the `regex-screen-hardening` Q5(a) precedent, *"a refusal is a safe failure, a hang is not"* — and the
false-positive class is enumerated and disclosed (AC4).

Two things this deliberately does **not** do:

- it does not refuse `a*a*` on the strength of the *pattern text alone being unable to prove disjointness*
  when the atoms are literally the same class — that case **is** provable-overlapping and must be refused;
  the disclosure duty is for the residual where the proof is merely *absent*;
- it does not reintroduce a per-file match budget under another name (the maintainer's removal stands).

---

## 3. Acceptance criteria — pinned (replacing the draft set)

The spec's ACs 1–5 were marked draft. These are the pinned forms; each names its red-first vehicle.

- **AC1 — the three shapes are refused, not abandoned.** For each of shape (i), (ii), and (iii-B as
  rendered), `--regex=<shape>` on a **non-matching subject of the shape's own alphabet** exits 1 with a
  **structural refusal message** identifying the overlapping-quantifier construct — *not*
  `kRegexAbandonedReason`. Red on pre-change: today all three are either admitted (i, ii) or abandoned (iii-B).
  **Discrimination (required, and stricter than first drafted):** the arm asserts the presence of the
  structural token (`catastrophic backtracking` / `overlapping`) **and the absence of `abandoned`**.
  It must **not** assert on the word `refused` — that word prefixes *both* messages, so a
  `grep refused` arm passes on an abandonment and is worthless (§0.1b). Nor on exit status (§0.4).
  **Fixture (now pinned):** the subject must **contain the pattern's required literal** while failing to
  match — otherwise the prefilter drops it and the run is clean, giving a dud arm. Vehicles:
  `evidence/b_then_a.c`, `evidence/b_mid.c`; control that must stay clean: `evidence/a_then_b_then_c.c`.
- **AC2 — the admit set is unchanged.** `(a|b)+`, `(abc)+`, `TODO|FIXME`, `foo.*bar`, `(\s*\w+){1,20}`
  all still admitted, with verdicts byte-identical to pre-change on the in-tree fixture. Red-first
  vehicle: apply the new rule with an over-broad first cut, watch this arm go red, then narrow.
- **AC3 — no refusal regression.** `test/regexguardcheck.sh` and `test/regexbombcheck.sh` are green, and
  the `^(a|aa)+b$` control still refuses with the **full PM-1 disjointness wording** (verbatim, not merely
  "refused" — the merged message is 1020 bytes of stderr and the arm pins it).
- **AC4 — the false-positive class is measured, named and disclosed.** The 99,845-literal corpus sweep
  re-runs; the newly-refused set is enumerated in the evidence bundle and each entry classified. A
  non-zero newly-refused count is *expected and permitted* only if disclosed; newly-**admitted** must
  remain **0** (the first screen's own invariant). *Restated 2026-10-31:* every sweep count must **name
  its engine flavour**. The screen itself is platform-independent, but the measured false-positive class
  is engine-conditioned, and a count without a flavour is not reproducible.
- **AC5 — determinism.** The verdict is a pure function of (file, pattern): the same binary on the same
  input produces byte-identical output across runs, and no bound introduced by this spec reads a clock.
  **This is the AC that forbids the obvious "cap the wall time" fix** and the reason the risk-class cap
  (AC6) must be a **count**.
- **AC6 — the risk-class cap is load-bearing, and is NOT the stack-cap family wholesale.** A subject at
  the new cap returns within a bounded time on **libstdc++** for the worst admitted shape; a subject one
  byte over is `Skipped` and disclosed. §H negative control: the arm is shown red with the cap raised to
  the existing stack-cap value, proving the new cap — not something else — is what bounds it.
  *Restated 2026-10-31 on the PM fold's new fact:* the subject cap is **build-flavour-dependent** — the
  same source yields `cap=989` on g++-14/libstdc++ and **`SIZE_MAX` (no cap)** on clang++/libc++, where
  the only safety is the engine's `error_complexity` throw. So the risk-class cap is a **new count
  independent of `maxEngineSubjectBytes`**, and it is **pinned on the libstdc++ leg**, the only one where
  it is load-bearing.
- **AC7 — libc++ leg mandatory in every arm, as regression coverage; soundness lives on libstdc++.** Every
  arm runs on **both** toolchains (`clang++`/libc++ and `g++-14 -B/usr/bin`/libstdc++). The two legs have
  different roles, and conflating them is how #397's round 1 went wrong: the **libc++ leg proves the
  admit set is small and unchanged** (the engine throws before cost is reached, so AC1/AC6 §H controls
  *cannot* fail there), while **only the libstdc++ leg can prove the bomb bounded**. Confirmed on this
  host: g++-14 at `/usr/local/bin/g++-14` (14.2.0_1).
- **AC8 — the vocabulary is extended, not blurred.** A structural refusal names the overlapping-quantifier
  construct; an engine abandonment still quotes `kRegexAbandonedReason`; an over-long subject still quotes
  `kRegexOversizeReason`. `kRegexBudgetReason` is **not** reintroduced. Since refusal and abandonment both
  exit 1 (§0.4), the arms discriminate on message text, never on exit status.

### 0.4 (added) Exit status cannot discriminate refusal from abandonment

Measured: screened refusal → exit 1 / stdout 0 B / stderr 1020 B; engine abandonment → exit 1 / stdout
0 B / stderr 489 B; clean → exit 0 / stdout 1595 B. **Every arm must discriminate the message.** An arm
asserting only `exit != 0` passes on the pre-change binary and is worthless — the exact failure class
`SR-2026-10-30-gate-scenario-discrimination` exists to prevent.

### 0.5 (added 2026-10-31, at arm-authoring time) TWO DEFECTS IN THIS DOCUMENT, FOUND BY TRYING TO WRITE THE ARMS

Both were found the only way they could be: by attempting to author a gate arm that the document's own
wording said should be red, and measuring that it was not. Recorded here rather than silently patched,
because the second one changes §1's mechanism reasoning and therefore owes the PM seat a decision.

**(a) AC1's discrimination token set is UNUSABLE — `catastrophic backtracking` is not structural.**

AC1 pinned: *"the arm asserts the presence of the structural token (`catastrophic backtracking` /
`overlapping`) and the absence of `abandoned`."* Measured on the pre-change binary, shape (i)
`a*a*a*a*a*b` over `b`+`a`×400 — the case AC1 says must be a structural refusal — and its stderr is:

    [math degraded] grep: the regex engine abandoned a match (catastrophic backtracking?) — the verb refuses the answer  (search.h:1236, …)
    ripwire: --regex='a*a*a*a*a*b' refused, no hit is reported: the regex engine abandoned the match (std::regex gave up …)

The engine-**abandonment** path prints `catastrophic backtracking` too (as a hedged parenthetical,
`(catastrophic backtracking?)`, in the `[math degraded]` DISCLOSE at `search.h:1236`). So a presence
test on that token passes on an abandonment — **it is a dud arm, the exact class this document's own
§0.1b warns about.**

Worse, the negative half is also unsound as literally worded. The structural message contains
`abandons the match` (present tense, in `catastrophicRegexMessage`: *"libc++ abandons the match in under
a second"*), and the abandonment message contains `abandoned the match`. A negative test on `abandoned`
therefore passes for the structural message — but it discriminates on **one letter** (`abandons` vs
`abandoned`), which is a wording accident, not a contract. Any future copy-edit flips it.

**The sound discriminator, verified exclusive in source rather than in samples:** the two messages have
**different lead-ins**, emitted from different files, and neither emitter can produce the other's:

| verdict | lead-in | emitter | sites |
| --- | --- | --- | --- |
| structural refusal (screen) | `refused, nothing was scanned:` | `verbs_grep.h:991` | exactly 1 |
| engine abandonment | `refused, no hit is reported:` | `verbs_grep.h:899` | exactly 1 |

(`grep -rn` over `src/` confirms one emitting site each; the other hits in both searches are comments.)
The lead-in *is* the contract: it says whether a scan happened. Arms assert the lead-in, **not** exit
status (§0.4), **not** `refused` alone (§0.1b), **not** `catastrophic backtracking` (this section), and
**not** `abandoned` (one-letter accident). The construct token is still asserted *in addition*, as a
content check that the refusal names the family — but it is never the discriminator.

**(b) §2's rule, as written, CANNOT catch shape (iii) — the mechanism section under-counts by one rule.**

§2 pins the rule as: *refuse when two or more quantified atoms **adjacent in the same repetition scope**
have character sets that are not provably disjoint.* That closes (i) (`a*a*a*a*a*` — five adjacent
quantified atoms, `a` vs `a`) and (ii) (`^(a)*(a)*(a)*…` — the same, inside groups whose quantifiers are
siblings). **It does not close (iii-B).** Shape (iii)'s offence is `(.|.)` — an overlapping alternation
whose **outer `{1,3}` is bounded**, so `regexCloseGroupVerdict`'s arm (2) never fires (`quant.isUnbounded`
is false). But in `(.|.){1,3}` the two `.` atoms are adjacent inside an **alternation**, not inside a
repetition scope, and each branch carries **no quantifier of its own** — so "quantified atoms adjacent in
the same repetition scope" has no pair to look at. Measured: the pre-change screen ADMITS `(.|.){1,3}`
(clean, exit 0) while refusing `(.|.)+` (structural) — the existing arm is **bounded-outer-blind**, and my
§2 rule shares that blindness because it inherits the same scope notion.

So the structural rule needs **two** clauses, not one:

1. **the repetition-scope clause** (§2 as written) — adjacent unproven-disjoint quantified atoms inside
   one scope. Closes (i), (ii).
2. **the bounded-outer-overlap clause (NEW)** — an alternation the screen cannot prove disjoint, under a
   **bounded** outer quantifier, when the group is **nested inside another repetition** or the bounded
   repeat is itself repeated. Closes (iii-B).

Clause 2 must NOT refuse the lone `(.|.){1,3}`: measured, that pattern is clean and cheap at every length
(iii-B only blows up once it is *nested*: `((.|.){1,3}){1,3}` is already structural-refused today, and
`((( .|.){1,3}){1,3}){1,3}`-style nesting is what makes the product explode). The line between "bounded
overlap, harmless" and "bounded overlap, nested = explosive" is a **nesting-depth** condition, and pinning
it is Phase 1's design work, not something this document can assert. §1's claim that "the structural rule
is the load-bearing mechanism" is **unchanged**, but the rule is larger than §2 describes, and AC1's
shape-(iii) row is only satisfiable by clause 2.

**Verdict for the PM seat:** (a) is a drafting correction — the arms are written to the lead-in
discriminator, and AC1's sentence should be folded in those words. (b) is a **scope observation the
mechanism decision should absorb**: option 3 still stands, but the structural rule is two clauses, and
the "(iii) is a member" premise depends on clause 2 existing. I am proceeding on that reading — it is the
only reading under which AC1's own shape-(iii) row is satisfiable, and the spec's rationale (*"(.|.) IS an
overlapping alternation, but its outer {1,3} is bounded"*) already describes clause 2's trigger.

---

## 4. Interfaces pinned

- **`patternAdmission`** — `catastrophicRegexConstruct()` keeps its **signature**; the refusal set widens.
  `screenRegexPattern()` order is unchanged, so a size refusal still precedes a structural one.
- **The risk-class cap** — a new named constant beside the existing ones with a comment stating it is a
  **time** bound, not a stack bound, and why it differs from `regexMaxSubjectBytes`. It surfaces through
  the existing `RegexVerdict::Skipped` path and the existing `kRegexOversizeReason` disclosure machinery —
  **no new verdict value**, because `-Werror=switch` means every consumer must stay exhaustive.
- **Manifest `produces` / `consumes`:** the consumption of `patternAdmission` from
  `regex-screen-hardening` is real, so it should be a **formal `consumes` edge**, with the reciprocal
  addition of this spec id to that spec's `patternAdmission.consumers`. Drafted for the PM seat; not
  applied by the producer (step 2).

---

## 5. Corrections the PM seat should fold into `spec.md`

**STATUS 2026-10-31: all three were folded by the PM seat on 2026-10-30 (`spec_revised` history event,
`pm-fold-phase0.md`). Item 1 below is superseded by the PM's version — see §0.3.** Kept for the record,
because the producer's own first pass at item 1 was wrong in the same way it accused the spec of being
wrong, and that is worth not repeating.

1. Objective: `src/regexguard.h:1657` → **`src/regexguard.h:1859`** (the per-line skip against
   `policy.engineLineBytesMax`) and **`:1978`** (`maxEngineSubjectBytes`), read from the **merged-tree
   object**. Superseded note: my draft proposed `:1178`/`:1295`, which are the *stale 1365-line
   checkout's* line numbers for the same code; the citation `:1657` itself does exist in the merged
   object (it is `regexMaxSubjectBytes`'s return) but names the wrong site for the claim.
2. Implementation Notes: `kRegexBudgetReason` → the surviving pair `kRegexAbandonedReason` /
   `kRegexOversizeReason`, with the maintainer-removal rationale cited. **Confirmed correct** against
   the merged object.
3. Shape (iii): make the spec's own rendered spelling explicit in the table (the `\|` is markdown
   escaping) so no downstream reader copies the note's literal version. The two spellings are different
   patterns with different behaviour — this is a fixture-authoring hazard, not a wording nit.
   **Confirmed correct**; the note was corrected inline too.

### 5b. New items arising from the PM fold (for the PM seat, not yet folded)

4. **AC6 wording.** The PM observed the subject cap is **build-flavour-dependent**: the same source
   gives `cap=989` on g++-14/libstdc++ and **`SIZE_MAX` (no cap at all)** on clang++/libc++. So AC6's
   "NOT `regexMaxSubjectBytes`" should read "not the stack-cap family wholesale" — the risk-class cap is
   a *new count*, independent of `maxEngineSubjectBytes`, **pinned on the libstdc++ leg where it is
   load-bearing**. Adopted here; AC6 above is restated accordingly.
5. **AC7 restated as a role split.** The libc++ leg proves only that the admit set is small (regression
   coverage); it can never prove the bomb, because the engine throws before cost is reached. Soundness
   lives on the libstdc++ leg.
6. **Corpus-sweep counts must name their engine flavour** (AC4), since the newly-refused set can differ
   by engine — the screen is platform-independent, but the *measured* class is engine-conditioned.
7. **Fixture-naming discipline is part of the evidence** (SR-2026-10-30-measure-on-the-reviewed-tree
   extension earned this round): every probe log names its fixture files, binary path, compile command,
   and engine flavour. `evidence/phase0-reachability.log` is the first log written to it.

---

## 6. What Phase 1 does next (the order, so no arm is written red against a moving premise)

1. Re-run the **convergence freshness probe** (done this cycle: upstream `main` is `d044662a`, 0 ahead /
   0 behind; no open PR or issue mentions regex/quantifier/backtrack/screen — **no convergent fix**).
2. Write the **red arms first**, from the pinned shapes in §0.2 (spec's rendered spelling), asserting
   message text and bounded time on **both** toolchains. Each is shown red on the pre-change binary.
3. Implement the structural rule; narrow it until AC2/AC3/AC4 are green.
4. Measure the risk-class cap for AC6; prove it load-bearing with the raised-cap control.
5. Evidence bundle + PBT (≥10,000 seeded patterns, §H control per property, libstdc++ leg), corpus sweep,
   then the hand-back contract.
