# Regex Screen Hardening II — the multi-quantifier family

## Header

```yaml
id: regex-screen-multiquantifier
type: unit
version: 0.1.0
manifest: ../../manifest.yml
```

## Objective

Close the **multi-quantifier backtracking family** that `regex-screen-hardening` disclosed and did **not** fix (its
Q8/Q9): a pattern carrying several quantified atoms that can match the same text, meeting a subject that fails to
match, backtracks with cost polynomial in the subject length and exponential in the number of atoms — and on
**libstdc++** nothing bounds it. *(Folded 2026-10-30, post producer Phase-0; verified against the `d044662a` tree.)*
The ORIGINAL text's "per-file budget … checked before the engine is handed a line (`src/regexguard.h:1657`)"
describes the **pre-review lane tree**: upstream review of #397 **removed the per-file match budget entirely**
(one stopped-`--regex` cause — the engine abandoning). What remains pre-engine on main is only the per-line
length limit: `lineBytes > policy.engineLineBytesMax` (`src/regexguard.h:1859`), the cap computed by
`maxEngineSubjectBytes()` (`src/regexguard.h:1978`) — a bound calibrated for **stack safety**, bounding the
subject's length and **nothing about match cost**. Folded anchors cite the merged tree; the 1657 figure is the pre-review LANE tree's
(2048 lines, where the removed per-file budget sat at :1657) — a lineage the first fold mis-attributed
to the train-27 checkout; coincidentally the merged object also has a :1657 (a `maxEngineSubjectBytes`
return, NOT the budget site the draft meant). Corrected 2026-10-31 after the producer's re-verification.

This is a **different structural family** from the one `regex-screen-hardening` closes. That spec's rule refuses a
group's top-level `|` under an unbounded outer quantifier; every member below is admitted by it, by construction.
Closing this family needs its own admit-set analysis and its own negative controls — it is not a widening of the
first rule.

## Scope

### The family (all ADMITTED by the current screen)

Reproduced in `specs/regex-screen-hardening/evidence/p6-negative-control.log` — libc++ returns at every `k` because
its engine throws `error_complexity`; libstdc++ runs 2.25 s at `k=4` and does not return at `k>=5`, with the budget
never firing (`budgeted=0` throughout).

| # | shape | example | why the current screen misses it |
| --- | --- | --- | --- |
| i | group-free flat | `a*a*a*a*a*b` | no group to inspect |
| ii | grouped, no `|` | `^(a)*(a)*(a)*(a)*(a)*$` | no top-level `|` to inspect |
| iii | bounded-nested | `^(ab\w\|((.\|.){1,3}){1,3}){1,3}$` | `(.\|.)` **is** an overlapping alternation, but its outer `{1,3}` is **bounded**, so the unbounded-outer rule never fires |

*(Folded 2026-10-30, post producer Phase-0.)* **Shape (iii)'s `\|` in the cell above is markdown escaping** — the
rendered, intended pattern is `^(ab\w|((.|.){1,3}){1,3}){1,3}$`, with **real alternation** `(.|.)`. A literal
backslash-pipe spelling (`(.\|.)`) is a **different, harmless pattern** (matches a literal `|`; admitted, 0.0 ms at
every length). Phase 0 measured both: the rendered form does not return from n=30 on libstdc++; the literal form is
inert. Any gate arm or fixture authoring shape (iii) MUST use the rendered form — see
`phase0-planning.md` §0.2 and `evidence/phase0-shape-cost.log` (the two spellings are labelled iii-A / iii-B).

### The hard constraint that shapes every option

**The verdict must be a pure function of (file, pattern).** This tree gates on byte-identical output, so a per-line
**wall-clock** bound is unavailable — the result would depend on the machine and the run. Any per-line bound must
therefore be a **count**. And `std::regex` exposes **no step/visit count** to its caller: a single `match` call is
atomic, so a caller-side counter cannot observe the work inside it. That is the whole reason
`regex-screen-hardening`'s budget is an aggregate and not a per-line bound.

### Candidate mechanisms (for this spec's own design phase — NOT decided here)

1. **A screen rule for adjacent/nested quantifier ambiguity.** Refuse a pattern where two or more quantified atoms
   can consume the same text under a repetition — flat adjacency (`a*a*`), grouped adjacency (`(a)*(a)*`), and
   nested bounded quantifiers whose product overlaps (`(X{1,3}){1,3}` where `X` can match what `X` matches).
   *(Folded 2026-10-31 at validation — `phase0-planning.md` §0.5(b): the single rule as drafted cannot close shape
   (iii), whose offence is atoms in ALTERNATION BRANCHES under a BOUNDED outer; the implemented mechanism is
   therefore TWO clauses.)* **Clause 1** — adjacent unproven-disjoint unbounded quantified atoms in one repetition
   scope (closes i, ii; a quantified group whose body is a single width-one atom counts as a quantified atom).
   **Clause 2** — an unproven alternation repeated *within a repeat* (closes iii; the fact travels group frames
   exactly as M2-d's `unprovenAlternation` does, so `(.|.){1,3}` alone stays admitted — the nesting is the
   offence, not the alternation).
   - **The admit-set analysis is the work, and it is non-trivial.** It must still admit `.*.*`-free shapes that are
     legitimate in this tree — `\s*\w+`, `(get|getResponse){1,5}`, `(a|b)+`, `(abc)+`, `TODO|FIXME` — and it must
     not refuse a pattern merely because two quantified atoms *could* overlap when their character sets are
     provably disjoint. Every analysis rule is a soundness surface: a missed overlap is a live bomb, an over-broad
     rule eats working patterns (the false-positive class `regex-screen-hardening` already names).
   - Precedent for the conservative direction: `regex-screen-hardening`'s Q5(a) ruling — "a refusal is a safe
     failure, a hang is not" — but the false-positive budget here is **larger**, because `a*a*`-shaped adjacency is
     far more common in real patterns than a `|` under an unbounded outer.
2. **A subject-length cap for the risk class.** For a pattern the screen cannot prove single-atom-per-repetition,
   bound the line length handed to the engine — a **count**, deterministic, cheap. This trades a refusal for a
   bound rather than for a false positive, and it is closer to what the tree already does for engine recursion
   (`regexMaxSubjectBytes`).
3. **Both** — a screen rule for the clear cases, a subject cap for the residual.

A **fourth** possibility — replacing or wrapping the engine to expose a step count — is out of scope for a gap-fill
spec and would be its own proposal.

### Phases

- **Phase 1 — the admission rule (or the subject cap).** Extend `catastrophicRegexConstruct()` / the structural
  scan with the chosen mechanism. The admit set above MUST stay admitted; the false-positive class MUST be
  enumerated and measured, exactly as `regex-screen-hardening` did for its own class.
- **Phase 2 — the gate arms.** The refusal battery gains the three family shapes; each arm asserts a bounded wall
  time and a message that names the construct honestly. **A `libstdc++` leg is mandatory** (Homebrew `g++-14`,
  `-B/usr/bin`): the whole point is the platform where the engine does not throw. A libc++-only arm proves
  nothing — the round-1 `regex-screen-hardening` verdict is the precedent.
- **Phase 3 — evidence.** A §H **negative control per property**, with the kill recorded where the property can
  fail, and the corpus sweep re-run (99,845 literals) to measure the new false-positive class in-tree.
  *(Provenance footnote, folded 2026-10-31: the sweep ran on the grown tree — 115,288 base-tree / 115,366
  lane-tree literals — and re-harvesting the predecessor's own commit `0e0f67c7` gives **99,822**, not the
  99,845 the round-2 record quotes; the 23-literal gap is unexplained (candidates: a different harvest.py
  revision or the patched verify tree) and is recorded, not written down. It changes no verdict pair — one
  harvested set feeds both screens — so the DIFF stands. Validator independently reproduced 115,288 / 115,366
  with byte-identical newly-refused lists on both trees: 25 and 32, NEWLY ADMITTED = 0 on both.)*

## Interfaces

Provisional — this spec is `planned`, and its interface contract is settled in its own planning cycle. The manifest
entry therefore declares none yet (`produces: []`, `consumes: []`); the shapes below are the draft's starting point,
not a commitment.

- **`patternAdmission`** — extends the existing verdict (`catastrophicRegexConstruct()`); signature unchanged, the
  refusal set widened. Consumed from `regex-screen-hardening`; if the planning cycle makes this a formal `consumes`
  edge, `regex-screen-hardening`'s `patternAdmission.consumers` must gain this spec id (the manifest's reciprocity
  check).
- **A new evidence interface** for the family, since `pbtEvidenceBundle`'s properties are the first spec's.

## Acceptance Criteria

*(Folded 2026-10-31 at validation — two of the producer's Phase-0 findings corrected the draft ACs before code;
both are now the pin, not a footnote.)*

1. Every family member above is refused (or bounded) with a bounded wall time on **both** toolchains. The
   refusal must be distinguished from an **engine abandonment** by its **lead-in** —
   `refused, nothing was scanned:` (structural, `verbs_grep.h:991`) vs `refused, no hit is reported:`
   (abandonment, `verbs_grep.h:899`) — because exit status (both 1), the word `refused` (prefixes both), the
   construct token `catastrophic backtracking` (also on the abandonment's hedged DISCLOSE, `search.h:1236`) and
   `abandoned` vs `abandons` (a one-letter copy-edit accident) are ALL non-discriminating. Measured on the
   pre-change binary; recorded as `phase0-planning.md` §0.5(a).
2. The admit set is unchanged: `(a|b)+`, `(abc)+`, `TODO|FIXME`, `foo.*bar`, `(\s*\w+){1,20}` still admitted.
3. No refusal regression against `regex-screen-hardening`'s battery.
4. Determinism preserved (the AGENTS.md ritual).
5. The §H control exists and is load-bearing on libstdc++.

## Implementation Notes

- **`regex-screen-hardening` lands first** and is the substrate: this spec reuses its screen, its refusal-message
  vocabulary and its gate discipline. The `depends_on` edge is what keeps that ordering honest.
- **The refusal must not overclaim.** The PM-1 clause is the house style — say what the screen *cannot prove*, not
  what the pattern *is*. A new rule that says "this pattern backtracks" is a claim the screen cannot support.
- **Determinism is a contract.** Any bound chosen must be a count derived from the input, never a clock; the
  `--regex` path distinguishes a screen refusal from an engine abandonment and an over-long-subject skip
  (`kRegexAbandonedReason` / `kRegexOversizeReason` — the per-file match budget and its `kRegexBudgetReason`
  were **removed in upstream review of #397**; do not resurrect them), and this spec must extend the surviving
  vocabulary rather than blur it. *(Folded 2026-10-30, post producer Phase-0.)*
- **The false-positive class is measured, named and disclosed** — a rule that quietly eats a common pattern is the
  primary risk, and it is a disclosure duty, not a tuning detail.

## Failure Modes

- **The new rule refuses a legitimate pattern** — the primary risk, and the reason for the admit-set analysis. The
  false-positive class must be measured, named and disclosed, not discovered by users.
- **The rule misses a family member** — a soundness failure. The gate battery must include each of the three shapes
  explicitly, plus generated patterns.
- **The bound is a clock, not a count** — the determinism contract fails on the first machine whose timing differs.
  A wall-clock bound is not available here for exactly this reason.
- **The rule is written against libc++** — a libc++-only arm passes while libstdc++ hangs. The mandatory libstdc++
  leg exists to make this failure visible; the round-1 verdict found it by exactly this route.

## Dependencies

`regex-screen-hardening` — **must land first**: this spec closes what that one discloses, and reuses its screen, its
refusal-message vocabulary and its gate discipline. `depends_on: [regex-screen-hardening]`.

## Consumers

- **Spec:** security-regression-integration — the family's refusal text, for byte-precise assertions.
- **Spec:** audit-validation-standalone — the new evidence bundle at the declared path.

## Status

**Status:** approved  # VALIDATED 2026-10-31 by the validator-of-record (PM seat, VALIDATION_PROTOCOL step 2 / Q10 (a)): all eight AC evidence claims independently reproduced (verdict-validator.md); AC6 ruled met-by-supersession — the structural rule refused every shape the cap was sized to bound, and the remaining reachable class ((a|aa){1,100}b$) is not subject-cap-boundable; its disclosure in docs/LIMITS.md is the standing contract. Lane: 4 commits at 93aae229 (3 producer + 1 validator changelog-fix, disclosed), merge-ready. Prior: DISPATCHED 2026-10-30, base re-pinned 65210e86.  # DISPATCHED 2026-10-30 by the operator; dispatcher-of-record = PM seat (planned -> in_progress, spec_started manifest event, base d044662a, producer = the Deepseek-V4.1-Flash "-1017" session). Phase 0 (this spec's own planning cycle) pins the draft interfaces/ACs BEFORE any code; see dispatch-note.md. **Validation wave 2026-10-31 (validator seat, this file's ACs as folded): all eight AC evidence claims independently reproduced — see `validation/verdict-validator.md` for the AC table and the AC6 disposition.**
**Last updated:** 2026-10-30T11:35:00Z
**Updated by:** dispatcher-of-record (PM seat), under the operator's 2026-10-30 dispatch directive —
**promoted from `drafts/` at the operator's Q9 ruling (option (a), 2026-10-13) and held `planned` until
this dispatch.** This is a **draft-stage spec**: it is in the DAG, its scope/family table/hard constraint
are settled, and its interfaces, ACs and failure modes are
sharpened in its own planning cycle (the ACs are
explicitly marked draft in the source). It was written because the round-2 record of `regex-screen-hardening` names
this family as a **confirmed, reachable, unbounded-on-libstdc++** residual rather than a bounded one — the honest
follow-up is a spec that closes it, not a claim that it is closed.

## Validation Strategy

Tier 2 — property-based testing required (input validation/sanitization of a hostile-controllable pattern language;
security-sensitive availability boundary — the same surface and the same tier as `regex-screen-hardening`).

- **Components requiring PBT:** `catastrophicRegexConstruct()` (the widened admission rule) and, if mechanism 2 is
  chosen, the subject-length cap.
- **Formal properties (draft — to be pinned in the planning cycle):**
  - ∀ p ∈ the three family shapes: `refused(p) ∨ bounded(p)`, and the scan returns within the wall-clock cap on
    **both** toolchains.
  - ∀ p ∈ the admit set: `admitted(p)`, with results byte-identical to pre-change.
  - ∀ p: the verdict is deterministic across runs and platforms.
- **§H negative control:** every property must be shown capable of failing on the platform it is run on. For this
  spec that means a **libstdc++ leg is mandatory** — on libc++ alone the properties cannot fail, because the engine
  throws, so a libc++-only pass is not evidence.
- **Input domains:** a random pattern generator over the ECMAScript subset the verb documents (groups, alternation,
  classes, quantifiers, anchors), seeded; plus the three fixed family shapes and the admit corpus.
- **Case budget:** ≥10,000 generated patterns plus the fixed corpora; the run under a **wall-clock cap** whose kill
  is the negative control, not a flake.
- **Evidence bundle:** property-test source, seeds, platform, case counts, result logs, the §H controls — in
  `specs/regex-screen-multiquantifier/evidence/`. PBT does not prove absolute security; it evidences the properties
  hold over the generated domain.

## Progress Tracking

- [x] Phase 1: extend `catastrophicRegexConstruct()` (or add the subject cap) with the chosen mechanism; enumerate
      and measure the false-positive class — **DONE in `be1d31c1` + `1001ee07`** (two clauses, mechanism option 3's
      structural half)
- [x] Phase 2: gate arms for the three family shapes, each asserting a bounded wall time and an honest message,
      with a mandatory `libstdc++` leg — **DONE in `3785cea5` (red) + implement; `regexmultiquantcheck`, 31 arms,
      green on both legs**
- [x] Phase 3: the §H negative control per property, and the 99,845-literal corpus sweep re-run — **DONE: PBT
      P1–P5 (10,000 seeded cases incl. P5 monotone admission vs the real base binary); corpus sweep 115,288/115,366
      literals, 0 newly admitted, all newly-refused classified (see Phase-3 provenance footnote above)**
