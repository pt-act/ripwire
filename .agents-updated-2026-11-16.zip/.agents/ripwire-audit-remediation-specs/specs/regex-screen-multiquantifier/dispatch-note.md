# Dispatch Note — regex-screen-multiquantifier

**Dispatched:** 2026-10-30T11:35Z, by the PM Advisor seat (dispatcher-of-record) under the
operator's dispatch directive of this date.
**Producer session:** WorkBuddy AI / Deepseek-V4.1-Flash (the "-1017" session).
**Base commit:** `65210e86` (train-43a head; upstream main as of 2026-10-31 07:46Z; fork
`pt-act/ripwire` main fast-forwarded to it this date — build your scratch tree FROM the fork main so
the lane starts at main's tip). *(Re-pinned 2026-10-31 from `d044662a`: 137-commit upstream fast-forward,
regex surface byte-identical across the drift — every Phase-0 fact below stands unchanged; the
verification round itself ran at the old base, quoted sha-checks prove equivalence.)*
**Manifest bookkeeping for THIS dispatch** (status → in_progress, execution.producer,
base_commit, `spec_started` history event) is done by the dispatcher in the same act — you do NOT
touch the manifest for the dispatch itself. Any LATER manifest mutation you need (produces /
consumes edges settled by your planning cycle, status transitions per VALIDATION_PROTOCOL) is
**drafted by you, applied through the PM seat** — the producer never flips statuses (step 2;
Q10 ruling 2026-10-29, option (a)).

## Read-first list (in this order)

1. **Your spec:** `specs/regex-screen-multiquantifier/spec.md` — draft-stage (v0.1.0): the family
   table (three shapes), the pure-function-of-(file,pattern) constraint, the candidate mechanisms,
   and the phased plan are SETTLED; the interfaces/ACs are explicitly draft and are pinned in YOUR
   planning cycle (Phase 0 below).
2. **The substrate lane's terminal record:** `specs/regex-screen-hardening/` — `spec.md`,
   `phase-log.md` (four upstream review rounds; what they converged on), and
   `validation/resolution-report.md` (the shipped contract). Key facts you inherit:
   - The maintainer REMOVED the per-file match budget in review — the shipped contract is
     **one stopped-regex cause: the engine abandoning**. Do not reintroduce a line-count budget.
   - The refusal wording follows the **PM-1 clause**: say what the screen cannot PROVE, never
     what the pattern IS. Copy the voice, not the sentence.
   - The screen lives in `src/regexguard.h::catastrophicRegexConstruct()` — signature unchanged by
     contract; you widen its refusal set or add the subject cap beside it.
3. **The family's measured behavior:** `specs/regex-screen-hardening/evidence/` — especially
   `p6-negative-control.log`: libc++ throws `error_complexity` and returns at every `k`; libstdc++
   runs 2.25 s at `k=4` and does NOT return at `k>=5`, with the budget never firing
   (`budgeted=0`). That asymmetry is why a libc++-only arm proves nothing.
4. **The bank:** `.agents/memory_bank/` — `MASTER_CONTEXT.md` (Direction + Active Decisions 6–7),
   `standing_requirements.md` (ALL, especially the 2026-10-30 pair), `ARCHITECTURAL_DECISIONS.md`
   (the 2026-10-30 walker-rule pair is adjacent discipline), and the project
   `.workbuddy-ai/memory/MEMORY.md` (env traps; merge mechanics; the convergence course).
5. **Gate substrate on main:** `test/regexbombcheck.sh` (the bomb battery — your arms extend it),
   `test/regexguardcheck.sh` (the structural-screen gate), `test/regexfix/` +
   `test/regexbombfix/` (fixture trees). Read `docs/gatecount_build.py`'s role in MEMORY.md —
   the five-file train-merge mechanics WILL apply to your lane on the next upstream train.

## Verified pre-change facts (measured by the dispatcher 2026-10-30, on main's screen)

Binary = the train-42a line at `fafb3f26` (#469-head content), with `git diff fafb3f26..d044662a`
proving **`src/regexguard.h` untouched on the merge path** — these facts ARE main's screen:

- **Refusal control PASSED:** `--regex='^(a|aa)+b$'` refused, nothing scanned, full PM-1
  disjointness message. The screen is live exactly as merged.
- **All three family shapes ADMITTED live:** (i) flat `a*a*a*a*a*b`; (ii) grouped
  `^(a)*(a)*(a)*(a)*(a)*$`; (iii) bounded-nested **in its RENDERED form**
  `^(ab\w|((.|.){1,3}){1,3}){1,3}$` — real alternation `(.|.)`; the literal backslash-pipe
  spelling `(.\|.)` is a DIFFERENT, harmless pattern (matches a literal `|`; 0.0 ms at every
  length). *(Corrected inline 2026-10-30 post Phase-0: the original line carried the harmless
  spelling — the two-spelling split is pinned in phase0-planning.md §0.2.)* All are admitted
  **at the screen**; the family's cost grows in the SUBJECT length, so a small fixed fixture
  cannot exhibit it (the measured ladders are in `evidence/phase0-shape-cost.log` — shape i
  does not return by n≈96 on libstdc++; on the CLI the prefilter denies bare a-runs, so a red
  arm's subject line must CONTAIN the required literal `b` while staying unmatchable — e.g.
  `a-run + z + b`; see also phase0 §0.1 re the note's original "returned fast" claim).
- Probe fixture persisted at `/Users/rna/ripwire-scratch/regexprobe/` — reuse or replace. *(Its inside-git lines are 8–42 bytes — restore the as-dispatched fixture (good.c only) before any
  abandon-measuring run; `shield/long.c` added by Phase 0 is the working candidate-line
  template.)*
- **`g++-14` is at `/usr/local/bin/g++-14`** — the mandatory libstdc++ leg is executable on this
  host (spec Phase 2: Homebrew `g++-14`, **`-B/usr/bin`** — without the `-B` flag, ld fails on
  this host's CLT tapi files; both seats hit this trap; the producer's successful legs all
  carried it).

## Phase 0 (planning cycle, before any code)

The spec names the candidate mechanisms but does NOT choose: (1) a screen rule for
adjacent/nested quantifier ambiguity, (2) a subject-length cap for the risk class, (3) both.
Your planning cycle decides, pins the interfaces/ACs, and answers the admit-set analysis BEFORE
the first gate arm is written red. The admit set is contract: `(a|b)+`, `(abc)+`, `TODO|FIXME`,
`foo.*bar`, `(\s*\w+){1,20}` stay admitted, plus the 99,845-literal in-tree corpus sweep
(false-positive class measured, named, DISCLOSED — a rule that quietly eats `a*a*`-shaped
patterns is the primary spec-named risk). If your planning makes the `patternAdmission`
consumption a formal manifest edge, `regex-screen-hardening`'s `patternAdmission.consumers` must
gain this spec id (manifest reciprocity) — draft it, route it through the PM seat.

## Hard constraints (from the spec; non-negotiable)

- **Determinism:** the verdict is a pure function of (file, pattern). Bounds are COUNTS, never
  clocks — a wall-clock bound is unavailable here; this is the whole reason the budget is
  aggregate. The surviving vocabulary is `kRegexAbandonedReason` / `kRegexOversizeReason`
  (`kRegexBudgetReason` was removed with the per-file match budget in #397's upstream review —
  do not resurrect it); your work extends the surviving distinction, never blurs it.
  *(Corrected inline 2026-10-30 post Phase-0.)*
- **The libstdc++ leg is mandatory in every gate arm and every PBT property.** A libc++-only
  pass is not evidence (the engine throws there; the properties cannot fail).
- **Red-first gate discipline:** every arm asserts its refusal/boundedness and is shown RED on
  the pre-change binary BEFORE the implementation exists, then greened. Gate-scenario
  discrimination (SR-2026-10-30-gate-scenario-discrimination): every shim/premise arm must
  measure BOTH states and discriminate the design scenario from total failure.
- **PBT:** ≥10,000 generated patterns plus the fixed corpora, seeded, with the §H negative
  control per property (the kill is the control, not a flake). Evidence bundle in
  `specs/regex-screen-multiquantifier/evidence/`.

## Convergence freshness probe (the day's course, twice-proven)

Before starting Phase 1, and again before pushing: check upstream's recent commits and open
issues/PRs for convergent shapes — on 2026-10-30 the maintainer independently landed our
scoped-fix shapes within hours (premise arms `b66e26e6`; walker rule `90acd0f1`), as with
B6b/`aa13b254` on 10-28. If a multiquantifier-shaped fix appears upstream mid-lane, STOP and
re-baseline: shrinking the diff to the residual is cheaper than re-merging a superseded lane.

## House mechanics for this lane

- Scratch worktree under `/Users/rna/ripwire-scratch/` (never build in the main checkout);
  **absolute `-S`/`-B` paths** for background builds (SR-2026-10-30-measure-on-the-reviewed-tree
  — a relative-path build once silently built a 940-commits-behind tree).
- Branch: `lane/regex-multiquantifier` off the synced fork main (`65210e86`, train-43a). Authorship:
  `pt-act <psychoactive28@gmail.com>` set per-worktree before the first commit
  (SR-2026-10-12-authorship-identity).
- Logs under `/Users/rna/ripwire-scratch/logs/`, never `/tmp`. One Bash call = one fresh shell:
  cache/`TMPDIR`-rooted experiments run inside ONE call. No `timeout` on this host —
  `perl -e 'alarm N; exec @ARGV'`. Foreground commands die ~2 min (full build ~11 min —
  background it). `ps`/`top`/`lsof` blocked — use `pgrep`/`stat`/mtime. BSD `grep` does not do
  BRE `\|` alternation — use `grep -qE`. Selfcheck runs with `/usr/bin/python3` (PyYAML lives
  there, not in the default `python3`).
- Upstream trains re-merge into your lane on the five files (MEMORY.md "Lane-merge mechanics"):
  union the loop at the alphabetical slot, re-run `docs/gatecount_build.py`, take upstream's
  `versions.md` line. ~15 min per train.

## Hand-back contract

At lane completion: `validation/completion-report.md` (16-AC-style ledger: every AC, red-first
evidence, the corpus sweep numbers, the PBT bundle, the false-positive disclosure) +
`validation/verdict.md` (your go/no-go on the push), `phase-log.md` appended, the lane branch
pushed to the fork. The PM seat then validates (SR-2026-10-18 read end-to end), drafts the
upstream PR, and carries the review round — exactly as #397 and #433 ran. Status flips on
resolution are the dispatcher's act, never yours.
