# Completion Report — regex-screen-multiquantifier

## Header

spec_id: regex-screen-multiquantifier
producer: WorkBuddy AI / Deepseek-V4.1-Flash `-1017` (manifest `execution.producer`)
seats: producer = this session; PM/validator = GLM-5.3 (never this session — Q10 option (a): the producer does
not flip manifest status, and does not validate its own work)
started: 2026-10-30 (Phase 0), 2026-10-31 (Phase 1)
completed: 2026-10-31
base_commit: `65210e86` (train-43a head; re-pinned 2026-10-31 from `d044662a` — 137 upstream commits, regex
surface byte-identical, so every Phase-0 number carries)
lane: `lane/regex-multiquantifier`, worktree `/Users/rna/ripwire-scratch/rmq-r1`
authorship: `pt-act <psychoactive28@gmail.com>` (author and committer)

| commit | what |
|---|---|
| `3785cea5` | the RED arms — `test/regexmultiquantcheck.sh`, 31 arms, 6 failing on the pre-change binary |
| `be1d31c1` | the implementation — the third screen arm (two clauses), LIMITS disclosure, absorb loop, changelog |
| `1001ee07` | the honesty fix to clause 2's sentence, the LIMITS **generator** fix it exposed, and the AC4 sweep |

## What this closes, in one paragraph

The catastrophic-regex screen had two arms, and **both require a group closing under an UNBOUNDED quantifier**.
Three shapes therefore reached the engine with nothing having read them: `a*a*a*a*a*b` (no group at all),
`^(a)*(a)*(a)*(a)*(a)*$` (grouped, no alternation), and `^(ab\w|((.|.){1,3}){1,3}){1,3}$` (an overlapping
`(.|.)` whose outer `{1,3}` is *bounded*). On libc++ those cost an `error_complexity` throw; on libstdc++ there is
no budget and the process simply runs — 29.5 s at a 97-byte subject for shape (i), and climbing. All three are now
refused **structurally, by name, before any engine sees the pattern**, on both toolchains.

## The mechanism: two clauses, because the family has two shapes of adjacency

My Phase 0 pinned one rule ("quantified atoms adjacent within a repetition scope"). **That rule cannot catch shape
(iii)** — recorded as `phase0-planning.md` §0.5(b), found by trying to write the arm and measuring that it stayed
green. The offence in (iii) is `(.|.)`: two atoms in *alternation branches*, each carrying no quantifier of its
own, under a *bounded* outer. So the implementation is two clauses:

- **Clause 1 — adjacent unproven-disjoint unbounded quantified atoms in one repetition scope.** Closes (i) and
  (ii). A quantified *group* is treated as a quantified atom whose set is its body's set when the body is a single
  width-one atom (`(a)`, `(\d)`, `([a-z])`); otherwise the atom joins no proof — the conservative direction. Sets
  are read through the existing `regexCharSetOfSingleCharBranch` / `regexCharSetsIntersect`, so this inherits the
  alternation arm's width-one discipline instead of growing a second parser.
- **Clause 2 — an unproven alternation repeated *within a repeat*.** Closes (iii). The fact travels up the group
  frames exactly as M2-d's `unprovenAlternation` does, for the same reason: it belongs to the subtree, not to the
  group that happens to carry the quantifier. `(.|.){1,3}` **alone stays admitted** — measured cheap at every
  length; it is the nesting that enumerates.

Both clauses run **after** the existing arms, so every pattern refused before this spec keeps its byte-identical
message. Verified, not assumed: seven pre-existing refusal patterns (`(a+)+b`, `(a|a)+b`, `^(a|aa)+b$`, `(a?)+b`,
`(a{1,3})+b`, `(a|a*)+`, `((a|aa))+b$`) produce **md5-identical stderr** against the pre-change binary.

## Red first (the arms were red before the code existed)

`test/regexmultiquantcheck.sh`, run on the pre-change binary: **12 PASS / 6 FAIL, exit 1**. The six failures are
exactly the behaviours the spec adds (three shapes abandoned rather than refused, the corpus-dependent verdict, and
the two message-content arms). Evidence: `evidence/phase1-red-baseline.log`, verbatim.

After the implementation: **31/31 PASS, exit 0**, on **both** legs.

## The discriminator problem, which is the methodological core of this round

Four candidate discriminators were tested against *both* messages on the pre-change binary. Three are unusable,
and each would have produced a **dud arm** — a green gate that measures nothing:

| token | why it fails |
|---|---|
| exit status | refusal and abandonment **both** exit 1 with empty stdout |
| `refused` | prefixes **both** messages |
| `catastrophic backtracking` | the **abandonment** path prints it too — as the hedged `(catastrophic backtracking?)` in the `[math degraded]` DISCLOSE at `search.h:1236` |
| `abandoned` | the structural message contains `abandon**s** the match`; the negative test passes on **one letter** — a copy-edit accident, not a contract |

The sound discriminator is the **lead-in**, and it is sound because the two emitters are in different files with
exactly one site each, and neither can produce the other's sentence:

- `refused, nothing was scanned:` → structural refusal (`verbs_grep.h:991`)
- `refused, no hit is reported:` → engine abandonment (`verbs_grep.h:899`)

Every arm asserts the lead-in pair (present/absent), never exit status, never `refused`, never the construct
token alone. This also corrects **AC1's own wording**, which had pinned exactly the unusable token — recorded as
§0.5(a) rather than silently patched.

## Two defects found in my own Phase 0 (both recorded, neither hidden)

1. **§0.5(a) — AC1's discrimination token was a dud.** `catastrophic backtracking` is present on an abandonment
   (§0.1b had caught the *word* `refused` but not this one). Found by measuring the message the arm was supposed
   to distinguish.
2. **§0.5(b) — §2's single rule cannot close shape (iii).** The rule as written inherits the existing screen's
   bounded-outer blindness, so AC1's shape-(iii) row was unsatisfiable by it. This is the reason the
   implementation has two clauses; the PM seat should absorb it as a scope note, because the spec's own rationale
   (*"(.|.) IS an overlapping alternation, but its outer {1,3} is bounded"*) already describes clause 2's trigger.

Both were found the only way they could be — by attempting the artefact the document said should be red, and
measuring that it wasn't.

## A third defect, found in the shipped message after the first build

Clause 2 borrowed `catastrophicRegexPrologue`, which hardcodes **"the unbounded quantifier"**. For
`((a|aa){2,5}){2,5}$` that produced:

> `catastrophic backtracking: the unbounded quantifier '{' is applied to an alternation …`

False **twice**: `{2,5}` is *bounded*, and `'{'` is not a quantifier character but the first byte of an interval. A
refusal that misdescribes the pattern is worse than a vague one, because the workaround it then teaches ("bound
the outer quantifier") is what the reader has already done. Fixed with a bounded-prologue variant that prints the
quantifier **as written** (`the quantifier '{2,5}'`), selected by `quant.isUnbounded`. The M2-c/M2-d callers keep
the old sentence byte-for-byte (defaulted parameter; verified md5-identical).

## A fourth defect: `docs/LIMITS.md` is generated, and I edited the generated artefact

`docs/LIMITS.md` is written by `docs/limits_build.py` and pinned by `test/limitstablecheck.sh` (section B runs
`--check`). My `be1d31c1` edited the **generated file** and left the generator carrying the old residual
paragraph, so `limits_build.py --check` reported **STALE** — a gate that would have gone red on the validator's
run, from a change that read as complete. Found by running the AC4 sweep and then asking whether the tree was
self-consistent; no amount of reading the code would have shown it. Fixed at the generator, then regenerated.

That fix exposed a **fifth** defect, in prose rather than code: the generator still claimed
`((a|aa){2,5}){2,5}b$` "passes the screen because both quantifiers are bounded", and still described the family
as "admitted by the screen by construction". Both are false after clause 2 — the first pattern is now *refused*,
and the second sentence is the one this spec exists to delete. Rewritten to what the screen now does, and to name
the class that **is** still open (see AC6).

## Acceptance criteria

| AC | status | evidence |
|---|---|---|
| **AC1** three shapes refused, not abandoned | **MET** | 31/31 arms both legs; discriminator is the lead-in, not the exit status. *Wording of AC1 needs the fold in §0.5(a).* |
| **AC2** admit set unchanged | **MET** | 7 admit-set arms + 38-pattern sweep: 37 admitted |
| **AC3** no refusal regression | **MET** | `regexguardcheck` 143/143, `regexbombcheck` 135/135 (libc++), `regexrefusecheck` 14/14; 7 pinned messages md5-identical |
| **AC4** false-positive class measured, named, disclosed | **MET** | **corpus sweep RUN**: 115,288 base-tree and 115,366 lane-tree literals swept on the screen alone; **NEWLY ADMITTED = 0 in both**; all 25 (base) / 32 (lane) newly-refused classified, none is a ripwire pattern. Evidence `evidence/phase1-corpus-sweep.log` |
| **AC5** determinism, no clock | **MET** | P3 (two runs byte-identical), gate arm (5), and no time source anywhere in the rule |
| **AC6** risk-class cap load-bearing | **NOT IMPLEMENTED — see below** | the structural rule closes the measured family; no separate cap was added |
| **AC7** libc++ leg mandatory, soundness on libstdc++ | **MET** | 31/31 on both; roles stated in `evidence/phase1-both-legs.log` |
| **AC8** vocabulary extended, not blurred | **MET** | lead-in pair asserted; `kRegexBudgetReason` absence asserted; the bounded/unbounded sentence split is this round's fix |

### AC6 — the honest position, which is a deviation from the plan and needs the PM's ruling

Phase 0 chose **option 3: structural rule + a new risk-class cap**. The rule is in. **The cap is not**, and I am
not going to claim AC6 is met.

Why: the cap existed to bound what the structural rule *could not* refuse. Measured after the rule landed, every
shape the spec names is refused, and the long-line probes that the cap was meant to bound (`x+`, `x*y`, `\w+z`,
`x{1,3}y`, `(x)*y`, `((x|y){2,5}){2,5}z` over a 9 KB line) all return clean on the libstdc++ leg. The residual
that LIMITS.md named — a bounded quantifier over a repeating group, `((a|aa){2,5}){2,5}b$` — turned out to be
**already caught by clause 2** (measured: refused). Adding a second, much smaller cap would therefore be
machinery with no measured shape it bounds, and the tree has an explicit rule against exactly that (the PR #397
review removed a budget for this reason; `regexbombcheck` section (6) pins the removal).

**What I am NOT claiming:** that no admitted pattern is super-linear, and here the sweep let me upgrade a
suspicion into a number. `(a|aa){1,100}b$` is still admitted. On libstdc++ its cost is exponential in the
subject, measured on the bare engine (no screen, no CLI):

| subject `a`×n + `c` | 21 B | 25 B | 29 B | 33 B | 37 B | 41 B |
|---|---|---|---|---|---|---|
| libstdc++ | 7.8 ms | 27 ms | 517 ms | 1.86 s | 13.8 s | **99.1 s** |

~7× per 4 bytes. On libc++ the same pattern throws `error_complexity` from an 18-byte subject up. So the general
residual stands, it is **reachable**, and it is now disclosed with a ladder rather than an adjective —
`docs/LIMITS.md` carries these numbers. What changed is that the **named, measured** family is closed, so the cap
lost its target.

Note the shape of that measurement, because it nearly fooled me: through the CLI at default flags this pattern
looks flat at ~6 ms for every n. That is the **literal prefilter** dropping the line, not the engine being fast.
The honest measurement needs `--no-prefilter`, or the bare engine — the same fixture/flag conflation Phase 0's
reachability log lists as its second class. I ran the flat version first and wrote it down as a finding before
catching it; the ladder above is the corrected one, and `evidence/sweep-repro/` contains the harness so the
validator can re-run both.

**Decision owed by the PM seat:** (a) accept AC6 as satisfied-by-supersession with the disclosure above, or
(b) require the cap anyway as defence in depth, in which case it now has a **named target for the first time** —
the `(a|aa){1,100}b$` class, whose exponent is the size of the bounded outer quantifier, not the subject length.
That is why a subject-length or byte-size cap still would not bound it: the walk is bounded per position and the
product is over positions. A cap that *would* touch it is a per-position work cap, which is the budget the PR #397
review deleted. I am flagging that tension rather than resolving it, because resolving it is a policy call.

## Evidence bundle

| file | what it is |
|---|---|
| `evidence/phase0-shape-cost.log` | the cost ladders, both toolchains, with the cap arithmetic |
| `evidence/phase0-reachability.log` | the three conflation classes; as-dispatched fixture |
| `evidence/phase1-red-baseline.log` | the new gate RED on the pre-change binary, verbatim |
| `evidence/phase1-admit-set-sweep.log` | AC4 first pass: 38 patterns, 1 newly refused, and **which workarounds actually work** |
| `evidence/phase1-pbt-libcxx.log` | 10,000 seeded patterns, P1–P5 all pass |
| `evidence/phase1-pbt.py` | the PBT source (seeded, reproducible; `--base` turns on P5) |
| `evidence/phase1-both-legs.log` | every gate on both toolchains, with the legs' different roles |
| `evidence/phase1-corpus-sweep.log` | **AC4**: both trees swept, 0 newly admitted, all newly-refused classified |
| `evidence/sweep-repro/` | the sweep + engine-cost harness (harvest, scan, diff, ladder), so it can be re-run |

### PBT result (10,000 patterns, seed 20261031)

```
refused (structural): 2779   admitted: 7220   engine-abandoned: 1
P1 no crash · P2 no hang · P3 deterministic · P4 one lead-in · P5 monotone admission    ALL PASS
```

P5 is the load-bearing property: **nothing the pre-change binary refused is admitted now** (AC4's "newly-admitted
must remain 0"), tested against a real `65210e86` build in `/Users/rna/ripwire-scratch/rmq-base`.

### A correction to my own evidence, kept rather than quietly rewritten

`phase1-admit-set-sweep.log` first named `.*?` and `[^ ]*` as workarounds for the `import\s+.*from` refusal.
**Both are still refused** — measured. Laziness changes which path the engine tries first, not how many exist, and
`[^ ]` still intersects a dot-family set. Corrected in place with the measurement; the refusal message itself
never taught either, and was verified to teach only the three workarounds that actually work.

## Deviations from the dispatch note, all measured

1. **The three shapes were not "admitted and fast"** — they were admitted and *slow*, which is the difference
   between measuring the screen and measuring the fixture. Phase 0 §0.1, withdrawn claim.
2. **Shape (iii) has two spellings that are different patterns.** The spec's table cell `\|` is markdown escaping
   (real alternation, the bomber); the dispatch note's prose `\|` is a literal backslash-pipe (inert, 0.0 ms at
   every length). An arm authored from the note's spelling would have been **green on the pre-change binary**. The
   gate asserts the inert twin stays admitted, so nobody "fixes" (iii) by refusing it.
3. **`regexguardcheck` arm (b2) went red, correctly.** Its real-engine vehicle was `a*a*a*a*a*b` *because* the
   screen admitted it — this spec closes exactly that. Re-vehicled to `(a*){20}b`, admitted for a non-accidental
   reason (one bounded repeat of a group with one unbounded quantifier: no arm fires), so the arm keeps proving
   what it was written to prove.

## Gate/tree obligations discharged

- `test/regexmultiquantcheck.sh` absorbed at its alphabetical slot; **737 → 738 gates**, count regenerated by
  `docs/gatecount_build.py` (8 marked sites, 3 files) — never hand-written.
- `changelog.d/regex-multi-quantifier-refusal.md`, validated by `scripts/changelog_assemble.py check`.
- `docs/LIMITS.md` residual paragraph rewritten: it said the family was "admitted by the screen by construction …
  never claimed closed", which is now false for the two shapes refused here.
- `gateexitcheck` (G2) caught a real defect in the new gate — a one-line `&& ok … || no …` that would print FAIL
  for an arm that passed when `ok()`'s printf hit a stalled pipe. Converted to `if/else`.

## What the PM seat should do next

1. **Rule on AC6** (accept-by-supersession vs require the cap; if the latter, the target is now named —
   `(a|aa){1,100}b$`, and it has the per-position-work shape that PR #397 deleted, which is the tension to
   resolve).
2. **Fold §0.5(a)** (the lead-in discriminator) into `spec.md`'s AC1, and **§0.5(b)** (two clauses) into §2.
3. **Fold the Phase-3 disposition**: AC4's corpus sweep is now **run and met** — but note that the count is
   115,288/115,366, not the 99,845 the spec's text expects, because the tree grew. I harvested the
   predecessor's own commit to check and got **99,822**, not 99,845, and did not resolve the 23-literal gap
   (candidates: a different `harvest.py` revision, or its patched verify tree). The gap changes no verdict pair
   — one harvested set feeds both screens — so it is a provenance footnote, not a defect. Flagged because the
   spec pins the number and the spec's number does not reproduce.
4. The manifest's `status` is **not flipped by this session** (Q10 option (a)); this report is the input to the
   validator's decision.
5. **Note for the merge**: `test/limitstablecheck.sh` must be green on the validator's run. It is a gate my first
   commit would have broken (defect 4, above), and it is not one of the regex gates, so a "the regex gates are
   green" check would have missed it.
