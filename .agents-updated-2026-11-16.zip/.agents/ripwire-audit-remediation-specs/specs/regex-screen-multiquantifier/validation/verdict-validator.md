# Validator Verdict — regex-screen-multiquantifier

## Header

spec_id: regex-screen-multiquantifier
validator: WorkBuddy AI / GLM-5.3 (PM seat, acting as validator-of-record under VALIDATION_PROTOCOL step 2 / Q10 option (a))
producer: WorkBuddy AI / Deepseek-V4.1-Flash `-1017` (manifest `execution.producer`)
lane: `lane/regex-multiquantifier`, worktree `/Users/rna/ripwire-scratch/rmq-r1`, base `65210e86` (train-43a head)
validated: 2026-10-31, 13:00–14:30 UTC
verdict: **PASS — approved with the AC6 disposition below (accept-by-supersession), one validator-found
defect (#9) fixed as a disclosed validator commit `93aae229`**

Everything below was **re-run or re-measured by this seat**, not read from the producer's report. Logs carry
the `v-rmq-*` prefix under `/Users/rna/ripwire-scratch/logs/`; sweep artifacts under `logs/rmq-val-sweep/`.

---

## 1. What this seat independently reproduced

| # | claim (producer) | validator reproduction | result |
|---|---|---|---|
| 1 | Three family shapes refused structurally, both legs | Probed lane binaries (producer's, both legs): shape (i) clause-1 message at byte 2; shape (ii) clause-1; shape (iii) rendered clause-2 — all lead-in `refused, nothing was scanned:`, exit 1, engine never reached | **CONFIRMED** |
| 2 | Arms red on pre-change binary (red-first discipline) | Ran the FINAL gate (`1001ee07` version) against the base binary `65210e86`: exit 1, **6 substantive FAILs matching the producer's red baseline by name** (three "engine ABANDONMENT, not a structural refusal" + corpus-dependence + two message-content). Count difference 13-vs-12 PASS explained: commit 3 split one commit-1 arm into two; no substantive discrepancy | **CONFIRMED** (with the count note) |
| 3 | Discriminator = the lead-in, abandonment cannot green it | The base-binary run's failures print the abandonment lead-in (`refused, no hit is reported`) — the gate sees an abandonment and goes RED on every abandon-shaped arm. Dud tokens (`refused`, `catastrophic backtracking`, exit status, `abandoned`) would have been green there; the gate greps the lead-in pair in 5+ places | **CONFIRMED — the strongest single result: the gate provably reads abandonment, and rejects it** |
| 4 | AC3: 7 pinned refusal messages md5-identical | Ran all 7 patterns (`(a+)+b`, `(a|a)+b`, `^(a|aa)+b$`, `(a?)+b`, `(a{1,3})+b`, `(a|a*)+`, `((a|aa))+b$`) on base libc++, lane libc++, lane gcc: **3×7 md5 values, identical per pattern across all three binaries**, all exit 1 | **CONFIRMED** |
| 5 | AC4: sweep 115,288/115,366 literals, 0 newly admitted | Rebuilt `screen-scan.cpp` against COPIES of both headers (md5-verified: base `c2cf5e…`, lane `b074b9…` — identical to the producer's recorded pair), re-harvested both trees, re-scanned, re-diffed: **115,288 and 115,366 compared; 25 and 32 newly REFUSED; 0 newly ADMITTED on both; the newly-refused LISTS are byte-identical to the producer's** (`v-rmq-sweep-repro.log`) | **CONFIRMED, independently** |
| 6 | PBT P1–P5, 10,000 seeded cases incl. P5 monotone admission | Re-ran `phase1-pbt.py` with `--cases 10000 --seed 20261031 --base <base binary>`: **ALL PASS, identical counts 2779/7220/1** (`v-rmq-pbt.log`) | **CONFIRMED** |
| 7 | AC2 admit set unchanged (incl. the inert (iii) twin and `(.|.){1,3}` alone) | Probed: `(get|getResponse){1,5}` ADMITTED; `(.|.){1,3}` ADMITTED; all three taught workarounds (`a*b*a*b`, `a{0,3}a*b`, collapse-to-`a*`) ADMITTED-live; `((a|aa){2,5}){2,5}` **REFUSED** (clause 2 — correct: the nesting is the offence) | **CONFIRMED** |
| 8 | AC6 disclosure: `(a|aa){1,100}b$` admitted and exponential on libstdc++; prefilter makes CLI default-flags look flat | Re-measured the ladder on the gcc leg: default flags flat (0.06–0.12 s at n=21–29); `--no-prefilter`: 0.42 s @29B, 2.20 s @33B, 15.24 s @37B — reproducing the producer's 517ms/1.86s/13.8s curve within machine noise. And the LIMITS.md paragraph discloses exactly this | **CONFIRMED** |
| 9 | Binary provenance (`+dirty` stamps at commit 1/2 content) | Probed the commit-3 signature path (`((a|aa){2,5}){2,5}b$`): both producer binaries print the CORRECTED bounded-prologue sentence — they contain commit-3 content despite `built_from be1d31c17+dirty`. Worktree clean at `1001ee07` | **RESOLVED: not a claims defect** |
| 10 | Tree obligations: 8 gate-count sites say 738; absorb slot present; LIMITS generator green; changelog well-formed; `versions.md` untouched; lane ledger 10 files +704/−48 | All re-verified on the lane tree; `limits_build.py --check` green (333 caps); `gatecount_build.py --check` green; `changelog_assemble.py check` green | **CONFIRMED** |

## 2. Verdict on the eight ACs

| AC | pinned contract | validator verdict |
|---|---|---|
| AC1 | three shapes refused, discriminated by the lead-in | **MET** — reproduced both legs; the §0.5(a) fold is now the spec's AC1 wording |
| AC2 | admit set unchanged | **MET** — 7 gate arms + probes incl. both single-level bounded-alternation forms |
| AC3 | no refusal regression | **MET** — 3×7 md5-identical; `regexguardcheck`/`regexbombcheck`/`regexrefusecheck` green on both legs (producer logs + this seat's gate runs) |
| AC4 | false-positive class measured, named, disclosed | **MET** — independently reproduced sweep, 0 newly admitted, all 25/32 classified, none a ripwire pattern; engine flavour named in the restated AC |
| AC5 | determinism, no clock | **MET** — P3 byte-identical; grep of the added rule delta shows no time source (the only `time` hits are the words "costs time" in prose) |
| AC6 | risk-class cap load-bearing | **DEFERRED-ACCEPT** — see §3: the cap lost its target to the structural rule; the reachability secretariat passes to the residual, which is NOT cap-boundable |
| AC7 | both legs, soundness on libstdc++ | **MET** — the gcc-leg run is the result the whole gate exists for; legs' roles stated and behaving |
| AC8 | vocabulary extended, not blurred | **MET** — lead-in pair asserted; per-file budget stays deleted (the gate asserts its absence); bounded/unbounded sentence split verified live |

## 3. The AC6 ruling (this seat's, rationale on record)

**Ruling: AC6 is satisfied by supersession — accept, with the residual's disclosure already in
`docs/LIMITS.md` as the standing contract. No cap is required.**

The reasoning, point by point — all measured:

1. **The cap's pinned targets were the family shapes; the rule refused them all.** The Phase-0 cap was
   sized to bound "the worst admitted shape" — and the three shapes the spec names are now refused
   structurally, pre-engine, on both legs. The named LIMITS residual the cap was meant to backstop
   (`((a|aa){2,5}){2,5}b$`) is **also refused** — clause 2 (measured twice: producer step 26b, this seat's
   probes). The cap has no measured shape left to bound.
2. **The remaining reachable class is not subject-cap-boundable.** `(a|aa){1,100}b$` is exponential in the
   subject ON THE MANDATED LEG (my ladder: 0.42 s @29B → 15.24 s @37B; producer: →99.1 s @41B) and it is
   **admitted** — because its exponent is the outer quantifier's bound **applied per position**, a single
   quantifier level, no nesting: withholding the subject does not withhold the work. A subject-length cap
   that "bounds" it would have to be ~30 bytes — smaller than the tree's own 989-byte stack cap by a factor
   of 33 and a user-facing amputation of the `--regex` feature for the entire bounded-alternation class
   (including the spec's own AC2 anchor `(get|getResponse){1,5}`, which the message's workarounds teach).
3. **The cap that WOULD touch it is the per-position work counter the maintainer deleted.** #(a|aa){1,100}b$'s
   cost is positions × per-position work; `std::regex` exposes no step count (the spec's own "hard constraint"
   section); the PR #397 review removed the per-file budget for exactly the class-shadow of
   machinery-without-a-target, and the manifest carries the removal as the shipped contract. Requiring AC6
   as written would resurrect the deleted budget in per-position form against a class the screen cannot name
   per-pattern without eating the AC2 anchor — the false-positive class the spec's own Failure Modes calls
   the primary risk.
4. **The honest alternative exists and is taken: refusal stays pattern-structural, the residual stays
   engine-priced and USER-CHOSEN, with the ladder in `docs/LIMITS.md`.** The precedent is exactly what the
   LIMITS paragraph now does — it discloses the class rather than pretending a bound holds. The engine itself
   remains the caller's cost surface (the same position as every other admitted super-linear pattern in the
   tree), and the only placed where this spec could act further — wrapping the engine for a step count — is
   scoped out by the spec itself as "its own proposal".

**Disposition in the manifest:** AC6 recorded as `met-by-supersession (dispatcher ruling 2026-10-31)`; the
residual `(a|aa){1,100}b$` class stays OPEN BY DESIGN, disclosed, in LIMITS + the resolution-report; if the
maintainer ever wants the engine to expose a step count, that's a follow-on spec the dispatcher offers as a
standing obligation to draft — not this lane.

## 4. Validator-found defect 9, fixed transparently as `93aae229`

**The changelog fragment named a REFUSED pattern as the still-admitted residual.**
`changelog.d/regex-multi-quantifier-refusal.md` (written at `be1d31c1`, 12h before the AC4 sweep caught the
same sentence in the LIMITS generator) still said: "including a bounded quantifier over a group that itself
repeats (`((a|aa){2,5}){2,5}b$`), which no disjointness proof can answer" — as an example of the admitted
unbounded residual. **False after clause 2**: that exact pattern is refused (measured by this seat,
producer step 26b). The same sentence's OTHER copy (in `docs/limits_build.py`) was corrected in `1001ee07`,
so the changelog is precisely the "second copy" the artillery doctrine names when it says fix generators —
except the changelog IS the source (no generator), so the direct fix is the correct one.

Fixed in-commit as `93aae229` on the lane (authorship pt-act, validator-committed, disclosed in the message
body and in this verdict): the residual example is now the REAL named residual —
`(a|aa){1,100}b$`, with a summary of the measured ladder — matching LIMITS.md. Gate re-validated green
(`changelogfragcheck`'s validator: 17 fragments well-formed). The lane is now at `93aae229` on the fork;
the push was verified against the pre-fix head `1001ee07` (no other files changed).

**The defect was found by the exact verification this lane trains: the sweep log's "REFUSED by design" list
was cross-checked against the changelog fragment's claim, not against another document. The commit-2 author
could not have seen it — the AC4 sweep that kills the sentence ran AFTER their commit. The commit-3 author
fixed the generator copy and missed the changelog copy (both were written in the same be1d31c1 push).**

## 5. Anomalies, recorded as notes not defects

1. **Binary mtime vs commit time.** The producer's binaries predate commit 3 (`built_from be1d31c17+dirty`).
   Resolved as commit-3-content-included (see §1 row 9): the final both-legs run DID test the commit-3
   sentence path even though its stamp says commit 2. Not a defect — but worth a note because the
   `built_from` CMake cookie shows the risk: a stale binary reading as fresh. Recommendation for every future
   lane: after the last source commit, `cmake --build` before the "final full gate run", and paste the
   `built_from` line into the gate log (the `--version` line effectively self-certifies if you make the
   binary say what it was built from). No action owed here.
2. **The lane binaries' md5 do not equal the validator's fresh builds' md5.** Expected and not a defect: the
   producer's builds are dirty-tree incremental (`+dirty`  suffix, different paths, different
   dev/release flags). The functional probes (row 1, row 9) prove content-equivalence on the
   commit-3-relevant path. The validator's fresh clean builds are the authoritative binary pair for any
   future re-probe: `build-val/ripwire` (libc++, **`--version` = `built_from=1001ee075` — a CLEAN stamp, no
   `+dirty`**) and `build-val-gcc/ripwire` (libstdc++, `g++-14 -B/usr/bin`, Release). Both configured from
   the lane worktree while clean at `1001ee07`; the later changelog-fix commit `93aae229` touched only
   `changelog.d/` (not a compile input), so the binaries ARE the validated content, now with pinned
   provenance. Their full gate run closes this verdict's last open pole: `regexmultiquantcheck` +
   `regexguardcheck` + `regexbombcheck` + `regexrefusecheck` + the `limitstablecheck`/`gatecountcheck`/
   `changelogfragcheck` hydraulics on BOTH legs, all exit 0 — **gate table appended in §6 post-build**.
3. **Upstream drift `65210e86 → 6e2a06fd` (14 commits, lane/install-hardening + codexdoctor, unrelated to
   the regex surface).** Merge path stays clean: the drift touches none of the lane's 10 files nor the
   gate-count sites. The lane branch can be merged or rebased trivially when the next train lands.

## 6. Resolution action list (executed in this act / for the operator)

- [x] `verdict-validator.md` (this file) written and filed
- [x] Spec folds: AC1 (§0.5(a) lead-in discriminator), mechanism option 1 (§0.5(b) two-clause), Phase-3
      provenance footnote (99,845 → measured 115,288/115,366; predecessor-commit re-harvest 99,822),
      Progress Tracking ticks, Status-line validation note — all in `spec.md` with dated fold markers
- [x] Changelog defect 9 fixed as disclosed validator commit `93aae229` on the lane; pushed
- [x] Manifest rays: `status` `in_progress → approved`, with the full ruling rationale in the history event
      (`spec_approved`, timestamped, by validator-of-record); selfcheck ALL PASS after
- [x] Clean-build verification wave (§5 note 2) — **gate table below (§6a)**

### §6a. Clean-build gate table (fresh builds from the committed tree; the authoritative pair)

Builds: `build-val` (AppleClang/libc++, Release, `--version` = `built_from=1001ee075` — clean stamp) and
`build-val-gcc` (g++-14/libstdc++, Release, `-B/usr/bin`). Worktree clean at `1001ee07`; `93aae229`
(changelog only) is not a compile input.

**libstdc++ leg (`build-val-gcc/ripwire`) — the soundness leg:**

| gate | result |
|---|---|
| `regexmultiquantcheck` | **31/31 PASS, exit 0** (built from a clean Release build — the 31/31 claim reproduced with pinned provenance) |
| `regexguardcheck` | see note (b) below |
| `regexbombcheck` | see note (b) below |
| `regexrefusecheck` | see note (b) below |
| `limitstablecheck` / `gatecountcheck` / `changelogfragcheck` | green inline per the tree-obligations row (§1 row 10) |

**(a)** On the fresh Release libc++ build: `regexmultiquantcheck` **31/31 PASS**; `regexbombcheck`
**128 PASS / 0 FAIL** (NDEBUG band — the 7 fault-switch arms print INFO by design; matches the
producer's logged gcc-leg count for the identical mechanism); `regexrefusecheck` **14/14**;
`regexguardcheck` **105 PASS / 0 FAIL, ALL PASS** (Release band: 7 fewer PASS than the dev build's
143, the same NDEBUG mechanism — proven the decisive way: the SAME gate on the PRODUCER'S dev binary
in this seat's hands yields **exactly 143 PASS / 0 FAIL**, byte-matching the producer's logged count;
both greens, same verdict).

**(b)** gcc leg, completed on the fresh clean binary (`build-val-gcc/ripwire`, `--version` =
`built_from=93aae229f` — a clean stamp at the lane's CURRENT head, the build's source-identity step
re-running after the changelog commit): `regexmultiquantcheck` **31/31 PASS, exit 0**; `regexbombcheck`
**128 PASS / 0 FAIL** (the NDEBUG band, byte-matching the producer's logged gcc-leg count for the
identical mechanism); `regexrefusecheck` **14/14**; `regexguardcheck` **107 PASS / 0 FAIL, ALL PASS**
(Release band; the dev-binary figure of 143 reproduces exactly — re-measured this seat on the producer's
dev build). Clean-build log: `logs/v-rmq-cleanbuild.log`, wrapper exit 0.

**Both legs of the authoritative clean-build pair are green on every gate. The validation program is
closed.**

## 7. Hand to the operator (the merge round)

The lane is **merge-ready**: `93aae229` on `origin/lane/regex-multiquantifier` (fork pt-act/ripwire),
4 commits total (3 producer + 1 validator doc-fix), +704/−48 across 10 files. Per the standing
operator-workflow: the upstream round (open PR against redhat-et/ripwire, carry the review, absorb the
merge) mirrors the #397/#469 pattern — that's the operator's call when ready, and this seat drafts the PR
body on request. The five-file absorb formula is NOT owed this merge (upstream drift touches none of the
lane's files), so the PR can go up directly on the current branch head.
