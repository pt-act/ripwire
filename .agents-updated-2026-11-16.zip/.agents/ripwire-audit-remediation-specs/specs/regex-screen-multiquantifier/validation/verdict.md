# Verdict — regex-screen-multiquantifier

## Header

spec_id: regex-screen-multiquantifier
author: producer seat (WorkBuddy AI / Deepseek-V4.1-Flash `-1017`, manifest `execution.producer`)
status: **PRODUCER SELF-ASSESSMENT — NOT A VALIDATION**
validator: **not this session.** Per VALIDATION_PROTOCOL step 2 and the Q10 ruling (option (a)), the producer does
not validate its own work and does not flip the manifest's `status`. This file states what the producer believes
it has delivered, what it has measured, and what it is explicitly *not* claiming — so the validator's review has
a precise claim set to attack. The validator's own verdict belongs in `validation/verdict-validator.md`.
lane: `lane/regex-multiquantifier` @ `1001ee07`, worktree `/Users/rna/ripwire-scratch/rmq-r1`
base: `65210e86` (train-43a head)
timestamp: 2026-10-31 13:10 UTC

---

## What I am claiming

**The named family is closed, structurally, on both standard libraries, before any engine sees the pattern.**

Three shapes used to reach the engine with no arm reading them. All three are now refused by name:

| shape | pattern | clause | status |
|---|---|---|---|
| (i) flat adjacent quantifiers | `a*a*a*a*a*b` | 1 | refused |
| (ii) grouped, no alternation | `^(a)*(a)*(a)*(a)*(a)*$` | 1 | refused |
| (iii) bounded nested alternation | `^(ab\w\|((.\|.){1,3}){1,3}){1,3}$` | 2 | refused |

Supported by: 31/31 gate arms on **both** legs; 10,000-case seeded PBT with five properties (including
monotone admission measured against a real pre-change binary); a 115,288-literal corpus sweep with **0 newly
admitted**; and 7 pre-existing refusal messages verified md5-identical to the base binary.

## What I am explicitly NOT claiming

1. **That AC6 (the risk-class cap) is met.** It is not implemented. The structural rule removed the cap's
   target; I could not find a shape the cap would bound that the rule does not already refuse, and the tree has
   a rule against machinery with no measured target (PR #397 deleted a budget for exactly that reason). This is
   a **deviation from the accepted Phase 0 plan** and it needs the PM's ruling, not my silence. The full
   argument, and the one target I *can* now name (`(a|aa){1,100}b$`, exponential on libstdc++, measured 7.8 ms
   at 21 B rising to 99.1 s at 41 B), is in the completion report's AC6 section.
2. **That no admitted pattern is super-linear.** `(a|aa){1,100}b$` is admitted and is exponential on libstdc++
   (ladder above; harness in `evidence/sweep-repro/`). The general residual is disclosed in `docs/LIMITS.md` with
   those numbers.
3. **That shape (iii) is closed in every spelling.** Only the rendered form is the bomber; the
   backslash-pipe form is a different, inert pattern, and the gate asserts it stays *admitted* so nobody
   "fixes" it by refusing it.
4. **That the sweep's literal count reproduces the spec's 99,845.** It does not: the tree grew, so the sweep
   harvests 115,288 (base tree) / 115,366 (lane tree), and harvesting the predecessor's own commit gives
   **99,822**, not 99,845. The 23-literal gap is unexplained and recorded as such. It changes no verdict pair.
5. **That this is merge-ready.** `test/limitstablecheck.sh` had to be repaired in the last commit because I had
   edited a generated file; the validator should treat "green on the regex gates" as insufficient.

## Self-assessed acceptance criteria

| AC | self-assessment | the validator should verify |
|---|---|---|
| AC1 three shapes refused, not abandoned | met (31/31 both legs) | that the arms discriminate on the **lead-in**, not exit status or the word `refused` |
| AC2 admit set unchanged | met (7 arms + sweep) | that `(.|.){1,3}` and the inert (iii) twin are still admitted |
| AC3 no refusal regression | met | the 7 md5-identical messages, re-measured, not taken from this report |
| AC4 false-positive class measured/named/disclosed | met (sweep run) | the classification of all 25/32, and that `NEWLY ADMITTED = 0` |
| AC5 determinism, no clock | met | that no time source exists in the rule (grep it) |
| AC6 risk-class cap load-bearing | **NOT MET — deviation** | the PM ruling, not a producer claim |
| AC7 libc++ leg mandatory | met | that the libstdc++ leg is the one that proves the bomb bounded |
| AC8 vocabulary extended | met | the lead-in pair and the bounded/unbounded sentence split |

## Defects I shipped and then found, in order

Recorded because a validator should read the failure modes, not only the final diff. Each was found by
measuring, not by re-reading:

1. **Broken `Edit`** truncated `catastrophicRegexConstruct`'s body (removed its opening braces). Caught by
   `sed -n` before rebuilding.
2. **Shape (ii) still failed after the first build** — clause 1 broke adjacency at `(` and never treated a
   quantified *group* as an atom. Fixed by adding the group case.
3. **Arm asserted a phrasing, not a contract** — my gate grep pinned one clause's sentence, which made the other
   clause's arm fail on wording. Rewritten to assert `catastrophic backtracking` + `quantifier`.
4. **`gateexitcheck` caught a real defect in my new gate** — a `&& ok … || no …` one-liner that prints FAIL for a
   passing arm when `ok()`'s printf stalls. Converted to `if/else`.
5. **Message said a false thing** — clause 2 printed "the unbounded quantifier '{'" for a *bounded* `{2,5}`
   repeat. Fixed with a bounded prologue printing the quantifier as written.
6. **`docs/LIMITS.md` is generated and I edited the generated file**, leaving its generator stale — a gate
   (`limitstablecheck` section B) would have gone red on the validator's run. Fixed at the generator.
7. **My own evidence claimed two workarounds that do not work** (`.*?`, `[^ ]*` for `import\s+.*from`). Both are
   still refused; corrected in place with the measurement.
8. **I wrote an unmeasured adjective and nearly shipped it** — "(a|aa){1,100}b$ is exponential… abandoned by
   libc++" was asserted from the predecessor's prose, then measured flat because the CLI's **literal prefilter**
   was dropping the line. The real measurement needs `--no-prefilter` or the bare engine. The ladder in the
   completion report is the corrected one. This is Phase 0's own "flag conflation" class, made again by me.

## Pointer for the validator

Everything here is re-runnable from `evidence/sweep-repro/` plus the two worktrees. The two things I would
attack first, in this order:

1. **P5 (monotone admission)** with `evidence/phase1-pbt.py --base <pre-change binary>` — it is the property that
   makes AC4's "0 newly admitted" a claim rather than a coincidence.
2. **The gate's discriminator** — if the arms can be made green by an engine abandonment, the whole result is
   vacuous. That is the failure this spec's methodology exists to prevent, and it is where I would spend the
   review budget.
