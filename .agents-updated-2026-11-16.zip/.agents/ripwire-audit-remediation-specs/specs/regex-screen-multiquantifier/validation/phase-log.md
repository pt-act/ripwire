# phase-log — regex-screen-multiquantifier

One entry per decision-bearing step, in the order they happened. Steps that produced a *measurement* name the
file it is in; steps that produced a *correction* name what was wrong and how it was found.

---

## Phase 0 (2026-10-30 → 10-31)

1. **Dispatch audited before acting.** Fork main == upstream == `d044662a` (then `65210e86`); manifest flip
   `spec_started` = history event 31; selfcheck ALL PASS; `g++-14` 14.2.0_1 present; the four SR ids present;
   `regexguard.h` byte-identical on the merge path.

2. **Base re-pin verified independently**, not taken on trust: `65210e86` on both remotes, and six regex-surface
   files hash-equal across `d044662a..65210e86` — so every Phase-0 number carries and no five-file absorb is owed.

3. **Cost ladders measured** → `evidence/phase0-shape-cost.log`. Shape (i) doubles every ~6.1 bytes (5.4 ms @21 B
   → 29.5 s @97 B); shape (ii) is ~degree-4 polynomial; shape (iii) does not return from n=30. Both toolchains
   labelled; the two probe vehicles named.

4. **The existing cap cannot bound it.** `maxEngineSubjectBytes` computes **989 bytes** for shape (i) on an 8 MiB
   stack — a *stack-safety* number. 989 B is ~146 doublings past 29.5 s, so it bounds the subject and nothing
   about the cost. Recorded so mechanism 2 alone is excluded by arithmetic, not taste.

5. **Three conflation classes identified** while writing the reachability log →
   `evidence/phase0-reachability.log`: fixture pollution, flag conflation (`--no-prefilter` changes the verdict and
   must be written down), and the word `refused` prefixing both messages.

6. **PM fold received and verified, not trusted.** All three claims confirmed; **two were my errors**, both worse
   than the fold stated (§0.1 fixture claim withdrawn; §0.3 citations rewritten with the rule *citations come from
   `git show <sha>:src/…`, never a working copy, including a scratch worktree*).

7. **`phase0-planning.md` delivered**: mechanism decision (option 3), admit-set analysis, AC1–AC8 pinned,
   interfaces, corrections for the PM.

---

## Phase 1 (2026-10-31)

8. **Lane opened** — `lane/regex-multiquantifier` at `/Users/rna/ripwire-scratch/rmq-r1` off `65210e86`, author
   `pt-act`. Worktree `src/regexguard.h` sha256 == the merged object's; build exit 0, 0 errors.

9. **Red baseline established on the pre-change binary**: shape (i) ABANDONED, (ii) ABANDONED, (iii-B) ABANDONED,
   (iii-A) clean. This is the behaviour the arms must reproduce as RED.

10. **Two defects in my own Phase 0, found by trying to write the arms** → `phase0-planning.md` §0.5:
    - **(a)** AC1 pinned `catastrophic backtracking` as the structural token, but the **abandonment** path prints
      it too, in the `[math degraded]` DISCLOSE. The negative half (`abandoned`) discriminates on one letter
      (`abandons` vs `abandoned`). **The sound discriminator is the lead-in**, verified exclusive in source:
      `refused, nothing was scanned:` (verbs_grep.h:991) vs `refused, no hit is reported:` (verbs_grep.h:899).
    - **(b)** §2's single rule ("adjacent quantified atoms in one repetition scope") **cannot catch shape (iii)**:
      the offence is `(.|.)` — atoms in *alternation branches*, each unquantified, under a *bounded* outer. So the
      rule is two clauses, not one. Recorded rather than silently patched, because it changes the mechanism note.

11. **Arms written and shown RED first** — `test/regexmultiquantcheck.sh`, 31 arms, **12 PASS / 6 FAIL, exit 1**
    on the pre-change binary. Committed alone (`3785cea5`) so the red baseline is an artefact, not an anecdote.
    Evidence: `evidence/phase1-red-baseline.log`.

12. **Fixtures pinned at MEASURED abandon thresholds**, not at "small": shape (i) `b`+'a'×400 abandons from n≈20,
    (ii) 'a'×60+'z' from n=20, (iii) 'abw'+'.'×19+'Z' from n≈18. A shorter subject is admitted and clean, which
    would make the arm **green on the pre-change binary**.

13. **Clause 2 implemented** as a frame-carried flag (`hasRepeatedUnprovenAlternationInside`), mirroring M2-d's
    `unprovenAlternation`: the fact belongs to the subtree, not the group carrying the quantifier. `(.|.){1,3}`
    alone stays admitted (measured cheap at every length) — the *nesting* is the offence. **Measured, and it
    invalidated my first guess**: nesting depth alone is not the trigger either; `^((.|.){1,3}){1,3}$` is clean at
    every length tested, so the condition is "an overlap repeated within a repeat", which the flag states exactly.

14. **Clause 1 implemented** as a per-scope adjacency pass, reusing `regexCharSetOfSingleCharBranch` /
    `regexCharSetsIntersect` rather than growing a second parser.

15. **First build → shape (ii) still failed.** Cause: the scan broke adjacency at `(`, so `(a)*(a)*` never saw its
    neighbours, and a *quantified group* was not treated as a quantifier atom at all. Fixed by adding the group
    case (atom set = body set when the body is a single width-one atom). Rebuilt → **31/31**.

16. **`regexguardcheck` arm (b2) went RED — a real regression, and correctly so.** Its real-engine vehicle was
    `a*a*a*a*a*b` *because* the screen admitted it; this spec closes exactly that. The arm's *guarantee* (the
    engine abandons; the verb refuses rather than report a floor) must not be lost with its vehicle, so it was
    re-vehicled to `(a*){20}b` — admitted for a non-accidental reason (one bounded repeat of a group with one
    unbounded quantifier: neither the nested arm, the alternation arm, clause 1 nor clause 2 fires). Verified
    stable and engine-abandoned over 3 runs.

17. **`gateexitcheck` caught a defect in the NEW gate**: a one-line `&& ok … || no …`, which prints FAIL for an
    arm that passed when `ok()`'s printf hits a stalled pipe (the #126 CI failure mode). Converted to `if/else`.

18. **Over-refusal swept** → `evidence/phase1-admit-set-sweep.log`. 38 realistic patterns, **1 newly refused**
    (`import\s+.*from`). Then measured whether that refusal is *correct* rather than conservative: raw `std::regex`
    on a **failing** subject puts `a*a*b` at **85 ms @121 B** vs `a*b` at 4.8 ms — two adjacent quantifiers are
    already quadratic. So the refusal is right, and it is disclosed as the false-positive class rather than
    narrowed away.

19. **My own evidence corrected in place**: I had named `.*?` and `[^ ]*` as workarounds for that pattern.
    **Both are still refused** (laziness changes which path is tried first, not how many exist; `[^ ]` still
    intersects a dot-family set). Rewritten with the measurement, and the refusal message verified to teach only
    the three workarounds that actually work.

20. **AC7 second leg built and run** — g++-14/libstdc++ (`-B/usr/bin` required on this host; without it the
    compiler check fails to link). **31/31** on the leg where the shapes actually hang, which is the only leg that
    can prove a bomb bounded. Sibling gates green there too. → `evidence/phase1-both-legs.log`.

21. **PBT written and run** (`evidence/phase1-pbt.py`): 10,000 seeded patterns, properties P1 no-crash, P2
    no-hang, P3 determinism, P4 exactly-one-lead-in, **P5 monotone admission** (nothing the pre-change binary
    refused is admitted now) against a real `65210e86` build. **ALL PASS**; 2,779 refused / 7,220 admitted /
    1 engine-abandoned. → `evidence/phase1-pbt-libcxx.log`.

22. **A third defect, in the shipped message.** Clause 2 borrowed `catastrophicRegexPrologue`, which hardcodes
    "the **unbounded** quantifier"; for `((a|aa){2,5}){2,5}$` that printed *"the unbounded quantifier '{'"* —
    false twice (the repeat is bounded; `'{'` is not a quantifier character). Fixed with a bounded-prologue
    variant printing the quantifier **as written** (`the quantifier '{2,5}'`), selected by `quant.isUnbounded`.
    **Verified the M2-c/M2-d sentences stayed byte-identical** (7 patterns, md5-equal against the base binary).

23. **AC6 assessed honestly and NOT claimed.** The structural rule closes every shape the spec names, and the
    long-line probes the cap was meant to bound return clean on libstdc++. The residual LIMITS.md named
    (`((a|aa){2,5}){2,5}b$`) turned out to be **already caught by clause 2**. A smaller cap would therefore bound a
    shape I could not produce — so it was not added, and the deviation is escalated to the PM with both options
    rather than papered over. `(a|aa){1,100}b$` remains admitted and is disclosed as the open class.

24. **Tree obligations discharged**: gate absorbed at its alphabetical slot (737 → 738), count regenerated by
    `docs/gatecount_build.py`; changelog fragment added and validated; `docs/LIMITS.md` residual paragraph
    rewritten (it had said the family was "never claimed closed", now false for the two shapes refused).

25. **Completion report written** with AC4's full corpus sweep explicitly marked **OWED**, not done — the
    38-pattern pass is a spot-check and says so in its own log.

26. **AC4 paid off, and it found two more defects.** Swept the tree's own literals on the screen alone, both
    trees: base 115,288 → 25 newly refused, **0 newly admitted**; lane 115,366 → 32 newly refused, **0 newly
    admitted**. Classifying all 25 showed every one is prose, a fixture, a foreign-tool regex, or this spec's
    own artefacts — **not one is on a `--regex`/`--match`/`--arch`/`--graph-query` line**. Then the questions
    that follow a sweep:

    a. **`docs/LIMITS.md` is generated by `docs/limits_build.py`, and `be1d31c1` edited the GENERATED file.**
       `limits_build.py --check` reported STALE — `test/limitstablecheck.sh` section B would have gone red on
       the validator's run, from a change that read as complete. Fixed at the generator, then regenerated.

    b. **That exposed a false sentence in the generator**: it still said `((a|aa){2,5}){2,5}b$` "passes the
       screen because both quantifiers are bounded" and that the family was "admitted by the screen by
       construction". Clause 2 refuses the first and the second is the sentence this spec exists to delete.
       Rewritten to what the screen now does.

27. **An unmeasured adjective I nearly shipped, and the measurement that killed it.** Writing the new LIMITS
    paragraph I asserted `(a|aa){1,100}b$` is "exponential on libstdc++ and abandoned by libc++", borrowing the
    claim rather than making it. Measured through the CLI at default flags it looked **flat at ~6 ms for every
    n** — which would have made the sentence false. The flat reading was itself the error: the **literal
    prefilter** was dropping the line before the engine saw it. This is Phase 0's own "flag conflation" class,
    committed again. Re-measured on the bare engine and with `--no-prefilter`:

    | subject (`a`×n + `c`) | 21 B | 25 B | 29 B | 33 B | 37 B | 41 B |
    |---|---|---|---|---|---|---|
    | libstdc++ | 7.8 ms | 27 ms | 517 ms | 1.86 s | 13.8 s | 99.1 s |

    ~7× per 4 bytes — genuinely exponential, and libc++ throws `error_complexity` from an 18-byte subject up.
    The sentence went into `docs/LIMITS.md` **with the ladder** instead of the adjective, and the harness is in
    `evidence/sweep-repro/`.

28. **The spec's 99,845 does not reproduce, and I recorded that instead of writing the number down.** Harvesting
    the predecessor's own commit (`0e0f67c7`) gives **99,822**, not 99,845. I did not resolve the 23-literal gap
    (candidates: a different `harvest.py` revision, or its *patched* verify tree rather than the bare commit).
    It changes no verdict pair — one harvested set feeds both screens — so it is a provenance footnote, and it
    is in the sweep log as one.

29. **Reconciled 25 vs 32 exactly, rather than explaining it away.** Lane tree shows 32 because 22 of the base
    tree's 25 survive, **3 are gone** (the three LIMITS.md sentences I rewrote, so that wording no longer
    exists), and **10 were added** by this change (7 gate fixtures/labels/messages quoting the shapes they
    refuse, 3 replacement prose). 22 + 10 = 32. All ten added are refused by design.

30. **Full gate set re-run on BOTH legs after the last commit: 8 gates × 2 toolchains, all exit 0.**
    `regexmultiquantcheck`, `regexguardcheck`, `regexbombcheck`, `regexrefusecheck`, `gatecountcheck`,
    `gateexitcheck`, `limitstablecheck`, `changelogfragcheck`. The `limitstablecheck` line is the one that
    matters — it is the gate the first commit would have broken, and it is not a regex gate.

---

## Open, for the PM seat

| # | item |
|---|---|
| 1 | **AC6 ruling**: accept-by-supersession, or require the cap. The target is now **named** — `(a|aa){1,100}b$`, exponential in the subject and **not** bounded by a subject-length cap (the exponent is the outer quantifier's size); a cap that would touch it is a per-position work cap, i.e. the budget PR #397 deleted. That tension is a policy call, flagged not resolved |
| 2 | Fold §0.5(a) (lead-in discriminator) into AC1's wording |
| 3 | Fold §0.5(b) (two clauses) into §2's mechanism |
| 4 | ~~AC4's corpus sweep is owed~~ — **DONE**, 0 newly admitted on both trees, all newly-refused classified |
| 5 | The spec pins "99,845 literals"; the sweep harvests 115,288/115,366 (tree grew) and re-harvesting the predecessor's commit gives 99,822, not 99,845. Provenance footnote, no verdict pair changes |
| 6 | Manifest `status` is not flipped by this session (Q10 (a)) |
