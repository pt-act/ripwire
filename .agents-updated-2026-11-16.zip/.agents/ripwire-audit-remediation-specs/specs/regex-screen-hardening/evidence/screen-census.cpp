// probe-fp.cpp — re-baseline probe (2026-11-10). Two questions, both measured rather than inferred:
//
// (1) The bundle README (lines 130-136) explains nine "documented false-positive" shapes as REFUSED "because
//     ab|cd and cat|dog are the same SHAPE as the spec's own refused ^(ab|cd)+e$". The re-baseline now records
//     ^(ab|cd)+e$ as ADMITTED (M2-e first-character disjointness, regexguard.h:177-199). If the reference shape
//     is admitted, that explanation cannot hold, and these shapes should be admitted too.
//
// (2) corpus-sweep.txt (dated 2026-10-12, THREE DAYS BEFORE 3fb42b417 on 2026-10-15) records 33 "newly refused"
//     over the tree's own literals. If the rule widened, that count is stale in the same way the PBT log was.
//     These are the actual sweep strings that the README calls the false-positive class, verbatim.
#include "regexguard.h"
#include <cstdio>

int main()
{
    struct Row { const char* label; const char* pat; };
    const Row rows[] = {
        { "ref: ab|cd (admitted per M2-e)",  "^(ab|cd)+e$" },
        { "ref: get|getResponse (refused)",  "(get|getResponse)+" },
        { "sweep: JSON string body",         "\"(?:[^\"\\\\]|\\\\.)*\"" },
        { "sweep: JSON body + \\n excl",     "\"(?:[^\"\\\\\\n]|\\\\.)*\"" },
        { "sweep: single-quote body",        "'(?:[^'\\\\\\n]|\\\\.)*'" },
        { "sweep: brace escape",             "(?:[^{}]|\\{\\})" },
        { "sweep: File:/Line:",              "File:\\s*'((?:[^']|'')*)'\\s*,\\s*Line:\\s*(\\d+)" },
        { "sweep: sed-like rewrite",         "s/\"([^\"\\\\]|\\\\.)*\"//g" },
        { "sweep: match? verb form",         "#(not-)?match\\? @[A-Za-z_.]+ \"([^\"\\\\]|\\\\.)+\"" },
        { "control: bomb (a|aa)+b",          "(a|aa)+b$" },
        { "control: bomb (a|a)+z",           "(a|a)+z" },
        { "control: nested ((a|aa)+)+",      "((a|aa)+)+" },
    };
    for( const Row& r : rows )
    {
        auto v = rw::screenRegexPattern( r.pat );
        std::printf( "%-34s %s\n", r.label, v ? "REFUSED" : "admitted" );
    }
}
