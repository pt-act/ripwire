# Completion Report — regex-screen-hardening — round 3 (mechanical quality-delta cleanup)

## Header

spec_id: regex-screen-hardening
producer: WorkBuddy AI / Deepseek-V4.1-Flash
round: 3 (mechanical, after the PM's round-3 `needs_revision` verdict — exactly ONE red item)
started: 2026-10-13T21:40:00Z
completed: 2026-10-13T22:35:00Z
spec_version: 2.0.3 (**UNCHANGED** — round 3 changes no spec text)
supersedes: nothing. `validation/completion-report-r2.md` still stands for every AC claim and every piece of evidence.

Round base: `0e0f67c73` (post-0.6.7, train 27). Scratch tree `/Users/rna/ripwire-scratch/rsh-r1`.
Branch `lane/regex-screen-hardening` on `origin` (pt-act/ripwire), now at **`77de7863`**:

| commit | what |
|---|---|
| `91c5fb2e` | round 1 + 2's shipped artifact (`fix(regex): refuse overlapping alternation, budget the match, disclose the residual`) |
| `77de7863` | **round 3** — `refactor(regex): split round 1's grown helpers so the branch's quality-delta is clean` |

## What round 3 is

The round-3 verdict was green on everything except `--quality-delta=0e0f67c73..HEAD`, which gated **six**
findings — all of them **structural debt round 1's own change introduced**, none of them a behaviour defect.
The PM's relay: *"round 3 is mechanical, not architectural — extract helpers for the two duplication pairs,
split the screen function's alternation arm into a helper to bring complexity and verbosity under bar, and
re-run `--quality-delta=0e0f67c73..HEAD` until `gating="0"`. No spec text, no behavior, no gate arms need to
change."*

Round 3 is exactly that, and nothing else.

## The six findings, and what cleared each

| kind | symbol / members | was → now | cleared by |
|---|---|---|---|
| complexity | `catastrophicRegexConstruct` | 34 → 43 | the group-close arm moved out (below) → back to **27** |
| verbosity | `catastrophicRegexConstruct` | 53 → 78 | the same move → back to **52** |
| complexity | `grepScanText` | 14 → 18 | the literal path's line cursor moved out → back to **13** |
| complexity | `refuseAbandonedRegexScan` | 7 → 19 | the cause resolution and the emit moved out → back to **3** |
| duplication | `catastrophicRegexAlternationMessage` \| `catastrophicRegexMessage` | 24 tokens | the shared opening is now `catastrophicRegexPrologue` |
| duplication | `regexFileMatchBudget` \| `isChargeBufferFaultInjected` | 22 tokens | both now read through `faultSwitchOnOnce<Tag>` |

The five extractions:

- **`catastrophicRegexPrologue`** — the two refusal sentences' shared opening (`"catastrophic backtracking:
  the unbounded quantifier '<q>' is applied to "`). Spelled out in both, it was 24 identical normalized
  tokens. The concatenation is the same bytes, so every pinned refusal still reads word for word.
- **`faultSwitchOnOnce<Tag>`** (`src/infra/emit.h`) — the once-per-process fault-switch read, in one place.
  A **tag type** is what keeps each switch's own `static`: a function-local `static` initialised from a
  runtime *parameter* is set on the first call and every later call — from any switch — would get that first
  answer. The env name stays in the wrapper body, which is what a reader greps for. Migrated: the three
  `infra/emit.h` switches, `isChargeBufferFaultInjected` (`serialize.h`), `regexFileMatchBudget`
  (`regexguard.h`). The four switches whose wrapper does more than the read (`throwIfMatchFaultInjected`, the
  line-bound switch, the scan-stack-mix switch, the skill-walk switch) keep their inline form — they are not
  the read-only shape the helper is for.
- **`RegexGroupFrame` + `regexCloseGroupVerdict` + `regexCloseGroup`** (`src/regexguard.h`) — the scan's
  group-close arm: pop the frame, judge it (the two arms, in order, with M2-c's alternation arm second so
  every pre-M2-c refusal keeps its message), fold the verdict into the parent, step past the group's
  quantifier. The frame struct moved from a function-local to file scope because the helper reads it.
- **`abandonedRegexFirstPath` + `resolveAbandonedRegexScan` + `emitAbandonedRegexRefusal`**
  (`src/verbs_grep.h`) — the refusal sentence's cause resolution (which reason, which first file) and its
  emit. The sentence's head is identical for both causes and only the trailing advice differs, so the advice
  is now the one argument the caller supplies. The emitted bytes are unchanged.
- **`lineAtOffset`** (`src/search.h`) — the literal path's line cursor, lifted out of `grepScanText`. This is
  the one extraction that is **not** on the changed path: the two `DISCLOSE` calls that round 1's Phase 2
  added are pinned to `grepScanText` by the `DISCLOSE` macro, whose 3-arg form string-concatenates its
  message (`"" msg`), so the message cannot be selected at runtime and the call site cannot move without
  changing the diagnostic trace's `_PRETTYFUNCTION_`. Extracting the cursor instead reduces the function by
  the same bar without moving a single byte of output.

## Verification

**The gate that gated, now clean.** `./build/ripwire . --quality-delta=0e0f67c73..HEAD`:

```
base_ref="0e0f67c73ca332ed58bb8478677f916f7ccc1e84"
target_ref="77de7863141de09d82a0a697c2e750b1965996f8"
regressions="10"  minor="7"  gating="0"  preexisting-worse="7"  new-symbol="3"  acked="0"  stale="147"
exit code 0
```

`gating="0"`, exit 0. Every remaining row is `origin="new-symbol"` (never gates) or `sev="minor"` (never
gates); the largest are `regexCharSetOfClass` (round 1's new class parser, ccx 42 / 85 loc, new-symbol) and
the pre-existing `RegexCharSet::add` | `RegexCharSet::remove` pair (new-symbol). No new duplication pair
appeared from any of the new helpers.

**Nothing else moved.** All runs with the scrubbed environment and `SDKROOT` (AD-2026-10-12-gates-need-scrubbed-env;
the `SDKROOT` recipe is in `current_focus.md`):

| gate | result |
|---|---|
| `regexguardcheck.sh` | **ALL PASS** — the gate that pins every refusal message word for word |
| `regexrefusecheck.sh` | ALL PASS |
| `regexcheck.sh` | ALL PASS |
| `regexbombcheck.sh` | ALL PASS — the bomb battery, the budget section, the refusal shape and exit codes |
| `grepcheck.sh` | ALL PASS |
| `grepscancheck.sh` | ALL PASS |
| `grepanchorcheck.sh` | ALL PASS |
| `limitstablecheck.sh` | ALL PASS |
| `selfcheckcheck.sh` | ALL PASS |
| `manifestcheck.sh` | PASS |
| `readmedriftcheck.sh` | **only the pre-existing (G4) arm fails** — proven not ours with the pristine-binary control; (L1)/(L2)/(L3) all PASS, so the cap count is still 255 caps / 7 parameters |

**`test/` is untouched by round 3.** `git diff --name-only 91c5fb2e..77de7863` lists five `src/` files and
nothing else:

```
 src/infra/emit.h |  31 +++++++++----
 src/regexguard.h | 134 ++++++++++++++++++++++++++++++++++---------------------
 src/search.h     |  20 +++++++--
 src/serialize.h  |   7 +--
 src/verbs_grep.h |  88 +++++++++++++++++++++++-------------
 5 files changed, 184 insertions(+), 96 deletions(-)
```

Both gate scripts on the branch (`test/regexbombcheck.sh`, `test/regexguardcheck.sh`) are round **1**'s
re-scoped arms (the (b2)/(i) re-scope and PM-2's BSD-grep portability fix) and are unchanged since `91c5fb2e`.

## Honest notes

- **No behaviour change is claimed and none was made.** Every refusal message, disclosure text, hit count and
  exit code is byte-identical; `regexguardcheck.sh` and `regexbombcheck.sh` assert that at every entry point.
  The one place a refactor *could* have moved output — the `grepScanText` disclosure trace, which prints
  `_PRETTYFUNCTION_` — was deliberately left alone for that reason (see `lineAtOffset` above).
- **The residual is unchanged and is not claimed closed.** The budget bounds a file's **aggregate** cost; a
  single pathological match remains unbounded on libstdc++, tracked by the follow-on spec
  `regex-screen-multiquantifier` (in the DAG, `status: planned`, `depends_on: [regex-screen-hardening]`). The
  round-1 disclosure in `CHANGELOG.md` and `docs/LIMITS.md` is untouched by round 3.
- **Status is deliberately NOT flipped.** Per `VALIDATION_PROTOCOL.md` step 2 the producer signals completion
  by writing this report and does **not** flip status or write the manifest; the spec stays `in_progress`.
  (`PROJECT_MANIFEST.md` §E step 3 assigns the `in_review` flip to the producer, which contradicts step 2 —
  flagged to the operator, still unresolved, unchanged by round 3.)
- **Repro notes the verdict passed along, for the record:** the crawl root must be a **directory** (a bare
  file answers `files="0"`); subjects past the measured-safe line bound get `Skipped` rather than backtracked;
  the battery runs through `--regex=`, not `--grep=`. A gate arm asserting the screen covers both spellings
  was suggested **if** `--grep=` is a real surface — that is a gate-arm question, and the PM's round-3 relay
  said no gate arm needs to change, so it is left as an open suggestion, not actioned here.

## Resumption point

Round 3 is **committed and pushed**; `origin/lane/regex-screen-hardening` == local HEAD == `77de7863`
(verified by `git ls-remote`). The next actor is the **PM's delta-only re-validation** of
`--quality-delta=0e0f67c73..HEAD`, then the **operator's independent validation** and the upstream PR.
