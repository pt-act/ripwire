# Draft reply to joyful-ii-V-I on PR #397

Status: DRAFT — for RA to post from the pt-act account (reply to
https://github.com/redhat-et/ripwire/pull/397#issuecomment-6301372407).

Every factual claim below was verified locally on 2026-10-23 against the merged
head `bb2b25e6` (see the verification block at the bottom).

---

@joyful-ii-V-I — apologies for the slow reply, and thank you for the re-review.

The non-ASCII literal byte fix is a real find in our screen, and it is fixed at
the right layer: `RegexCharSet::add` was recording a byte ≥ 128 in the low-7-bit
bitmaps, so the first-character disjointness proof read 'é' as {C} — and any
complement or shorthand set that merely excluded 'C' then looked disjoint from
it. Routing high bytes to `matchesNonAscii` closes the class in the set
representation rather than per-pattern, which is where it belonged. The two
altCase arms pin both shapes, and we agree the bounded-over-bounded residual
belongs in LIMITS as a documented limit rather than a silent catch.

We have synced locally to the merged head (bb2b25e6) and the screen and refusal
code are intact in it. A fresh local build is clean (exit 0) and the regex gate
battery is green here: regexbombcheck ALL PASS (including both new altCase
arms), plus regexguardcheck, regexrefusecheck, hazardpatterncheck and
manifestcheck. CI on the merged head agrees so far — 21 passed, 9 still running,
none failed as of this morning.

Standing by for your report on the nested-group bypass shapes — and thanks again
for doing the fix, the CHANGELOG credit and the main merge directly on the
branch. Happy to help with whatever else the re-check turns up.

---

## Verification block (not for posting — the evidence behind every claim)

- **Thread state:** latest comment is joyful's 2026-10-20 21:00 UTC (the one being
  answered); no report-back comment has landed since.
- **His work on our branch (all authored by joyful-ii-V-I):**
  - `dc495a787` — the non-ASCII fix: `RegexCharSet::add` now sets `matchesNonAscii`
    for `c >= 128` and records nothing in the ASCII bitmaps; two altCase arms added
    to `test/regexbombcheck.sh` pinning `(\W|é)+b$` and `([^C]|é)+b$` (his message:
    red on the unfixed head at 10 FAIL, green after at 128 PASS).
  - `aa2c829f2` — CHANGELOG credits @pt-act for the regex screen entry.
  - `bb2b25e6` — merge of origin/main into `pr397-maint` (2026-10-22), the step his
    comment promised once the re-check was clean. Our `3fb42b41` is an ancestor;
    `refuseAbandonedRegexScan` / `kRegexAbandonedReason` verified present in the
    merged head.
- **Local build:** `cmake -S . -B build && cmake --build build -j` on `bb2b25e6` →
  exit 0 (binary linked).
- **Local gates (scrubbed env, sequential):** regexbombcheck exit 0 (ALL PASS,
  136 PASS / 0 FAIL — the gate has grown past his 128), regexguardcheck exit 0
  (144/0), regexrefusecheck exit 0 (15/0), hazardpatterncheck exit 0 (38/0),
  manifestcheck exit 0.
- **CI on `bb2b25e6`:** 21 success, 9 pending, 0 failed (GitHub check-runs API,
  read 2026-10-23 ~10:50 UTC). Re-read before posting if time passes — the numbers
  move as shards finish; the claim in the draft is hedged with "as of this
  morning".

## Notes for the poster

- Post from **pt-act** (the account he addressed), not ra-co88 — his comment is
  directed at @pt-act.
- If CI has since failed on the merged head, drop the CI sentence rather than
  post a stale green claim.
