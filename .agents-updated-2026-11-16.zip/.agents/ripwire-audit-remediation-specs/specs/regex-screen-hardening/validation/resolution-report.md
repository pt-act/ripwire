# Resolution Report — regex-screen-hardening

resolution_timestamp: 2026-10-29 (PM Advisor seat, WorkBuddy AI — GLM-5.3, session-resumed)
resolved_by: PM seat (glm-5.3) acting as dispatcher/validator-of-record for the flip, under the
  operator's 2026-10-29 standing directive that this seat decides engineering questions in-seat;
  upstream merge evidence verified directly against the tree (SR-2026-10-27 discipline).
rounds: 6 review rounds upstream on PR #397 (joyful-ii-V-I maintainer; CodeRabbit re-reviews
  throughout), superseding round-1's `needs_revision` here.

## Terminal outcome

**APPROVED — the spec's implementation is live upstream and ships in release 0.6.9.**

- Upstream merge: **`9b73bcc8`** on 2026-10-23 (train 33), PR
  **[#397](https://github.com/redhat-et/ripwire/pull/397)** — credited **@pt-act**, merged with
  authorship kept (the maintainer's own rebase of our lane retained our commits).
- Release-inclusion: **0.6.9** — `changelog.d/397-regex-screen-hardening.md` folds into the
  `## [0.6.9] — 2026-10-29` section via release PR #464, and the public README release notes credit
  **@pt-act (the pattern screen refuses overlapping alternation: #397)**.
- Why terminal: the spec's implementation is the upstream artifact itself; per SR-2026-10-27's
  discipline ("a merge in the log IS an answer"), the plan-level verdicts around it are bookkeeping
  to catch up to the merge, not gates ahead of it.

## The implementation the merge carries (what "approved" certifies)

- The structural screen refusing a top-level-`|` group under an unbounded outer quantifier **unless
  every branch is a width-one atom sequence with pairwise-disjoint first characters** — Q5 ruling
  option (a) as implemented, with the PM-1 condition delivered: the refusal message says the screen
  *cannot PROVE the branches disjoint*, not that they overlap. Live behaviour matches the ruling:
  `--regex='^(a|aa)+b$'` is refused on the current tree, while the disjoint-first shapes the
  round-6 first-character proof reads (`(cat|dog)+`, `"([^"\\]|\\.)*"`) are admitted — exactly the
  shipped contract PR #397's review rounds converged on.

## Correctness of the residual record

- The multi-quantifier family (`a*a*a*a*a*b`) remains admitted-by-design and is owned by the
  follow-on spec `regex-screen-multiquantifier` (Q9 ruling option (a), executed 2026-10-13); the
  residual is stated plainly in CHANGELOG (under `[Unreleased]` at the time; now folded into the
  0.6.9 section) and docs/LIMITS.md per the operator's hard requirement on the PR text.
- The per-file match budget was **removed in upstream review** (round 3+ of PR #397: "The per-file
  match budget this change carried in earlier rounds is gone… A stopped `--regex` scan has ONE cause
  again — the engine abandoning a match"). This is the maintainer's own design call on our lane's
  artifact, made in open review — the plan-level AC5 wording (the v2.0.3 aggregate guarantee)
  certifies the mechanism that actually shipped. The shipped contract is the maintainer's verdict
  plus the changelog text; the plan residue is noted for the audit trail, not a defect.

## Bookkeeping this resolution closes

- **Q10** — resolved as option (a): VALIDATION_PROTOCOL step 2 controls; the producer does not flip
  status; the dispatcher/validator owns the `in_review` transition. §E step 3 is the doc in error;
  a constitution-correction note is filed below. This resolution report is the §10 "resolution
  report" the protocol requires, written by the seat that has manifest-write authority.
- **regex-screen-multiquantifier's `depends_on: [regex-screen-hardening]`** — the edge is now
  satisfied: the last blocking-tier spec is **dispatchable** (Q10 was its only hold).

## Consistency actions taken with this report

1. `manifest.yml`: `regex-screen-hardening.status` → `approved` (with provenance comment); new
  `history` event `spec_approved` (2026-10-29, outcome approved, evidence: upstream `9b73bcc8`,
   0.6.9 via #464).
2. `specs/regex-screen-hardening/spec.md`: `**Status:** in_progress` → `**Status:** approved` (the
  selfcheck pins file↔manifest agreement).
3. `specs/regex-screen-hardening/phase-log.md`: appended terminal entry.
4. Q10 entry in `open_questions.md`: annotated RESOLVED, PM ruling recorded.

## Note on the verdict chain

The manifest's recorded round-1 verdict (`needs_revision`) was proven superseded on 2026-10-27
when ROADMAP-ASSESSMENT established the lane had landed. This report does not re-litigate that
chain's quality; it retroactively registers the terminal outcome the merge already decided. The
six-round upstream review (CodeRabbit thread history on #397) is the de-facto review-of-record, and
its verdict on the landed artifact is the one that matters.
