# Completion Report — regex-screen-hardening — round 4 (the mixed-cause honest-counts fix)

## Header

spec_id: regex-screen-hardening
producer: WorkBuddy AI / Deepseek-V4.1-Flash
round: 4 (behaviour fix, relayed by the operator as the CodeRabbit-style review of the branch's refusal message)
started: 2026-10-14 (round-4 work; final verification + push 2026-10-14)
completed: 2026-10-14
spec_version: 2.0.3 (**UNCHANGED** — round 4 touches no spec text)
supersedes: nothing. `validation/completion-report-r3.md` still stands for every AC claim and every piece of evidence; round 4 is a behaviour fix on top of the pushed branch.

Round base: `77de7863` (round 3) on `lane/regex-screen-hardening`. Round 4 adds **`ef6586a2`**:

| commit | what |
|---|---|
| `ef6586a2` | **round 4** — `fix(regex): a mixed stopped scan names both causes, each with its own count` |

Pushed: `git ls-remote origin refs/heads/lane/regex-screen-hardening` = `ef6586a28a77fb99a15d806e6f53ee29f7d4bfc8`
(`77de7863..ef6586a2`), author AND committer `pt-act <psychoactive28@gmail.com>` (SR-2026-10-12-authorship-identity
applied in the scratch tree before the commit). Working tree clean. 6 files, +205/−81: `src/verbs_grep.h`,
`src/search.h`, `src/regexguard.h`, `test/regexbombcheck.sh`, `test/hazardpatterncheck.sh`, `CHANGELOG.md`.
**PR #397** (upstream `redhat-et/ripwire`, head = this branch) now carries the fix: its `headRefOid` is `ef6586a2`,
and its commit list is `91c5fb2e` → `77de7863` → `ef6586a2` — see honest note 3 (it also reads
`mergeable: CONFLICTING` after upstream's drift past `0e0f67c7`).

## What round 4 is

One `--regex` run can stop files for **TWO causes at once**: the engine abandoning a match (`Exhausted`) and
the guard's per-file match budget. The old `refuseAbandonedRegexScan` resolved **one** cause and summed **every**
stopped file into it (`found.regexAbandonedFiles + aux.regexAbandonedFiles`), so a mixed run told the reader that
N files hit the budget when only some did — and named no file for the rest. Each cause now reports its **own**
count, reason sentence, first file and advice, in a fixed order (budget first), and a single-cause run prints one
sentence byte-identical to before.

## The subset relation (load-bearing — do not re-derive)

A budget stop **arrives as** `RegexVerdict::Exhausted` (search.h's per-file loop sets `isAbandoned` and
`isBudgeted` together), so **`budgeted ⊆ abandoned`**. The engine's own count is therefore
`abandoned − budgeted`, never the total. `regexAbandonedFiles` (the aggregate) deliberately stays the **whole**
stopped set, because `degraded` reads `regexAbandonedFiles != 0` — redefining it would break the degrade path.

Counts and first-paths are **different projections** of the per-file bit vectors. `firstRegexAbandonedFile` is
the lowest file among ALL abandoned files (engine + budget), so it **cannot** name the engine sentence's file in
a mixed run. The lowest *engine-only* fileId did not exist and had to be **added**
(`firstRegexEngineOnlyFile` / `firstRegexEngineOnlyPath`).

**Disclosed: the relay's premise was wrong.** The brief called this "presentation, not plumbing" — "the data is
already collected". The counts were; the per-cause first-path projections were not. That is the plumbing the
brief did not anticipate, and it is the reason round 4 touches `src/search.h` beyond the message assembly.

## The first cut was WRONG — caught by the round's own arm, not by a reviewer

The first implementation used `firstRegexAbandonedFile` for the engine sentence. On the mixed corpus that
produced *"the regex engine abandoned the match … in 1 file(s), first budgetA.md"* — the engine **claiming a
budget file**, violating the binding "neither claims the other's files" constraint. Fixed by adding the
engine-only projection above. Recorded because the error was invisible in review and only the arm caught it.

## The fault-switch masking finding (why a THIRD switch was needed)

`RIPWIRE_FAULT_REGEX_MATCH` **masks** `RIPWIRE_FAULT_REGEX_BUDGET`: `throwIfMatchFaultInjected()` is the first
statement inside `forEachLineMatch`'s try (regexguard.h), **before** `regexScanLines` — so under MATCH=1 every
file is engine-abandoned and `budgeted` stays 0. **The two existing switches can never produce a mixed run**
(verified 3×, deterministic: MATCH=1 → 2 files/budgetA.md; BUDGET=1 → 1 file/many.md; BOTH → identical to MATCH
alone). There is also no portable real-engine abandon reachable (a screen-admitted flat optional chain scans
fine; overlapping alternations are screened).

Closed with the tree's own idiom: **`RIPWIRE_FAULT_REGEX_MATCH_MIXED`**, a per-subject sibling that throws only
for subjects ≥ `kRegexFaultMixedSubjectBytes = 64`. With the budget switch on, the LARGE file is
engine-abandoned while the small many-lined files are budget-stopped — both counters, one run. Three call sites
pass `subject.size()`; deliberately **not** `noexcept` (it throws by design). `hazardpatterncheck.sh`'s B2
registry reason now names both switches; the function still holds exactly **one** throw, as the judge requires.

## Quality-delta (Phase D) — the round's own gate

First measured run came back **RED** (`gating="2"`), both rows structural debt from this round's own change:

| row | was → now | cause | fix |
|---|---|---|---|
| `complexity src/search.h::rw::scanUnsupportedFiles` | 18 → 23 (+27.8% ≥ the 25% bar) | the nested per-file `if( !isBudgeted )` | folded the aux per-file decision into ONE `GrepAuxCollection::noteRegexScanOutcome` so the caller keeps no branch; the row dropped off the report entirely |
| `duplication countAbandonedFiles \| countEngineOnlyFiles` | 89 tokens | the new helper was a near-clone of the old pair | BOTH helpers replaced by one single-pass `countStoppedFiles` |

Final: `build/ripwire . --quality-delta=0e0f67c7..HEAD` → **`gating="0"`, exit 0** —
`regressions="10" minor="7" acked="0" stale="147" preexisting-worse="7" new-symbol="3" gating="0"`,
`base_ref=0e0f67c73ca332ed58bb8478677f916f7ccc1e84`, `target_ref=ef6586a28a77fb99a15d806e6f53ee29f7d4bfc8`.
Every survivor is `origin="new-symbol"` or `sev="minor"` (neither gates). Measured twice (standalone, then inside
the final verification run).

## Verification

- **Phase C — byte-identity, proven against a binary.** The pre-change binary (`/tmp/ripwire-r3`, tree at
  `77de7863` with the three round-4 headers reverted) was driven over 8 single-cause/normal paths (engine-only,
  budget-only, safe scan, hit-cap/paging, structural bomb refusal, literal scan, engine/budget on a plain
  corpus): **stdout, stderr and exit code all byte-identical**. Only the mixed path differs, and the diff is
  exactly the added engine sentence.
- **Phase B — the mixed arm.** `test/regexbombcheck.sh` section (7): a 3-file corpus (one ≥64-byte line; two
  10-line small files) under both switches asserts exit 1, no `hits=`, the budget sentence's own count (2) + path,
  the engine sentence's own count (1) + path, each sentence's own reason word (`kRegexBudgetReason` /
  `kRegexAbandonedReason`), the fixed order (budget first), and byte-determinism across two runs. **7 arms, all
  PASS.**
- **Mixed smoke, run by hand on the pushed binary** (exact gate corpus, logs outside the scan root): exit 1,
  empty stdout, two sentences — budget first (`in 2 file(s), first budgetA.md` + budget reason + budget advice),
  then engine (`in 1 file(s), first engine.md` + engine reason + engine advice).
- **Gates (scrubbed env, `env -i … SDKROOT=…`):** `regexbombcheck.sh` **ALL PASS — 108 PASS / 0 FAIL** (solo
  re-run); `regexguardcheck.sh` ALL PASS; `regexrefusecheck.sh` ALL PASS; `hazardpatterncheck.sh` ALL PASS.
- **Golden 2:** `astqueryregexcheck.sh` **ALL PASS, exit 0** — byte-identical to `test/astqueryregex_golden.txt`.
- **Golden 1 (the `regression.sh` golden): RED, and PROVEN PRE-EXISTING.** `build/ripwire test/fixture
  --no-cache` does not match the committed `test/golden.xml` — but the **pre-change binary produces byte-identical
  output to the round-4 binary on that corpus**, so round 4 moves nothing there. The drift is the committed
  golden's own staleness: it was last touched **2026-10-04 (train 25, `25873dd9`)**, before upstream's map
  format moved to `schema=ripwire.map/v1` (the symbol rows are identical; the header legend and `est_tokens`
  905 → 736 moved with that upstream change). Same class as the standing pre-existing `readmedriftcheck` (G4)
  red. Recorded as a deviation, NOT fixed: refreshing the golden is a separate, deliberate act
  (`UPDATE_GOLDEN=1`) and the full battery belongs to CI (below).

## Honest notes (known deviations, disclosed — not excused)

1. **The full `regression.sh` battery did not complete here — environment, again (Q6 follow-up).** The gate runs
   ~640 nested gates; the run was stopped at roughly gate 120/640 when the volume hit **100% (609 MiB free)** —
   the documented hazard (the suite filled the volume twice before, once as an explicit `OSError [Errno 28]`).
   The killed run's temp was reclaimed and the golden evidence was taken by running the gate's **own section-4
   command** directly (byte comparison above). The 683-gate suite remains a CI-only artifact, as recorded in
   round 1 and round 3. Disk at report time: **621 MiB free** after the reclaim.
2. **One earlier gate run showed a load-artefact false RED, now cleared.** Under 8 concurrent background tasks
   (load average 425 → 794) `regexbombcheck.sh` reported `FAIL (a+)(b)+ (siblings): TIMEOUT/KILLED after 20s`.
   Measured: that arm uses 7.9 s user CPU but took 29.7 s wall at 28% CPU share — a wall-clock-cap artefact, not
   a verdict. The **solo re-run passes it** (`not over-refused: (a+)(b)+ (siblings) still scans at exit 0`), and
   the whole gate is 108/0.
3. **CORRECTED 2026-10-14 (after the PM flagged it): the relay named "PR #397" and it DOES exist — the producer's first report of non-existence was an error.** PR #397 lives on the **upstream** repo `redhat-et/ripwire` as a cross-repo PR — head `pt-act/ripwire:lane/regex-screen-hardening`, base `redhat-et/ripwire:main`, https://github.com/redhat-et/ripwire/pull/397 (OPEN, not draft). The producer's `gh pr view 397 --repo pt-act/ripwire` checked the **fork**, which holds only the merged intra-fork PRs #1–#5, and wrongly concluded the PR did not exist. **The worktree was never mis-remoted:** `git remote -v` in `/Users/rna/ripwire-scratch/rsh-r1` shows `origin` = pt-act/ripwire (the push landed there — which IS the PR's head repo) and `upstream` = redhat-et/ripwire. **PR #397's tip is now `ef6586a2`** (`gh pr view 397 --repo redhat-et/ripwire --json headRefOid` == the pushed sha), its commit list is exactly the lane's three commits (`91c5fb2e`, `77de7863`, `ef6586a2`), and CodeRabbit's finding is answered in that history. **New fact for the dispatcher:** the PR now reads `mergeable: CONFLICTING` — base main has advanced to `d4325a8cca79…`, past our `0e0f67c7` anchor, so the merge path needs a rebase. That is upstream drift, not a round-4 defect; no rebase was performed (round 4 is closed).
4. **The commit sha changed from the one the operator named.** The relay said push `d3cfcedf`; the commit was
   **amended to `ef6586a2`** to fold the two quality-delta fixes (the `noteRegexScanOutcome` restructure and the
   `countStoppedFiles` merge) into the same commit. Same content, new sha. Flagged here and to the operator.
5. `spec_version` stays **2.0.3** and no spec file was touched (the brief's "no spec-text change"). A CHANGELOG
   paragraph was added under `## [Unreleased]` because the wording materially changed (a mixed run now prints
   two sentences); the single-cause sentence is byte-identical to before.
6. Two authoring hazards hit during the round and were fixed before commit: a `noexcept` mistakenly added to the
   throwing fault function (broke the build with `-Wexceptions`; removed), and the first cut's wrong
   first-path projection (above). Both were caught by the round's own gates, not by inspection.
7. Round 4 changes **no admission decision and no single-cause message**: the newly refused / newly abandoned
   surface is empty — the only behavioural delta is the mixed-run stderr.

## Resumption point

- **The branch is pushed at `ef6586a2` and the completion signal is this report.** Per
  `VALIDATION_PROTOCOL.md` step 2 the producer does **not** flip `in_review` and does **not** write the
  manifest; the spec stays `in_progress` (the §E-vs-step-2 conflict is still open as Q10). The **PM validates
  from the push**.
- Next after validation: **`git-porcelain-framing` phase 2** — the shared `gitLogRecords()` helper plus the
  five-consumer migration in `/Users/rna/ripwire-scratch/gpf-r1`, a separate scratch tree and lane. Round 4
  deliberately kept the two lanes separate (the round-4 commit is on `lane/regex-screen-hardening` only).
