# Phase 0 return — audit-validation-standalone: RETURN TO THE DISPATCHER on measured grounds

**Date:** 2026-11-10T20:15Z. **Producer:** the local seat. **Base:** `b8032471f` (pinned at dispatch).
**Trigger:** dispatch-note.md §5, the halt condition — *"If Phase 0 finds the repair unworkable on
measured grounds … RETURN TO THE DISPATCHER with the measurement — the node reverts to `planned`;
the lane does NOT limp."*

This is not a request for scope narrowing and not a schedule complaint. The repair as dispatched
rests on a premise that **measurement disproves**: the one bundle the mandate calls REAL does not
reproduce against the tree we are pinned to, and the divergence is not noise — it is a dated,
bisected disagreement between the committed artifact and the committed harness.

---

## 1. What I verified before concluding anything (the dispatch baseline)

Re-measured independently, because the dispatch note is a relay and the tree is the canon:

| consume | dispatch note | measured | verdict |
|---|---|---|---|
| `regex-screen-hardening/evidence/` | REAL, 22 entries | **22 entries**, harness + seeds + logs present | **confirmed** |
| `git-porcelain-framing/evidence/` | `layout-pin.md` only | **1 entry**, `layout-pin.md` | **confirmed** |
| `edit-workspace-pin/` | spec.md only, retired | **1 entry**, `spec.md` | **confirmed** |
| `atomic-write-tempfile/` | spec.md only, retired | **1 entry**, `spec.md` | **confirmed** |
| SRI report rows | "8, not the drafted five" | **8** repelled rows (A1×2, A2×2, A3×1, A4×1, A5×2) | **confirmed** |

The structural premise — one real PBT bundle, three other evidence classes — **holds**. That part of
the mandate is sound and I am not disputing it.

## 2. Three citation defects in the dispatch note itself

Found while pinning the live-contract class, all correctable, none fatal on its own:

**(a) `mcp.h:319-370` is not the assumedRoot tier contract.** At the pinned base those lines are
`batch` verb-list code (`mcpGitOnlyNotBatchServed`, `mcpBatchExcludedCount`,
`mcpBatchServedVerbsList`). The real contract is:
- the transport-policy tier comment begins at **`mcp.h:508`**
- `pinnedRoot` field **`:551`**, `assumedRoot` field **`:554`**, `noRootReason` **`:555`**
- `mcpResolveAssumedRoot` **`:591`**

**(b) `createExclTempFile` is cited at commit `7884ac4`, which does not exist.** Not in the pinned
base, not in any upstream ref, not fetchable. The commit that introduced the exclusive temp helper is
**`78825ac49`** (2026-09-16, *"harden(atomic-writes): create publish temp files exclusively, without
following links"*), **confirmed an ancestor of `b8032471f`**. The definition itself is
**`src/pathguard.h:507`**. This looks like a one-character-short SHA (`7884ac4` vs `78825ac49`) that
propagated unchecked — and it would have failed the live-contract arm as written.

**(c) The dispatch note's own "byte-identical at base" claim for `mcp.h` is right, but for the wrong
reason in my first read** — see §4, where I record my own error.

## 3. THE MEASURED BLOCKER — the real bundle does not reproduce at the pinned base

The mandate's core moving part is: *"seeded re-execution ≥10% of committed cases from committed
seeds via the bundle's own `pbt-run.sh`"*, applied to the one real bundle. I ran exactly that.

**First, the harness compiles against the pinned base.** The narrow-TU device works as documented:

    clang++ -std=c++23 -O2 -I <base>/src -o pbt pbt-regex-screen.cpp      → rc=0, 6.4 s, 150,744 B

**Then it fails, on the bundle's own fixed bomb corpus:**

    $ pbt --cases=2000 --seed=20261012
    FAIL  P2 bomb NOT refused: ^(ab|cd)+e$
    P2 bomb->refused:      16/17
    FAIL  P4 refusal does not name the construct: ^(ab|cd)+e$
    P4 refusal names the construct: 16/17
    cases=2000 seed=20261012 result=fail

The committed log records **`P2 bomb->refused: 17/17` … `result=pass`**. Same harness, same seed,
same corpus — opposite verdict.

### It is not my invocation, and not the tree

- The log's own provenance header names its tree: `# tree: /Users/rna/ripwire-scratch/rsh-r1`.
- I compiled the **same** PBT source against `rsh-r1` and got **the same `16/17, result=fail`**.
- `rsh-r1`'s `src/regexguard.h` is **byte-identical to the pinned base**
  (`707950a5d8792d06d7ca07fe8052b7c936f17eb6` both sides).

So: the artifact says pass, the tree it names says fail, and the header it points at is unchanged
between them. The log is not reproducible on the tree it cites.

### Root cause — bisected, and it is a dated supersession

`^(ab|cd)+e$` is admitted by the current screen **by design**. Base's own contract comment
(`mcp`-independent, `regexguard.h:177-199`) says the second arm refuses an unbounded alternation
*"UNLESS it can prove the branches disjoint"*, and the M2-e widening proves disjointness by **first
character**. `ab` and `cd` differ in first character → provably disjoint → **admitted, correctly**.
The rule even names the admitted set explicitly: `(cat|dog)+`, `(foo|bar)+`, `([^"\]|\\.)*`.

Direct probe at the pinned base (`^(ab|cd)+e$` = **admitted**; the other six alternation/重复 bombs
all **REFUSED** with the construct named):

    ^(ab|cd)+e$            admitted
    ^(a|aa)+b$             REFUSED: …cannot PROVE are disjoint…
    (a|a)+b                REFUSED
    (x|xy)+c$              REFUSED
    (\w|\d)+$              REFUSED
    (a|a*)+                REFUSED
    ((a|aa)+)+             REFUSED
    (cat|dog)+             admitted
    (a|b)+                 admitted

Bisection across the commit that landed the widening (`3fb42b417`, 2026-10-15):

| tree | `^(ab|cd)+e$` |
|---|---|
| `3fb42b417^` (parent) | **REFUSED** |
| `3fb42b417` and everything after, incl. base | **admitted** |

And the artifact dates:

| file | mtime |
|---|---|
| `pbt-regex-screen.log` | **2026-10-13** 20:34 |
| `pbt-regex-screen.cpp` | 2026-10-13 20:32 |
| `seeds.txt` | 2026-10-12 12:28 |

**The log was produced two days before the rule that invalidated its own bomb corpus.** Its `17/17`
is a true record of a screen that no longer exists. This is not fabrication — it is a stale
artifact whose `kBomb[]` still lists a shape the implementation deliberately stopped refusing.

### Why the repair cannot simply patch around it

The mandate's tension, stated precisely:

- The arm asserts `P2 bomb ⇒ refused` over a **committed fixed corpus** (`kBomb[17]`).
- One corpus member (`^(ab|cd)+e$`) is **correctly admitted** by the shipped design.
- So **either** the corpus is wrong (it is — it encodes a pre-M2-e expectation) **or** the
  implementation is wrong (it is not — admitting provably-disjoint branches is the documented,
  gate-pinned intent, and `regexbombcheck`/`regexguardcheck` both pass at base).

Fixing this means **editing the evidence bundle of an APPROVED spec** (`regex-screen-hardening`,
validator-approved 2026-10-31, "the validator re-ran P1–P5 live"). That is not a Phase-0 interface
re-pin. It reopens an approved node's evidence, and it is exactly the class of decision the halt
condition exists to route to the dispatcher rather than take unilaterally inside a validation lane.

**Additional, independent reason the seeded arm cannot run as specified:** `pbt-run.sh` writes
`LOG="$HERE/pbt-regex-screen.log"` — re-executing it **overwrites the committed evidence it is
verifying**. A validation harness that destroys its own input on first run is not runnable as
specified; the arm needs a redirected-log contract before it can be called "re-execution".

## 4. My own error, recorded

My first pass reported "`regexguard.h` has moved **809 diff lines** from where the bundle was built →
seeded re-execution is not a reproduction". That number is real but I drew the wrong conclusion from
it: the 809 lines are `0e0f67c7` (the **pre-patch** tree the round patch applies to) vs base. The
bundle was actually measured at `rsh-r1`, whose header is **byte-identical to base**. I corrected it
by hashing rather than by re-reading my own reasoning — the same discipline that caught the PM's
three prose defects. The corrected finding is *stronger*, not weaker: identity of header proves the
divergence is not drift, it is a stale corpus.

## 5. What IS ready, and unblocked

So that the node is not idle while this returns, the Phase-0 products that do not depend on the
disputed arm:

- **Inventory arm** — the 5-row measured table in §1 is the pinned inventory; classes are correctly
  separated. Runnable today.
- **Live-contract class** — both probes are pinnable at the corrected citations in §2: assumedRoot
  tiers (`mcp.h:508-560`, `mcpResolveAssumedRoot:591`) and `createExclTempFile`
  (`pathguard.h:507`, introduced `78825ac49`, ancestor-verified). Both are behavioural and stand on
  their own against the base binary — no bundle needed, no approved spec reopened.
- **Regression-report restatement** — 8 rows, schema `attack_id, transport, expected_shape,
  observed, wall, verdict`, restatable shape-exactly from `report.txt`.

What is **not** ready: the PBT seeded re-execution arm, which is the mandate's centrepiece.

## 6. The question this return puts to the dispatcher

Not a menu — a required ruling, with my recommendation attached per the standing directive.

**Ruling needed:** the `regex-screen-hardening` evidence bundle's `kBomb[]` contains a member the
shipped implementation correctly admits, and its log predates the rule change (2026-10-13 vs
2026-10-15). Two coherent resolutions:

- **(A) Recommended — re-baseline the bundle's PBT as a dated supersession.** Correct `kBomb[]` to
  what the shipped rule asserts (drop `^(ab|cd)+e$` from the bomb corpus, add it to the admitted
  corpus where it belongs, or replace it with a genuine M2-e-shaped bomb such as
  `(get|getResponse)+` which the rule names as still-refused), regenerate the log at the pinned base
  with a **redirected log path**, and commit both under a superseded-notice. The bundle then
  substantiates the *shipped* screen rather than a two-day-old ancestor of it. This is a producer
  fix on an APPROVED node — hence the dispatcher's call, not mine.
- **(B) Do not ship the seeded arm at all; state the limitation.** The verdict rule then reads
  `do-not-ship` for the PBT class with the reason named, and the report ships as a partial verdict.
  Cheaper, honest, but it under-delivers the node's whole purpose ("is the evidence real?") for the
  one bundle that is real.

I recommend **(A)**, with the corpus edit scoped to the minimum that makes the arm assert the
shipped design, the regenerated log committed beside the old one (superseded, retained), and the
report header recording that the bundle was re-baselined at Phase 0 under this return.

**Second ruling needed (small):** the `pbt-run.sh` log-overwrite contract. Recommended: the harness
invokes the runner with an explicit output path under `run/`, never `$HERE`, so committed evidence is
read-only to the validator. This is a one-line change to the *caller*, not to the approved bundle.

## 7. Lane state

Lane branch `lane/audit-validation-standalone` at `b8032471f`. **No commits made** — a Phase-0 return
with a measurement does not ship code, and I did not build a harness around a premise I had just
disproved. Scratch worktree `~/ripwire-scratch/avs-p0/tree` (detached at base) is disposable.

Everything in this document is reproducible from `b8032471f` with the two compile lines and the probe
source quoted above; no claim here rests on a report I read rather than a command I ran.
