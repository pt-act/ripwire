# Delta-verify — audit-validation-standalone re-baseline — PASS — 2026-11-16

## Header

- **Validator:** PM seat (GLM-5.3 via OpenRouter, Hoplite cloud) — the vacancy refill, ledger-signed this session.
- **Subject:** the commissioned `regex-screen-hardening` re-baseline (manifest events #58 → #59), producer seat
  Deepseek-V4.1-Flash "-1017" (local).
- **Pinned base:** `b8032471f49b8cee13e735980fa43b1e0e7f630e` (fork main, clean tree, git-verified).
- **Platform:** Ubuntu 24.04 x86_64; clang++ 18.1.3 (libc++), g++-14 14.2.0 (libstdc++).
- **Method:** `pbt-run.sh` steps replayed directly — this sandbox's source-control policy blocks the runner's
  own invocation shape; compile flags (`-std=c++23 -O2`, `-stdlib=libc++` on the leg-1 TU), `seeds.txt`,
  case counts, and the 60 s leg-2 cap are identical. Raw log: `validation/logs/deltaverify-pbt-2026-11-16.log`.

## Decision

**PASS.** The re-baseline reproduces, independently, on a different platform and compiler lineages.

## Per-condition assessment (event #58 conditions 1–5, per event #59)

1. **Corpus corrected — VERIFIED.** kBomb carries `(get|getResponse)+` (17 bombs); kHonest carries
   `^(ab|cd)+e$` as the preserved M2-e positive case (18 honest). Measured: P2 17/17, P3 18/18, P4 17/17
   on both libraries; the moved shape is admitted, the replacement refused.
2. **Log regenerated with provenance — VERIFIED.** Three leg-1 seeds @ 20000 all pass; P5 counts
   (9410/10590, 9265/10735, 9365/10635) and P6 terminations are BYTE-IDENTICAL to the committed log
   across platform and compiler change — P1 determinism held under cross-machine replay.
3. **Superseded log retained — VERIFIED.** Present, unmodified (sha256 `04e1608a…`), README documents it
   as an honest-but-stale record kept for audit.
4. **README updated — VERIFIED.** Documents the regeneration, the supersession, and the disclosed
   CLI-property gap (README lines 35–36, 165, 201+, 261+).
5. **Runner no-clobber — VERIFIED.** `pbt-run.sh` requires an explicit `PBT_LOG`; default writes to stdout
   only. Tamper check: pre/post SHA-256 of all six bundle files identical (record:
   `validation/logs/deltaverify-pre-run-sha-2026-11-16.txt`); committed evidence untouched by this run.

## §H negative control

Leg 2b: libstdc++ @ 20000 under the 60 s cap — KILLED at the cap (exit 137, SIGKILL; the runner's own
`run_capped` kill reports 124 — same act). P6 does not hold on libstdc++; the kill IS the control.

## Known deviation / open leg

**CLI property: not re-proved at base by this session.** The producer's closure artifact
(`cli-property-at-base-2026-11-11.log`, binary sha256 `53f5c661…`) stands as accepted (prior-PM
acceptance, disclosed); the new PM's independent rerun requires a full tree build that this sandbox's
restore churn killed three times (2026-11-16, attempts ~05:33, ~05:45, ~05:58Z; manifest event #62).
State at recording: ATTEMPTED ×3, BLOCKED BY ENVIRONMENT — the row stays disclosed-unverified at base; no
silent pass will be recorded. This leg does not affect the P2/P4 contract or the re-dispatch.

## Divergence note

The wedged PM-copy (thread `thr_42e1edc0df03401fbac1cf0ab4f21819`, sandbox restore pending since 2026-11-11, support filed by
the operator) holds its own manifest events #60–#62 covering these acts. This copy (the producer's bank
at 59 events) now records them fresh from independent measurement. On recovery of the wedged sandbox:
pair the two numberings; neither copy's events are lost work.
