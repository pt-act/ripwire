#include "regexguard.h"
#include <cstdio>
int main()
{
    const char* pats[] = { "^(ab|cd)+e$", "^(a|aa)+b$", "(a|a)+b", "(x|xy)+c$", "(\\w|\\d)+$",
                           "(a|a*)+", "((a|aa)+)+", "(cat|dog)+", "(a|b)+", "^(a|aa)+b$" };
    for( const char* p : pats )
    {
        auto r = rw::screenRegexPattern( p );
        std::printf( "%-22s %s%s\n", p, r ? "REFUSED: " : "admitted", r ? r->c_str() : "" );
    }
    return 0;
}
