# Dispatch note — audit-validation-standalone (the program-terminal ship verdict)

**Dispatched:** 2026-11-10T19:50:00Z by the PM seat (dispatcher-of-record) on the rotation ruled at
the WKC phase-3 verdict §11 and banked at manifest event #55 (rank-1; no new operator round-trip
owed — the rotation was bought with the ruling). **Producer:** the local seat
(Deepseek-V4.1-Flash "-1017"). **Base:** `b8032471f` pinned fresh this act — fork main synced
`fc0e35967 → b8032471f` (ff-verified), pushed; lane branch `lane/audit-validation-standalone`
pushed at `b8032471f`, remote-verified both. Manifest event #56.

> **ERRATUM (2026-11-10T20:30Z, dispatcher — corrected in place, provenance recorded):** the
> original issue of this note carried two defective citations, both caught by the producer's
> Phase-0 measurement (event #57) and verified by the PM (event #58): (i) the assumedRoot tier
> contract was cited as `mcp.h:319-370` — a stale September-era line range propagated unverified
> from the retired-node manifest comment (those lines are batch verb-list code at the current
> base); the tier contract sits at **`mcp.h:508-560`** (comment block + `McpDispatchPolicy`
> fields: `pinnedRoot:551`, `assumedRoot:554`; `mcpResolveAssumedRoot:591`). (ii) createExclTempFile
> was cited as upstream commit `7884ac4` — **a transcription garble that resolves in no ref**;
> the manifest's own cite (`78825ac4`) is a valid abbreviation of the introducing commit
> **`78825ac49`** (ancestor-verified of `b8032471f`; the function is defined at
> `src/pathguard.h:507`). Lesson banked: dispatcher prose gets the same instrument discipline as
> any other claim — a SHA must resolve and a line range must exist before it ships. The
> Phase-0 halt return and the dispatcher's ruling are recorded at manifest events #57 and #58;
> this note's §2 classes stand, with the PBT-class premise now carrying the measured
> stale-corpus finding (see §1a below).

---

## 1. THE OWED PREMISE REPAIR — Phase 0 opens here, and the baseline is measured, not assumed

This spec was drafted 2026-09-14 by the spec-architect and never executed. Since then the DAG
changed under it: two of its four consumed specs retired (never executed as our units), one
consumed bundle turned out never to be a PBT bundle, and the regression report grew rows. The
dispatcher baselined every input THIS ACT, by instrument (ls + reads, 2026-11-10). **Phase 0's
first work is to re-pin Interfaces/ACs/the verdict rule onto this measured reality.** The
baseline, itemized:

### The four drafted `pbtEvidenceBundle` consumes — what each ACTUALLY is

| consume | on disk | class |
|---|---|---|
| `regex-screen-hardening/evidence/` | **REAL bundle** — 22 entries: `pbt-regex-screen.{cpp,log}`, `pbt-run.sh`, `seeds.txt`, `p6-negative-control.{cpp,sh,log}`, `screen-probe.cpp`, `screen-scan.cpp`, gate baseline/final logs, `corpus-sweep.txt`, `determinism-ritual.txt`, `manifestcheck.txt`, `README.md`, `diffverdicts.py`, `harvest.py` | the ONLY consume satisfying the drafted shape (property source, seeds, case counts, result logs). **The ≥10% seeded re-execution arm applies HERE and only here.** |
| `git-porcelain-framing/evidence/` | `layout-pin.md` ONLY (6.3KB) — no harness, no seeds, no property logs | **NOT a PBT bundle.** The spec's approval rode both-platform CI (upstream-merged via PR #469, `d044662a`, our 19 commits + the maintainer's review fixes) + the resolution report. Evidence CLASS: upstream-merged CI + review. |
| `edit-workspace-pin/` | `spec.md` only — NO evidence dir | **retired:never-executed** (landed upstream 2026-09-24; status DO-NOT-EXECUTE pinned by `_selfcheck.py`). Contract pins FROM THE LIVE UPSTREAM IMPLEMENTATION: the assumedRoot pin tiers at `mcp.h:508-560` (`pinnedRoot:551`, `assumedRoot:554`, `mcpResolveAssumedRoot:591`) — mcp.h **byte-identical at the pinned base** (measured 2026-11-10: `fc0e35967..b8032471f` diff on mcp.h is EMPTY). |
| `atomic-write-tempfile/` | `spec.md` only — NO evidence dir | **retired:never-executed** (createExclTempFile, upstream commit `78825ac49`, ancestor-verified of the pinned base, defined at `src/pathguard.h:507`). Same live-contract pin. |

### The other consumed inputs

- **auditRegressionReport** (`security-regression-integration/report/report.txt`): EXISTS —
  **8 repelled rows, not the drafted "five"** (the drafted count is stale; the SRI approval
  record pins "schema stable for audit-validation-standalone" — the ROW SCHEMA is the interface;
  the harness reads rows from the artifact and never from a count in prose).
- **The drafted verdict rule's "all four blocking-gate units carry validator approval"**: the DAG
  state today is regex-screen-hardening APPROVED (validated 2026-10-31, the validator re-ran
  P1–P5 live), git-porcelain-framing APPROVED (upstream-merged #469), edit-workspace-pin +
  atomic-write-tempfile retired-live-contract ("validator approval" is undefined for
  never-executed units — the two-tier retired:SATISFIED recording governs, per
  AD-2026-11-04-retired-spec-flag). The re-based verdict rule must speak in the evidence classes
  that exist, not in the 2026-09-14 unit map.

## 2. The repair mandate (what Phase 0 re-pins)

Rebuild **Consumes / ACs / the verdict rule** into evidence classes that exist:

1. **PBT class (real bundle)** — inventory + seeded re-execution ≥10% of committed cases from
   committed seeds via the bundle's own `pbt-run.sh` (its README documents `--seed`/`--cases`).
   The negative property requirement stays (p6-negative-control is the bundle's own negative
   arm). The drafted case-budget sentence ("≥10k/5k/2k/20k") DIES with the dead bundles — the
   regex bundle's committed case count is the bound.
2. **Upstream-merged CI class (git-porcelain-framing)** — the recorded evidence is the merge +
   the green matrix + the resolution report. The harness verifies the RECORD (merge commit
   present at the pinned base's ancestry, resolution report committed at its path), and states
   the class honestly in the inventory. No seeded re-execution is possible or claimed.
3. **Live-contract class (the two retired specs)** — verify the LIVE implementations at the
   pinned base by the harness's own behavioral probes against the base binary (the
   "contracts pin from the live upstream implementations" ruling): assumedRoot pin tiers
   (`mcp.h:508-560`, byte-identical at base) and createExclTempFile (`78825ac49`,
   `src/pathguard.h:507`). Phase 0 designs
   the probes and pins their expected refusals/behaviors from the live code, citing base
   numbering. (Do NOT borrow our unpushed lanes' gates for this — the pinned base is the upstream
   tree; probes stand on their own.)
4. **Regression-report restatement class** — rows restated from `report.txt` by shape-exact
   match, schema-pinned, count read from the artifact.

The verdict rule maps over these classes: `ship` iff every class verifies mechanically; else
`do-not-ship` naming the failure. The tamper arms (deleted input, edited log, hand-edited row)
SURVIVE and grow MORE load-bearing — they are how this harness proves it detects fabrication,
which matters more with half the drafted inputs gone.

## 3. Hard constraints

- **The harness FAILS missing inputs, never synthesizes them.** No bundle fabrication for the
  retired specs to make an inventory arm pass. A missing input = a failed row = a named
  `do-not-ship` reason, never a quietly narrowing scope.
- Every number in the report traces to a raw log committed beside it (the spec's own invariant).
- **The §11 doctrine applies to the report itself**: prose takes its canon from measured
  artifacts — every claim in the report cites the inventory it measured. (This lane's neighbors
  produced three §11 sightings; do not add a fourth.)
- House G3: POSIX shell + the repo's own binary; no new deps.
- `ok()` canonical from commit one (the tree's gateexitcheck contract); if the harness ships
  anything in-tree, GEN-DOCS-MERGE same-commit registration + the sweep-audit of new files
  against the absorb list before any push. (Dispatcher's recommendation: keep the harness at the
  drafted `specs/audit-validation-standalone/run/` location — this node's products are internal,
  deployment-facing leaf; no upstream surface arises for it.)
- **Host rules**: any binary build for the pinned base runs serialized on this host or in the
  operator's 16GB VM; `built_from=` stamps are the instrument; `/usr/bin/g++` is a clang stub —
  a gcc claim requires `/usr/local/bin/g++-14`.
- Counts instrument discipline as banked: three counts never conflated; `| head`/`| tail` steal
  `$?`.

## 4. Distinctness — ruled for this node

The spec's Implementation Note requires the executor not be the producer of the specs it
validates, and validators stay unassigned in the manifest. **Ruled:** the local seat executes
AVS. The four Tier-2 inputs were produced by a different, earlier seat (pre-2026-11-04
rotation) — those classes carry no self-restatement. The ONE overlap is SRI (the local seat
produced it): the report's restatement of `report.txt` is **disclosed self-restatement, made
safe by** (a) shape-exact restatement from the committed immutable artifact, (b) the tamper
fixture proving the arm detects edits, (c) the report header's who-produced-what record (the
spec's own requirement), and (d) the PM seat — a different interpreter — remaining the phase-3
validator of the harness AND the verdict. Record all four in the report header contract at
Phase 0.

## 5. Halt condition

If Phase 0 finds the repair unworkable on measured grounds (e.g., no defensible live-contract
probe for a retired spec), RETURN TO THE DISPATCHER with the measurement — the node reverts to
`planned`; the lane does NOT limp. A ship verdict built on a broken premise is worse than no
verdict.

## 6. What the verdict must answer (the Objective, unchanged)

"Did the audit fixes actually land, and is the evidence real?" — mechanically, over the measured
classes, with seeds and raw logs beside every number, and an explicit scope-and-limits paragraph.
The report states what was checked, over what domains, with what seeds — no absolute-security
claim.
