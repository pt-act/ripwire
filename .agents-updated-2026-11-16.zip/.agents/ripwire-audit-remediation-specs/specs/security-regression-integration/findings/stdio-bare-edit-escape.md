# Finding SRI-F1 — the bare-stdio edit escape (silent write-anywhere on the assumedRoot tier)

**Filed:** 2026-11-06, by the PM seat (dispatcher-of-record, Phase-0 fold) from the producer's
C1 disclosure — independently reproduced by both seats before filing.
**Lane disposition:** OUT of `security-regression-integration`'s scope (test-only lane, zero
`src/` files — the dispatcher's constraint). **Proposed spec:** `stdio-bare-edit-escape`
(type: unit), to enter the DAG on the operator's word (Q9 precedent: producer discloses,
operator rules the node).
**Severity:** High-confidence product finding against audit attack A2's intent — the
shipped edit pin covers every launch tier EXCEPT the most common one.

## The finding

A bare `ripwire --mcp` (no startup root) runs on the **assumedRoot** tier — `mcpStdioPolicy`
sets `assumedRoot` from the launch cwd (`src/mcp.h:3074–3078`, the R2a "softest default"
block) and leaves `defaultRoot` empty. The stdio edit pin at `src/mcp.h:1941–1947` is gated
on `!policy.defaultRoot.empty()` — so on the bare launch it **never fires**, and an edit verb
(`replace_symbol_body`, the other E3 verbs) whose `path` names any directory outside the
launch cwd is **silently applied**:

- the response envelope is `['jsonrpc','id','result']` — no refusal, no disclosure;
- the result **echoes** `"root":"../B"` as though editing a neighbouring tree were routine
  (an honest-output question in its own right — every truncation and degrade in this codebase
  is disclosed, but an out-of-workspace edit is not);
- the victim file's bytes change.

The code comment at `src/mcp.h:1941–1943` documents the tier split as **intentional**:
read verbs stay unrestricted "matching stdio's existing 'a request may name any path'
contract", and the pin applies only when a startup root was explicitly given. So the
shipped contract and audit-AC-2's premise are opposites — which is exactly why this is a
finding to spec, not a lane arm: the integration harness verifies shipped behavior, and the
shipped behavior here is the escape.

**Why it matters in severity terms:** the bare launch is the *default* shape for agent hosts
(a host that runs `ripwire --mcp` in the workspace dir, no positional root). The tiers that
DO pin (startup-root stdio, both HTTP forms) are the ones a host must explicitly configure
into. A malicious or imprecise agent on the default tier can rewrite any file the process can
write, outside the workspace, with the server's answer dressing it as routine.

## Reproductions (two seats, two clean fixtures)

| seat | launch | form | outcome |
|---|---|---|---|
| producer (2026-11-06, self-built `built_from=50bc05e84`, 15m12s) | `ripwire --mcp`, cwd=A | `replace_symbol_body {path:"../B", file:"victim.c"}` | **applied**, victim sha `2f54c03f…→69342e8f…` (return 999), then clean-restore rerun `→770e0ca2…` (return 666); logs `sri-a2/attack-bare.jsonl`, `sri-a2/escape-full.jsonl` |
| PM (2026-11-06, same binary, own fixture, own sha pair) | `ripwire --mcp`, cwd=C | `replace_symbol_body {path:"../V", file:"victim.c"}` | **applied**, victim sha `dfa60fd3…→9566cdc4…` (return 1 → return 4242); envelope all-`result`, frame 2 = the edit, frame 3 = healthy `tools/list` — server not even degraded |

**The launch forms that refuse correctly** (both seats measured; PM reproduced both):
- `ripwire <root> --mcp` (startup root) → `-32602 "path outside workspace; start the server
  on that root or pass an absolute in-root path"`, victim unchanged (`src/mcp.h:1950`).
- HTTP `--listen` (with or without `--allow-remote-edits`) → `-32602 "path is outside this
  server's workspace (this listener serves one fixed workspace, pinned at startup) — …"`,
  victim unchanged (`src/mcp.h:1921`).

## Cause (code sites, per both seats' reads — identical)

- `src/mcp.h:1941–1943` — the tier-split comment ("a request may name any path"), the D4
  framing (the incident was an edit verb splicing a file into the wrong repo).
- `src/mcp.h:1944` — `if( !pathsUsageError && policy.pinnedRoot.empty() && !policy.defaultRoot.empty() )`
  — the gate that the assumedRoot tier never enters (`defaultRoot` empty on the bare launch).
- `src/mcp.h:3074–3078` — `mcpStdioPolicy`: `defaultRoot` only from `config.roots`/`config.root`;
  bare launch → `assumedRoot` = the resolved cwd (R2a, the 2026-08-12 usage mine, "/" and
  $HOME excluded).

## Proposed fix shapes (for the spec to pin; upstream's call between them)

1. **Parity (the strong fix):** the bare-stdio tier extends the same edit-verb pin to
   `assumedRoot` — `isMcpEditVerb( name ) && !mcpPathInsideRoot( policy.assumedRoot, path )`
   → the same `-32602` refusal. Read verbs stay unrestricted on every tier (unchanged).
2. **Honesty floor (the weaker fix):** keep the tier permissive, but disclose — the edit
   result envelope carries the assumed root and the out-of-workspace fact explicitly, so no
   caller can read the edit as in-workspace routine.

The spec should also pin the regression guard: a gate arm asserting the bare form refuses
(formerly: applies) — si the fix, when it lands, has its own red→green. When upstream fixes
it, THIS lane's A2 arms (the pinned forms) do not change — they already assert refusals.

## Boundary of this finding

- This is NOT in scope for `security-regression-integration` (test-only lane — the dispatcher's
  ruling stands; the harness does not carry a known-red arm).
- The interlock applies to the future spec as to every lane: nothing upstream-visible until
  PR #484 concludes.
- Related upstream history: the D3/D4/X7 fix family (the comment's own citations) — the
  assumedRoot tier's absence from the pin is the residual their incident framing did not
  cover.
