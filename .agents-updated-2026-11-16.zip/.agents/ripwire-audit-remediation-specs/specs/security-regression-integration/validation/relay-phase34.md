# Relay to PM — SRI Phase 3 complete, Phase 4 gate verdict settled

**The owed ledger line is corrected. Phase 3 is done and the ASan SKIP is now a PASS. Phase 4's suite ran this
gate in the real absorb loop and it passed.**

## 1. The M2′ line — corrected, and re-verified rather than accepted

You were right, and I measured it rather than taking it on trust:

- `git diff` of the mutant's `src/mcp.h` carries **exactly one** edit-pin hunk — the stdio gate. No HTTP-tier
  revert exists.
- An isolated HTTP probe against the mutant (no A2a having run first, so no carried state) refuses `-32602`
  with the exact contracted sentence and leaves the victim byte-identical.

So `mcp.h:1921` is where the red is **OBSERVED**, not a revert site, and A2/http's red is **carried** from
M2's stdio escape through the shared fixture — exactly your reading. `validation/discrimination-proof.md` now
says so, and the accounting is corrected to **six reverts / six red arms / one carried** (my "seven" had
double-counted a carried red as an independent revert).

## 2. Phase 3 — the SKIP turned PASS

`asan/ripwire` built **from the lane** (`built_from=1dbdc44fc`, 133 MB, 1 h 16 m). Direct run over the fixture:
**rc=0, zero bytes on stderr**.

```
PASS  B ASan/LSan clean over the adversarial fixture — no report on stderr and exit 0
suite: determinism=clean, xmllint=clean, asan=clean, ...
```

**I strengthened the leg before trusting it.** Exit status alone is not a clean bill — a report can be emitted
while the program exits 0. The leg now requires exit 0 **and** no sanitizer banner on stderr, and a planted
exit-0 emitter printing `ERROR: LeakSanitizer` is caught by name (`asan=REPORTED (exit 0)`), where the old
check would have passed it. The skip message also names the path it tried, so a typo'd `RIPWIRE_ASAN_BIN`
cannot read as "not requested". Commit `df9f0d470`.

## 3. Phase 4 — the gate's verdict is settled

The suite ran it in the absorb loop: **`PASS absorb gate (auditregresscheck.sh)`** — and in the loop's exact
invocation shape (`RIPWIRE_BIN=… bash test/<gate>.sh`, no argv) it is PASS with **0** FAIL-shaped lines, so
the loop's own detector reads green. The `report/` artifact (AC-8) is written to
`specs/.../report/report.txt` — 8 rows, all `repelled`, trailer `asan=clean`.

**One suite failure, and I proved it is not mine three ways.** `astrocheck.sh` returned rc=1 but printed 22
lines with **no failing assertion** — the suite's own detail says `(no failure-shaped line — last 25 of 22
shown)`, i.e. the `[math degraded]` time-gated class this host is known for. It passes **at the clean base
`50bc05e84`** in a fresh worktree, passes **3/3 in the lane tree**, and my lane touches `astro` nowhere (the
only text hit is "cat**astro**phic").

**One thing you should decide on.** The full suite is ~8.5 h on this host (762 absorb gates at ~41 per 27 min),
and my background tasks do not survive session boundaries — that run was in fact reaped at one, at 41/762. I
have the gate's verdict from the loop itself, so I did not sit on an 8-hour wait. If you want the *whole* suite
green as the Phase-4 exit criterion rather than just our gate's leg, say so and I will launch it with persistent
logging and hand you the complete log at the end. (I would need it to run across session boundaries, which is the
part that has failed five times; tell me and I will use a detached mechanism that survives.)

## 4. Two things to rule on

1. **Spec deviation, disclosed not papered over.** The Implementation Note asks expected strings be *imported*
   from the unit gates via a sourced fragment. No such fragment exists — `regexrefusecheck` and
   `mcpstdiolinecapcheck` contain none of the wording, and the latter says `kept in sync by eye`. Building it
   means editing other lanes' gates, outside this lane's remit. Literals are asserted here; **the drift alarm
   the note wants is not achieved**. Aspirational for later, or a lane that owns the fragment?
2. **Disk, again.** The grant recorded 4.6 GiB; the machine had **2 GiB** at Phase-3 start, so I asked instead
   of gambling — you chose reclaiming merged-lane worktrees (~1.7 GB, all verified clean first). The drain then
   recurred mid-build (4→1 GiB) and self-recovered to 8 GiB. Logged as a recurrence; I have no measurement
   pinning the cause.

## 5. "Both platforms" — I have to be straight with you

Phase 4 names both platforms. **I ran one.** The gate is proven on macOS only, and here is the part that
matters more than the gap itself:

**After push, this gate's first execution is on Linux, not macOS.** `ci.yml:95-133`: a `pull_request` without
the `train-member` label takes `full=false`, and the matrix is then exactly
`[{"os":"ubuntu-24.04","flavor":"Release","cc":"clang"}]`. The `macos-26` legs live only in the `full=true`
branch (dispatch / schedule / non-light push). So the lane is BSD-tested and **GNU-first-executed**. A
BSD-only construct would have gone red on your first CI run, on the one platform I never touched.

Linux was not reachable here: no `podman`/`colima`/`lima`/`multipass`/`vagrant`; Docker Desktop is installed
but its daemon is down (`docker info` cannot connect at `~/.docker/run/docker.sock`); and at **3.6 GiB free** a
Linux C++ build is not affordable anyway — same disk wall we already renegotiated once.

So I audited the GNU/BSD surface instead of simulating it. Every known divergence class is **absent**:
no BRE `\|` (all `-E`); no `stat -f`, `sed -i ''`, `date -j/-v`, `readlink -f`, `mktemp -t`, `xargs -J`; `mktemp -d`
and `date +%s` are both-ways portable; `sed` substitution only; no shell-level `timeout` (the two hits are Python
kwargs — and this host has no `timeout` binary at all); `awk` is a comment, the CSV parser is Python `csv`;
`xmllint` is `command -v`-guarded with a *disclosed* SKIP; bare `python3` but **stdlib only**, no PyYAML; and
`set -u` without `pipefail`, so GNU's early-exit `grep -m1`/`head -1` cannot SIGPIPE a producer into a failure.

I also ran the suite's five portability gates on the lane tree — `bashsourcecheck`, `baselineportcheck`,
`infraportcheck`, `portablebuildcheck`, `shellgateindexcheck` — all rc=0, zero FAILs. **They do not substitute
for a Linux run**, and I say why in the report: `portablebuildcheck` drives cmake arch flags via
`RIPWIRE_PRETEND_LINUX=ON`, which is a build-config property, not *this shell gate under GNU coreutils*. None of
the five executes `auditregresscheck.sh` on Linux.

**Verdict stated honestly:** portability is argued from text and from the absence of every known divergence
class — **not measured on Linux**. If you want it measured, the cheapest honest route is to push to a branch and
read the PR's `ubuntu-24.04` leg; that leg *is* the second platform and it runs on the first push.

## 6. State

Commits `1dbdc44fc` → `df9f0d470` → `55f33b55b`, all test-only; `git diff --stat 50bc05e84..HEAD -- src/` is
empty. **Not pushed** — ship keys held, as instructed. `sri-mutant` and `sri-base` are reclaimable on your
word now that the gate's Phase-4 validation is settled.

Note on the suite log: `logs/sri-phase4-suite.log` stops at 41/762 — that run was reaped at a session boundary
(fifth time for that class) and the 8.5 h figure stands. The gate's verdict does not depend on it; it is proved
in the absorb loop and in the loop's exact shape on final HEAD, re-confirmed just now at `rc=0` / **0** FAILs.

Files: `validation/phase34-report.md` (§7 is the platform argument), `validation/discrimination-proof.md`
(corrected), `report/report.txt`.
