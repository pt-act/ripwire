# Relay to producer — SRI fork-CI fix round: ACCEPTED; matrix re-dispatched on 073f05acb; what happens next

Verdict filed: validation/verdict-phase4-ci.md. Short form: **the fix round is accepted in full;
every load-bearing claim re-proven by this seat's own runs before acceptance.**

## What I re-ran myself (nothing read back)

- Both meta-gates at lane+fixes: nulbytecheck ALL PASS (arm (c) honest — the .docx row is backed);
  gitenvhermeticcheck ALL PASS (D) all 187.
- The hostile-GIT_DIR discrimination, reproduced exactly: shipped rc=0/0 FAIL; stripped copy six
  A4 FAILs, ownership 6→0, the githarden diagnostic disclosing the discovery failure. The line at
  :69 is load-bearing.
- Mutant re-seal at the NEW gate text: 15 FAILs (six mutation sites still caught); shipped control
  green. Discrimination intact through both commits — the third re-seal this lane has survived.
- Neighbours re-run green (attrvocab, barrelshortkey); manifestcheck 762; lane arithmetic exact
  (5 commits, 6 files, +774, src/ drift 0, tree clean).
- Spec.md:59 confirmed: "a `.docx`" is a required adversarial input. Your wrong-instinct catch
  (checking before deleting the fixture) is exactly the standard this repo sets — and the
  allowlist row with its reason is the documented mechanism.

## The §6 correction, verified on disk

The fresh validation copy runs §1–§9 in order; your inversion correction is stated rather than
quietly edited, and the "memory file only helps if read first" lesson is the right one to log.
The same class of slip was caught on this seat two rounds ago (both of us had the platform fact
inverted; my empirical probe settled it and my bank was rewritten) — your report now says it
plainly. Consider the earlier "one §7 line owed" instruction from my Phase-3+4 relay SATISFIED and
superseded: §6/§7 do the work the owed line would have done.

## Ship status (my acts, disclosed)

- Lane pushed to the fork at `073f05acb`; remote head re-verified.
- Matrix re-dispatched, running TWICE on the same commit: my workflow_dispatch
  (`42340727896`) and the push-auto-triggered PR run (`42340729544`) — a free two-run consistency
  read. Watcher parked on the PR run.
- Green on both platforms in the matrix completes Phase 4's both-platforms clause. The status
  flip on the spec (terminal validation) happens on the operator's word with the green matrix in
  hand. The upstream PR question stays interlocked on #484.
- Fork PR #7 remains the instrument: green matrix read → terminal validation → upstream PR →
  PR #7 closes UNMERGED. Fork main stays the mirror of `50bc05e84`.

## One caution to carry into the next round

The first red matrix cost one fix round + a re-dispatch because the swept violations were
invisible to your 41-min short-suite instruments. That is not a defect in your runs — CI is the
only instrument that runs the release- and plain-list sweeps on both platforms; it is why the fork
matrix prefaces every push. Before any NEXT lane's first push, sweep-audit the new files locally
against the FULL absorb list (grep the sweep gates' assertions over your registrations), so
matrix-round-one is cheap by design.

Nothing upstream-visible has happened. Nothing else is owed by your seat.
