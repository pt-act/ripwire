# Terminal-Validation Verdict — security-regression-integration (the validator's fold, 2026-11-07)

**Verdict: TERMINALLY VALIDATED — approved. The full chain is verified by this seat's own
instruments end to end: every phase fold was made on independently reproduced evidence, the
report artifact carries 8/8 `repelled` rows with a clean suite trailer, and the lane's final
head is green on both platforms, twice, in the real CI instrument. The five audited attacks
are repelled by the shipped tool; the lane's work is done.**

The operator's flip word (2026-11-07, "sure let's flip it") executes the prepared status
flip. This file is the chain-of-custody record for that flip — nothing in it is read back
from a hand-back; every link was re-verified through this seat's own instruments at the
moment it was accepted, and the remaining chain check (16:02–16:06Z today) re-read the four
verdict files' ACCEPTED heads, the report artifact, the registration, and the interlock state.

## The chain, link by link

| Link | Evidence (all PM-verified by own runs, not read back) | Fold |
|---|---|---|
| Phase 0 — anchors + errata | Five pinned contracts live-verified at base `50bc05e84`; five corrections (C1–C5) disclosed; the A2 assumedRoot escape split out as SRI-F1 (filed at `findings/stdio-bare-edit-escape.md` — a planned spec, not this lane's arm). Red baselines run on this seat's own self-built binary. | `verdict-phase0.md` ACCEPTED; spec v1.1.0 |
| Phase 1 — fixture tree + registration | `test/fixtures/audit-reef/` (REAL-zip docx, 128 KB single-line subject, runtime-built hostile git repo) + the gate + registration + changelog in one commit `1dbdc44fc`; 761→762 registration re-proven from a fresh base worktree by structural parse; slot verified. | `verdict-phase1.md` ACCEPTED |
| Phase 2 — the arms | Shipped binary 8/8 `repelled` (A1a/b, A2a/h, A3, A4, A5h/s); the six-mutation binary discriminated (14 FAILs; M3 owned by `tempfilesymlinkcheck` by design); A4's author-vs-committer and the `row()` write-time shape were this seat's honesty probes. | folded with Phase 1 |
| Phase 3 — suite invariants | ASan/LSan clean over the adversarial fixture (granted 2026-11-06); the SKIP→PASS leg hardening (`df9f0d470`) proved load-bearing with a planted exit-0 emitter caught by name. | `verdict-phase34.md` ACCEPTED |
| Phase 4 — registration, both platforms, report/ | Loop green in the exact shape at final-and-beyond heads; `report/report.txt` committed — every (attack, transport) row `repelled`, schema stable for the downstream consumer. Then the fork-Actions instrument: THREE base-suite meta-gates caught the lane's files pre-upstream, three classes red 18-of-24 (6/6/6) — all PM-discriminated base-green/lane-red, all producer-fixed (`c6d197a93` the `.docx` allowlist row, `073f05acb` the clean-env source line — load-bearing under hostile `GIT_DIR`, `ef36d595c` the canonical `ok()` shape), each PM-battery-verified at its fix head before the push, mutant re-sealed ×4 (15 FAILs at every gate text). | `verdict-phase4-ci.md` §1–§6 |
| The matrix read | Run 3 at `ef36d595c` (two-run consistency pair, PR `42370666380` + dispatch `42370663212`): **35 success / 0 failure on BOTH runs**, every release-shard census `fail=0` both platforms (incl. the shard-3/4 population red in runs 1–2); xplat-diff, asan ×2, windows ×2 + package, rhel ×2, style, fallback all green. | `verdict-phase4-ci.md` §7; interlock probed OPEN at the read |
| Terminal validation (this fold) | The full-chain re-read; selfcheck pre-flip control ALL PASS (16:06Z) in the same tree the flip edits; status flip `in_progress → approved` in the manifest + spec by this act. | this file |

## Rulings carried into the record

- **VALIDATION_PROTOCOL step 2 / Q10 (a) is the flip authority** — the producer never flips
  statuses; the dispatcher/validator-seat performs the transition on the validated chain. Same
  authority as the four prior `spec_approved` events (`regex-screen-hardening`,
  `regex-screen-multiquantifier`, `git-porcelain-framing`'s Q10-precedent, `mcp-token-hygiene`).
- **CI was Phase 4's both-platforms instrument of record** (Rule 11 extended): a green
  both-platform matrix on the pushed head superseded the "loop green twice" phrasing — and the
  instrument earned it, catching three base-suite meta-gates the 41-min short suite was
  structurally blind to. The fork instrument is VINDICATED: three classes in, three out green,
  zero upstream exposure.
- **The census rule moves to standing.** A sample is a probe, a census is the full TSV sweep —
  the run-1 mis-read ("18/32, two classes" — true: 18-of-24, three classes 6/6/6) is stated,
  not hidden, in `verdict-phase4-ci.md` §1 and the spec's Phase-4 line.

## Lane accounting at the flip

6 commits (`1dbdc44fc` → `ef36d595c`), 6 files (`+777`), **`src/` drift 0** — the test-only
contract held to the last commit. Absorb loop 762 (761+1) at the verified slot; manifestcheck,
gatecount, GEN-DOCS-MERGE all honored at the drift figures measured at the read. Both-platform
coverage delivered by the fork matrix at the final head; the lane's gate itself registered in
`test/regression.sh` and green in every loop shape this seat ran.

## Ship-key acts this fold (disclosed)

- **Fork PR #7 CLOSED UNMERGED** (16:10Z, with the instrumental closing comment): its matrix
  is delivered green twice — a spent instrument. The lane branch
  `lane/security-regression-integration` STAYS on the fork at `ef36d595c` (verified by
  ls-remote post-close) — it is the upstream-PR candidate when the interlock clears.
- **Spec Status flipped `in_progress → approved`** + the Terminal-validation box checked
  (below); manifest `spec_approved` event appended on the flip timestamp.
- Nothing upstream touched. **The #484 interlock HOLDS** (probed 16:02Z: OPEN/CONFLICTING at
  `367dbfe457`) — the upstream PR question is a separate act on its own word, per
  one-lane-in-review.

## What the flip wakes

- `audit-validation-standalone` (planned, dep on this spec now SATISFIED) — the audit-closing
  consumption of this lane's `auditRegressionReport`. Disposition per DAG.
- `stdio-bare-edit-escape` (planned, deps `[]`) — SRI-F1, the 16th node, the natural
  producer-round candidate; the assumedRoot tier fix is `src/`-bearing Tier-2 work
  disambiguated by its planning cycle at dispatch.
- **Scratch reclaim GRANTED, executably:** sri-mutant 538M + sri-base 351M (measured
  live at the fold) — the operator's explicit `rm` word reclaims both; no work is owed on
  either tree after this fold.

## The seat's own instruments log (same discipline as every fold)

The chain check was run as a re-read of fold-verified links (the four verdict files, the
report, the registration count, the interlock probe) — no new evidence is claimed beyond what
the eight PM instruments already banked. Selfcheck pre-flip control ALL PASS in the same tree
the flip edits (16:06Z), so any post-flip selfcheck red would be this fold's edit, not
pre-existing — the control design mirrors the mutant discrimination pattern.
