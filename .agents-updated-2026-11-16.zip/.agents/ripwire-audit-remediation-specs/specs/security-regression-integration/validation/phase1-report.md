# SRI Phase 1 — completion report

**Spec:** `security-regression-integration` v1.1.0 · **Commit:** `1dbdc44fc` · **Base:** `50bc05e84`
**Branch:** `lane/security-regression-integration` · **Author:** `pt-act <psychoactive28@gmail.com>`

Phase 1 delivered the gate skeleton with all eight arms, registered in the same commit, and — beyond what Phase 1
strictly owed — the red→green discrimination proof, because a gate that has never been seen to fail is not yet
evidence.

## 1. What was delivered

| Path | Change | Note |
|---|---|---|
| `test/auditregresscheck.sh` | new, 100755, ~700 lines | the integration gate; 8 rows across arms A1a/A1b, A2a/A2h, A3, A4, A5h/A5s, B, C |
| `test/regression.sh` | +1 line at `:322` | byte-ordered slot: after `attrvocabcheck`, before `barrelshortkeycheck` |
| `test/fixtures/audit-reef/minified-oneline.js` | new, 130,650 B | the ReDoS subject: one line, only `a`/`b`, ends `…b` |
| `test/fixtures/audit-reef/minimal.docx` | new, 952 B | a REAL minimal OOXML zip (members `[Content_Types].xml`, `_rels/.rels`, `word/document.xml`); a fake `PK\x03\x04` header would prove nothing about the markitdown branch |
| `changelog.d/security-regression-integration.md` | new | names the four non-assertions and A3's regression-guard status |

**Zero `src/` files.** Verified: `git show --stat HEAD | grep -c '^ src/'` → `0`.

## 2. Registration, arbitrated by the tree's own instruments

`docs/gatecount_build.py --check`, before and after the loop line, same tree:

```
without the line:  the loop in test/regression.sh names 761 today
with the line:     the loop in test/regression.sh names 762 today
```

`./test/manifestcheck.sh` → **rc=0**, and it confirms the change from both sides:

```
PASS: (REGISTRY) the 776 top-level test/*.sh gates CI runs are exactly the 762 in the absorb list
                 plus the 14 regression.sh invokes by name; one name per line, byte-sorted, no duplicate
PASS: (REGISTRY) mutation control (unregistered file) is caught
PASS: (REGISTRY) mutation control (out of byte order) is caught
```

`docs/counts_snapshot.py check --max-drift` → **rc=0**, `gates.scripts ≤ 10`. The drift is 9 after this line
(753 snapshot → 762 live), i.e. within bound but consuming one unit of headroom. Flagged, not fixed: the
snapshot refresh is the merge's job (`merge_main.sh --regen-after-build`), not a feature PR's.

**Byte-order was measured, not assumed.** `LC_ALL=C sort` on the neighbours puts `auditregresscheck` after
`attrvocabcheck` and before `barrelshortkeycheck` (`t`=0x74 < `u`=0x75), which is where the verdict pinned it.

## 3. Every arm discriminates — against a six-mutation binary

A gate that passes proves nothing until it is seen to fail when its behaviour is removed. I built a mutant tree
(`~/ripwire-scratch/sri-mutant`, full Release build, 34 min) with six behaviours reverted and ran the same gate:

| Revert | Site | Arm | Mutant observed | Verdict |
|---|---|---|---|---|
| M1 CLI screen `return 1`→`0` | `verbs_grep.h:998` | A1/cli | `rc per pattern = 000` | **red** |
| M2 startup-root pin disabled | `mcp.h:1944` | A2/stdio | `code=none`; `victim CHANGED` | **red** |
| M2′ same, HTTP tier | `mcp.h:1921` | A2/http | `victim CHANGED in both states` | **red** |
| M3 `O_EXCL`/`O_NOFOLLOW` dropped | `pathguard.h:414` | A3/stdio | still `repelled` | **see §4** |
| M4 `%ae`→`%ce` attribution | `gitmine.h:1104` | A4/cli | `committer-email rows 1; spoof top=committer@x.com` | **red** |
| M5 HTTP cap 8→16 MiB | `mcpserver.h:60` | A5/http | `400 Bad Request (no 8 MB sentence)` | **red** |
| M6 stdio cap 32→64 MiB | `mcp.h:3009` | A5/stdio | `-32600 (NOT answered); refusals measured: 0` | **red** |

Shipped binary: **PASS, 8/8 rows `repelled`**. Mutant: **14 failures, 6/8 `unproven`**.
Logs: `logs/sri-shipped-postfix2.log`, `logs/sri-mutant-run2.log`, ledger `logs/sri-discrimination-proof.md`.

## 4. M3 does not discriminate through A3 — and that is the spec's own boundary

A3 is worded as a **regression guard** because the shipped temp name is 24 hex chars of `/dev/urandom` created
`O_EXCL|O_NOFOLLOW` with 8 retried draws. The six historical shapes A3 plants (`subject.c.{$$,0,1,2,tmp,XXXXXX}.tmp`)
can never collide with a name the binary will draw, so removing `O_EXCL` does not make *A3's* attack land —
collision probability is what protects it, not the flag.

The gate that owns M3 is `test/tempfilesymlinkcheck.sh`. Run **inside the mutant tree** it fails four rows:

```
FAIL (f1) openExclNoFollow refuses an existing symlink at its name with EEXIST
FAIL (f1) the link and the file it points at are unchanged
FAIL (f2) openExclNoFollow refuses a dangling symlink and creates nothing at its target
FAIL (f3) openExclNoFollow refuses an existing regular file and leaves it unchanged
```

So the behaviour is gated, by the gate the spec names for it. A3's narrower job — historical shapes stay dead,
the edit still publishes — is asserted and passes.

**Instrument note worth recording.** My first run of that unit gate was made from `sri-r1`, so its probe
compiled against the *clean* `$ROOT/src` and passed. A gate that compiles against the tree it sits in must be run
from that tree. Same class as the earlier `grep`-subcommand and `$c:t` incidents: the ruler was wrong.

## 5. Two defects the discrimination run found in my own gate — both fixed

**5.1 The A4 fixture could not tell the author from the committer.** Both `GIT_AUTHOR_EMAIL` and
`GIT_COMMITTER_EMAIL` were `real@x.com`, so M4 (`%ae`→`%ce`) answered identically and A4 passed a binary with a
swapped attribution field. Fixed: the fixture now commits as two different people, and A4 asserts
`committer@x.com` appears in **zero** rows. This is the single most valuable thing the mutant build bought.

**5.2 Several `observed` fields stated shapes they had not measured.** On the mutant, A5/stdio printed
`-32600 request line exceeds the 33554432-byte limit (x1)` beside a check that said `got 0`, and A2/http printed
`-32602 path is outside this server's workspace` beside a `victim CHANGED` failure. These were constructed
strings — the report said what the contract wanted, not what happened. Every row now reports only measurements
(`code=<actual>`, `refusals measured: <n>`, `control=<n>`, `rc per pattern = 111`), and `row()` enforces the
relation at write time: a `repelled` verdict whose expected shape is not a real substring of its observed text is
downgraded to `unproven` **and named in a FAIL line**.

## 6. One further design correction (report shape)

Arm C originally split report rows on `", "` to count columns. AC-1 *requires* the literal
`refused, nothing was scanned:` in the expected-shape field, so that row is genuinely well-formed and the counter
called it malformed. The report is now emitted with `csv.writer` and parsed with `csv.reader`
(`QUOTE_MINIMAL`, so a line still begins `A1,` and the consumer's `^A[1-5],` schema grep is untouched — asserted
explicitly as its own check).

## 7. Disclosures

- **A1b asserts transport safety, not a refusal**, per C3/ruling. The positive control (`total=1`) is mandatory
  and asserted; without it an empty answer cannot be told from a scan that never ran.
- **Two SKIPs in arm B are deliberate and named**: pargates (would recurse unboundedly — `pargates.py` runs
  every `test/*.sh`, this file included) and ASan (no `RIPWIRE_ASAN_BIN`; the 1.4 GiB build is the granted
  Phase-3 line item, not a per-PR gate).
- **Arm B's ASan leg is wired and ready**: setting `RIPWIRE_ASAN_BIN` turns the SKIP into a real assertion.
  Phase 3 only needs to supply the path.
- **Port probing**: bind-and-release with 20 bounded attempts, because `--listen` refuses port 0 (`1..65535`).
  A failure to start is a disclosed FAIL, never a silent pass.

## 8. Owed / next

- **Phase 2** — arms are complete (A1a/A1b, A2a/A2h, A3, A4, A5h/A5s all landed and discriminating). Phase 2
  is therefore folded into this commit rather than pending.
- **Phase 3** — ASan build + arm B's ASan leg under `RIPWIRE_ASAN_BIN`; disk-gated (3.7 GiB free, 1.4 GiB
  needed, GRANTED).
- **Phase 4** — full suite run (`./test/regression.sh`), then the `report/` artifact under the spec dir.
- **Held for the operator**: promotion of `stdio-bare-edit-escape` to a spec node is the operator's word (it has
  landed as the 16th DAG node per the 11-06 relay). The main-checkout pull (2,017/75ff behind) and the
  ~3.7 GiB reclaim set also remain operator decisions.
