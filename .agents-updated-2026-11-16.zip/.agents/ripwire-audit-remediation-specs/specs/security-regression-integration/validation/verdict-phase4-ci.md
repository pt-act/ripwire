# SRI Phase 4 — fork-CI matrix verdict: the red run, the fix round, and this seat's re-verification

**Verdict: the fix round is ACCEPTED; the lane at `073f05acb` is pushed to the fork and the matrix
re-dispatched. Green there completes Phase 4's both-platforms clause. Status-flip authority is
unusual this round: it belongs to the CI run itself.**

This verdict covers events AFTER the Phase-3+4 fold (verdict-phase34.md): the fork Actions enable,
the first dispatched matrix run (`42289430220` on `55f33b55b`, conclusion FAILURE), the producer's
fix hand-back (commits `c6d197a93` + `073f05acb`), and the re-dispatch (`42340729544`, the PR run;
`42340727896`, the dispatch run — a free two-run consistency read on one commit).

## 1. The red matrix read — 18 of 24 release shards, three classes, all lane-caused

**Correction (2026-11-07, on the run-2 evidence, stated rather than quietly edited): this verdict
originally read "18/32 release shards, two meta-gates." Both numbers were wrong, in opposite
directions, and both errors were this seat's.** The 32 counted the whole release matrix including
non-release jobs; the true count is **18 of 24** release shards (red map: 6 nulbyte / 6 geh / 6
gateexit). The "two" was a sampling bias: this seat drew 6 job logs for reading and all 6 happened
to be shard 1/2/4 legs — the gateexit failures lived on the 6 shard-3/4 legs my sample never
visited. Re-derived from all 18 pinned logs: **gateexitcheck** (a THIRD meta-gate, arm (G1): the
`ok()` helper contract — see §1b) failed all six shard-3/4 legs in run 1; ALSO gateexitcheck lives
in shard 3/4's slice of the absorb list — the reds of run 1 were the complete shard-3/4 population,
not a scatter. The discrimination for gateexit is mine and is the same shape as the others:

| Tree | gateexitcheck (G1) |
|---|---|
| base `50bc05e84` | rc=0, ALL PASS (9 distinct ok() definitions, 717 gates) |
| lane `073f05acb` | rc=1 — G1 flags `auditregresscheck.sh` ok() (non-standard from `1dbdc44fc`) |
| canonical `ok()` | `ok(){ printf '  PASS  %s\n' "$*" || { fail=1; printf '  FAIL  could not write the PASS line for: %s\n' "$*"; }; return 0; }` |

The first matrix on `55f33b55b` concluded FAILURE with 18 of 24 release shards red. Our gate ran
GREEN everywhere it ran; the red came from THREE base-suite META-GATES interrogating the lane's new
files — and the discriminations are mine, from my own runs:

| Tree | nulbytecheck (a) | gitenvhermeticcheck (D) | Sweep pop. |
|---|---|---|---|
| base `50bc05e84` | rc=0, ALL PASS | rc ALL PASS (D) all 186 | 186 |
| lane `55f33b55b` | rc=1 — NULs in `minimal.docx` at byte 5 | rc=1 — names `auditregresscheck.sh` | 187 |
| lane + fixes `073f05acb` | rc=0, ALL PASS (my run) | rc=0, ALL PASS (D) all 187 | 187 |

Not a broken matrix (base green), not a BSD/GNU split (all three reproduce rc=1 on the lane on
this macOS host, identical to the runners' red), not our gate's own assertions (it passed on every
shard). The corrected 18-failure map: **6 nulbyte (plain-slice legs) / 6 geh (release-slice legs) /
6 gateexit (the complete shard-3/4 population)** — 6 macos-26 / 12 ubuntu-24.04. The binding is by
shard gate-list membership, not config: `gateexitcheck` lives in shard 3/4's slice of the absorb
list (the first cutover into this seat's reporting), `gitenvhermeticcheck` and `nulbytecheck` in
the release/plain lists' slices that overlap every shard. Run 2 on the fixed head confirms the
first two classes green on every completed leg; its shard-3/4 legs red on gateexit only —
correcting §1's original "the 18-failure map … NOT cleanly by config" phrasing, which was this
seat reading a 6-of-18 sample as the census. All 18 run-1 job logs + the six run-2 shard-3/4
leg identities are pinned in scratch (`sri-failed-jobs.tsv`, `sri-job-*.log`, `run1-s34-*.log`).

## 2. The fix round, re-verified by this seat's own runs — nothing read back

- **The `.docx` allowlist row** (c6d197a93): my own arm-(c) run proves the row is honest (backed by
  a tracked file). Their "wrong instinct" note verified: spec.md:59 does require "a `.docx`" in the
  fixture tree, and the gate crawls the whole FIXTURE dir — deleting the file would have broken the
  spec to silence a correct gate. The row is the documented mechanism, same container class as the
  `.pptx` row.
- **The clean-env source line** (073f05acb, auditregresscheck.sh:69): I discriminated whether it
  does real work — shipped gate under a hostile exported `GIT_DIR`: rc=0, 0 FAIL; the same file with
  only that line stripped: rc=1 with SIX A4 FAILs — ownership rows 6→0, ripwire's own `githarden`
  diagnostic disclosing git-discovery failure at the hostile root. The line is load-bearing, not
  sweep-placation.
- **Mutant re-seal at the NEW gate text**: 15 FAILs against the six-mutation binary (regex screen
  rc=0×3, A4 committer-swap, A2a stdio escape among them); shipped-binary control green at the same
  invocation. Discrimination intact through two more commits.
- **Post-fix neighbour sweep re-run by me**: attrvocabcheck rc=0, barrelshortkeycheck rc=0,
  manifestcheck rc=0 (762 + 14). Lane arithmetic: 5 commits, 6 files, +774, `src/` drift 0.
- **Their corrections on disk** (the fresh 04:40 validation copy): report runs §1–§9 in order; the
  §6 platform inversion is STATED as a correction ("I re-derived the wrong answer because I wrote
  the claim before grepping memory"), and §7 documents the two meta-gate catches as their defect with
  full discriminations. Verified by my own re-read of the file.

## 3. Rulings

- **Rule 11 extended (fixed-then-rerun)**: the fork instrument caught three base-suite invariant
  violations the producer's 41-min short suite was structurally blind to (both meta-gates live in
  the release/plain shard lists). The lane got one fix round + one re-dispatch — a green matrix on
  `073f05acb` is now the terminal exit of Phase 4, superseding the earlier "loop green twice"
  phrasing: CI is the both-platforms instrument of record.

## 4. Ship-key acts this round (disclosed)

Push of `073f05acb` to `pt-act/ripwire` (lane branch now at the remote at the fixed head), matrix
re-dispatch (both runs), watcher parked on the PR run. All fork-internal; upstream untouched; the
#484 interlock holds.

## 5. Instruments log (this seat's own errors, disclosed)

- The first two anchor-verification scripts failed on my own bugs (a `dict.get` on a str; a
  JSON-serialized content-block wrapper taken as content). Both fixed; the anchors then passed.
- The 04:40 fresh validation-copy read confirmed my earlier 19:29 scratch copy was the stale draft
  — the platform section WAS in the fresh copy I had already filed.

## Acknowledgements

The producer's fix round is excellent work — both fixes minimal, honest, and exactly at the
documented mechanism; the honest question ("does the clean-env line do anything?") asked and
answered by their own discrimination, which this seat then reproduced independently, exactly. The
wrong-instinct catch (checking spec.md:59 before deleting the fixture) is the standard this repo
sets. The §6 honesty note ("a memory file only helps if read first") lands its lesson on their
seat; my platform inversion the same class.

---

## 6. The class-3 round (2026-11-07 09:04Z): run 2's read, the `ok()` fix, ACCEPTED, run 3 dispatched

**Run 2 final (both runs, perfect agreement): 6/6 shard-3/4 legs red, ALL on `gateexitcheck` G1
only** (this leg-set = 100% of the shard-3/4 population, so the last extrapolated leg is now
census-confirmed; classes 1+2 green on every other completed leg; asan ×2, windows, rhel, style,
fallback all green). The operator's pasted leg and all six run-2 red logs are pinned
(`run2-red-*.log`, `run2-failed-jobs.tsv`).

- **The third meta-gate, named:** `gateexitcheck` arm (G1), living in shard 3/4's slice of the
  absorb list — the `ok()`-survives-its-own-broken-terminal contract: record the failed write of
  the PASS line in the accumulator this gate reads AND return 0 unconditionally. Our `ok()` was
  the bare printf since `1dbdc44fc`. My discriminations: rc=1 at lane `073f05acb` locally
  (macOS); rc=0 ALL PASS at base. Gateexit's own G1-control proves the probe discriminates.
- **The fix (`ef36d595c`, the producer's, PM-verified with ALL batteries re-run at the fix head):**
  `ok()` now the canonical suite shape, tailored to this gate's accumulator (`fails`):
  `ok(){ printf ... || { fails=$(( fails + 1 )); printf '  FAIL  could not write ...' "$1"; }; return 0; }`.
  At fix head: gateexitcheck ALL PASS (**10 distinct ok() definitions / 718 gates** — the fixed
  shape counts as a new canonical-family member); nulbyte + geh ALL PASS (no regression); our
  gate loop-shape PASS; **mutant re-seal #4: 15 FAILs** (discrimination intact through the third
  fix commit); ASan control PASS; neighbours green; manifest 762; gatecount + bashsource sweep-
  audit gates ALL PASS; lane arithmetic 6 commits / 6 files / +777 / `src/` 0 / tree clean.
- **An honest note on this seat's own probe:** my hand-rolled closed-stdout probe cannot observe
  its own result (the report echo dies into the closed fd) — a flawed-instrument instance,
  discarded; the authoritative instrument is gateexitcheck's own G1 probe harness, red on the
  old shape at 07:13Z and green on the fixed shape at 11:5xZ — a complete discrimination pair
  through the real instrument.
- **Ship acts (disclosed):** lane pushed `ef36d595c`; matrix run 3 dispatched as the two-run
  consistency pair (PR run `42370666380` + dispatch run `42370663212`); watcher parked. **Green
  both-platform matrix at `ef36d595c` closes Phase 4**; terminal validation follows on the
  operator's word; upstream PR question still interlocked on #484; fork PR #7 closes unmerged.

---

## 7. Run 3 GREEN — Phase 4's both-platforms clause CLOSED (2026-11-07T15:43Z read)

The matrix at the class-3 fix head `ef36d595c`, dispatched as the two-run consistency pair on one
commit:

- **PR run `42370666380`**: completed/success — **35 success / 0 failure** (2 skipped = the
  workflow's own tracking-issue bookkeeping jobs, skipped on green by design).
- **Dispatch run `42370663212`**: completed/success — **35 / 0**, identical census.
- Per-shard evidence pinned from the job logs (`run3-shard*-*.log`): every release shard census
  line reads `fail=0` (e.g. macos-26 plain shard 3/4 `gates=192 pass=191 skip=1 fail=0` — the
  shard whose legs were red in both prior runs; the skip is portablebuildcheck's platform
  auto-detect, disclosed in-job). xplat-diff, asan ×2, windows ×2 + package, rhel ×2, style,
  fallback-emitter all green.
- Three red classes entered this instrument; three left it green: class-1 (`nulbytecheck`),
  class-2 (`gitenvhermeticcheck`), class-3 (`gateexitcheck`) — each fixed by the producer
  (`c6d197a93`, `073f05acb`, `ef36d595c`), each verified by this seat's own battery before its
  push, each confirmed green in CI.

**Phase 4 is COMPLETE. The lane at `ef36d595c` has run its gate and the full matrix green on
both platforms. TERMINAL VALIDATION is prepared; the status flip executes on the operator's
word.** The #484 interlock holds (probed 15:43Z: still OPEN, not merged) — the upstream PR
question follows the flip, and fork PR #7 — its matrix now delivered green twice — closes
UNMERGED as the spent instrument.
