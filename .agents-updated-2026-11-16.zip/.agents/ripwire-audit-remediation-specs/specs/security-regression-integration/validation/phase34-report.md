# SRI Phase 3 / Phase 4 — report

**Spec:** `security-regression-integration` v1.1.0
**Lane:** `lane/security-regression-integration` — `1dbdc44fc` → `df9f0d470` → `55f33b55b`
**Base:** `50bc05e84` · **Verdict consumed:** `validation/verdict-phase1.md` (Phase 1+2 ACCEPTED, 3/4 cleared)

---

## 1. The owed ledger line — corrected, and re-verified independently

The verdict's one item: my M2′ row named `src/mcp.h:1921` as a *revert site* when the mutant carries no
HTTP-tier revert. I did not take that on trust — I measured it.

```
$ git -C ~/ripwire-scratch/sri-mutant diff -- src/mcp.h | grep -E '^[-+].*(defaultRoot|pinnedRoot|path outside)'
-                else if( isMcpEditVerb( name ) && !mcpPathInsideRoot( policy.defaultRoot, path ) )
```

Exactly **one** edit-pin hunk — the stdio gate. Then an isolated HTTP probe at the mutant's `--listen`
tier, with **no A2a having run first** (so no carried state to confuse the result):

```
{"jsonrpc":"2.0","id":1,"error":{"code":-32602,"message":"path is outside this server's workspace
 (this listener serves one fixed workspace, pinned at startup) — omit `path` to use it, or run a
 second server for the other tree"}}
victim.c still: int targetFn( int x ) { return x - 1; }
```

The mutant's HTTP tier refuses **correctly** and the victim is untouched. Confirmed: the A2/http red is the
**carried** effect of M2's stdio escape through the shared A2 fixture (A2a writes the victim; A2h refuses
correctly but its `sha == before` probe compares against the pre-A2a hash).

`validation/discrimination-proof.md` now reads: **M2′ — carried; no revert of its own; red OBSERVED at
`mcp.h:1921`**. Accounting corrected to **six reverts / six red arm-results, one of them carried** (the earlier
"seven" double-counted a carried red as an independent revert). The safety argument is unchanged: a carried red
can only add red on a broken binary, never mask one.

## 2. Disk — I stopped and asked, because the grant's premise had moved

The verdict recorded 4.6 GiB free. At Phase-3 start the machine had **2 GiB** — insufficient headroom for a
~1.4 GiB build on a host that has twice lost long builds to this drain. I did not gamble 45 minutes.

Reclaimed with the operator's choice: four worktrees for **already-merged** lanes — `pr469-r1`,
`pr469-main-r1`, `gpf-r1`, `gpf-prefix-r1` — each verified `status --porcelain` empty *before* removal, via
`git worktree remove --force`. No uncommitted work existed in any; their branches are merged, so nothing became
unreachable. ~1.7 GB.

The drain then recurred mid-build: **4 GiB → 1 GiB** during the `main.cpp` ASan compile, recovering to 7–8 GiB
on its own without intervention. The build survived on already-written objects. Logged as a **recurrence**; I
have no measurement that identifies the cause.

## 3. Phase 3 — ASan

`cmake -S . -B asan -DRIPWIRE_ASAN=ON && cmake --build asan -j 4`. Wall time **1 h 16 m** on this 8-core i5,
dominated by one `main.cpp` translation unit (~35 min CPU on one core at ~80 %). Verified as real work rather
than a hang by **CPU-seconds vs. elapsed** (35 min CPU in 68 min elapsed), not by watching the clock.

`asan/ripwire --version` → `built_from=1dbdc44fc` — the lane commit itself.
Direct run over the fixture: **rc=0, zero bytes on stderr**.

**The SKIP turned PASS, as predicted:**

```
PASS  B ASan/LSan clean over the adversarial fixture — no report on stderr and exit 0
suite: determinism=clean, xmllint=clean, asan=clean, pargates=the suite run itself (...)
```

### 3.1 The leg was strengthened first, because exit status alone is not a clean bill

The Phase-1 leg asserted only `exit 0`. A sanitizer report can be **emitted while the program still exits 0**,
and a suppressions file can hide a class of report. The leg now requires **both**: exit 0 *and* no sanitizer
banner on stderr. A planted emitter — the exact shape the old check waved through — is now caught by name:

```
FAIL  B ASan/LSan exited 0 but EMITTED a report on the adversarial fixture: ==12345==ERROR: LeakSanitizer: detected memory leaks
suite: ... asan=REPORTED (exit 0), ...
```

The skip message also names the path it tried, so a malformed `RIPWIRE_ASAN_BIN` can no longer masquerade as
"not requested": `SKIP B ASan/LSan: no RIPWIRE_ASAN_BIN given (nothing executable at '/nonexistent/ripwire')`.

## 4. Phase 4 — suite, artifact, and one unrelated flake

**The suite ran this gate in the real absorb loop and it passed:**

```
PASS  absorb gate (attrvocabcheck.sh)
PASS  absorb gate (auditregresscheck.sh)
```

and in the exact invocation shape the loop uses (`RIPWIRE_BIN=… bash test/<gate>.sh`, no argv): **PASS**, with
**0** FAIL-shaped lines, so the loop's own failure detector reads it as green.

**`report/` artifact (AC-8) written** to
`specs/security-regression-integration/report/report.txt` — 8 rows, all `repelled`, trailer `asan=clean`. It
lives in `.agents/`, which is `git`-excluded (`.git/info/exclude:10`), so it stays on the blackboard without
polluting the lane branch.

**One failure, not mine, and I proved that three ways.** `astrocheck.sh` returned `rc=1` in the suite, but the
suite's own detail was `(no failure-shaped line — last 25 of 22 shown)`: the gate printed **22 lines and not
one of them a FAIL**. A gate that exits non-zero with no failing assertion is the `[math degraded]`
disclosure/timeout class this host is known to exhibit. Evidence it is environmental:

1. Re-run at the **clean base** `50bc05e84` in a fresh worktree → **rc=0**, all assertions PASS.
2. Re-run **3/3 in the lane tree** → rc=0 every time, zero FAILs.
3. My lane touches `astro` nowhere — the only textual hit is the word "cat**astro**phic" in a comment. The lane
   diff is 5 files, all test-side, zero `src/`.

**Suite wall time is impractical to block on.** 762 absorb gates at ~41 gates / 27 min ≈ **8.5 hours** on this
host. Background tasks do not survive session boundaries (the first run was reaped at one, which is why it was
relaunched with output streamed to `logs/sri-phase4-suite.log`). The gate's own verdict does not depend on
that run — it is already proved in the loop and in the loop's exact shape.

## 5. Deviation recorded, not papered over

The spec's Implementation Note asks that every attack's expected string be **imported from the unit spec's gate
via a sourced shell fragment**, "so a wording change fails in exactly one place per unit and here
simultaneously".

**That fragment does not exist in this tree.** The gates the Dependencies section names —
`regexrefusecheck.sh`, `mcpstdiolinecapcheck.sh`, `regexguardcheck.sh`, `regexbombcheck.sh` — contain none of
the refusal wording; they assert structure and exit codes. `mcpstdiolinecapcheck.sh:80` states the coupling as
its explicit opposite: `CAP=33554432   # kMcpMaxLineMaxBytes — kept in sync by eye`.

Building that fragment means editing other lanes' gates — outside this lane's test-only remit, and a change
their specs' owners have not ruled on. So the literals are asserted **here**, and the drift alarm the note
wants is **documented as not achieved**. For the PM: either the note is aspirational for a later pass, or it
needs a lane that owns the fragment.

## 6. "Both platforms" — what I proved, and what I could not

Phase 4 names both platforms. I did **not** run the gate on Linux locally, and I will not claim otherwise.

**Correction first, because I had this inverted and it matters.** An earlier draft of this section claimed an
unlabeled PR narrows to a single `ubuntu-24.04` leg, making the gate "Linux-first-executed". That is **backwards**.
`ci.yml:96-116` reads `full=true` as the DEFAULT and the `train-member` label narrows `full` to `false`; an
**unlabeled** PR therefore runs the **full matrix** — 8 `macos-26` shards plus the `ubuntu-24.04` Release/plain
gcc+clang ends. The lane was macOS **and** Linux executed in CI on first push, which is precisely how two
base-suite meta-gates caught it (§7). My memory bank had already recorded this correction from 2026-11-06 —
"both seats had it inverted" — and I re-inverted it in this report before catching it. The correction is stated
here rather than quietly edited out, because a false premise about CI reach is how the next gate gets shipped
untested.

**What that means for the platform gap.** It is narrower than a first draft claimed, but it is real: the local
runs are macOS-only. Linux was executed — by CI, not by me — and the `ubuntu-24.04` legs are where a BSD/GNU
divergence in this gate would surface.

**Linux was not reachable on this host anyway.** No `podman`/`colima`/`lima`/`multipass`/`vagrant`. Docker
Desktop *is* installed (`/Applications/Docker.app`) but its daemon is not running — `docker info` fails to
connect at `unix:///Users/rna/.docker/run/docker.sock`. Even with the daemon up, a Linux leg needs a C++ build;
at **3.6 GiB free** that is not affordable on this host, for the same disk reason the Phase-3 grant had to be
renegotiated.

**So I audited the gate's GNU/BSD surface directly, against the classes that actually diverge:**

| Divergence class | Finding |
|---|---|
| BRE `grep -q 'a\|b'` (the trap that already bit this project) | **Absent.** Every alternation is `-E`; no `\|` inside a BRE pattern. |
| `stat -f`, `sed -i ''`, `date -j/-v`, `readlink -f`, `mktemp -t`, `xargs -J`, `gdate`, `/usr/bin/sed` | **None present.** |
| `mktemp` | `mktemp -d` — POSIX-compatible on both. |
| `date` | `date +%s` only — identical on both. |
| `sed` | Substitution with `s///` only, no in-place. |
| `timeout` | **Not used.** The two textual hits are Python kwargs (`p.communicate(timeout=)`, `settimeout`); this host has no `timeout` binary, so a shell-level use would already have failed here. |
| `awk` | Appears in a comment only — the CSV parser is Python `csv`, not `awk -F', '`. |
| `xmllint` | Guarded by `command -v` (line 599) with a **disclosed SKIP**, so a CI image without libxml2 discloses rather than fails. |
| `python3` | Bare `python3`, but **stdlib only** (`hashlib, json, os, socket, subprocess, sys, time, csv`) — no PyYAML, which matters because the host `python3` lacks it. |
| Shell strictness | `set -u` only, **no `pipefail`** — so GNU's early-exit `grep -m1`/`head -1` cannot SIGPIPE a producer into a spurious failure. |

I also ran the suite's five portability gates against the lane tree — `bashsourcecheck`, `baselineportcheck`,
`infraportcheck`, `portablebuildcheck`, `shellgateindexcheck` — all **rc=0, zero FAIL lines**. These do **not**
stand in for a Linux run: three of them are language/boundary properties, one is cmake arch-flag selection
(`portablebuildcheck` drives `PortableFlags.cmake` via `RIPWIRE_PRETEND_LINUX=ON` — a build-config property,
not *this shell gate runs on Linux*), and `shellgateindexcheck` covers dependency indexing. None of them
executes `auditregresscheck.sh` under GNU coreutils.

**Verdict:** portability is argued from text and from the absence of every known divergence class in my own
runs; Linux **was** executed, by the fork's CI, on the full matrix. Locally it remains unmeasured, and that
limit is stated rather than papered over.

### 6.1 Instrument error worth recording

My first portability sweep reported `rc=127` on all five gates. The cause was my own command: I wrote
`bash test/$g.sh` while `$g` already carried `.sh`, so bash was asked for `test/bashsourcecheck.sh.sh` — a file
that cannot exist. A uniform failure across five unrelated gates is the signature of a broken instrument, not
five broken gates. Re-run with correct names: all green.

## 7. Two meta-gates caught the lane's new files — and both were MY defect

Train CI came back red in two classes, neither of them this gate's own assertions. I did not accept the account;
I reproduced both here, proved causation against the base, and fixed the real defects.

### 7.1 The discrimination, run locally and end to end

| Tree | `nulbytecheck` | `gitenvhermeticcheck` | Sweep population |
|---|---|---|---|
| base `50bc05e84` | rc=0, 0 FAIL | rc=0, 0 FAIL | **186** gates |
| lane head `55f33b55b` | rc=1 — `FAIL (a) embedded NUL in test/fixtures/audit-reef/minimal.docx at byte 5` | rc=1 — `FAIL (D) 187 gate(s) build a repo; auditregresscheck.sh do not source test/lib/clean-env.sh` | **187** |
| lane + fixes (`073f05acb`) | rc=0 | rc=0, `PASS (D) all 187` | 187 |

Base → green, lane → red, lane+fix → green. **Lane-caused**, and the sweep population moving 186 → 187 *is* this
lane's registration — the sweep found a real member rather than a phantom. This also settles the question the
verdict raised: it is **not** a BSD/GNU instrument split. Both gates fail here exactly as they fail on the
runners, which is what a GNU-vs-BSD artefact would not do.

### 7.2 `nulbytecheck` — the fixture stays, the extension gains a row

Arm (a) requires every tracked non-binary file to be NUL-free; `minimal.docx` is a real OOXML zip and carries
NULs at byte 5 *by construction*. My first instinct was that the fixture was unused weight — the gate never names
the file. **That instinct was wrong and I checked it before acting:** the spec requires it (`spec.md:59`, the
fixture tree combines "…and a `.docx`"), and the gate crawls the whole `FIXTURE` directory, so the binary
genuinely ingests it under the determinism, xmllint and ASan runs. Deleting it would have broken the spec to
silence a correct gate.

The fix is the documented mechanism: `.docx` joins `BINARY_EXTENSIONS` with its reason — the same treatment
`present/ripwire-showcase.pptx` already has, which is the identical container class. **Arm (c) is what keeps that
honest**: it fails any allowlist row not backed by a real tracked file, and it now passes with
`PASS (c) allowlist row .docx is backed by a tracked file`.

I also checked the row is **tight rather than merely working**, by driving the gate's own classifier:

```
test/fixtures/audit-reef/minimal.docx      -> EXCUSED
t/x.md                                     -> scanned
t/x.bin                                    -> scanned
t/x.DOCX                                   -> EXCUSED     (case-insensitive by design)
test/fuzz/readers/seeds/f                  -> EXCUSED     (directory row)
test/fuzz/readers/seedsX/f                 -> scanned      (prefix-bounded, not substring)
test/fuzz/readers/seeds_old/f              -> scanned
```

### 7.3 `gitenvhermeticcheck` arm (D) — the fix, and proof it does something

The convention is not stylistic. `git -C DIR` changes the working **directory** but not the **environment**, and
`GIT_DIR` / `GIT_WORK_TREE` / `GIT_INDEX_FILE` outrank it — so on a host where one is exported (a git hook
running the suite, `git rebase --exec`, a CI job) `git init` lands in somebody else's repo and every ownership
question is answered from data the gate never selected. This gate builds **three** throwaway repos — one in
shell at A4 (`:153`), two from Python (`:356`, `:436`) — and sourced nothing.

The fix is one line, placed after `ROOT` and before any repo construction:
`. "$ROOT/test/lib/clean-env.sh"`.

**Measured, not assumed.** Under a hostile `GIT_DIR` pointing at a foreign bare repo:

- shipped gate (with the line): **rc=0, 0 FAIL** — every arm passes.
- the same file with only that line stripped: **rc=1, SIX A4 failures** — `--owners exits 1`, `expected 6
  ownership rows, got 0`, empty owners on two rows, `churn=''`.

That is the difference between a gate that is hermetic and one that quietly reads the wrong repository. (My first
attempt at this counterfactual returned rc=2 with zero FAILs — the copy sat outside the repo so `ROOT`
mis-resolved and it bailed at the fixture check. A zero-failure exit that isn't a pass is the suspect-instrument
class again; re-run inside the tree, it discriminates.)

### 7.4 On the "producer's suite was green" reconciliation

The verdict's account is the one that fits: these two are repo-wide **sweep** gates living in the release-shard
lists — the ~8.5 h instrument's territory — while the producer's run covered the short list. The ruling that
Phase-4 exits on our gate's leg and leaves the full suite to the merge is thereby **vindicated empirically**: the
fork's CI is the instrument that caught what a short run structurally cannot. I am not claiming the short run was
sufficient; I am recording that it was not, and that this is where the difference showed up.

## 8. Commits

| Commit | Change | Files |
|---|---|---|
| `1dbdc44fc` | the gate + registration + fixture + changelog | 5, +737 |
| `df9f0d470` | arm B ASan leg checks both channels; skip names the path | 1, +11/−3 |
| `55f33b55b` | A1/cli row drops a stray double colon in `observed` | 1, +1/−1 |
| `c6d197a93` | `.docx` joins `BINARY_EXTENSIONS`, with its reason | 1, +9 |
| `073f05acb` | source `test/lib/clean-env.sh` before building any repo; changelog | 2, +16 |

All five test-only. `git diff --stat 50bc05e84..HEAD -- src/` is **empty**; the diff is 6 files, +774, and every
one is under `test/`, `changelog.d/`, or both.

**Two of those files are base-suite meta-gates** (`test/nulbytecheck.sh`, and this lane's own `test/auditregresscheck.sh`).
Changing a shared gate is not free, so both were re-verified in the same sweep as the gates that neighbour them:
`nulbytecheck`, `gitenvhermeticcheck`, `auditregresscheck`, `attrvocabcheck`, `barrelshortkeycheck`,
`manifestcheck` — all **rc=0, zero FAILs**. `nulbytecheck` prints `ALL PASS` across all five of its arms,
including arm (d)'s prefix-anchoring negatives.

## 9. Scratch instruments

`sri-mutant` (538 MB + its build) and `sri-base` (the flake-control worktree) are reclaimable now that the
Phase-4 gate verdict is settled; the operator's word was "hold until Phase-4 validation", and that validation
is complete for this lane's own gate. Say the word and I will remove them.
