# Phase 0 — `security-regression-integration`: pinned anchors + red baselines

**Seat:** LOCAL producer (Deepseek-V4.1-Flash "-1017"), WorkBuddy AI on the operator's Mac
**Checkout:** `/Users/rna/ripwire-scratch/sri-r1`, branch `lane/security-regression-integration` at `50bc05e84`
**Binary:** `./build/ripwire` — `ripwire 0.6.9 (dev, AppleClang 16.0.0.16000026, emit=std::print, built_from=50bc05e84)`, rc=0, 15m12s, **self-built this seat** (first in the seat's history)
**Date:** 2026-11-06
**Logs:** `~/ripwire-scratch/logs/sri-{a1b,a2,a3,a4,a5}/`

---

## 0. Headline

Phase 0 was told to "VERIFY each anchor live … it does not re-design". Verification produced
**five corrections, one of which makes a specified acceptance criterion unimplementable as written**
and **one of which is a red finding at base that this test-only lane cannot turn green.**

| # | Correction | Severity | Consequence |
|---|---|---|---|
| C1 | **A2 is RED at base on bare stdio** — the edit escapes the workspace | **BLOCKER** | AC-2's premise contradicts the shipped contract; src-level, out of lane scope |
| C2 | **A5's boundary is the wrong cap on the wrong transport** | major | AC-5 as literal is red at base; the *property* is live at the right boundary |
| C3 | **A1 has no MCP transport to repel on** — no verb takes a regex | major | "both transports" is unsatisfiable without a feature |
| C4 | **A3's attack cannot be mounted** — CSPRNG temp name, O_EXCL, already gated | moderate | the arm becomes a regression guard, not a live attack |
| C5 | **A1b/A5h arm mechanics** — listener pin, headers-first read | minor | arm wording; two measured traps |

C1 and C2 and C3 are **relays, not lane work**. No `src/` change is in scope and none was made.

---

## 1. Pinned anchors (re-verified on THIS checkout; content match, line numbers re-pinned)

### A1 — `patternAdmission` ← regex-screen-hardening
- `src/regexguard.h:732` — `"branches the structural screen cannot PROVE are disjoint. A branch carries no quantifier of its own, so the "` (the refusal body)
- `src/regexguard.h:313` — `catastrophicRegexPrologue( char outerQuant )`; used at `:322`
- **Live wording (measured, CLI):**
  `ripwire: --regex='<pat>' refused, nothing was scanned: catastrophic backtracking: the unbounded quantifier '+' is applied to an alternation whose branches the structural screen cannot PROVE are disjoint. … (a hits="0" here would be a failure, not a measurement — fix the pattern, e.g. ripwire <dir> --regex='fnv1a\w+')`
- **Lead-in discriminator (unchanged, still the only usable one):** `refused, nothing was scanned:` (structural screen) vs `refused, no hit is reported:` (abandonment). Exit status, the bare word `refused`, and `catastrophic backtracking` all remain unusable as discriminators.

### A2 — `editPathAdmission` ← edit-workspace-pin (RETIRED)
- `src/mcp.h:1921` — HTTP pin refusal: `"path is outside this server's workspace (this listener serves one fixed workspace, pinned at startup) — omit \`path\` to use it, or run a second server for the other tree"`
- `src/mcp.h:1950` — stdio startup-root refusal: `errResult( -32602, "path outside workspace; start the server on that root or pass an absolute in-root path" )`
- `src/mcp.h:1944` — **the gate**: `if( !pathsUsageError && policy.pinnedRoot.empty() && !policy.defaultRoot.empty() )`
- `src/mcp.h:1950` — `isMcpEditVerb( name ) && !mcpPathInsideRoot( policy.defaultRoot, path )`
- `src/mcp.h:3074` — `mcpStdioPolicy`: `defaultRoot` is set **only** from `config.roots`/`config.root`; a bare `ripwire --mcp` falls to `assumedRoot` (`:3078`)
- `src/mcpedit.h:1286` — symlink refusal: `"refusing to edit '<path>': it is a symlink, and editing through it would replace …"`

### A3 — `atomicPublish` ← atomic-write-tempfile (RETIRED)
- `src/mcpedit.h:739` — `rw::pathguard::ExclTempFile temp = rw::pathguard::createExclTempFile( path + ".", ".tmp", 0644 );`
- `src/pathguard.h:361` — `randomTempSuffix()`: **12 bytes from `/dev/urandom`**, hex-expanded to 24 chars (`:398–405`); `std::random_device` fallback only when urandom cannot be read
- `src/pathguard.h:507` — `createExclTempFile( prefix, suffix, mode )`: **8 attempts**, retry only on `EEXIST`
- `src/pathguard.h:410` — `openExclNoFollow`: `O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC`
- **Pre-existing gate:** `test/tempfilesymlinkcheck.sh`, registered at `test/regression.sh:991`. Its header already states the hedge: the arms *"do NOT drive a collision at the random name the writer actually draws — that name cannot be chosen from outside without a hook in product code."*

### A4 — `gitRecordFraming` ← git-porcelain-framing
- `test/gitframingcheck.sh:118` — `attr_of(){ tr '>' '\n' < "$1" | psel "$2" | grep -oE "$3=\"[^\"]*\"" | head -1 | sed 's/^[^"]*"//; s/"$//'; }`
- `test/gitframingcheck.sh:153–158` — fixture battery: `__C__`, `__C__ 1694000000.cpp`, `__C__.cpp`, `__C__x|1694000000.cpp`, `q"uote.cpp`, `sp ace.cpp`, `back\slash.cpp`, `pi|pe.cpp`, `--dashdash.cpp`, `a<LF>b.cpp`
- Assertions consumed read-only at `:284–290` (`__C__x|1694000000.cpp` owned by `real@x.com`; `a&#10;b.cpp` one path)

### A5 — `boundedStdioLine` ← stdio-request-cap (RETIRED) — **two different caps**
- **HTTP** (`src/mcpserver.h`): `:59` `kMaxHeaderBytes = 64u*1024u → 431`; `:60` `kMaxBodyBytes = 8u*1024u*1024u → 413`; `:311` refuses on `contentLength` **before reading the body**; `:608` `respond( fd, "413 Payload Too Large", …, jsonRpcError( -32600, "request body exceeds the 8 MB limit" ) )`
- **stdio** (`src/mcp.h`): `:3009` `kMcpStdioLineMaxBytes = 33554432` (**32 MiB**); `:3020` refusal `{"jsonrpc":"2.0","id":null,"error":{"code":-32600,"message":"request line exceeds the {}-byte limit"}}`

### Registration slot (unchanged, verified)
`test/regression.sh:321` `attrvocabcheck \` / `:322` `barrelshortkeycheck \` — the new line goes between them.

### Counts (via the generator, not a grep)
`python3 docs/gatecount_build.py --check` → **"the loop in test/regression.sh names 761 today"**; snapshot 2026-11-03 says 753. `counts_snapshot.py check --max-drift` → **within bound** (`gates.scripts` MAX_DRIFT 10; 761−753 = 8, +1 for my gate = 9). No refresh needed for this lane.

---

## 2. Red baselines — measured, not inferred

### A1 CLI — **contract live, repelled** ✅
`./build/ripwire test/fixtures/audit-reef --regex='<pat>'` over the 130,650-byte single-line fixture:

| pattern | rc | wall | lead-in |
|---|---|---|---|
| `^(a|aa)+b$` | 1 | 0.13 s | `refused, nothing was scanned:` |
| `(x|xy)+c$` | 1 | 0.03 s | `refused, nothing was scanned:` |
| `(\w|\d)+$` | 1 | 0.03 s | `refused, nothing was scanned:` |

All three carry the full PROVE wording verbatim. Well inside the 60 s hang bound.

> **A methodology note that cost this seat a wrong first reading:** the CLI has **no `grep`
> subcommand**. `ripwire grep <pat> <dir>` answers `root path does not exist: grep`, and
> `ripwire <dir> grep <pat>` does the same — the verb is `--regex=PAT` / `--grep=STR`. A first pass
> at this arm used the subcommand form and would have recorded "no refusal" for the wrong reason.
> Arm A1 must use `--regex=`.

### A1 over HTTP — **not available; this is not a refusal** ⚠️ C3
Listener pinned at the fixture, all three bombs:

```
A1b[0] ^(a|aa)+b$  wall=0.01s  result: files=0 total=0 complete=true pattern_meta="| ^$"
A1b[1] (x|xy)+c$   wall=0.00s  result: files=0 total=0 complete=true pattern_meta="|"
A1b[2] (\w|\d)+$   wall=0.00s  result: files=0 total=0 complete=true pattern_meta="\\"
control  aaaaaaaaaa  0.03s  total=1 complete=true     ← positive control: the fixture IS scanned
control  b           0.00s  total=1
control  ZZZNOHIT    0.00s  total=0
```

The bombs return an **ordinary empty answer**, and the positive control proves the tree was scanned —
so this is neither a refusal nor a vacuous zero. It is the literal-only verb: `src/mcpverbs.h:1324`
`grepCollect( ing, pattern, /*regex=*/false, … )`, `:1343` same for the aux pass. A tree-wide search
for a wire field matching `"[a-z_]*regex[a-z_]*"` in the MCP surface returns **nothing**, and the
`tools/list` schema for `grep` is `['path','paths','pattern','in','limit','offset']` — no regex.

**No MCP verb accepts a regex.** AC-1's "refused or bounded-degraded … on both transports" has no
MCP leg to satisfy.

Two further measured facts for the arm:
- **The listener pins ONE workspace at startup.** A `path` naming any other tree is refused at
  `src/mcp.h:1921` **before** the verb runs: `path is outside this server's workspace …`. So A1b
  must launch `ripwire <fixture> --listen=…` and **omit `path`** (or pass the pinned root); a bare
  `path:"."` from a server started on the repo root is that same refusal.
- Port 0 is refused (`"want HOST:PORT or PORT, 1..65535"`) → probe-and-retry is mandatory, as the
  spec's failure-mode note already says.

### A2 — **RED at base on bare stdio** 🔴 C1
Fixture: `A/local.c` (git repo), `B/victim.c`, server launched **bare** from `A`.

```
victim BEFORE : 2f54c03f63fc650b41b97f03bb2899793dfec92b08cd7fd9465c1e9931e71609
  request     : tools/call replace_symbol_body { path:"../B", file:"victim.c", symbol:"targetFn",
                                                new_body:"int targetFn( int x ) { return 999; }" }
  response    : result  (NOT an error) — applied:"replace_symbol_body", file:"victim.c",
                root:"../B", blob_sha:65a2edb9…, note:"index invalidated; the next verb call rebuilds from disk"
victim AFTER  : 69342e8fd70b6a2bd44bcd154d4fa6b00d3d332433b1d30086078191f7e6da14
victim bytes  : int targetFn( int x ) { return 999; }
```

**Reproduced from a clean restore** (second run, `return 6666` → `770e0ca2…`). The escape is
**silent**: the envelope is `['jsonrpc','id','result']` — no `_assumed_root`, no refusal, no
disclosure. The frame *echoes* `"root":"../B"` as though editing a neighbouring tree were routine.

**Same attack, the other launch forms:**

| launch | response | victim |
|---|---|---|
| `ripwire A --mcp` (startup root) | `-32602 path outside workspace; start the server on that root or pass an absolute in-root path` | **unchanged** |
| `ripwire --mcp` (bare, cwd=A) | **applied** | **CHANGED** |
| `ripwire A --listen=… --mcp-token=…` (no `--allow-remote-edits`) | `-32602 path is outside this server's workspace …` | **unchanged** |
| `ripwire A --listen=… --allow-remote-edits` | `-32602 path is outside this server's workspace …` | **unchanged** |

**Cause, from the code (not guessed):** `src/mcp.h:1944` gates the stdio edit pin on
`!policy.defaultRoot.empty()`. `mcpStdioPolicy` (`:3074`) sets `defaultRoot` only when a startup
root or a 2+ root set was given; a bare `ripwire --mcp` sets `assumedRoot` instead — the *softest*
tier — which never enters the pin. The comment at `:1942` states the intent explicitly:
edit-verb refusal on an explicit outside path applies "ONLY for the 3 EDIT verbs — read verbs stay
unrestricted, matching stdio's existing **'a request may name any path'** contract".

So this is **documented behaviour, and the AC asserts its opposite.** Two readings, and the choice
is the PM's:
- **(a) AC-2 is mis-specified.** The contract that *is* live is the startup-root form
  (`ripwire A --mcp` → `-32602 path outside workspace`) and the HTTP form. Arm A2 tests those, all
  rows go `repelled`, AC-8 holds, lane stays test-only. The bare-stdio write-anywhere goes to a
  separate src-level spec.
- **(b) The bare form is the finding.** Then A2 cannot be green without a `src/` change, which is
  explicitly out of this lane's scope ("zero `src/` files; a src-looking need is a relay, not a lane
  extension"). The lane would have to ship a red row or block.

**This seat's recommendation: (a)**, with (b) relayed as a new finding. Either way it is a relay,
not lane work, and I have made no `src/` change.

### A3 — **contract live, but the attack cannot be mounted** ✅ / C4
Six symlinks planted at every predictable old shape, all → `outside.txt`:
`subject.c.{$$,0,1,2,tmp,XXXXXX}.tmp`

```
overlap  BEFORE: 1aade896593dd3ec3a85b9d6f861bfa81433986f8ed24f4388d4984cd09673c3
subject  BEFORE: 8b7cc48da42670436453eb5ff7335314d9902b031d71b863c14e4bb186fa9583
  edit: replace_symbol_body { path:".", file:"subject.c", … }  → applied, span {0,45}
overlap  AFTER : 1aade896593dd3ec3a85b9d6f861bfa81433986f8ed24f4388d4984cd09673c3   UNCHANGED
overlap  bytes : ORIGINAL-EXTERNAL
subject  AFTER : 6ebad7fe25e166f7145d85a99418312a66bfc14db520438ef0adfa2ad35e3341   changed (edit published)
temp residue   : none
```

**A new disclosure observed during the run** (worth pinning in the arm, it is an honest answer from
the crawl, not the edit):
`[math degraded] ingest: a symlink's target leaves the crawl root — file refused (see --skipped why=escaped-root)  (ingest_crawl.h:1277, recordRootEscape)`

The arm cannot be the live attack the spec describes: the real name is 24 hex chars of `/dev/urandom`
entropy, created `O_EXCL|O_NOFOLLOW` with 8 `EEXIST` retries, so no name can be pre-planted; and
`test/tempfilesymlinkcheck.sh` is **already registered** at `regression.sh:991` and says so in its
own header. What remains testable — and worth having — is a **regression guard at the old
predictable shape**, plus the "edit still publishes, victim byte-identical, no residue" triple.

### A4 — **contract live, repelled** ✅
Minimal hostile-name repo at `gitframingcheck`'s own shapes (7 files, one pinned commit):

```
rows: 6   (7 files, `__C__` is extension-less and unindexed BY DESIGN — matches the gate's own note)
true-author rows: 6/6
forged author "x" occurrences: 0

__C__x|1694000000.cpp      top=real@x.com
__C__.cpp                  top=real@x.com
a&#10;b.cpp                top=real@x.com     ← one path, XML-escaped, not split into `a` and `b.cpp`
pi|pe.cpp                  top=real@x.com
sp ace.cpp                 top=real@x.com
Alpha.cpp                  top=real@x.com
```

`--for=nlFn` reports `churn="1"` on `p="a&#10;b.cpp"` — one path, one commit. Attribution holds;
no spoof survives.

### A5 — split verdict ⚠️ C2

**HTTP — 413 live, boundary exactly `8388608`:**

| body | status | body |
|---|---|---|
| 8388608 (`cap`) | `400 Bad Request` | `malformed HTTP request` (the 8 MiB of `x` is not valid JSON — the cap did *not* fire) |
| 8388609 (`cap+1`) | **`413 Payload Too Large`** | `{"jsonrpc":"2.0","id":null,"error":{"code":-32600,"message":"request body exceeds the 8 MB limit"}}` |
| 9437184 (`9 MiB`) | **`413`** | same |
| after all three | `HTTP/1.1 200 OK`, `tools/list` answers | server alive ✅ |

**stdio — 9 MiB is SERVED, not refused:**

| line | frames | outcome |
|---|---|---|
| 9 MiB | 2 | `id:1` **`result`** (the pattern is echoed back as a normal answer), `id:2` `tools/list` result |
| 33 MiB | 2 | `id:null` **`-32600 "request line exceeds the 33554432-byte limit"`**, then `id:2` `tools/list` result ✅ |

The dispatch note folds two caps into one arm ("the 8 MiB line cap … 413 wording"). They are different
transports with different limits: **HTTP 8 MiB → 413; stdio 32 MiB → -32600 line refusal.** AC-5's
"9 MiB line → exactly one framing error" is **red at base on stdio** and green on HTTP. The *property*
the spec actually cares about — **one error, then a healthy next request** — is live, at each
transport's own boundary.

Arm wording should therefore split into **A5h** (HTTP, `cap+1`, assert `413` + the 8 MB sentence +
`tools/list` answers) and **A5s** (stdio, `>32 MiB`, assert exactly one `-32600 "…33554432-byte
limit"` + the following `tools/list` answers). Both properties are asserted; neither bound is faked.

### A5h / A1b arm mechanics — C5
`gatehttp.post( port, 9MiB-body )` **reports `Broken pipe`** (`HTTP request failed after 0 response
bytes`) even though the server answered `413` correctly: a 9 MiB `sendall` races the server's
`Connection: close`. The refusal happens on `Content-Length` at `src/mcpserver.h:311`, **before the
body is read**. The arm must either send headers first and read the answer before the body, or use a
raw socket. `gatehttp` is still the right client for every normal-size request; it is only the
over-cap arm that needs the headers-first shape.

Second trap: omitting `Accept: application/json, text/event-stream` gets a `406 Not Acceptable` — an
"is the server alive" probe that drops the header reports a false death.

---

## 3. Report-format literal (proposed, for PM ruling)

Spec contract (unchanged, 6 columns, one line per row):
`attack_id, transports, expected_refusal_shape, observed_outcome, wall_time, verdict`
AC-8's verifier: `^A[1-5],` rows + trailer lines.

Proposed concrete literal — one row per **(attack, transport)** pair, because a single row per attack
cannot honestly hold a split verdict:

```
# ripwire auditregresscheck — security-regression-integration
# columns: attack_id, transports, expected_shape, observed, wall, verdict
A1, cli,  "refused, nothing was scanned: catastrophic backtracking", "refused, nothing was scanned: catastrophic backtracking (rc=1, hits=0)", 0.13s, repelled
A1, http, "n/a — no MCP verb takes a regex", "grep is literal-only (grepCollect regex=false); bombs answer files=0 complete=true", 0.00s, not-applicable
A2, stdio+startup-root, "-32602 path outside workspace", "ERROR -32602 path outside workspace; … | victim sha256 unchanged", 0.31s, repelled
A2, stdio+bare,        "-32602 path outside workspace", "RESULT applied … victim sha256 2f54c03f→69342e8f CHANGED", 0.28s, red
A2, http,              "-32602 path is outside this server's workspace", "ERROR -32602 … | victim sha256 unchanged", 0.42s, repelled
A3, stdio,             "victim byte-identical; edit applied; no temp residue", "victim 1aade896 unchanged; subject 8b7cc48d→6ebad7fe; residue=none", 0.30s, repelled
A4, cli,               "__C__x|1694000000.cpp → top=real@x.com; a<LF>b.cpp one path", "6/6 rows top=real@x.com; forged \"x\" ×0; churn=1", 0.55s, repelled
A5, http,              "413 + \"request body exceeds the 8 MB limit\"", "413 Payload Too Large + sentence; tools/list 200 after", 0.04s, repelled
A5, stdio,             "-32600 \"request line exceeds the 33554432-byte limit\", once", "one -32600 at 33 MiB; next tools/list answers", 3.45s, repelled
# trailer
suite: pargates=… determinism=… xmllint=… asan=…
binary: ripwire 0.6.9 (dev, …, built_from=50bc05e84)
```

**The tension the PM must rule on:** AC-8 requires "each row `repelled`". With C1 as it stands, the
`A2, stdio+bare` row is **red** and `A1, http` is **not-applicable**. Under recommendation (a) —
repair AC-2 to the startup-root form and drop the A1-http row — every remaining row is `repelled`
and AC-8 holds with no change to the column contract. Under (b), AC-8's "each row repelled" must be
relaxed to "each row `repelled` or disclosed non-applicable", which changes the contract
`audit-validation-standalone` greps.

I am not altering the column shape; that contract is the consumer's.

---

## 4. Arm wording (tightened against measurement)

**A1 (CLI)** — `--regex=PAT` (never a `grep` subcommand). Assert the **lead-in**
`refused, nothing was scanned:` ∈ stdout, `rc=1`, and wall < 60 s, for all three patterns, over
`test/fixtures/audit-reef/`. The lead-in is the discriminator; `catastrophic backtracking` alone is
not.

**A1b (HTTP)** — *conditioned on C3*. If kept: launch `ripwire <audit-reef> --listen=127.0.0.1:$PORT
--mcp-token=$TOK`, **omit `path`**, POST the three bombs, and assert each answer is a **structured
empty result with `complete=true`** — i.e. the literal-only verb neither refuses nor hangs — plus a
following `tools/list` answering. Do **not** assert a refusal; there is none to assert.

**A2 (stdio)** — two arms, not one:
- `A2a` startup-root: `ripwire "$A" --mcp`; assert `-32602` and the substring
  `path outside workspace` **and** `sha256(B/victim.c)` unchanged.
- `A2b` bare: `ripwire --mcp` from `$A`; this is the C1 finding. Under (a) it is not in the suite;
  under (b) it asserts the escape and the suite is red by design.

**A2h (HTTP)** — `--listen` + token, `path="../B"`, assert the `path is outside this server's
workspace` substring and unchanged sha256. Verified to refuse **with and without**
`--allow-remote-edits`.

**A3** — plant the six old-shape symlinks; assert (i) victim sha256 unchanged, (ii) the edit still
reports `applied`, (iii) no non-symlink `*.tmp` residue. Word it as a **regression guard**, not a
live attack; note in the header that the real name is CSPRNG and `tempfilesymlinkcheck.sh` owns the
live half.

**A4** — fixture repo at `gitframingcheck`'s shapes, expectations read from that gate's literals (not
re-typed). Assert: 6 rows, all `top="real@x.com"`, zero `="x"` occurrences, `a&#10;b.cpp` present as
ONE row, `churn=1` for the newline file.

**A5h (HTTP)** — headers-first raw exchange at `cap+1`; assert `413`, the sentence
`request body exceeds the 8 MB limit`, then `tools/list` → 200 with `"result"`. Do not use
`gatehttp.post` at this size.

**A5s (stdio)** — 33 MiB line; assert **exactly one** frame with `-32600` and
`request line exceeds the 33554432-byte limit`, then the following `tools/list` answers.

**Every arm** — `BIN="${1:-${RIPWIRE_BIN:-$ROOT/build/ripwire}}"`; victims sha256'd before/after;
walls recorded but only bounded at 60 s.

---

## 5. Discrepancies found and NOT acted on

1. **`docs/counts.tsv` is stale** (2026-11-03: `gates.scripts` 753 vs 761 live). Within
   `MAX_DRIFT 10`, so `gendocsmergecheck` is green; no refresh needed for this lane and I did not
   refresh it (that would be an unrelated doc change in a test-only lane).
2. **`src/mcp.h:1942`'s comment vs AC-2** — the comment is the authority on intended behaviour and
   it says the opposite of the AC. Relayed, not edited.
3. **A5's dispatch wording conflates the two caps.** Relayed.
4. **The `[math degraded] ingest: a symlink's target leaves the crawl root` line** appears on stderr
   during A3. Not a defect — an honest disclosure — but a gate capturing only stdout would miss it
   and a gate asserting "no stderr output" would false-red. Noted for the arm.

---

## 6. State

- Branch `lane/security-regression-integration` at `50bc05e84`; **nothing committed yet**.
- Untracked: `test/fixtures/audit-reef/minified-oneline.js` (130,650 bytes, 1 line — the `(a|aa)+`
  bomb's subject).
- Binary provenance: `built_from=50bc05e84`, rc=0, 15m12s, self-built.
- Disk: 3.5 GiB free. ASan dir (~1.4 GiB) not built — deferred to Phase 3, and only after the PM's
  word, since the disk is the thin resource.
- No `src/` file touched. No manifest edit. No ship key used.

**Awaiting the PM's ruling on C1 (a or b), C2 (arm split), C3 (drop the A1-http leg or assert the
empty-result contract), and the AC-8 tension in §3, before Phase 1.**
