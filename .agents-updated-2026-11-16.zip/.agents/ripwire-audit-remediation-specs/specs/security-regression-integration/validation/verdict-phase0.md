# Phase-0 Verdict — security-regression-integration (the dispatcher's fold, 2026-11-06)

**Verdict: ACCEPTED with corrections, and the blocker is ruled on.** Phase 0 did exactly what
Phase 0 exists to do: verify every anchor live before code exists, and surface premise breaks
cheaply. Four owed items delivered in full (anchor re-pins, red baselines on a self-built
binary, tightened arm wording, the report literal); five corrections (C1–C5) found, measured,
and correctly relayed rather than lane-fixed. No `src/` file touched, no manifest edit, no ship
key used — the boundary held.

## The independent verification (this seat, not the producer's report read back)

Every load-bearing claim reproduced first-hand on the producer's self-built binary
(`built_from=50bc05e84`, verified via `--version`):

- **C1 (the blocker) CONFIRMED.** My own fixture, my own sha pair: bare `ripwire --mcp`,
  cwd=C, `replace_symbol_body {path:"../V"…}` → **applied**, victim
  `dfa60fd3…→9566cdc4…` (return 1 → return 4242), envelope `['jsonrpc','id','result']` — no
  refusal, no disclosure, frame 3 a healthy `tools/list` (the server not even degraded).
- **The pinned forms refuse (ruling (a)'s linchpin, verified both ways):**
  `ripwire <C> --mcp` (positional startup root) → `-32602 "path outside workspace; start
  the server on that root or pass an absolute in-root path"`, victim unchanged; HTTP
  listener pinned to C, `path:"../V"` → `-32602 "path is outside this server's workspace
  (this listener serves one fixed workspace, pinned at startup) — …"`, victim unchanged.
- **All code sites read first-hand**: the `:1944` gate `!policy.defaultRoot.empty()` + the
  `:1941–43` tier-split comment ("a request may name any path" — intended behavior); the
  R2a `assumedRoot` block `:3074–78`; the two caps (`kMaxBodyBytes` 8 MiB → 413 at
  `mcpserver.h:311/608`; `kMcpStdioLineMaxBytes` 33554432 at `mcp.h:3009/3020`); the
  `mcpverbs.h` `/*regex=*/false` pair; the `pathguard.h` CSPRNG/O_EXCL|O_NOFOLLOW/8-EEXIST
  trio; `tempfilesymlinkcheck` at `regression.sh:991`.
- **A1 CLI reproduced live** (all three bombs, PROVE wording, lead-in as the discriminator).
- **A4's units** verified against the gitframingcheck literals (`:153–158` shapes, `:284–290`
  assertions — consume read-only).

## The rulings

- **R1 (C1): option (a) ADOPTED — the (b) option is denied, not deferred.** AC-2 is repaired
  to the shipped contract (the pinned tiers); the bare-stdio escape is **SRI-F1**, filed at
  `../findings/stdio-bare-edit-escape.md` with both seats' reproductions. Reasoning: the
  harness reports shipped behavior; a permanently red row is an issue tracker, not a gate;
  and this lane's test-only constraint is load-bearing — the escape needs a `src/` fix that
  the lane forbids and the DAG will spec separately. **SRI-F1 becomes the proposed spec
  `stdio-bare-edit-escape`** (type: unit; enters the DAG on the operator's word — Q9
  precedent: producers disclose, operators rule nodes).
- **R2 (C2): ADOPTED** — arm split A5h/A5s. Two caps, two transports, two bounds; a 9 MiB
  stdio line is INSIDE the shipped bound (served, correctly — NOT an attack row).
- **R3 (C3): the drop and the assert, COMBINED** — drop the "A1 refused on HTTP" leg; the
  arm asserts the transport-safety fact instead (structured empty + mandatory positive
  control + responsive server). The bombs-not-refused fact on HTTP is the honest shape.
- **R4 (C4): ADOPTED** — A3 as a regression guard at the historical shapes, the live half
  owned by `tempfilesymlinkcheck` (its own header says so). The `escaped-root` stderr line
  is an honest disclosure, tolerated by the arm.
- **R5 (C5): ADOPTED** — headers-first exchange for the over-cap HTTP arm; `Accept:
  application/json, text/event-stream` on every liveness probe.
- **AC-8: HOLDS under the repairs** — per-pair rows, all `repelled`, the
  audit-validation-standalone grep untouched. The column contract is the consumer's; the
  producer was right to refuse changing it.
- **ASan (Phase 3): GRANTED, deferred to Phase 3 with the disk word.** Disk was 3.5 GiB at
  report time — the ~1.4 GiB asan dir is the single largest Phase-3 line-item. The operator's
  reclaim-set word (rmq-r1 1.0G et al.) clears the disk question entirely; my recommendation
  stands: give the word, and consider the pm-verify-r1 (505M) and rmq-base (470M) items —
  the two smallest sufficient to make Phase 3 comfortable.