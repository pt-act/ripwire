# Discrimination proof — SRI integration gate vs. a six-mutation binary

**Question this answers.** A gate that passes proves nothing until it is shown to FAIL when the behaviour it
guards is removed. Every arm here is checked against a binary built with its own fix reverted.

- Shipped binary (lane base `50bc05e84`, clean): **PASS**, 8/8 rows `repelled` — `logs/sri-shipped-postfix2.log`
- Mutant binary (`50bc05e84+dirty`, six reverts): **14 failures**, 6/8 rows `unproven` — `logs/sri-mutant-run2.log`
- Mutant source: `~/ripwire-scratch/sri-mutant` (full build, 34 min, `-DCMAKE_BUILD_TYPE=Release`)

| # | Reverted behaviour | Site | Arm | Mutant result | Discriminates |
|---|---|---|---|---|---|
| M1 | CLI screen reports refusal (`return 1` → `return 0`) | `src/verbs_grep.h:998` | A1/cli | `rc per pattern = 000` → `unproven` | **yes** |
| M2 | Startup-root edit pin disabled (`else if( false )`) | `src/mcp.h:1944` | A2/stdio | `code=none (no refusal answered); victim CHANGED` → `unproven` | **yes** |
| M2′ | **carried** — no revert of its own (see below) | red OBSERVED at `src/mcp.h:1921` | A2/http | `victim CHANGED in both states` → `unproven` | **carried red** |
| M3 | `O_EXCL`/`O_NOFOLLOW` dropped from the atomic create | `src/pathguard.h:414` | A3/stdio | **still `repelled`** | **no — by design** |
| M4 | Author email → committer email (`%ae` → `%ce`) | `src/gitmine.h:1104` | A4/cli | `committer-email rows 1; spoof top=committer@x.com` → `unproven` | **yes** |
| M5 | HTTP body cap 8 MiB → 16 MiB | `src/mcpserver.h:60` | A5/http | `400 Bad Request (no 8 MB sentence)` → `unproven` | **yes** |
| M6 | stdio line cap 32 MiB → 64 MiB | `src/mcp.h:3009` | A5/stdio | `-32600 (NOT answered); refusals measured: 0` → `unproven` | **yes** |

**Six** reverts, **six** discriminating arm-results of which **one is carried**, and one documented
non-discrimination.

## M2′ is a CARRIED red, not a revert site (corrected per the Phase-1 verdict)

The mutant diff carries exactly **one** edit-pin revert — the startup-root stdio gate at `mcp.h:1944`. There is
**no HTTP-tier revert in the mutant**, and the mutant's HTTP tier still refuses correctly: `-32602` with the
exact contracted sentence, in both `--allow-remote-edits` states.

So `src/mcp.h:1921` is where the A2/http red is **OBSERVED**, not a site where behaviour was reverted. The
red is the **carried** effect of M2's stdio escape through the shared A2 fixture: A2a runs first and writes the
victim, then A2h refuses correctly but its `sha(victim) == before` probe compares against the **pre-A2a** hash
and fails. The refusal itself was never broken.

A carried red is safe by construction: it can only add red on a broken binary, never mask one. The accounting
therefore stands at six reverts / six red arms, with M2′ named as the observation point of a carried effect —
the earlier "seven discriminating arm-results" figure double-counted it as an independent revert.

## M3 is a boundary, not a gap

A3 is worded in the spec as a **regression guard**, and this is why. The shipped temp name is 24 hex chars drawn
from `/dev/urandom` and created `O_EXCL|O_NOFOLLOW` with 8 retried draws (`pathguard.h:361-410,507-523`), so the
six historical shapes the arm plants (`subject.c.{$$,0,1,2,tmp,XXXXXX}.tmp`) can never collide with a name the
binary will draw. Removing `O_EXCL` therefore does not make *this arm's* attack land — the collision is what
protects it, not the flag.

The half that owns M3 is `test/tempfilesymlinkcheck.sh`, which drives the primitives directly through a program
compiled against `pathguard.h`. Run inside the mutant tree it fails four rows:

```
FAIL  (f1) openExclNoFollow refuses an existing symlink at its name with EEXIST
FAIL  (f1) the link and the file it points at are unchanged
FAIL  (f2) openExclNoFollow refuses a dangling symlink and creates nothing at its target
FAIL  (f3) openExclNoFollow refuses an existing regular file and leaves it unchanged
```

So the behaviour IS gated, by the gate the spec names for it. A3's job is narrower and it is stated in the gate
header: keep the HISTORICAL predictable shapes dead and prove the edit still publishes. Asserting M3 there would
require pre-planting a CSPRNG name, which is impossible by construction.

**A note on instrument discipline.** The first run of that unit gate was made from `sri-r1`, whose `$ROOT/src`
is the clean tree — so its probe compiled against clean headers and passed. A gate that compiles against the
tree it sits in must be RUN from that tree. Re-run inside `sri-mutant`, it fails as above. This is the same
class as the earlier `grep`-subcommand and `$c:t` incidents: the ruler was wrong, not the thing measured.

## Two defects the discrimination run exposed (and how they were fixed)

**1. The A4 fixture could not tell the author from the committer.** Both `GIT_AUTHOR_EMAIL` and
`GIT_COMMITTER_EMAIL` were `real@x.com`, so M4 — an attribution field swapped from `%ae` to `%ce` — answered
identically and A4 passed. The fixture now commits as two different people (`real@x.com` author,
`committer@x.com` committer) and asserts the committer email appears in ZERO rows. Without this, the gate would
have shipped a green row over a broken attribution.

**2. Several `observed` fields stated shapes they had not measured.** On the mutant, A5/stdio printed
`-32600 request line exceeds the 33554432-byte limit (x1)` beside a check that said `got 0`; A2/http printed
`-32602 path is outside this server's workspace` beside a `victim CHANGED` failure. These were constructed
strings, not measurements — the report said what the contract wanted rather than what happened. Every row now
reports only what it observed (`code=<actual>`, `refusals measured: <n>`, `control=<n>`, `rc per pattern = 111`),
and `row()` enforces the relation at write time: a `repelled` verdict whose expected shape is not a real
substring of its observed text is downgraded to `unproven` and named.
