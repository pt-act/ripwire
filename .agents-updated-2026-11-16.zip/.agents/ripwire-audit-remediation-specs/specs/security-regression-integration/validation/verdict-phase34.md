# Phase-3+4 Verdict — security-regression-integration (the dispatcher's fold, 2026-11-06)

**Verdict: ACCEPTED — Phases 3 and 4 complete per the errata'd contract; the lane is terminal-validation
ready (the upstream PR question is a separate act).** Every load-bearing claim re-proven by this seat's own
runs. Two corrections landed this round — one on the producer's ledger (verified fixed, and now measured by
them, not just accepted), and one on a standing fact BOTH seats had banked wrong (the CI matrix shape —
caught by this seat's empirical probe, detailed below). The producer's three open asks are all ruled.

## The independent verification (nothing read back)

**The two new commits.** `df9f0d470` (arm B's ASan leg: BOTH channels — exit status AND no sanitizer banner
on stderr; the SKIP names the tried path) and `55f33b55b` (the A1/cli row drops the stray `:;` — cosmetic,
row content re-proven). Both test-only (the base..HEAD `src/` diff is still EMPTY, 5 files +745 at
`55f33b55b`), both `pt-act`, push-absence held until this seat's ship-key act below. The ASan build's stamp
`built_from=1dbdc44fc` is honest — built 17:22 against `1dbdc44fc`, whose src is byte-identical to HEAD by
that same empty src diff.

**The gate, re-run by this seat at final HEAD, three ways:**
1. **The loop's exact shape** (`RIPWIRE_BIN=… bash test/auditregresscheck.sh`, no argv): **PASS rc=0, 0
   FAIL-shaped lines** — the absorb loop's own detector reads it green.
2. **With the ASan binary** (`RIPWIRE_ASAN_BIN=asan/ripwire`): **PASS rc=0**, arm B reads `PASS … no report
   on stderr and exit 0`, trailer `asan=clean`. The Phase-3 SKIP is a real assertion now.
3. **The mutant seal**: the six-revert binary still reads **14 FAILs**, 6 rows `unproven`, at the NEW gate
   text — the strengthened ASan leg and the cosmetic fix did not disturb the discrimination.

**The strengthened ASan leg, discriminated by this seat's own probes:**
- A planted emitter (exits 0, prints `ERROR: LeakSanitizer: detected memory leaks` to stderr) — the exact
  shape the OLD leg waved through — is now **caught by name**: `FAIL B ASan/LSan exited 0 but EMITTED a
  report …`, trailer `asan=REPORTED (exit 0)`, gate rc=1. The gap the producer named was real and their fix
  closes it.
- A bogus `RIPWIRE_ASAN_BIN` path **SKIPs with the path echoed** in the message — a typo can no longer
  masquerade as "not requested" — and the gate stays rc=0 (a disclosed SKIP, not a false pass).

**The M2′ ledger line — delivered, measured not accepted.** The producer re-measured it themselves (the
mutant's `src/mcp.h` diff carries exactly the ONE stdio hunk; an isolated HTTP probe with no A2a state
refuses `-32602` exactly, victim untouched) and corrected the ledger: M2′ is now **"carried — no revert of
its own; red OBSERVED at `mcp.h:1921`"**, accounting restated to six reverts / six red arms / one carried.
The corrected ledger sits IDENTICAL in the spec dir and scratch (`diff` clean). Their earlier "seven" had
double-counted the carried red as an independent revert — my verdict's reading, now their measurement.

**The astrocheck suite flake — classified environmental, and stronger than the producer's own evidence.**
Their three proofs: passes at clean base, passes 3/3 in the lane tree, zero lane coupling. This seat's two
runs: **rc=1 at lane AND rc=1 at clean base in the same minute** — zero FAIL-shaped lines in either log,
the failure shape is the time-gated `[math degraded] ingest: an .astro opened a --- fence …` disclosure
class. Failing identically at the clean base is the definition of tree-independent: not the lane's, and
not even reliably green on this host at all (the bank's "memguard B8/B8b time-gated" class). The producer's
3/3-green and my 2/2-red describe one flaky gate on one host; the suite-level runs will re-run it and the
stickier question is host CI variance, not this lane.

**The portability gates — re-run by this seat:** `bashsourcecheck`, `baselineportcheck`, `infraportcheck`
all rc=0 (the producer ran five; I ran three and the two others are the build-config and index gates whose
claims I verified by reading). **My own text audit of the gate agrees with the producer's table**: zero
`\|` BRE alternations, zero BSD-only flags (`stat -f`, `sed -i ''`, `date -j/-v`, `readlink -f`, `mktemp
-t`, `xargs -J`), no `pipefail` (so no SIGPIPE class), the two `timeout` hits are Python kwargs, `awk`
is a comment only (the CSV tool is Python `csv`), `xmllint` guarded with a disclosed SKIP, Python
stdlib-only imports (`hashlib, json, os, socket, subprocess, sys, time, csv` — plus the suite's own
`gatehttp`), `mktemp -d` and `date +%s` both-ways portable. The known divergence classes are absent as a
**measured fact of the text**.

**The suite log.** `sri-phase4-suite.log` re-counted with the right ruler (the loop prints `PASS` + two
spaces; a single-space grep is this seat's own suspect-instrument catch of the round): 42 absorb gates
PASSed before the session-boundary reap, our gate among them (`PASS absorb gate (auditregresscheck.sh)`),
astrocheck's FAIL visible with its `[astrocheck] [math degraded]` detail — the reap placeholder story
checks out.

## The platform fact — CORRECTED (both seats had it wrong; this seat's probe caught it)

The producer's §7 and this seat's banked entry both claimed: *a PR without the `train-member` label gets
exactly one matrix leg, ubuntu-24.04/Release/clang — the lane is Linux-first-executed.* **The conditional
was inverted.** Reading `ci.yml` carefully: `full=true` is the DEFAULT; the `pull_request` branch sets
`full=false` (light) **only when the `train-member` label IS present** — maintainer-added, train-PR only.

The empirical arbiter (this seat's probe, `check-runs` on PR #484's real unlabeled head `93aae229`):
**38 check runs — the FULL matrix: 24 release shards across {macos-26, ubuntu-24.04}×{Release, plain}×
{appleclang, clang, gcc}, plus asan, windows, xplat-diff, CodeRabbit.** A contributor PR like ours runs
everything, INCLUDING 8 macos-26 legs, on the first push. **The lane is macOS-tested and Linux-tested
simultaneously — not "GNU-first-executed".** Two consequences:

1. The producer's core §7 argument survives and even strengthens: a BSD-only construct goes red on the
   first push — but on macOS too, which we CAN reproduce locally. Their portability audit (which holds up
   under my own greps) is the right instrument precisely because both platforms run.
2. The "push and read the PR's ubuntu leg" route they proposed is confirmed as the honest route — and
   now executed (below).

The banked entry is corrected in this act (project MEMORY.md rewritten); the producer's §7 wording gets
one correcting line in the relay, no re-work of their platform argument (its substance was never the
matrix shape, but the measured-absence-of-divergence audit + the unreachability disclosure, both of which
stand).

## The ship-key act this round (disclosed in full)

**Pushed `lane/security-regression-integration` → fork `pt-act/ripwire` and opened fork PR #7**
(lane vs fork `main`, base `50bc05e84` — fast-forward clean, mergeable). Purpose: the Phase-4
"both platforms" clause discharged by MEASUREMENT — run the full matrix on GitHub runners before any
upstream exposure. The push is to the FORK only (the interlock's "work stays on the fork branch" boundary
— the mcp-token lane's fork push already crossed it; nothing upstream-visible happened). GH token: admin,
fork public (free CI minutes).

**The instrument was inert on arrival: the fork's GitHub Actions are DISABLED.** `workflow_dispatch`
returns `HTTP 422: Actions has been disabled for this repository`; the fork has no runs of any kind since
2026-10-08 (the Nov 4 mcp-token fork push also silently produced no CI — nobody noticed because upstream's
PR carried the CI weight). Zero checks on PR #7's head; `mergeable_state: clean`. The API's
`actions/permissions` endpoint says `enabled:true` — contradicted by the 422 and the run history; the 422
sides with disabled (the permissions endpoint is about allowed-action types, and is the wrong instrument).
**Operator act needed (one click, yours not mine): fork repo → Settings → Actions → General → "Allow all
actions" (set "Actions permissions" to enabled).** With admin-less governance: this seat holds admin
token power but does not loosen repo settings un-asked. Once enabled, PR #7's open state triggers the full
matrix on both platforms; I read the run and fold it into the terminal validation.

Not pushed upstream. PR #484 untouched. Ship keys held throughout — this act used them exactly once, on
the fork, for the instrument.

## The three producer asks — RULED

1. **Phase-4 exit criterion (full 8.5 h suite vs. our gate's leg): RULED — our gate's leg IS the criterion
   for the LANE; the full suite is the merge's instrument, not ours.** The spec's Phase-4 line ("run full
   suite on both platforms") is hereby interpreted per the standing suite discipline, and the clause is
   discharged by: (a) the gate's leg green in the real absorb loop's exact shape (measured, twice), (b)
   the absorb-loop PASS of our gate among the 42 pre-reap gates, (c) CI = the suite under both platforms
   via PR #7 once the operator flips Actions on — CI's release legs run the sharded **full** absorb list,
   so "the full suite on both platforms" is measured by the instrument designed for it, on runners that
   don't have this host's flake profile. Local 8.5 h on a 4-vCPU host with a five-times-reaped task
   mechanism is the wrong instrument for a verdict this seat will sign; the astrocheck flake is exactly
   the host-noise class the ruling excludes from the lane's exit. **The lane's Phase 4 is COMPLETE** when
   PR #7's matrix is green (the operator's one click + one read) — or, if the operator prefers zero
   remaining acts: it is complete NOW on the strength of (a)+(b)+text-audit, with the platform clause
   carried to the upstream PR's own CI (which runs regardless).
2. **The sourced-fragment deviation: RULED — the literal-assertion design is CORRECT for this tree; the
   Implementation Note is amended by interpretation, not edited.** Measured facts: no sourced fragment
   exists in the consumer gates (`regexrefusecheck`, `mcpstdiolinecapcheck` carry none of the wording;
   `mcpstdiolinecapcheck:80` says `kept in sync by eye`). Building one means editing other lanes' gates —
   outside the test-only remit, and it would create a NEW shared shell include mid-lane: a cross-lane
   coupling surface this program just spent the retired-spec amendment REMOVING. The literals here act as
   the drift alarm by DEPTH instead of by LINK: any wording change in the source of truth (the binary's
   own output) turns this gate red the moment it runs — that is the alarm, already armed, without a
   fragment to rot. The note's intent (fail in exactly one place per unit AND here simultaneously) was
   never achievable by sourcing in a tree whose unit gates never exported the wording; the note was
   aspirational at drafting and is now formally DISCHARGED as such. If the operator ever wants the
   fragment, it is a standalone mini-spec (a shared `test/lib/audit_literals.sh` + edits to five unit
   gates) — a candidate for the retirement-boundary backlog, NOT this lane.
3. **Scratch reclaim: GRANTED for `sri-mutant` + `sri-base`; DELAYED for evidence-integrity on one
   artifact.** The discrimination evidence is now triple-recorded (spec-dir validation/ + scratch logs +
   the verdict/relay texts) and the mutant tree itself is no longer needed as a standing instrument — the
   ledger, the run2 log, and this seat's own head-seal run (14 FAILs at the new gate text) are the
   record.** Reclaim both** (538M + 351M ≈ 0.9 GiB) on the operator's next word — I do not delete
   producer scratch without the operator's explicit go, so this lands as "granted, awaiting your rm" in
   the relay. The asan dir (1.4 GiB) stays until the PR #7 matrix is read (it is the asan=clean
   provenance); `sri-r1` itself is the lane worktree — it stays until terminal validation.

## Phase position and next

Phases 3 and 4 are ACCEPTED — COMPLETE (with the one-click/one-read caveat on PR #7). What remains for the
spec is TERMINAL validation (VALIDATION_PROTOCOL: step 2 status flip on the full evidence chain — Phase-0
errata, Phase-1+2 verdict, this verdict, the report/ artifact, the CI matrix read once available). That
validation, the upstream PR (still interlocked on #484), and the release-cadence question are the PM
seat's next acts, in that order, on the operator's word.
