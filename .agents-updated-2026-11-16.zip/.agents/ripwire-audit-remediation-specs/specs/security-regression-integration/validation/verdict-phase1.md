# Phase-1+2 Verdict — security-regression-integration (the dispatcher's fold, 2026-11-06)

**Verdict: ACCEPTED in full — Phase 1 and the folded Phase 2 both cleared; Phase 3 (ASan) and
Phase 4 (full suite + report/) cleared to proceed.** Every load-bearing claim in the hand-back
was independently reproduced by this seat — the gate re-run on both binaries, the registration
re-arbitrated from a fresh base worktree, the mutant source read hunk-by-hunk, the unit gate
that owns M3 re-run in both trees. One recording correction is owed on the producer's
discrimination ledger (the M2′ row's mechanics, detailed below); it affects no acceptance
criterion, no discrimination result, and no shipped byte.

## The independent verification (this seat's own instruments, nothing read back)

**The commit.** `1dbdc44fc` (authored/committed `pt-act`, subject `test(auditregress): an
integration gate for the five audit fixes, both transports`), parent = base `50bc05e84`
exact. 5 files, +737: `test/auditregresscheck.sh` (704 lines, mode 100755),
`test/regression.sh` (+1), `changelog.d/security-regression-integration.md` (+31), and
`test/fixtures/audit-reef/{minified-oneline.js (130,650 B, one line), minimal.docx (952 B)}`
— the docx verified a REAL three-entry OOXML zip (`[Content_Types].xml`,
`_rels/.rels`, `word/document.xml`; not a fake `PK` header, which would prove nothing about
the markitdown branch). `git diff --name-only 50bc05e84..HEAD -- src/` is EMPTY — the
test-only constraint held on the commit itself. Push-absence verified two ways: no
remote-tracking ref contains `1dbdc44fc` (`branch -r --contains` empty; the local lane
branch is unpushed, not even to the fork). Ship keys and the #484 interlock honored.

**The gate re-run by this seat, shipped binary (`--version`: `built_from=50bc05e84`): PASS,
rc=0, 8/8 rows `repelled`.** A1a: all three bombs refused with the structural lead-in
(`refused, nothing was scanned:`, rc=1 each, the abandonment lead-in explicitly excluded as
the discriminator). A1b: structured empty ×3 + the POSITIVE CONTROL (`total=1` — the scan
really ran) + `tools/list` after. A2a/A2h: `-32602` with the exact contracted sentences,
victim byte-identical, both HTTP states (default and `--allow-remote-edits` — the workspace
pin is correctly not the optional edit gate). A3: six planted historical symlinks ignored,
the edit still published (`applied=replace_symbol_body`), no temp residue, the escaped-root
stderr disclosure asserted present. A5h: 413 at cap+1 (8388609) with the 8 MB sentence via the
headers-first exchange, `tools/list` after. A5s: exactly one `-32600` at the 33 MiB line then
a healthy `tools/list` (resync). Arm B: determinism byte-identical + xmllint clean. Arm C: 8
rows, 6 columns each parsed as real CSV, the consumer's `^A[1-5],` grep sees all 8, every
verdict `repelled`, provenance line present. The two SKIPs (pargates self-recursion; no
`RIPWIRE_ASAN_BIN`) print with reasons — Phase-3 lines, correctly not pretended.

**The gate re-run by this seat, mutant binary (`built_from=50bc05e84+dirty`, Release): 14
FAILs, rc=1, 6 rows `unproven`** — identical failure set and row content to the producer's
`sri-mutant-run2.log` (wall times within machine noise). M1 → A1/cli `rc per pattern = 000`;
M2 → A2/stdio `code=none (no refusal answered)`, victim CHANGED; M4 → A4 committer-email
rows 1, `top` 0/6; M5 → A5/http `400 Bad Request` (no 413 sentence); M6 → A5/stdio
`refusals measured: 0`. The row() write-time enforcement visibly worked throughout — no
mutant row displays a shape it failed to produce.

**The mutant source read hunk-by-hunk** (working-tree diff, 305 lines, dumped to
`~/ripwire-scratch/logs/v-pm-sri-mutant-diff.txt`): exactly six src/ reverts at the claimed
anchors — M1 `verbs_grep.h` (the refusal screen's `return 1` → `return 0`), M2 `mcp.h` (the
stdio edit-pin `else if( false )` at the `:1944`/1950 gate), M3 `pathguard.h:414`
(`O_EXCL|O_NOFOLLOW` → `O_TRUNC`), M4 `gitmine.h:1104` (`%ae` → `%ce`), M5 `mcpserver.h:60`
(8 → 16 MiB), M6 `mcp.h:3009` (32 → 64 MiB). No seventh revert exists — which is itself
evidence for the correction below.

**The unit gate that owns M3, re-run by this seat in BOTH trees:** lane (clean) ALL PASS
rc=0; mutant tree **4 FAILs** — exactly the four rows the ledger names (f1 existing-symlink
EEXIST + unchanged pair, f2 dangling symlink, f3 existing regular file). The M3 boundary
story is independently confirmed: A3 stays `repelled` on the mutant BY DESIGN (collision
probability protects the historical shapes, not the flag); the behavior is gated by
`tempfilesymlinkcheck`, the gate the spec names. (Instrument note, this seat's own, disclosed:
the first attempt ran the gate directly and got rc=126 — the suite invokes gates via
`bash "$ROOT/test/$_g.sh"` (`regression.sh:1055`); re-run via bash, both results above.)
A second instrument note: the `strings`-based stamp probe answers empty — `built_from`
composes at runtime; `--version` is the instrument.

**The registration, re-arbitrated by the tree's own instruments and re-derived
independently:** `docs/gatecount_build.py --check` on the lane: the loop names **762** today,
rc=0. The SAME instrument on a FRESH DETACHED WORKTREE this seat built at `50bc05e84`: names
**761** — the 761→762 delta proven by an independent probe, not the producer's stash.
`test/manifestcheck.sh` rc=0 on BOTH sides with the registry arm's own arithmetic: lane
**776 top-level = 762 absorb + 14 by-name**; base **775 = 761 + 14** — the delta is exactly
our one gate, byte-sorted, no duplicate, every mutation control catching. The slot byte-order
RE-MEASURED (`LC_ALL=C sort`): `attrvocabcheck < auditregresscheck < barrelshortkeycheck`,
and the +1 loop line sits in-commit at exactly that slot (same-commit discipline held:
gate + registration + fixtures + changelog in one commit).

**counts drift — the producer's non-refresh is CORRECT, now verified against the tree's own
per-PR gate:** `docs/counts_snapshot.py check` rc=1 STALE (`gates.scripts 753→762` — drift
9 of bound 10, plus the unbounded totals drifting normally since 11-03), but
`test/gendocsmergecheck.sh` — the D arm, the gate CI actually runs — rc=0 ALL PASS: "within
the drift bound". The refresh is the merge's job (`scripts/merge_main.sh --regen-after-build`),
never a feature PR's; the GEN-DOCS-MERGE discipline, correctly applied. `limitstablecheck.sh`
rc=0. No action owed; the flag was the right disclosure, not a defect.

**The two self-found gate defects, verified as FIXED in the shipped file:** (1) the A4
two-people fixture — author `real@x.com` / committer `committer@x.com`, with the committer
email asserted in ZERO rows (lines 160–201); the mutant run proves the discriminator bites
(1 committer row, `top` 0/6, spoof file owned by the committer). (2) the `row()` write-time
shape enforcement, in BOTH the shell (l.96–110) and the Python twin (l.232–240): a `repelled`
verdict whose expected shape is not a real substring of the observed text is downgraded and
named at write time. The mutant run's honest wordings (`code=none (no refusal answered)`,
`refusals measured: 0`, `(NOT answered)`) are the enforcement visibly working — the
constructed-observed defect this gate exists to avoid is dead.

## The one recording correction (owed, not blocking)

The discrimination ledger's M2′ row — "same revert, HTTP tier, site `src/mcp.h:1921`" —
overstates the mechanics. Grounding: the mutant diff carries exactly ONE edit-pin revert
(the stdio gate; the diff has no hunk anywhere near `mcp.h:1921`, which is the HTTP
pinned-root refusal). This seat's own mutant run confirms the mutant's HTTP tier STILL
refuses correctly — `code=-32602` with the exact contracted sentence, in both
`--allow-remote-edits` states. The A2/http row's `unproven` on the mutant is the CARRIED
effect of M2's stdio escape through the shared A2 fixture: A2a (stdio) escapes and writes
the victim first; A2h (HTTP) refuses correctly, but its `sha(victim)==before` probe fails
because both arms compare against the one `before` hash taken before A2a ran.

For the gate this is safe by construction — a carried-effect red can only ADD red on a
broken binary, never mask one — and the refusal-then-changed-victim combination is exactly
what the row() enforcement is for (it visibly named this contradiction). The seven-red
accounting ("six mutations, seven discriminating arm-results") and the commit message
("M2 A2/stdio + A2/http all go red") both stand as written. What is owed is ONE LINE in
`sri-discrimination-proof.md` at the producer's next touch (the Phase-3/4 report): the M2′
row's Site column names where the red is OBSERVED (the HTTP refusal that correctly fired),
not a revert site — no HTTP-tier revert exists in the mutant. No re-run, no re-work.

## Phase position and what is cleared

Phase 2 folded into `1dbdc44fc` — all arms landed and discriminating, verified. **Cleared:
Phase 3** (ASan Release build ~1.4 GiB — the operator's disk word granted 2026-11-06; 4.6 GiB
free at verification time; supply `RIPWIRE_ASAN_BIN` to arm B's wired leg — the LSAN
suppressions are already in the wiring) and **Phase 4** (the full suite
`bash test/regression.sh` on the lane tree — the registration is live, the loop will run our
gate; the `report/` artifact under the spec dir; both platforms). The scratch instruments
(the `sri-mutant` worktree, 538M, its build) are reclaimable AFTER Phase-4 validation — the
operator's reclaim list, not before.
