# Dispatch Note — security-regression-integration (attachment 1 of 2)

**Dispatched:** 2026-11-06T10:33:33Z, by the PM seat (dispatcher-of-record, WorkBuddy AI /
GLM-5.3) under the operator's dispatch directive of this date, verbatim: *"ok sounds good flip
please and il activate the producer"* (on the Mode-B rank-1 recommendation).
**Producer:** Deepseek-V4.1-Flash "-1017" — **the LOCAL seat, this Mac** (the rotation's first
dispatch; Stage-1 accepted + probe answered 2026-11-04, ledger signed 19:30Z). Build-capable,
bash-3.2-native. Ship keys stay with the PM seat (§03.7): the upstream PR is NEVER yours.
**Base commit:** `50bc05e84` — fork `pt-act/ripwire` main = upstream `redhat-et/ripwire` main =
`50bc05e84` (verified this date). Branch **`lane/security-regression-integration`** off
`50bc05e84`. Upstream has advanced (b059ac59, merged 2026-11-05) but is ~2 trains/day and
mid-lane drift is handled by `scripts/merge_main.sh --regen-after-build` when needed; the lane
is test-only, so the collision surface is the standing registration files.
**Attachment 2 of 2 is your spec** (v1.0.0, PINNED). Its Interfaces / ACs / Failure Modes are
the contract. Your Phase 0 VERIFIES each anchor live on the current tree and tightens arm
wording where needed; it does not re-design.

**Manifest bookkeeping for THIS dispatch** (status planned → in_progress, execution.producer,
`spec_started` history event, this spec file's Status line) is done by the dispatcher in the
same act — you do NOT touch the manifest for the dispatch itself. Any LATER manifest mutation
you need is drafted by you in your hand-back and **applied through the PM seat** — the producer
never flips statuses (Q10 ruling 2026-10-29).

## The lane, in one line

Compose the five audit attacks (A1–A5) into one adversarial fixture tree + one driver gate
(`test/auditregresscheck.sh`), replay every attack end-to-end through CLI and MCP transports,
assert the contracted refusal shapes, and emit the report block that audit-validation-standalone
consumes. **The lane is TEST-ONLY: your touch set is `test/auditregresscheck.sh`, its
registration, fixtures under `test/fixtures/audit-reef/`, and one changelog fragment — ZERO
`src/` files. If a fix looks like it needs a src change, that is a finding to relay, not a
lane extension.**

## The five contracts you consume — one comes from our gate, three from upstream's living code

The spec's innovative constraint: three of your five consumed contracts come from **retired
specs** — fixes upstream shipped from their own audits, never executed as our unit gates. Your
expected refusal shapes therefore **pin from the LIVE implementations on your base**, not from
our never-run gate files. All anchors below were live-verified by the dispatcher on `50bc05e84`
this date — your Phase 0 re-verifies them on YOUR checkout and re-pins line numbers:

- **A1 (patternAdmission ← regex-screen-hardening):** the refusal surface lives in
  `src/regexguard.h:732` — *"…branches the structural screen cannot PROVE are disjoint…"*. The
  exact refusal sentence your arm greps: fire `--regex='^(a|aa)+b$'` on a fixture and pin the
  exact output; the wording carries the PM-1 honesty condition (the screen says it cannot
  PROVE disjointness — check it matches). Bomb patterns per the spec: `^(a|aa)+b$`,
  `(x|xy)+c$`, `(\w|\d)+$` over the ≥100 KB single-line fixture.
- **A2 (editPathAdmission ← edit-workspace-pin, RETIRED): bare-stdio edit escape.** The pin
  policy upstream shipped lives in `src/mcpedit.h` (+`src/pathguard.h` — the shared symlink
  predicate; `src/mcpedit.h:23` includes it). Launch bare `ripwire --mcp` in fixture dir A;
  script `analyze` + `replace_symbol_body` aimed at dir B; the edit is refused and B's file
  sha256 unchanged. Your Phase 0 pins the **exact refusal code + wording live** (grep for the
  workspace/off-workspace refusal wording in mcpedit.h — the -32602 family; the live text is
  the contract, our 2026-09 draft is not).
- **A3 (atomicPublish ← atomic-write-tempfile, RETIRED): the temp-name symlink farm.** The
  create-use seam is `O_NOFOLLOW`/`O_EXCL` (grep `src/mcpedit.h`, `src/arch.h`,
  `src/infra/os.h` — the atomicWrite temp-then-rename seam near `mcpedit.h:1268–1288`, which
  is also the symlink-edit refusal: *"refusing to edit '…': it is a symlink…"*). Pre-plant
  symlinks at the predicted temp-name pattern; an edit run leaves every victim byte-identical;
  the edit discloses honestly. **Convergence note:** `test/mcpaudit4hardencheck.sh` already
  gates the mcp.h symlink-edit refusal (A4-F14) — a pattern precedent and a ready-made
  assertion shape to copy, NOT a surface collision (your farm targets the Edit temp-name
  seam — a different mechanism).
- **A4 (gitRecordFraming ← git-porcelain-framing): hostile git filenames.** The framing
  gate + its fixtures ARE on your base — landed via #469 (`test/gitframingcheck.sh` exists on
  50bc05e84; its fixture expectations are your expectation source — the spec says consume them
  read-only, one source of truth). Attributions verified live: `__C__x|1694000000` and the
  newline-named file attributed correctly in the `--owners`-family output over the fixture repo.
- **A5 (boundedStdioLine ← stdio-request-cap, RETIRED): the 9 MiB stdio line.** The cap lives in
  `src/mcpserver.h:59–60`: `kMaxHeaderBytes = 64 KiB` → 431, `kMaxBodyBytes = 8 MiB` → **413
  "request body exceeds the 8 MB limit"** (`mcpserver.h:608`, the wording your arm greps). 9
  MiB line → exactly one framing error, then a healthy `tools/list`.

## Cross-transport parity (the integration value)

The same grep refusal and the same edit refusal occur over stdio AND over loopback HTTP (with
token — pinned via env var, never argv; mcp-token-hygiene's warning is asserted in its own
gate). Both transports must refuse byte-comparably at the JSON-RPC error-shape level. The
HTTP-test pattern to follow lives in **`test/lib/gatehttp.sh`** (SOURCED, not run — read its
header): start_server waits until the listener ANSWERS (no fixed sleeps), the curl shim,
ephemeral port pick, mktemp + cleanup trap, ok/no helpers. `test/mcpremotecheck.sh` and
`test/mcpaudit4hardencheck.sh` are the two best in-tree pattern precedents for server-driven
arms.

## Read-first list (in this order)

1. **Your spec** (attachment 2): Objective / Scope / ACs 1–8 / Failure Modes / Implementation
   Notes — especially the report row contract (`attack_id, transports, expected_shape,
   observed, wall, verdict`) that audit-validation-standalone's schema grep consumes.
2. **In your clone (all at `50bc05e84`):** the five anchor sites above; then
   `test/lib/gatehttp.sh` (the HTTP pattern), `test/mcpaudit4hardencheck.sh` (best gate-shape
   precedent), `test/gitframingcheck.sh` (A4's fixture source), `test/regression.sh` lines
   287–1049 (the absorb loop; your registration target), `AGENTS.md` (the house rules),
   `CONTRIBUTING.md` (the gate-first + submission checklists).
3. **The accounts of the tree: `docs/counts.tsv` is generator-owned** — do not touch count
   sites or the snapshot; more below.

## Phase 0 (planning + red baseline — the local seat's text)

Build the base binary FIRST (yes, you can — that is the point of you):

```bash
cmake -S . -B build && cmake --build build -j
```

1. Verify every anchor above against YOUR checkout; re-pin line numbers (content match, not
   line match, is the rule).
2. **Red baseline every armed attack on the base binary:** A1's bomb refused (the screen is
   live), A2's off-workspace edit refusal wording captured verbatim, A3's temp-name pattern
   observed in the wild (the seam runs; record the actual temp-name shape), A4's attribution
   over the hostile-filename fixture, A5's 413 wording. These baselines prove the contracts
   are live before you compose anything.
3. Pin your gate skeleton: arms A/B/C per the spec (A1–A5 replays, B the four suite invariants,
   C the report schema grep). BIN resolution:
   `BIN="${1:-${RIPWIRE_BIN:-$ROOT/build/ripwire}}"` — the absorb loop invokes gates as
   `RIPWIRE_BIN="$BIN" bash "$ROOT/test/$_g.sh"`; a bare `BIN=` is the miss that runs a
   stale binary (this exact defect cost the multiquantifier lane a false red).
4. Reply-in-thread (via the operator relay) with: pinned anchors, arm wording, the report-format
   literal, and red-baseline output. The PM confirms before Phase 1 (folds corrections
   cheaply, exactly as prior lanes ran).

## Hard constraints (from the spec; non-negotiable)

- **Every verdict row is shape-matched, not exit-code-matched** — `repelled` requires the
  contracted refusal string IN the captured output (arm C's schema grep and the schema of
  audit-validation-standalone both depend on it).
- **Refusal paths never write or corrupt target bytes** — sha256 assertions on every victim
  file (A2's dir-B file, A3's farm, A4's fixture repo).
- **Timing bounds are hang-catchers, generously wide (60 s)** — the arms catch deadlock, not
  performance variance.
- **Unit wording drift must fail here too** — import each unit's expected string from the
  unit gate's own asserted text (source the shape from the live implementation or the
  gitframing fixture), so a wording change breaks in exactly one place per unit and here
  simultaneously. **That coupling is the drift alarm — it is intended.**
- **Red-first:** every armed attack demonstrated RED (or contract-live) on the pre-change
  binary before the composed fixture tree exists.
- **No refusal path regresses the suite** — arm B asserts pargates green, determinism
  (`>a; >b; diff -q a b` — outputs OUTSIDE the crawled tree), xmllint clean, ASan/LSan clean
  over the adversarial fixture. ASan build per AGENTS.md:
  `cmake -S . -B asan -DRIPWIRE_ASAN=ON && cmake --build asan -j` +
  `LSAN_OPTIONS=suppressions=lsan_suppressions.txt ./asan/ripwire .` — the asan build dir is
  ~1.4 GiB; **disk is thin (4.1 GiB free)** — build, run, capture, and consider removing the
  asan dir when the log is captured if space squeezes (your lane is test-only; the rebuild
  is cheap in comparison to a dead disk).
- **Bash 3.2 native** — you are ON the machine the suite runs on; the env-array guard idiom
  (`env ${envs[@]+"${envs[@]}"}`) and friends are native here. Detection is yours; immunity
  is not (your own §8 correction holds).
- **No new gates beyond auditregresscheck** — the spec's produces is ONE gate. Fixture
  sub-files are fine; a second registered gate is a scope break.

## Registration mechanics (post-GEN-DOCS-MERGE — same as the mcp-token lane)

- **Absorb loop:** one-gate-per-line, LC_ALL=C byte order. Insert `    auditregresscheck \`
  **after `attrvocabcheck` (line 321), before `barrelshortkeycheck` (line 322)** at base —
  (base loop = 761 members; yours makes 762; the structural parse found 761 including the
  hyphenated `det-gate` member — beware parsers that miss it). Verify with the tree's own
  generator: `python3 docs/gatecount_build.py --check` — never a grep (three instruments
  answered zero on this loop during THIS dispatch: over-escaped grep, wrong-terminus parser,
  and zsh eating `$M:test/…` into `mainest/…` — the banked :t-trap. If your instrument reads
  zero, READ THE FILE).
- **DO NOT touch the published gate counts** (README.md / docs/EVALS.md / deck) or
  `docs/counts.tsv` — totals publish from the dated snapshot; a feature PR adds ONLY the gate
  file + its loop line + the changelog fragment. If `gendocsmergecheck` goes red on you (the
  drift gate), a snapshot refresh is a MAINTAINER step — report it in your hand-back, never
  fix it yourself.
- **Changelog:** new fragment `changelog.d/security-regression-harness.md` (read an existing
  fragment for format); `python3 scripts/changelog_assemble.py check` green.
- **manifestcheck needs `bash`, not `sh`** (process substitution). `test/manifestcheck.sh`
  requires the new gate file + loop line in the SAME commit (the same-commit discipline —
  every prior lane shipped this).
- **Validation battery on your tree, minimum:** your gate (every arm red→green),
  `gatecount --check`, `manifestcheck`, `gendocsmergecheck`, `changelog_assemble check`,
  `gitframingcheck` (your A4 arms consume its fixtures — they must stay green), plus the full
  regressions if runtime allows; CI runs the rest on the PR. **Heapwatch: arm B's
  ASan/LSan leg on the adversarial fixture can run long** — the alarm idiom
  (`perl -e 'alarm N; exec @ARGV'`) is the host's no-timeout workaround; background runs are
  documented in the bank.

## Environment notes (your LOCAL habitat — the rotation's whole point)

- **Disk is THIN: 4.1 GiB free.** The build ~1 GiB + asan ~1.4 GiB + your fixture tree. Build
  stepwise; capture logs to `~/ripwire-scratch/logs/` (never `/tmp` — wiped 4×); the reclaim
  set (rmq-r1 1.0G, gpf-prefix-r1 502M, pm-verify-r1 505M, rmq-base 470M, mth pair 1,225 MB)
  is operator-held — do not delete anything scratch-side without the operator's word; when
  space pinches, REPLY-RELAY, never a silent purge.
- **Each Bash call is a fresh shell** — multi-step experiments in ONE call. Foreground dies
  ~2 min: pargates full-suite and asan builds run in the background with TaskOutput-style
  reads; `ps`/`top`/`lsof` are blocked → `pgrep`/`stat`/mtime.
- **Authorship: every commit ships as `pt-act <psychoactive28@gmail.com>`** — set per-worktree
  before the first commit (a session that never set identity once shipped everything as a
  platform bot; pinned pipeline-wide). `git add` takes an explicit path list, never `-A`.
- **Worktree discipline:** branch `lane/security-regression-integration` off `50bc05e84` —
  NOT off the main checkout's current HEAD unless they coincide (your Phase 0 verifies). The
  main checkout is 2,017 commits behind (ff-safe, operator-held); your lane does not touch it.
- **Lane-branch commit rhythm is ROUND rhythm** (AD-2026-11-04-lane-branch-commit-rhythm): red
  baselines and armed gates are committed as you go; **every mid-round commit carries its
  justification in that round's completion report** — that is the standing duty the ruling
  installed.
- **Commit messages follow the house style** (look at our prior lane commits: short imperative
  subject, body explains the why). No AI-era trailers, no platform bots, clean history — the
  #484 clean-history rule rides every lane.

## Base drift while you work (upstream lands ~2 trains/day)

If upstream main moves mid-lane: the lane is test-only, so `test/regression.sh` and the
standing registration files are the conflict surface. `scripts/merge_main.sh` (in your clone at
this base) does the mechanical absorb; `--regen-after-build <bin>` re-pins binary-pinned files
post-build. **Refresh your convergence probe before hand-back:** no upstream PR or issue may
have gained an audit-replay harness while you worked. If one did, STOP and relay — a shrunk
residual lane beats a superseded one (twice-proven course in this pipeline).

## The one-lane-in-review interlock (standing operator directive)

**Nothing upstream-visible from this lane until PR #484 (regex-screen-multiquantifier)
concludes — merged or explicitly declined.** Concretely: work on
`lane/security-regression-integration`; push the branch to the fork `pt-act/ripwire` when the
lane is complete (a fork branch is NOT upstream-visible). The upstream PR is **the PM seat's
act** after hand-back validation and after #484 concludes — never yours, even if CI invites
you.

## Hand-back contract

At lane completion, relay through the operator to the PM seat: (1) the lane branch pushed
(patches if you cannot push); (2) a completion report per VALIDATION_PROTOCOL §C — every AC
with its command + output, the red-baseline outputs from Phase 0, the report-format literal,
the battery results; (3) your phase notes. The PM validates independently (both toolchains —
libc++ and the g++-14/libstdc++ leg) and files the canonical artifacts under the spec's
`validation/`. Status flips on resolution are the dispatcher's act, never yours.
