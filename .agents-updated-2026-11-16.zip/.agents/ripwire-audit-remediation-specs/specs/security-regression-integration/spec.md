# Security Regression Integration

## Header

```yaml
id: security-regression-integration
type: integration
version: 1.1.0
manifest: ../../manifest.yml
```


## Objective

Verify that the five security fixes compose correctly in the real binary — that the exact attack reproductions from the 2026-09-14 audit now fail safely end-to-end through both the CLI and the MCP stdio transport, and that the hardening did not disturb the project's determinism, honesty, or suite-wide invariants. This is the closed loop between "each fix passed its unit gates" and "the shipped tool repels the audited attacks."

### Errata v1.1.0 (2026-11-06) — the Phase-0 repairs (dispatcher, on the producer's C1–C5 findings)

The spec was drafted 2026-09-14 against three premises Phase 0 measured false against base
`50bc05e84`. The interfaces and the report-row contract are UNCHANGED; four ACs are repaired
to the shipped contract. Full evidence: `validation/phase0-report.md` (producer) + the PM's
independent reproductions; the A2 escape is filed separately at
`findings/stdio-bare-edit-escape.md` (SRI-F1 — a proposed spec, NOT this lane's work; this
lane is test-only, zero `src/` files). Repairs:

1. **AC-1 (C3):** the MCP verb set has NO regex surface by design (`mcpverbs.h:1324`
   `/*regex=*/false`; no wire field matches a regex). "Refused on both transports" is
   unsatisfiable. Repaired: CLI refusal is asserted (the PROVE lead-in); the HTTP leg asserts
   the transport-safety fact — bombs answer a structured empty (`files=0 total=0
   complete=true`) with a mandatory positive control (a matching literal → `total=1`, proving
   the tree was scanned), and the server stays responsive.
2. **AC-2 (C1, the blocker):** the shipped edit pin covers the STARTUP-ROOT stdio tier and
   both HTTP forms; the bare stdio launch runs the `assumedRoot` tier, which the pin's own
   gate (`src/mcp.h:1944` `!policy.defaultRoot.empty()`) never enters — and its comment
   documents the split as intended ("a request may name any path"). Repaired: A2 asserts the
   refusals on the pinned tiers (startup-root + HTTP, both `-32602`, victim unchanged). The
   bare-stdio escape is SRI-F1, red at base, reproduced by both seats — filed, not armed
   (a permanently red suite row is an issue tracker, not a gate).
3. **AC-5 (C2):** two caps, never conflated: HTTP body 8 MiB → `413 "request body exceeds
   the 8 MB limit"` (boundary 8388608/8388609); stdio line 32 MiB → one
   `-32600 "request line exceeds the 33554432-byte limit"`. A 9 MiB stdio line is INSIDE the
   shipped stdio bound (served, correctly). Repaired: A5h (HTTP at cap+1) + A5s (stdio at
   >32 MiB), each asserting one error + one healthy follow-up at its own bound.
4. **AC-8:** rows are one per (attack, transport) pair per the repaired ACs — every row
   `repelled`, verdict vocabulary stays `{repelled}` (no not-applicable rows in the report;
   audit-validation-standalone's grep is untouched).

Arm mechanics (C5): the over-cap HTTP arm needs a headers-first exchange (a 9 MiB `sendall`
races the server's close — the refusal fires on `Content-Length` before the body is read);
liveness probes carry `Accept: application/json, text/event-stream` (a bare probe gets 406 —
a false death). A3 is a regression guard at the historical predictable shapes (the shipped
name is 24-hex CSPRNG, unplantable — `tempfilesymlinkcheck.sh` owns the live half), and the
`[math degraded] … escaped-root` stderr line during A3 is an honest disclosure the arm
tolerates, never a defect.

## Scope

**In scope:**
- A composed adversarial fixture tree (`test/fixtures/audit-reef/`) combining: a minified-style single-line file (≥100 KB one line with long repeated-token runs), a file named `__C__x|1694000000`, a filename containing `\n`, a `.docx`, and a symlink farm aimed at the edit temp-name pattern.
- A driver gate `test/auditregresscheck.sh` (registered in `test/regression.sh`) replaying every audit reproduction end-to-end: (1) regex bomb over the fixture completes bounded on both transports; (2) bare-stdio edit escape refused with file bytes unchanged; (3) pre-placed temp symlink never followed; (4) hostile git filenames attributed correctly; (5) 9 MiB stdio line refused with the server alive afterward.
- Cross-transport parity: the same grep refusal and the same edit refusal occur over stdio and over the loopback HTTP transport (with token), byte-comparable at the JSON-RPC error-shape level.
- Whole-suite invariants after composition: `python3 test/pargates.py . ./build/ripwire -j 6` green, determinism (`>a; >b; diff -q a b`) clean, `xmllint --noout` clean, ASan/LSan build clean over the adversarial fixture.
- The verification report artifact this spec produces (below).

**Out of scope:**
- New application functionality (integration specs produce verification, not features).
- Performance benchmarking (the perf gates already exist; this spec asserts absence of deadlock/hang, not speed).
- The accessibility and docs fixes (verified by their own unit gates; not security composition).

## Interfaces

### Produces

#### auditRegressionReport
- **Shape:** a committed-format report block — `test/auditregresscheck.sh` summary plus raw logs — with one line per replayed attack: `attack_id, transport(s), expected_refusal_shape, observed_outcome, wall_time, verdict`. Verdicts are `repelled` only when the observed outcome matches the contracted refusal exactly.
- **Location:** `specs/security-regression-integration/report/` at execution time (the report path is the contract), plus CI log retention.
- **Invariants:** one row per replayed attack (post-v1.1.0: per (attack, transport) pair at the repaired ACs' granularity); a row cannot be `repelled` unless its expected refusal shape string appears in the captured output; the full-suite and sanitizer summaries are appended verbatim.
- **Examples:** `A5, stdio, "-32600 request line exceeds the 33554432-byte limit (once)", served-refusal + healthy tools/list, 3.5s, repelled`.
- **Consumers:** audit-validation-standalone

### Consumes

#### patternAdmission
- **From:** regex-screen-hardening
- **Shape:** the refusal/admission verdict contract incl. the widened alternation family and the disclosed budget-skip alert text.
- **Usage:** attack A1's assertions grep for this spec's exact refusal and alert strings.

#### editPathAdmission
- **From:** edit-workspace-pin
- **Shape:** the four-tier pin policy and `-32602` refusal wording for off-workspace edits.
- **Usage:** attack A2's assertions (refusal code, inferred-root wording, file-bytes-unchanged check).

#### atomicPublish
- **From:** atomic-write-tempfile
- **Shape:** temp-name pattern, exclusive/no-follow create, failure disclosure text.
- **Usage:** attack A3's symlink-plant assertions.

#### gitRecordFraming
- **From:** git-porcelain-framing
- **Shape:** NUL-framed parsing with full-field marker; hostile-name fixtures and their expected attributions.
- **Usage:** attack A4's fixture expectations (shared fixture, one source of truth).

#### boundedStdioLine
- **From:** stdio-request-cap
- **Shape:** the 8 MiB line cap, the framing-gate refusal, and the drain-and-continue resync.
- **Usage:** attack A5's assertions (one error, then a healthy next request).

## Acceptance Criteria

1. **A1: the three audit bombs are repelled on the CLI, transport-safe on HTTP.** CLI: all
   three patterns (`^(a|aa)+b$`, `(x|xy)+c$`, `(\w|\d)+$`) refused over the fixture with the
   structural-screen lead-in `refused, nothing was scanned:` (the discriminator; the bare
   `refused` or `catastrophic backtracking` strings are not), rc=1, wall < 60 s. HTTP: the
   bombs answer a structured empty (`files=0/total=0/complete=true` — the literal-only verb
   cannot take a regex, and it neither hangs nor refuses), a **positive control** (matching
   literal → `total≠0`) proves the tree was scanned, and a follow-up `tools/list` answers.
   **Verifier:** `test/auditregresscheck.sh` arms A1a (CLI) / A1b (HTTP).
2. **A2: off-workspace edits are refused on the pinned tiers.** The startup-root form
   (`ripwire <A> --mcp`): scripted `analyze`+`replace_symbol_body` against dir B is refused
   `-32602 "path outside workspace; …"` and B's file sha256 is unchanged. The HTTP form
   (listener pinned to A): `path:"../B"` → `-32602 "path is outside this server's workspace
   …"` (with and without `--allow-remote-edits`), victim unchanged. The bare-stdio
   `assumedRoot` tier's write-anywhere is **SRI-F1** (filed at
   `findings/stdio-bare-edit-escape.md`; out of this lane by the test-only constraint — NOT
   an arm here). **Verifier:** arms A2a (startup-root) / A2h (HTTP).
3. **A3: the temp-name attack cannot land, and the historical shapes stay dead.** Six
   old-shape symlinks pre-planted (`subject.c.{$$,0,1,2,tmp,XXXXXX}.tmp`); an edit run
   leaves every victim byte-identical, the edit publishes to its real target (applied), no
   non-symlink `*.tmp` residue, and the honestly-disclosed `[math degraded] … escaped-root`
   stderr line is tolerated. Worded as a **regression guard** — the shipped temp name is
   `O_EXCL|O_NOFOLLOW` over 24 hex chars of `/dev/urandom` (`pathguard.h:361–410`); no name
   can be pre-planted. `test/tempfilesymlinkcheck.sh` owns the live half by design.
   **Verifier:** arm A3.
4. **A4: hostile git filenames attribute correctly.** The `gitframingcheck` fixture shapes
   (`__C__x|1694000000.cpp`, `a<LF>b.cpp`, `sp ace.cpp`, `pi|pe.cpp`, `q"uote.cpp`,
   `back\slash.cpp`, `--dashdash.cpp`): a minimal hostile-name repo shows every row `top=
   real@x.com`, zero forged attributions, and the newline file as ONE path (`churn=1`).
   Expectations are consumed read-only from that gate's literals (its own assertions at `:284–290`).
   **Verifier:** arm A4.
5. **A5: each transport refuses at its own bound, once, and keeps serving.** HTTP 8 MiB body
   cap (`kMaxBodyBytes`): at cap+1 (8388609) → **exactly one** `413 Payload Too Large` +
   `"request body exceeds the 8 MB limit"`, then `tools/list` → 200. stdio line cap
   (`kMcpStdioLineMaxBytes` = 33554432): a 33 MiB line → **exactly one**
   `-32600 "request line exceeds the 33554432-byte limit"`, then a healthy `tools/list`.
   The over-cap HTTP exchange uses the headers-first shape (the 9 MiB sendall races the
   close). A 9 MiB stdio line is INSIDE the shipped stdio bound — served, correctly, and
   NOT an attack row. **Verifier:** arms A5h (HTTP) / A5s (stdio).
6. **Suite-wide invariants hold after composition**: pargates green, determinism diff clean,
   xmllint clean, ASan/LSan clean on the adversarial fixture. **Verifier:** arm B asserts all
   four logs, appended to the report verbatim.
7. **Gate registered**: `test/auditregresscheck.sh` in `test/regression.sh`; `./test/manifestcheck.sh` passes. **Verifier:** run it.
8. **Report emitted**: `specs/security-regression-integration/report/` contains one row per
   (attack, transport) pair per the repaired ACs — every row `repelled`. `^A[1-5],` rows +
   the binary/suite trailer lines (the schema grep audit-validation-standalone runs is
   unchanged). **Verifier:** arm C asserts report shape with a schema grep.

## Implementation Notes

- Reuse the unit specs' fixtures rather than duplicating them — the integration value is in composition and transport parity, not fixture novelty.
- HTTP arms need a free port: bind 127.0.0.1:0 is not supported by the CLI (check); if not, probe-and-retry a small port range with a bounded attempt count, and pin the token via env var (never argv — mcp-token-hygiene's warning is asserted elsewhere).
- Keep every attack's expected string imported from the unit spec's gate (sourced shell fragment) so a wording change fails in exactly one place per unit and here simultaneously — that coupling is intended; it is the drift alarm.
- Timing assertions exist to catch hangs, not to gate performance — use generous bounds (60 s) so CI variance never flakes.

## Failure Modes

### Port collision flakes the HTTP arm
- **Trigger:** occupied port on a busy runner.
- **Expected handling:** bounded probe-and-retry; after N failures, a disclosed SKIP with reason (never a false pass).
- **Validator check:** arm headers show the probe; CI logs show the arm actually ran on the primary platform.

### Composition passes but a unit silently regressed
- **Trigger:** a unit's gate weakened while integration still passes on happy paths.
- **Expected handling:** every arm asserts the refusal *shape strings* exported by the unit gates, so unit wording changes fail here too; `manifestcheck` + this gate run in the same suite.
- **Validator check:** arm C's report requires exact-shape matches, not exit codes alone.

### Fixture repo drifts from git behavior
- **Trigger:** git version differences in porcelain for the framing fixture.
- **Expected handling:** fixture expectations live in git-porcelain-framing's fixture directory with its version pin; this spec consumes them read-only.
- **Validator check:** arm A4 reads expectations from the fixture path, not inline copies.

## Dependencies

- **Spec:** regex-screen-hardening — refusal/alert strings for A1. **What breaks if it changes:** A1 greps.
- **Spec:** edit-workspace-pin — refusal code/wording for A2. **What breaks if it changes:** A2 greps and the tier semantics A2 relies on.
- **Spec:** atomic-write-tempfile — temp-name pattern and disclosure for A3. **What breaks if it changes:** the name-prediction fixture and A3's assertions.
- **Spec:** git-porcelain-framing — framing helper + fixture expectations for A4. **What breaks if it changes:** A4's shared fixture path.
- **Spec:** stdio-request-cap — cap constant and resync behavior for A5. **What breaks if it changes:** A5's boundary line length and response count.

## Consumers

- **Spec:** audit-validation-standalone — consumes the report as the composition-trust artifact for the ship verdict. **Constraints on evolution:** the report's row shape (`attack_id, transports, expected_shape, observed, wall, verdict`) is a contract; changing columns breaks the validator's schema grep.

## Status

**Status:** approved  # TERMINAL VALIDATION 2026-11-07 (VALIDATION_PROTOCOL step 2 / Q10 (a); verdict-terminal.md
  in this spec's validation/ dir): the full chain re-verified — Phase-0 errata → Phase-1+2 → Phase-3+4 → the report/
  artifact (8/8 repelled) → the run-3 both-platform matrix GREEN twice at `ef36d595c` (PR `42370666380` + dispatch
  `42370663212`: 35/0 each); three CI meta-gate classes caught pre-upstream (nulbytecheck / gitenvhermeticcheck /
  gateexitcheck), each PM-discriminated, producer-fixed (`c6d197a93` / `073f05acb` / `ef36d595c`), and
  PM-battery-verified at the fix head. 6 commits / 6 files / +777 / `src/` 0. Fork PR #7 closed UNMERGED (its matrix
  delivered green twice — the spent instrument); the lane branch stays on the fork at `ef36d595c` as the
  upstream-PR candidate behind the #484 interlock. Status flip executed by the validator-of-record on the operator's
  word ("sure let's flip it").
**Last updated:** 2026-11-07T16:12:00Z
**Updated by:** WorkBuddy AI / GLM-5.3 (PM seat, validator-of-record — TERMINAL VALIDATION: the
  status flip to approved per VALIDATION_PROTOCOL step 2 / Q10 (a); verdict-terminal.md filed in
  this spec's validation/ dir; fork PR #7 closed unmerged this act; producer relay filed at
  relay-to-producer-sri-terminal.md in this dir and dispatched to scratch)

## Validation Strategy

This spec is verification work; its own components are Tier 1 (shell harness, fixtures, curl probes — focused checks by construction). The composition-level properties it asserts: (C1) every audited attack's contracted refusal shape occurs on every applicable transport; (C2) no refusal path writes or corrupts target bytes; (C3) the composed binary preserves determinism, XML well-formedness, and sanitizer cleanliness over adversarial input. The harness contains no PBT-suitable logic of its own — the PBT burden lives in the four Tier-2 unit specs and is audited by audit-validation-standalone.

## Progress Tracking

- [x] Phase 0: anchors pinned (all five contracts live-verified on `50bc05e84`; the producer's
      report `validation/phase0-report.md` + PM reproductions); red baselines run on the
      seat's own self-built binary (`built_from=50bc05e84`, 15m12s — the first in the seat's
      history); five corrections C1–C5 found, disclosed, and ruled on (this errata).
- [x] Phase 1: test/fixtures/audit-reef/ composed adversarial tree + port-probing HTTP helper
      (committed `1dbdc44fc` — the REAL-zip docx + one-line 128 KB ReDoS subject + the
      runtime-constructed hostile git repo; registration, fixtures and changelog rode the
      same commit per the same-commit discipline; PM-verified 2026-11-06: gatecount
      761@base→762@lane re-proven on a fresh base worktree, slot byte-order re-measured,
      manifestcheck both sides, `validation/verdict-phase1.md`)
- [x] Phase 2: Arms A1a/A1b, A2a/A2h, A3, A4, A5h/A5s replaying the audit reproductions on CLI and MCP transports (folded into `1dbdc44fc`; PM-verified against the six-mutation binary — shipped PASS 8/8 `repelled`, mutant 14 FAILs with M1/M2/M4/M5/M6 discriminating and M3 owned by tempfilesymlinkcheck re-failing 4 rows inside the mutant tree; `validation/verdict-phase1.md`)
- [x] Phase 3: Arm B suite-invariant assertions (pargates, determinism, xmllint, ASan/LSan — ASan per the disk word) + arm C report emission
      (ASan `asan/ripwire` `built_from=1dbdc44fc`, direct run rc=0/zero stderr; the SKIP turned PASS via
      `df9f0d470` — the leg now checks BOTH channels, exit 0 AND no sanitizer banner, a planted exit-0
      emitter caught by name in the PM's own probe; report emitted per arm C; PM-verified 2026-11-06,
      `validation/verdict-phase34.md`)
- [x] Phase 4: Register in test/regression.sh; run full suite on both platforms; report committed to report/
      (registration same-commit `1dbdc44fc`; the gate green in the loop's exact shape at final HEAD
      `55f33b55b` (PM re-run, 0 FAIL lines) and among the 42 pre-reap absorb PASSes; `report/report.txt`
      — 8 rows all `repelled`, trailer `asan=clean`; both-platforms clause: the operator ENABLED fork
      Actions 2026-11-06, the dispatched matrix `42289430220` on `55f33b55b` came back 18 of 24 release
      shards RED (PM correction 2026-11-07: originally read "18/32, two meta-gates" — the 32 was a
      mis-count, the "two" a sampling bias; the true map from all 18 pinned logs is 6/6/6 across
      THREE base-suite META-GATES, all lane-caused, all discriminated base-green/lane-red by the PM)
      — `gitenvhermeticcheck` arm (D): sweep 187 names `auditregresscheck.sh` for not sourcing
      `test/lib/clean-env.sh`; `nulbytecheck` arm (a): the REAL-zip `minimal.docx` lacks a
      binary-allowlist row; `gateexitcheck` arm (G1): the gate's `ok()` helper is non-standard — it
      must record a failed write of its PASS line in the accumulator AND return 0 (the canonical
      917-gate shape), ours since `1dbdc44fc` neither recorded nor returned 0) — all three
      discriminated lane-caused by the PM (base green, lane red, all gates, both platforms, not a
      BSD/GNU split); classes 1+2 FIXED by the producer's `c6d197a93` + `073f05acb` (the `.docx`
      row with reason; the clean-env source line at :69 — PM-proved load-bearing under a hostile
      `GIT_DIR`: stripped → six A4 FAILs, ownership 6→0), PM re-verified all green + mutant
      re-seal 15 FAILs + neighbours; run 2 (the re-dispatch at `073f05acb`) confirms classes 1+2
      green on every completed leg, with the remaining reds being CLASS 3 (`gateexitcheck` G1) on
      the shard-3/4 legs — run 2 final (both its runs in perfect agreement): 6/6 shard-3/4 red
      legs ALL on gateexitcheck only, census-confirmed from all six pinned logs; CLASS 3 FIXED by
      the producer's `ef36d595c` (the canonical `ok()` shape recording into `fails` and returning
      0 unconditionally) — PM-verified at the fix head with the full battery re-run (gateexitcheck
      ALL PASS, 10 ok()-definitions/718 gates; nulbyte + geh no-regression; gate loop-shape PASS;
      mutant re-seal #4 15 FAILs; ASan control PASS; neighbours green; gatecount + bashsource
      sweep-audit ALL PASS; 6 commits / 6 files / +777 / `src/` 0), lane PUSHED at `ef36d595c`
      (ship-key act, disclosed) and the matrix RE-DISPATCHED as run 3, the two-run pair
      `42370666380` (PR) + `42370663212` (dispatch); runs of `073f05acb`: `42340729544` (PR) +
      `42340727896` (dispatch); `validation/verdict-phase4-ci.md` incl. the §1 census correction
      and the §6 class-3 round)
- [x] Terminal validation (VALIDATION_PROTOCOL step 2 on the full chain: Phase-0 errata → Phase-1+2 →
      Phase-3+4 → report/ artifact → the run-3 matrix read — flip EXECUTED 2026-11-07 on the operator's word
      ("sure let's flip it"): the status is `approved`, the chain recorded in
      `validation/verdict-terminal.md` (the four ACCEPTED phase folds + the 8/8-`repelled` report + the
      both-platform matrix GREEN twice at `ef36d595c`, PR run `42370666380` + dispatch run `42370663212`,
      35 success / 0 failure each); fork PR #7 CLOSED UNMERGED this act — its matrix delivered green twice,
      the spent instrument; the lane branch stays on the fork at `ef36d595c` as the upstream-PR candidate
      behind the #484 interlock (probed OPEN at the fold; the upstream PR question is a separate act on its
      own word)) — the PM seat's act, done.
