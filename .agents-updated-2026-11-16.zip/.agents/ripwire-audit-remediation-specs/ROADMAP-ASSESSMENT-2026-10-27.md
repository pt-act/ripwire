# Roadmap Assessment — 2026-10-27

**Assessment base:** upstream `b7c56cf5` (train-37b) with `lane/git-porcelain-framing-v2` merged
(`c695c6b2`). Every status below was checked against **that tree's code**, not against the manifest —
the manifest's `status:` fields and `RE-BASELINE.md` predate the last 940 upstream commits.

**Why this document exists.** The DAG's own record is four specs behind reality, and the one
blocking-tier spec still open is gated on a process question rather than on work. Both facts change
what the next round should be.

---

## 1. The DAG against the code

| # | spec | manifest | verified on `b7c56cf5` | how |
| --- | --- | --- | --- | --- |
| 1 | regex-screen-hardening | `in_progress` | **LANDED upstream** — our PR #397, merged `9b73bcc8` 2026-10-23 (train 33), credited `@pt-act` | live: `--regex='^(a\|aa)+b$'` refused with the full disjointness message |
| 2 | regex-screen-multiquantifier | `planned` | **OPEN — reproduces** | live: `--regex='a*a*a*a*a*b'` admitted, ran to 234,668 hits |
| 3 | edit-workspace-pin | `planned` (DO-NOT-EXECUTE) | **retired — landed upstream** | RE-BASELINE (assumedRoot pin tiers) |
| 4 | atomic-write-tempfile | `planned` (DO-NOT-EXECUTE) | **retired — landed upstream** | RE-BASELINE (`createExclTempFile`) |
| 5 | git-porcelain-framing | `in_progress` | **IN FLIGHT — PR #433**, `MERGEABLE`, CI running green | live: lane `c695c6b2`, 14-arm gate ALL PASS |
| 6 | stdio-request-cap | `planned` (DO-NOT-EXECUTE) | **retired — landed upstream** | RE-BASELINE (`readByteSafeLineBounded`) |
| 7 | mcp-token-hygiene | `planned` | **OPEN** | code: no argv-exposure warning anywhere in `src/cli.h` |
| 8 | rendered-dom-audit | `planned` | **OPEN** (nothing rendered yet) | code: no CSP/ARIA/motion query in the export path |
| 9 | html-export-template-remediation | `planned` | **OPEN** | code: `src/htmlexport.h` has zero `content-security-policy` / `aria-` hits |
| 10 | graph-interaction-accessibility | `planned` | **OPEN** | code: zero `prefers-reduced-motion` / `tabindex` hits; one `<canvas id="c">`, no key model |
| 11 | markitdown-bridge-hardening | `planned` | **OPEN** | code: `docparse.h` still `popen`s `markitdown` off PATH; no opt-out, no PATH pin |
| 12 | parsepool-gate-guard | `planned` | **OPEN** | code: `ingest_parsepool.h:906` calls `installCompiledQueriesAndOpenGate` with **0** `try`/`catch` in the file |
| 13 | security-threatmodel-docs | `planned` | **OPEN** | code: `SECURITY.md` exists; no threat-model content anywhere in `docs/` |
| 14 | security-regression-integration | `planned` | **blocked on 1–6** | manifest `depends_on` |
| 15 | audit-validation-standalone | `planned` | **blocked on 1–6** | manifest `depends_on` |

**Tally: 4 landed · 1 in flight · 8 genuinely open · 2 blocked on dependencies.**

The manifest reads "13 planned, 2 in progress". The honest reading is 4 done, and the gap is not
cosmetic — three of the four are the specs a reader would schedule first.

---

## 2. The blocking surface is 4/5 closed

Five specs carry `validation_gate: blocking` — the Tier-2 input/authorization/write/framing surface:

| blocking spec | state |
| --- | --- |
| regex-screen-hardening (High) | **landed** — PR #397 |
| edit-workspace-pin | **landed** upstream |
| atomic-write-tempfile | **landed** upstream |
| git-porcelain-framing | **in flight** — PR #433, CI green so far |
| regex-screen-multiquantifier | **open** — the last one |

So the project's blocking tier is one spec from complete, and that spec is already written,
reproduced and scoped. That is a materially better position than the manifest's statuses suggest.

---

## 3. The critical path is Q10, not code

`regex-screen-multiquantifier` declares:

```yaml
depends_on:
  - regex-screen-hardening  # must reach approved first
```

`regex-screen-hardening` is `in_progress` for one reason, recorded in its own manifest comment: the
producer does not flip status (VALIDATION_PROTOCOL step 2), and the flip is the dispatcher's or
validator's per §E step 3 — a conflict open as **Q10**. Its validation trail stops at a **round-1
`needs_revision`** verdict; round 2 was pushed for re-validation and never re-validated.

Meanwhile the work itself is **upstream and live**: merged 2026-10-23 as `9b73bcc8`, after six
upstream review rounds, credited to us, guarded by their CI, and refused-on-demand in the binary
this assessment ran against.

So the last blocking-tier spec in the project is gated on a status field. **One ruling unblocks it.**
The ruling this assessment recommends, stated so it can be accepted or rejected as written:

> A spec whose change is merged upstream is `approved` for DAG purposes, and the evidence of record
> is (a) the upstream merge commit, (b) a live re-verification of the finding's PoC on the current
> base, and (c) the upstream review rounds — not an internal verdict written before the merge. The
> internal round-1 `needs_revision` is superseded, not overruled: upstream's six rounds are the
> review that landed.

This is the same shape as `SR-2026-10-18-rederive-external-pins` (the pin decays; re-derive from the
live source) applied to a *status* rather than a constant.

---

## 4. Recommended order for what remains

**Tier A — unblock and land (highest value per round)**

1. **regex-screen-multiquantifier** — blocking tier, the last one, already reproduced (`a*a*a*a*a*b`
   live-admitted; `^(a)*(a)*(a)*(a)*(a)*$`; the bounded-nested `(.\|.){1,3}` shape). Needs the Q10
   ruling first. This is the only remaining work on the security-blocking surface.

**Tier B — small, independent, no dependencies**

2. **mcp-token-hygiene** — an argv-exposure warning + stderr hint; the token already exists
   (`--mcp-token=` / `RIPWIRE_MCP_TOKEN`). Smallest unit in the DAG.
3. **markitdown-bridge-hardening** — opt-out and PATH-pinning for the `popen` bridge. Informational
   tier but a real supply-chain edge: today it runs whatever `markitdown` PATH resolves.
4. **parsepool-gate-guard** — exception safety between worker launch and
   `installCompiledQueriesAndOpenGate`. One `try`/`catch` and a gate-open on every path.

**Tier C — the UI chain (strictly sequential)**

5. **rendered-dom-audit** → 6. **html-export-template-remediation** → 7.
   **graph-interaction-accessibility**. The audit is the go/no-go evidence for both fixes and must
   render real output first; the two fixes are then ordered by their own dependency. Nothing in this
   chain can be parallelised, and the chain cannot start without a rendered artifact to inspect.

**Tier D — documentation and the closing verification**

8. **security-threatmodel-docs** — depends on the token and markitdown contracts existing, so it
   follows Tier B rather than leading it.
9. **security-regression-integration** → 10. **audit-validation-standalone** — both are verification
   work over the unit specs and belong last by construction.

---

## 5. Stale-record hazards worth fixing while this is fresh

- **`RE-BASELINE.md` is dated 2026-10-11** and the base has moved 940 commits since. Its four
  "UNVERIFIED this pass" rows are now answered by this document; three of them (mcp-token-hygiene,
  markitdown, threat-model docs) are still open, which is the answer, not a gap.
- **The three retired specs stay `planned` by design** ("a retired spec is never executed", pinned by
  `_selfcheck.py`). That is correct but reads as backlog; the manifest's header comment is the only
  thing distinguishing them. A `retired:` marker would make the tally legible without touching the
  pin.
- **`regex-screen-hardening`'s record is the one that matters**, because it gates Tier A. Its
  round-1 verdict is not wrong — it was right about the round-1 patch — it is simply superseded.
  Leaving it unamended is what makes the DAG look stuck.

---

## 6. What was and was not verified

- **Live-executed** on the assessment binary: the regex refusal, the multi-quantifier admission, the
  candidate-page tiering, the gate suite for the framing lane.
- **Read from source** on `b7c56cf5`: CSP/ARIA/motion absence, `popen` bridge, prewarm exception
  safety, argv-token warning, threat-model content.
- **Inherited from `RE-BASELINE.md` without re-verification**: the three landings (edit-workspace-pin,
  atomic-write-tempfile, stdio-request-cap). They are upstream and outside this lane's scope; if a
  round touches them, re-verify rather than trust the note.
