# FINDING — Solidity gap: not the gap the reporter found, and the fix already ships

**Recorded:** 2026-11-10T22:45Z by the local producer seat (pt-act). **Revised 22:50Z** — the toolkit doc was
found (it exists; my search could not reach it) and the doc-fix recommendation is filed against a real path.
**From:** an autopilot contributor session in another project (`safe-deployments`, DS-002 lane), via the operator.
**Status:** RECORDED, unverified against upstream's intent. Not dispatched, no PM ruling. Nothing pushed.
**Bearing on our audit lanes:** **none.** This is a product/doc question, not a finding against
`multiquantifier`, SBE, WKC, SRI or the regex-screen bundle. It does not touch the #484 interlock.
**Reports retained:** `reporter-report.md` (rev 1, superseded, kept for the correction record) and
`reporter-report-rev2.md` (**current** — carries all four corrections; safe to relay).

---

## What the reporter got right (verified here, independently)

Ripwire 0.6.7 has **no Solidity grammar**. Checked three independent ways in this session:

| claim | instrument | result |
| --- | --- | --- |
| zero `solidity` in the source tree | `git grep -ci solidity upstream/main` | **0** (whole tracked tree @ `5d61cf452`) |
| zero `solidity` in the binary | `strings … \| grep -ci solidity` | **0** |
| `.sol` never reaches the index | `--skipped` census | `indexed="115"`, `<e x=".sol" files="74"/>` |

The reporter's four reproductions all reproduce, and the exit codes were confirmed **without a pipe**
(`ripwire <repo> --tree >/dev/null 2>&1; echo $?` → **0**; `--skipped` → **0**; `--callers=execTransaction` on a
missing symbol → **1**). The impact framing is also right: `--tree` exits 0 and prints
a confident map, and nothing in *that output* signals the 74 contracts were skipped.

## What the reporter got wrong — three things, all of which would have cost us credibility

### 1. The proposed fix already exists: `--skipped`

The report's headline recommendation is *"consider a 'language not supported' signal in `--tree` … a one-line
warning (`skipped: 74 files, unsupported language: solidity`)"*. That is not a feature request. It is a
documented flag the reporter did not discover:

```
$ ripwire <repo> --skipped
<skipped indexed="115" … unsupported_ext="105" …>
  <f p="contracts/Safe.sol" why="unsupported-ext" bytes="24844" ext=".sol"/>
  … (all 74 .sol paths, individually)
  <e x=".sol" files="74"/>
  <lang n="ts" files="71" symbols="163"/>
```

`--help` advertises it as: *"`--skipped` — say WHY a file is missing from the index, and which indexed files
it cannot vouch for"*. It gives the exact number and the exact extension, per-file, today, on 0.6.7.

**So the real finding is a discoverability defect, not a missing capability.** Filing "add a skip signal" to a
project that already has one is the kind of report a maintainer answers with one line and a link — and every
other claim in the report gets discounted with it.

### 2. The language list is 25, not 7 — the grep method was unsound in two ways

The report concludes the binary supports seven languages from:

```sh
strings /usr/local/bin/ripwire | grep -iE "^(solidity|typescript|javascript|python|rust|go|java|c_sharp|ruby|php)$"
```

Two defects:

- **The pattern enumerates its own answer.** It can only ever print names the author already listed. It cannot
  discover a language it did not think of, and it silently omits any real name that is spelled differently.
- **`^…$` over `strings` output is not source-aligned.** `strings` emits the bare name without the quotes the
  source literal has, so `"ruby"`, `"rust"`, `"python"` survive — but the OTHER names in the same table are
  spelled `"csharp"`, `"objc"`, `"gdscript"`, `"clojure"`, `"proto"`… and `"c_sharp"` in the report matched the
  *symbol* `tree_sitter_c_sharp`, not the language name.

The authoritative instrument says **25**: `--doctor` prints `<c n="grammars" ok="1" loaded="25" expected="25"/>`
and `<c n="tree-sitter" … languages="25"/>`. `src/ingest_crawl.h`'s `kLangTable` agrees — 25 distinct grammar
names: `bash c clojure cpp csharp dart elixir gdscript go java javascript json kotlin lua objc php proto python
ruby rust swift toml tsx typescript yaml`. The reporter missed Kotlin, Swift, Dart, Elixir, Lua, GDScript,
Clojure, Proto, ObjC/ObjC++, Bash and C — including the languages a security-audit shop would care about most.

**This does not weaken the Solidity conclusion** — Solidity is genuinely absent from all 25. But it means the
report's method would have mis-measured any language it was pointed at, which is exactly why it cannot be
relayed as-is to a maintainer who will run it themselves.

### 3. Reproduction #4 proves nothing at all

```sh
grep -ril solidity /Users/rna/ripwire --include='*.rs' --include='*.toml' --include='*.md'   # (no matches)
```

**ripwire is C++, not Rust.** `src/` holds **199** `.h`/`.cpp` files and **zero** `.rs`. A `--include='*.rs'`
grep over a C++ project returns nothing for *any* search string — it is a null instrument. It cannot fail, so
it cannot support a claim. (It also excluded the `.toml`/`.md` corpus that does exist.) The correct form,
which does hold, is `git grep -ci solidity upstream/main` → **0**.

*This is our §11 class: prose asserting a state the command did not measure. Worth noting that the reporter
reached a correct conclusion through one instrument that was broken and one that was self-fulfilling.*

## The four claims the report explicitly did not make — and what we can now say

The report's "What this report does NOT establish" section was honest and is retained as-is. Two of its four
gaps are closable from here:

| its open question | answer |
| --- | --- |
| Is Solidity on the roadmap? | **Unknown.** No `solidity` anywhere in the tree, no roadmap mention. Not our call to assert. |
| Is there a plugin/extension mechanism? | **No evidence of one.** `kLangTable` is a static compile-time table of `{ext, Lang, &tree_sitter_*, querySub}` rows; grammars are linked in, and the vendored `third_party` tree has no Solidity grammar. Adding one is a code change, not config. **Stated as "no evidence", not "impossible"** — we did not audit for a plugin loader. |
| Behaviour on other languages? | Partly answered above: 25 grammars, not 7. |
| Already on their tracker? | **Unknown.** We did not query it. |

## The generalizable insight, which survives all three corrections

> For a code-intelligence tool, silent omission is worse than an error, because the caller cannot distinguish
> "not there" from "not parsed."

This is sound and it is worth keeping. Ripwire's own design already agrees with it — `--skipped` exists
precisely to answer "why is this file missing" — so the insight is not "add the mechanism", it is **"an agent
following the documented load order must be able to reach the mechanism."** That reframing is the actionable
part, and it is a documentation defect with a much cheaper fix than a grammar.

## The defect actually worth relaying to upstream

One real, reproducible defect. It is not the reporter's headline.

### Discoverability: `--tree` is silent, and the documented load order never mentions `--skipped`

Verified in this session:

| check | instrument | result |
| --- | --- | --- |
| `--tree`'s header carries any skip/unsupported field | `head -1 \| grep -oiE 'skip[a-z_]*\|unsupported[a-z_]*'` | **0 matches** |
| the `ripwire-before-you-build` skill mentions `--skipped` | `grep -c skipped SKILL.md` | **0** |

So the census exists and the documented path never points at it. An agent following orient → navigate →
security-scan on a Solidity repo gets a complete-looking 115-file map and no signal that 74 contracts were
dropped, because the verb that says so is not in the load order and not in `--tree`'s header.

**This is the fix worth proposing**, and it is cheap: either an `unsupported=N` count in the `--tree` header, or
one line in the skill/router routing table — *"a file you expected is missing → `--skipped` gives the reason and
the per-extension census."* No grammar work, no new verb.

### Retracted before it was sent: a `--doctor` exit-code bug that does not exist

My first draft of this record claimed `--doctor` exits 0 when invoked without a directory, and called it *"the
exact failure mode the reporter's insight describes, inside ripwire, in the diagnostic verb itself."* **That
was wrong, and it was wrong because I read the exit code off a pipeline.**

```
$ ripwire --doctor 2>&1 | head -40 ; echo $?        # 0  ← head's status, not ripwire's
$ ripwire --doctor >/dev/null 2>&1 ; echo $?        # 1  ← the actual status
```

`--doctor` correctly exits 1 when invoked incorrectly, and 0 when its 9 checks pass. **The trap is already
banked in this project's memory ("`… | head`/`| tail` steals `$?`") and I walked into it anyway, in the same
document whose subject is unreliable instruments.** Recorded rather than deleted, because a record that quietly
drops its own near-miss teaches the next seat nothing — and because the near-miss is itself an instance of the
reporter's insight: an instrument that reported success without measuring anything.

## The documentation defect — real, located, and filed

`.agents/principles/ripwire-toolkit.md` §4 **does exist**: `~/CyberStrike/.agents/principles/`, 8999 bytes,
mtime 2026-10-25 18:14, sha256 `bdcdd29f2a7b0cebba2c032d593ccf8c0d2c8719a0329bfb8ae791f437db6090`.

The quoted text is there verbatim, and `RIPE NCC` occurs exactly **twice**:

```
128:| Intake of a source-available program (e.g. RIPE NCC) | `ripwire-orient` → `ripwire-security-scan` on the untrusted-input paths |
137:(RIPE NCC, source-audit repos) and on the harness's own code. It is not a
```

Line 137 is inside §4's prose: *"Ripwire is especially useful on the programs where the toolkit is the source
(RIPE NCC, source-audit repos) and on the harness's own code."* The table row at 128 is the phase/task mapping.

**The defect, stated precisely:** §4 names one example program (`RIPE NCC`) plus the category phrase
`source-audit repos`. Solidity source-audit programs are that shape, so the sentence reads as coverage it does
not have. And the file **never mentions `--skipped`** (`grep -c skipped` → **0**) — so nothing in the toolkit
doc tells an agent where to find the census that would have explained the omission.

**Two fixes, both one-liners, and this is the cheapest of the three:**
1. §4's prose (line ~137): name the supported set, or add the pointer — *"if a source tree looks smaller than
   you expect, `--skipped` says why."*
2. §2 Load order or §7 Anti-patterns: one line, *"a file you expected is missing → `--skipped`."*

Recorded as a defect **in our own toolkit doc**, not upstream's — this one we can just fix, no maintainer
conversation needed. Snapshot retained at `.evidence/ripwire-toolkit.md.snapshot` so the §4 text stays verifiable
even after the doc is amended.

### Retracted: "that file does not exist" — it does, and my search could not reach it

My first draft of this record asserted the toolkit doc did not exist and that `RIPE NCC` appeared nowhere in
the searched trees. **Both statements were false**, and the operator corrected them within the hour.

The failure is instructive and identical in shape to the report's reproduction #4 — a search that cannot find
what it is looking for, returning a confident negative:

```
searched:  ~/Desktop/working  ~/.agents  ~/.claude  ~/.workbuddy-ai  ~/ripwire   (depth 6)
actual:    /Users/rna/CyberStrike/.agents/principles/ripwire-toolkit.md         ← not in any root
```

No root I chose contained `~/CyberStrike`, so `find` was **guaranteed** to return nothing. I then wrote the
result up as a property of the filesystem (*"the file does not exist"*) rather than as a property of my search
(*"I did not look there"*). **`find` returning empty over a hand-picked root list is a statement about the root
list, never about the machine.** The honest form of that finding was *"not present in the trees I searched;
I did not search `~/CyberStrike`"* — and the way to write it is to name the roots searched, which is exactly
what stops the reader (or me) from mistaking scope for absence.

Worse, this was a **negative existence claim**, and negatives need a search that can fail. My search could not
reach the target, so it could not fail, so it proved nothing — the same defect I had just spent a section
convicting the reporter of. The correction is applied above, and the doc-fix recommendation is now filed against
a real path with a hash rather than dropped as unrecordable.

## What was NOT established here

- Whether Solidity is planned, tracked, refused-as-out-of-scope, or simply unconsidered upstream.
- Whether a plugin mechanism exists (no evidence found; not a denial).
- Whether 0.6.7 is the current release (our binary is `built_from=0e0f67c73`, which is **behind**
  `upstream/main` @ `5d61cf452`; every claim here is against the 0.6.7 binary AND re-checked in the
  `5d61cf452` source where the instrument was source-based).
- Whether the reporter's `--tree` numbers (`files="115" files_unlisted="17" shown="80"`) were taken with a
  different flag set — we reproduced `indexed="115"` from `--skipped`, which agrees.

## Recommended next act (for the incoming PM, not for dispatch now)

**Do not relay the reporter's revision 1.** Revision 2 (`.evidence/reporter-report-rev2.md`, sha256
`27c46d55…`, 6688 bytes) is sound and already carries all four corrections — it can be relayed, if the operator
decides to. What follows is what I'd add to it from this side.

The work now splits in two, and only one half is a message to someone else.

### Half 1 — ours, no conversation needed: fix the toolkit doc

`.agents/principles/ripwire-toolkit.md` §4 (line ~137 prose, plus the table row at 128) reads as general
source-audit coverage. Name the supported set, or add the `--skipped` pointer. One line; zero risk; and it
directly serves the standing pattern I found in the packet: **whoever reads the toolkit doc starts with the
false impression, so fixing the doc is upstream of fixing the tool.** This is the cheapest of the three fixes and
the only one entirely within our control. The operator owns that file (`~/CyberStrike`), so the edit is theirs to
make; the recommendation and the exact lines are recorded here so it is not lost.

### Half 2 — upstream, one note: the machine-readable header

Ask whether `--tree`'s header should carry an `unsupported="74"` attribute (or similar). Framed as *"your tool
already computes this — `--skipped` proves it — the map just doesn't mention it."* Compliment with a fix
attached, not a bug report.

**Explicitly do not:** propose a Solidity grammar (no evidence about their roadmap — the overreach the reporter
correctly avoided); and **do not** carry over revision 1's reproductions #3 and #4, both unsound.

**Framing decision that is still the operator's:** if ripwire *is* planning Solidity this reads as a roadmap
note; if not, it is a doc-and-signal fix. Both halves above are worth doing either way, which is why they are
recommended over the reporter's framing — they do not depend on the answer.

## The pattern, recorded because it bit three times in one cycle

Three instruments, one failure mode, across two seats and two agents:

| # | instrument | why it answered a question it wasn't asked |
| --- | --- | --- |
| 1 | reporter: `grep -ril solidity --include='*.rs'` | null — no `.rs` files exist, so it cannot fail |
| 2 | me: `ripwire --doctor \| head -40; echo $?` | status of `head`, not of ripwire |
| 3 | me: `find` over five hand-picked roots | the target was in a sixth; absence of scope read as absence of file |

The general form is worth stating once, because it is the finding's own insight turned on its authors:
**an instrument that cannot fail cannot inform.** #1 could not fail (wrong file type), #2 reported a different
process's status, #3 could not succeed (wrong roots). Each returned a confident answer, each was written up as a
fact about the world, and each had to be retracted by the *other* seat.

The discipline that catches all three: **before trusting a negative or a status, ask what the instrument would
have had to do to fail, and confirm it was capable of doing that.** For a search, name the roots. For a status,
know which process you quoted. For a grep, confirm the files it was pointed at exist.

---

## Appendix — evidence (all retained under `2026-11-10-solidity-gap.evidence/`)

The reporter's raw output was left in `/tmp/rw_safe.txt`. **`/tmp` has been wiped four times in this project's
history**, so it was copied into the evidence dir on arrival; the copy is now the record of authority.

| file | sha256 (`shasum -a 256`) | bytes |
| --- | --- | --- |
| `reporter-report-rev2.md` (**current, safe to relay**) | `27c46d5501d84fb467c813ac22124c696d7aa3b3514a4bebd971a4d561206baf` | 6688 |
| `reporter-report.md` (rev 1, superseded, kept) | `bdeb8d49ea58529d5a62ea268df28898b974ebc79777fcc2b21b126e752c3655` | 4730 |
| `ripwire-toolkit.md.snapshot` (§4, the doc under fix) | `bdcdd29f2a7b0cebba2c032d593ccf8c0d2c8719a0329bfb8ae791f437db6090` | 8999 |
| `reporter-tree-raw.txt` (its `--tree` output) | `fc9e9278b7fd0259c0f5320b865a10bfcf0816e73482007925f166c9c87caf94` | 11163 |
| `skipped.xml` (**the instrument the report was missing**) | `040c7db1a04c451c3b4e9e73104701859a6af2158a77d4bef8ab3bfa58f898c7` | 12223 |
| `doctor.xml` (25 grammars; the real language list) | `c1c8eb8d40aec88a5ea46db45099cd23447dca912bdab925a77378f892ecf85c` | 4787 |
| `version.txt` | `6da62b1cd69eb8344a5e6c1db767a607afdeeeeda39e59d0869500a1306b161c` | 91 |
| `callers-execTransaction.txt` | `d49a148a3177ab13de6ea082d2711ce4580f6af2f89e5f7f74087964d0dd3399` | 408 |
| `around-setupOwners.txt` | `25852d448bafae2fd4337608fc81767c5770aeb2e55f0d32bb412ede10a343b8` | 48 |

`ripwire-toolkit.md.snapshot` is a **copy**, taken 2026-11-10T22:43Z, because the live file lives in
`~/CyberStrike` and will be edited when §4 is fixed. The snapshot is what makes the §4 quote verifiable after
the amendment — otherwise the evidence for "this doc said X" disappears precisely when the fix lands, which is
the usual fate of a doc-defect record.

Environment: `ripwire 0.6.7 (Release, AppleClang 16.0.0.16000026, emit=std::print, built_from=0e0f67c73)`,
macOS 14.8.9. Test repo: `safe-smart-account` v1.5.0 — **74 `.sol`, 74 `.ts`**. The harness and the contracts
are the same size, which is precisely why a 115-file map with zero contracts reads as complete: it is not a
thin map, it is half the repository.
