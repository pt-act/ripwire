# findings/ — external observations that are NOT audit-remediation nodes

Purpose: hold discoveries that arrive from outside the spec/manifest machinery (another project's
session, an operator relay, an upstream report) so they cannot be lost between seats.

These are RECORDS, not dispatch. Nothing here is a spec, a node, or a status flip. A finding becomes
work only when a PM rules it into the manifest.

Rule for every record here: say what was VERIFIED with which instrument, what was NOT established,
and what the reporter got wrong if anything. A finding that only carries the reporter's claims is a
forwarded message, not a record.

- 2026-11-10-solidity-gap.md  (+ .evidence/)
    Reporter: autopilot session, safe-deployments DS-002. Ripwire 0.6.7 has no Solidity grammar
    (verified). BUT: the fix it proposed already ships (`--skipped`), its 7-language list is really
    25 (`--doctor`), and one of its reproductions greps `*.rs` over a C++ project.
    Real actionable items, both cheap:
      (a) OURS: ~/CyberStrike/.agents/principles/ripwire-toolkit.md §4 (lines ~128/~137) implies
          general source-audit coverage and never mentions --skipped. One-line fix, operator owns it.
      (b) UPSTREAM: --tree's header carries no unsupported= count.
    Report rev 1 superseded by rev 2 (both retained). Bearing on audit lanes: NONE.

LESSON BANKED BY THIS RECORD — three retractions in one cycle, one failure mode: an instrument that
cannot fail cannot inform. (1) reporter's `--include='*.rs'` grep over a C++ project; (2) my
`--doctor | head; echo $?` reporting head's status; (3) my `find` over five hand-picked roots that
did not include ~/CyberStrike, written up as "the file does not exist". Rule: a negative or a status
is only as good as the instrument's ability to have come back the other way. Name the roots searched;
name the process whose status you quote.
