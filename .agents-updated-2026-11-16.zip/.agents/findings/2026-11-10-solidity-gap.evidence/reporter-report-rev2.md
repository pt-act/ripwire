# Ripwire 0.6.7 — Solidity discoverability gap

**Reporter:** Autopilot (contributor session)
**Date:** 2026-11-10
**Revision:** 2 — corrected after PM review. Revision 1 contained three
unsound evidence commands; see §6.
**Severity for downstream users:** medium — the mechanism exists, the
documented path does not reach it

---

## Summary

`ripwire` 0.6.7 does not index Solidity. That is by design and is **not** a
defect: `--skipped` reports it precisely, including a per-extension census and
every skipped path.

The defect is narrower and more interesting: **the documented entry points do
not point at `--skipped`.** An agent following the load order in
`ripwire-toolkit.md` (`ripwire-orient` → `ripwire-navigate`) receives a
complete-looking map with no signal that half the repository was excluded, and
no pointer to the command that would explain it.

This is a discoverability gap, not a capability gap.

---

## Environment

| Item | Value |
|---|---|
| Engine | `ripwire` 0.6.7 (Release, AppleClang 16.0.0.16000026, `emit=std::print`, `built_from=0e0f67c73`) |
| Binary | `/usr/local/bin/ripwire` |
| Source | `/Users/rna/ripwire` — **C++**, 199 `.h`/`.cpp` in `src/`, zero `.rs` |
| Platform | macOS (darwin 23.6.0) |
| Test repo | `safe-smart-account` v1.5.0 — **74 `.sol`** and **74 `.ts`** |

The 74/74 split matters: the TypeScript harness and the Solidity contracts are
the same size. A 115-file map with zero contracts is not a thin map — it is
half the repository.

---

## 1. The mechanism works

```sh
ripwire <repo> --skipped
```

Emits, among other things:

```xml
<e x=".sol" files="74"/>
<f p="certora/harnesses/SafeHarness.sol" why="unsupported-ext" bytes="3656" ext=".sol"/>
<f p="certora/mocks/ModuleGuardMock.sol" why="unsupported-ext" bytes="2630" ext=".sol"/>
... 74 entries total
```

`--help` describes it as *"say WHY a file is missing from the index, and which
indexed files it cannot vouch for."* This is exactly the right design. Nothing
needs building.

## 2. The documented path does not reach it

```sh
ripwire <repo> --tree
```

Header:

```
files="115" files_unlisted="17" shown="80" total="98"
shown_symbols="161" pr_iters="12"
```

- **No skip field.** `grep -c 'skipped\|unsupported'` on the `--tree` output
  → **0**.
- Exit code **0** (verified without a pipe).
- The map describes the TypeScript harness and the docs. No `.sol` appears.

An agent reading this output has no way to distinguish "the contracts are not
in this repo" from "the contracts were not parsed." Both produce the same
115-file map and the same exit 0.

## 3. The skill layer does not mention it either

`ripwire-before-you-build` — the skill an agent loads before starting
multi-symbol work — contains **zero** mentions of `--skipped`.

So both the machine-readable header and the human-readable skill omit the one
command that resolves the ambiguity.

---

## 4. Language census — 25, not 7

```sh
ripwire --doctor <dir>
```

```
languages="25"
```

`kLangTable` confirms 25 grammars. Solidity is genuinely absent from all 25 —
the conclusion holds — but the count matters for how the gap is described.

**Correction from revision 1:** the original report claimed 7 languages, based
on:

```sh
strings /usr/local/bin/ripwire | grep -iE "^(solidity|typescript|...)$"
```

That command is unsound. It **enumerates its own answer** — it can only print
names already listed in the pattern. It also matched `c_sharp` from the
*symbol* `tree_sitter_c_sharp`, not the language name (which is `csharp`). It
missed Kotlin, Swift, Dart, Elixir, Lua, GDScript, Clojure, Proto, ObjC, Bash
and C.

The correct instrument is `--doctor`, which reports the loaded table directly.

---

## 5. What is genuinely worth sending upstream

Two cheap fixes, both about routing rather than capability:

1. **Add a skip field to the `--tree` header.** One attribute —
   `unsupported="74"` or `skipped="74"` — converts a silent omission into a
   visible one. The data is already computed; `--skipped` proves it.
2. **One line in `ripwire-router` / `ripwire-before-you-build`:** *"If the map
   looks smaller than the repo, run `--skipped`."*

**Do not propose a Solidity grammar.** There is no evidence about the roadmap,
and requesting a language is a different (much larger) ask than fixing
discoverability. Revision 1 correctly avoided this; it should stay avoided.

---

## 6. Corrections to revision 1

Three evidence commands in revision 1 were unsound. Recorded rather than
deleted, because the failure mode is the same one the report is about.

| # | Revision 1 claim | Why it was wrong |
|---|---|---|
| 1 | "Consider a `skipped: 74 files` warning" as the headline fix | `--skipped` already ships and does exactly this. The finding is discoverability, not capability. |
| 2 | "The binary's language list is 7" | The grep enumerated its own answer and matched a symbol name. `--doctor` says 25. |
| 3 | `grep -ril solidity … --include='*.rs'` → 0 | **Null instrument.** Ripwire is C++; `src/` has 199 `.h`/`.cpp` and zero `.rs`. That grep returns nothing for *any* string. |

A fourth error was caught during PM review and is worth recording as a caution:
`ripwire --doctor 2>&1 | head -40; echo $?` reports **`head`'s** status, not
ripwire's. Without the pipe, `--doctor` exits **1**. The claimed exit-0 bug did
not exist. This is the same pipe-status trap already banked in this project.

---

## 7. What this report does NOT establish

- Whether Solidity is on the roadmap.
- Whether a plugin or extension mechanism exists for adding grammars.
- Behaviour on any language other than those in the 25-grammar table.
- Whether the project's issue tracker already covers this.

---

## 8. Provenance

Test repo (pinned):

```
/Users/rna/Desktop/working/safe-deployments/breifs/runs/DS-002/20261110T183542Z/sources/repos/safe-smart-account-v1.5.0
```

Evidence copies are held in the PM's record at
`/Users/rna/ripwire/.agents/findings/.evidence/` (7 files, hashed). The
original `/tmp` captures are **not** authoritative — `/tmp` has been wiped four
times in this environment.

---

## 9. The insight, restated

Revision 1's framing was: *silent omission is worse than an error, because the
caller cannot distinguish "not there" from "not parsed."*

That still holds — but ripwire already agrees, and already implements the
answer. The actionable form is narrower:

> **The documented path must reach the mechanism.**

A tool that can explain its own omissions, but whose default output and whose
skills never mention the explanation, still produces the silent-omission
failure. The fix is one header attribute and one line of skill text.
