# Ripwire 0.6.7 — Solidity support gap

**Reporter:** Autopilot (contributor session)
**Date:** 2026-11-10
**Severity for downstream users:** high — silent omission, not an error

---

## Summary

`ripwire` 0.6.7 does not index Solidity. On a real Solidity repository it
indexed 115 files and surfaced **zero** `.sol` files. Symbol lookups for
contract functions return `symbol not found`. The binary's language list
contains no Solidity grammar, and the string `solidity` appears **zero times**
in both the binary and the source tree.

This is not a configuration gap. There is no Solidity grammar anywhere in the
project.

---

## Environment

| Item | Value |
|---|---|
| Engine | `ripwire` 0.6.7 (Release, AppleClang 16.0.0.16000026, `emit=std::print`, `built_from=0e0f67c73`) |
| Binary | `/usr/local/bin/ripwire` |
| Source | `/Users/rna/ripwire` |
| Platform | macOS (darwin 23.6.0) |
| Test repo | `safe-smart-account` v1.5.0 — **74 `.sol` files** |

---

## Reproduction

### 1. Tree map omits every contract

```sh
ripwire <repo> --tree
```

Result header:

```
files="115" files_unlisted="17" shown="80" total="98"
shown_symbols="161" pr_iters="12"
```

Indexed files are `.ts`, `.md`, `.json`, `.yml`. **No `.sol` appears in the
output.** The map describes the TypeScript test harness and the docs, not the
contracts.

### 2. Symbol lookups fail

```sh
ripwire <repo> --callers=execTransaction
# ripwire: --callers symbol not found: execTransaction
# <callers ... of="execTransaction" found="0"/>

ripwire <repo> --around=setupOwners
# ripwire: --around symbol not found: setupOwners
```

Both symbols are defined in the repo's Solidity sources.

### 3. The binary has no Solidity grammar

```sh
strings /usr/local/bin/ripwire \
  | grep -iE "^(solidity|typescript|javascript|python|rust|go|java|c_sharp|ruby|php)$" \
  | sort -u
```

Output:

```
c_sharp
java
javascript
python
ruby
rust
typescript
```

No `solidity`.

### 4. Zero mentions in binary and source

```sh
strings /usr/local/bin/ripwire | grep -ci solidity
# 0

grep -ril solidity /Users/rna/ripwire --include='*.rs' --include='*.toml' --include='*.md'
# (no matches)
```

---

## Why this matters

`.agents/principles/ripwire-toolkit.md` §4 lists as a primary use case:

> "Intake of a source-available program (e.g. RIPE NCC)"
> "Ripwire is especially useful on the programs where the toolkit is the
> source (RIPE NCC, source-audit repos)"

Solidity source-audit programs are exactly that shape. An agent following the
documented load order (`ripwire-orient` → `ripwire-navigate` →
`ripwire-security-scan`) on a Solidity repo receives a map of the TypeScript
test harness and none of the contracts.

The dangerous part is the **exit code is 0 and the output looks complete**. An
agent has no signal that the contracts were skipped. The plausible failure is
concluding the contracts are absent from the repo, or that the repo is
"mostly TypeScript", rather than that the language is unsupported.

`ripwire-toolkit.md` §7 already names the adjacent anti-pattern:

> "❌ **Opening ten files to answer one question.** Orient first."

The inverse is worse: orient, get a confident map, and never learn the map
excluded the thing you came for.

---

## What this report does NOT establish

- Whether Solidity is on the roadmap.
- Whether a plugin or extension mechanism exists for adding grammars.
- Behaviour on any language other than those listed above (not tested).
- Whether the project's issue tracker already covers this.

---

## Suggested action for the ripwire PM

1. **Confirm whether Solidity is planned.** If it is, this is a roadmap note.
2. **If it is not**, amend `ripwire-toolkit.md` §4 to state the supported
   language set explicitly, so CyberStrike agents do not spend a cycle
   discovering it. The current text implies source-audit coverage generally.
3. **Consider a "language not supported" signal in `--tree`.** The current
   behaviour — index the repo, silently omit the unsupported files, exit 0 —
   is the failure mode that costs the most time. A one-line warning
   (`skipped: 74 files, unsupported language: solidity`) would convert a
   silent wrong answer into an obvious one.

Point 3 is the generalizable product insight: for a code-intelligence tool,
**silent omission is worse than an error**, because the caller cannot tell the
difference between "not there" and "not parsed".

---

## Provenance

All commands above were run in this session against the pinned
`safe-smart-account` v1.5.0 checkout at:

```
/Users/rna/Desktop/working/safe-deployments/breifs/runs/DS-002/20261110T183542Z/sources/repos/safe-smart-account-v1.5.0
```

Raw `--tree` output retained at `/tmp/rw_safe.txt` (11,163 bytes).
