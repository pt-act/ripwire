# Standing Requirements — Verdict-Time Rules With Provenance

## [SR-2026-09-21-counted-prose] Prose that names a counted token is a counted line

- **Rule:** never write an emitter-API name (formatTo, snprintf, …) in a comment inside src/ — the counting gates enumerate mentions line-by-line, comments included; reword the prose, never bump the pin.
- **Provenance:** PR #3 CI round 1 (fixedbufsweep 333→334) and round 3 (344→345, in the fix's own comment) — learned twice in one branch.
- **Scope:** any change touching src/ comments near serialize/emit surfaces.
- **Status:** active

## [SR-2026-09-21-degrades-need-sinks] Every degrade emits through a sink the emitter reads

- **Rule:** DISCLOSE takes (sink, why), never a bare message on an answer-changing path; the page IS the sink — a degraded render ships the honest document with reason=.
- **Provenance:** PR #3 CI round 2 (selfcheckcheck R: 49→51 sink-less sites).
- **Scope:** any new degrade path in verbs/emit code.
- **Status:** active

## [SR-2026-09-21-gate-sweep-is-owned] Name the affected-gate set by reading what owns each surface

- **Rule:** before claiming a sweep, enumerate the gates that own every touched surface (guard messages, schemas, counts, ceilings) — a sweep-miss is a CI round.
- **Provenance:** modifierguardcheck missed in PR #3's first sweep (16-gate list grew from 10); timing gates identified as flake-class only by comparing main's green runs.
- **Scope:** any verification claim.
- **Status:** active

## [SR-2026-09-28-explicit-path-add] git add by explicit path list, never -A

- **Rule:** on this workspace, `git add` takes an explicit path list (src/... test/...). `-A` / `-u` / `.` sweep the private workspace dirs (.hoplite/ attachments, .context/, specs/, .agents/) into public commits — .gitignore is the backstop, not the defense.
- **Provenance:** PR #362's review-fix commit (a1dcd742e) used `git add -A ':!.agents'` — it swept .hoplite/attachments (the operator's private audit/spec/memory-format files), .context/ and specs/ into the public branch and fork main. Both force-pushed clean within ~15 minutes; the unreachable commits linger on the provider until GC. Exposure: planning documents only, secret-scan clean.
- **Scope:** every commit on every branch of this fork.
- **Status:** active

## [SR-2026-09-29-help-output-triplets] A --help output change is a three-file commit

- **Rule:** any change that moves `--help` bytes lands as ONE commit with (1) the source change, (2) regenerated docs/COMMANDS.md (`python3 docs/docs_commands_build.py --bin ./build/ripwire`), and (3) the re-pinned `help_all` line in test/printf_parity.manifest. The pins exist to force exactly this.
- **Provenance:** the ci.yml full-matrix schedule failed on fork main at 9105b1979 — the #362 review round's help-text edit (run 36562387291, jobs release/docscommandscheck and fallback-emitter/printffmtparitycheck). Before re-pinning, prove the movement is identical on BOTH emitters (std::print build + the std::format+fputs fallback build) — identical movement = deliberate text change; different movement = a conversion drifted, and must be reverted instead.
- **Scope:** any src/ change that can alter --help or the flag surface.
- **Status:** active


## [SR-2026-10-12-authorship-identity] Every commit this project ships is authored as pt-act

- **Rule:** before ANY commit in any session, `git config user.name "pt-act"` and `git config user.email "psychoactive28@gmail.com"` at repo-local level, then verify with `git config user.email`. Applies to every workspace — fresh clones do NOT inherit this; it is set per-workspace, every session, before the first commit.
- **Provenance:** PR #362 merged 2026-10-11 with all commits authored by `usehoplite[bot]` (the platform's default identity) — the contributor badge accrued to the bot, not to the operator. The operator declined to ask for retroactive credit ("the badge should be earned, not begged for") and ordered the identity fixed for all future contributions: quote, "let's continue our contributions and the future will set it right." Authorship by git = the credit; PRs pushed from the fork pt-act/ripwire merge into redhat-et/ripwire with pt-act as author once this rule is applied.
- **Scope:** every repository, every session, the DAG phase's every PR.
- **Status:** active (set in this workspace 2026-10-12; verified `git config user.email` = psychoactive28@gmail.com)

## [SR-2026-10-18-artifact-paste-hygiene] Public artifacts are posted from files and read end-to-end, never pasted from a relay buffer

- **Rule:** any content crossing to a public channel (PR body, issue/review comment, commit message) is (1) written to a file first and posted from the file (`gh pr create --body-file`, `gh pr comment --body-file`), so channel content and operator-relay content never share a buffer, and (2) read end-to-end — top to tail — before posting. A relay buffer that carried assistant→operator handoff prose is presumptively contaminated; pasting from it whole is the failure mode.
- **Provenance:** PR #362's merged body shipped trailing operator-relay text — the "here it is, he — the full body, ready to paste… send me the number" handoff instructions — pasted verbatim below the Reference section. Spotted 2026-10-18 during post-merge ledger review; five review rounds and two agent-assisted teams missed it (residue at the tail, outside the diff). This is the manual-transport seam failing, not the operator: no human should be the transport layer for artifact content.
- **Scope:** every public artifact leaving the workspace — PR bodies/titles, issue and review comments, commit messages, gists/pastes.
- **Status:** active

## [SR-2026-10-18-rederive-external-pins] Externally-pinned constants are re-derived from the live source before every round and before landing

- **Rule:** any gate, manifest, or acceptance criterion pinned to a snapshot of mutable external state (upstream's advertised verb roster, generated docs, a live API surface) is re-derived from the live source before each review response and again before landing — never hand-patched from memory of what changed. If the pin moved, the refresh itself is evidence for the round, same class as red-before/green-after.
- **Provenance:** PR #291 pinned `EXPECTED_VERBS` to the 31-verb pre-train-10 roster; upstream train 10 (#300) landed `affected` + `rank_by` (→33) while the PR sat in review, reddening the PR's own (6b) arm against main. The maintainer's fix was exactly this rule: re-derive from a live `tools/list` call, then re-prove the mutations — "a mechanism that needed zero rework, only a data refresh."
- **Scope:** any pinned constant whose source of truth lives outside this branch.
- **Status:** active

## [SR-2026-10-27-issue-may-already-be-fixed] Before re-raising or nursing an issue, prove it is still open in the code

- **Rule:** an issue we filed is not evidence that the work is outstanding. Before nudging a maintainer, re-raising a "stale" issue, or waiting on one, run the three-second check: `git log --grep="<issue>"` across the current base, and `grep -rn "<issue>" src/ test/` — if either hits, read the hit and establish whether it closed the ask. Only an issue whose ask survives both checks is genuinely open. The same check applies to issues the maintainer answered: a ruling in a thread is not a merge, but a merge in the log IS an answer.
- **Provenance:** issue #294 ("extend the pageview paging window to the task-lens verbs") sat open from 2026-09-19 while we nudged it on 2026-09-28 and then watched it. The maintainer had **blessed the design on 2026-09-28** — a full ruling plus five optional suggestions — and the implementation was **our own PR #362**, merged upstream 2026-10-09 as `c7147f76` ("budgeted-bundle candidate page, @pt-act; no-ff, authorship kept"). Every part of the ask, including all five suggestions, was live in `main`; the source carried `#294`/`#362` markers in `forpage.h`, `cli.h`, `compactlegend.h` and `mcprefusal.h` the whole time. Closed 2026-10-27 with the evidence. The month of "waiting for the maintainer" was spent waiting for a merge that had already happened — the cost was attention, and the risk was re-raising a resolved issue at a maintainer who had answered it.
- **Scope:** any issue we opened, any review thread we left unanswered, any "blocked on the maintainer" claim in a status entry. Applies before every nudge and every roadmap assessment.
- **Status:** active

## [SR-2026-10-30-gate-scenario-discrimination] An arm's asserted observable must be ABLE to discriminate the design scenario from the weak one

- **Rule:** when an arm's purpose is "the tool degrades honestly under defect X while everything else stays healthy," the arm must construct an environment where everything else IS healthy — otherwise the asserted observables pass for the weak reason (total failure) and the arm is vacuous even while green. Before trusting a green arm that shims a dependency, measure BOTH states (shim-with-delegation vs shim-fully-broken): if the tool's asserted outputs — stdout AND stderr, byte-compared — are identical across the states, the arm cannot see the difference it exists to detect, and the fix is to make the environment real (e.g. export the fallback variable so the shim can delegate), not to add more assertions on the same overdetermined observable.
- **Provenance:** CodeRabbit F3 on PR #469 (2026-10-30, reply `4420227197`): `test/gitframingcheck.sh` line 98 assigns `REAL_GIT` without `export`, so arm 8's shim (`exec "$REAL_GIT" "$@"`) died `exec: : not found` (127) on every non-`-z` call — the tool lost git entirely and the arm's honest-degrade assertions (non-zero rc, zero rows, the stderr line) passed in both states byte-identically. Measured on the PR-tip binary: stdout and stderr byte-identical across no-export vs export environments; with the export, the same shim creates the design scenario (repo healthy, only the `-z` framed read refused). Origin: our own gate commit `4c0aa673`; the red-first review never caught it because the pre-fix binary fails every arm anyway.
- **Scope:** any gate that shims `git` (or any dependency) via PATH and asserts honest degrade — `gitframingcheck` arm 8 today; the export one-liner + the delegating-shim refinement land in the follow-up lane (sequenced behind #469's merge).
- **Status:** active

## [SR-2026-10-30-measure-on-the-reviewed-tree] Instrument claims are measured on the reviewed tree's own build; cache experiments run in one shell

- **Rule:** claims about the tool's behavior in a public artifact (review reply, PR body, closure comment) are measured on the *reviewed tree's own build* — never a neighboring lane build or a stale checkout; a scratch-worktree build always uses absolute `-S`/`-B` paths (a background build inherits the repo cwd, and a relative invocation silently builds the wrong tree). Any cache-rooted experiment (`$TMPDIR/ripwire`) runs inside ONE shell: tool-call shells do not share exported variables, so multi-step cache experiments silently split across roots and produce fake negatives — pin the cache root and probe blob mtime to distinguish served-from-cache vs recomputed.
- **Provenance:** the #469 verification round (2026-10-30). First: a background build launched with relative paths silently built the repo's own stale main checkout (940 commits behind) instead of the PR-tip worktree — caught only because the first experiment returned rc=127 before the correct binary existed; the re-run with absolute paths was correct. Second: the E2b fake-negative — the "healthy rerun" ran in a fresh shell without the pinned `TMPDIR`, silently recomputed from a different cache root, and printed the TRUE answer, which would have "refuted" the cache-poisoning claim had the run not been redone in one shell with mtime probes (blob mtime unchanged → served, not recomputed).
- **Scope:** every measurement backing a public artifact, and every cache-poisoning / cache-behavior experiment on this host.
- **Status:** active

---

# CONTRIBUTOR ENTRIES — the strix fork's fence run (2026-10-28 → 2026-11-09)

*Provenance context: the operator ran a parallel project (the strix fork — an autonomous-pentest-agent platform) through the same methodology's disciplines, manually applied: 31 adversarial validation rounds over a security layer ("the fence"), a six-round spec grading cycle, and an integration replay against a live container. The entries below are that run's scars, in the SR format, contributed per the operator's direction. The provenance cites the strix fork's own ledger (`.agents/memory_bank/manifest.yml`, 170 events at the contribution time).*

## [SR-2026-11-08-cross-boundary-ledger-keys] The same file gets one ledger key across every boundary — canonicalize at the boundary, both sides

- **Rule:** when two systems record and query the same object across a boundary (container/host, seed/gate, symlink/root), the spellings must be canonicalized at the boundary on BOTH sides — or the same file is two files to the ledger. Resolve once, store under the checked key, and verify the round trip by querying back what was just recorded.
- **Provenance:** the strix fork's integration replay, pass 3 (2026-11-08): `lookup('/usr/bin/ls')` hit the seed's envelope while `lookup('/bin/ls')` returned a miss — kali-rolling is usrmerged (`/bin` → `/usr/bin`), the inventory recorded the physical spelling, the gate resolved the symlink spelling. 317 executables seeded, and every seeded binary denied. The run's own fingerprint: a three-week-old handoff note ("5 TestImageInventorySeed /bin vs /usr/bin failures were merged-usr VM artefacts") was the live defect's signature, misread as a test-environment quirk.
- **Scope:** any cross-boundary key agreement — container/host, seed/consumer, symlink/real, proxy/origin.
- **Status:** active

## [SR-2026-11-08-invisible-lane] In-window beats invisible — a lane the operator cannot see must justify itself

- **Rule:** any validation or grading lane that runs where the operator cannot observe it must either become visible or be replaced by in-window work. A background dispatch that dies silently with zero footprint is WORSE than a failed verdict: the operator cannot distinguish "running" from "gone," and the wait is unbounded.
- **Provenance:** the strix fork's round-28 (2026-11-07): a dispatched background validator produced ZERO output — no archive step, no scratch, no write (forensics: the graded file's hash unchanged, no scratch dirs, the dispatch died at birth or never launched) — and no failure notification was ever coming. The grading was taken back in-window by the operator's direction; the lineage was honestly downgraded. The operator's critique: "you are the validator — why is this delegated elsewhere and where is it that I don't see it?"
- **Scope:** any background/async/delegated lane in an operator-supervised run.
- **Status:** active

## [SR-2026-11-08-hash-orphaning] A correction that rewrites a pinned artifact orphans the pin — disclose it, or pin before you append

- **Rule:** when a pinned artifact is append-corrected (the correction appended below the original), the ORIGINAL hash pin dies — the file's new hash no longer matches the pin that cited the pre-append state. Either pin the post-append hash and disclose the orphaned pin, or capture the original to a preserved copy before appending and pin both.
- **Provenance:** the strix fork, twice. (1) The round-20 verdict's full text: unrecoverable — the archive step was skipped, the file overwritten, no copy existed; the fragments survive only as quotations in a disposition. Recorded as a bookkeeping gap; the archive rule born. (2) The integration replay's transcript-3: the PM's correction append destroyed the pre-append state whose hash (`fcf8a97d`) the round-31 verdict cited as "pass 3" — the hash pinned nothing at grading time. Both caught by validators holding the pins to the same standard.
- **Scope:** every hash pin over an append-corrected artifact; every overwrite of a previously pinned state.
- **Status:** active

## [SR-2026-11-08-fixture-blindness] A mutation must revert the MECHANISM, not the first line of it

- **Rule:** a mutation (or a test fixture) that reverts "the first line of the mechanism" rather than the mechanism itself produces green-when-it-should-be-red — and the green is trusted because the mutation RAN. Define every mutation as the full mechanism revert; run the half-revert as a named diagnostic if you want the map, never as the kill.
- **Provenance:** the strix fork's cell-blindness lineage, four instances: M47 (a stale anchor aborted the edit script), M39 (the reorder made the guard non-load-bearing — "it is now its own guard" was false), M46 (the order-cell's fixture began with a `HOME=` assignment, so the install trigger never fired and there was no observation traffic to observe), M52 (the single-leg revert killed only the bare cell — the heredoc forms are caught by the text check). The producer's own diagnosis: "my mutation batteries keep being right about the code and lazy about the scope of the claim."
- **Scope:** every mutation battery; every fixture that claims to reach a mechanism.
- **Status:** active

## [SR-2026-11-08-audited-skip] An undecidable pass is RECORDED, not silent — and the record must say the pass was undecided

- **Rule:** when a decision surface cannot parse its input, the correct behavior is: record the skip (what class, what payload prefix), proceed if the design says proceed — and the record must make the undecidable pass VISIBLE. A silent skip is a failed gate that looks like no gate at all.
- **Provenance:** the strix fork's round-25 blocker 3: four payload classes (missing command key, non-JSON, non-string command, workdir-only) skipped the decision entirely — exec proceeded, no gate state, NO AUDIT LINE; the compensation (the SDK's own validation) was structural and unverifiable. The fix: `command_or_skip` names the four classes and each emits `apf_gate SKIP <class>` with the payload prefix, before proceeding. Measured live: the audited skip caught the replay harness's own payload-shape mistake in pass 1.
- **Scope:** every decision surface that can fail to parse its input.
- **Status:** active

## [SR-2026-11-08-seat-swap] No window grades its own design — the seats swap per the operator, and the discipline binds the authors first

- **Rule:** when a spec or a process must be judged, the judging window did not write it. The seats swap by the operator's direction, for the scope the operator defines (the spec's cycle only, or the implementation too — state it). And the discipline binds the AUTHORS: a spec codifying the measurement rule was falsified by its own measurement claim; a spec codifying the stamp discipline carried a future-dated stamp — both caught by the validator applying the document's own failure table to the document.
- **Provenance:** the strix fork's sync-spec cycle, six rounds (2026-11-07 → 2026-11-08): the PM window produced the spec, the old producer's window validated it through REQUEST-CHANGES → REQUEST-CHANGES → REQUEST-CHANGES → APPROVE-WITH-NOTES → APPROVE-WITH-NOTES — the convergence measured (4+5 → 3+4 → 2+4 → 0+5 → 0+2 → 0+2). The round-3 blocker was the spec's own measurement claim falsified by the validator's registry probe; the round-6 findings were the status block and the stamp, inside the document codifying both.
- **Scope:** every spec and process that its author's window would otherwise grade.
- **Status:** active

## [SR-2026-11-08-purpose-filter] The acquisition test is purpose-scoped — upstream is an option source, not a parent

- **Rule:** items from an upstream project are evaluated against the fork's PURPOSE, not their code quality or their origin's roadmap. Security fixes in the shipped surface outrank every class. Commercial features of the origin are rejected by default. The classes are decided in order and do not inherit; the rejections are recorded, re-evaluable, and never silent.
- **Provenance:** the strix fork's sync-spec ruling (2026-11-08): the fork measured **577 commits ahead** (403 files, 64,566 insertions the upstream never got) against 962 behind — a distinct derivative, not a lagging mirror. The operator's ruling: "strix is a commercial product, we are a research platform — pricing is not something I am developing this for." STR-1654 (a pricing refactor) REJECTED; the brotli CVE patch TAKEN. A rebase of 577 of the fork's own commits onto 962 of upstream's evolution was withdrawn as months of conflict resolution for zero fork value.
- **Scope:** every fork/off-network-derivative relationship to an upstream.
- **Status:** active
