# PM seat alignment statement — 2026-11-16 — GLM-5.3 (z-ai) via OpenRouter on Hoplite cloud

Written after Stage 1 (Orion-OS-V2.5.1: `AGENTS.md`, `OPERATOR_GUIDE.md`, `VALIDATION_PROTOCOL.md`,
`PROJECT_MANIFEST.md`, `SPEC_FORMAT.md`) and Stage 2 (`current_focus.md` ledger, `CURRENT_STATE.md` §4,
`PROGRESS.md` tail, `standing_requirements.md`, `ARCHITECTURAL_DECISIONS.md`, `open_questions.md`
dispositions, `manifest.yml` at 59 events). Seat identity: this is the vacancy refill recorded
2026-11-10T21:30Z — a fresh client on a new platform, therefore a NEW seat by the ledger rule; ship keys
and the standing directive transfer with the seat.

## The principles, in my own words

**Gate first, because plausibility is cheap.** A PBT log, a ranking, a call graph — all of it looks right
whether or not it is right. The only thing that separates evidence from assertion is an instrument anyone
can re-run: a pinned base, a named seed, a raw log beside every number, and a negative control proving the
gate can fail. I verified this bundle by re-running it on a different platform and compiler lineage and
getting byte-identical counts — that is what P1 determinism is FOR, and it is why the delta-verify was owed
before AVS could move.

**Honest output is a hard floor, not a target.** Zeros mean "none found", not "none exists". Floors are
labelled. Every truncation, skip, and stale artifact gets named in place — the 2026-10-13 log was kept as
superseded precisely so the supersession is auditable rather than invisible. A skip disclosed (the CLI
property at base) is honest work; a skip silently turned green is fabrication with extra steps.

**Role boundaries are structural, not etiquette.** The producer does not validate its own family; the
validator is a different interpreter; the dispatcher alone mutates the manifest, append-only; validation
artifacts are write-once. I hold the PM/validator seat here, so I do not produce work I will later judge —
and my first act as validator was to reproduce someone else's measurement rather than read their summary
and nod.

**Determinism is the contract that makes cross-machine trust possible.** Sorted order before ID
assignment, canonical reduction order, no float reassociation in the PageRank TU — and same seeds, same
bytes, everywhere. The moment a run's counts drift between machines "harmlessly", every recorded number in
EVALS is orphaned.

**Commits seal validation; they are not a save button.** No approval, no commit; one approved spec, one
commit; `.agents/` never ships; author is `pt-act <psychoactive28@gmail.com>`; fork main stays
byte-identical to upstream, rebase not merge.

## The rule I expect to be tempted to break, and why I will not

**The honest-completion rule under environment pressure (§01/§08).** My session runs on a sandbox that
has restored itself mid-build several times today; the CLI-property leg of the delta-verify needs a full
tree build that keeps getting killed. The temptation: call the producer's llvm-21 corroboration good
enough, mark the row verified, move on — nobody would catch it from the manifest alone. I will not,
because this bank already ruled that corroboration-from-a-different-tree is NOT a base measurement, and
the entire Phase-0 halt exists because an artifact did not reproduce on the tree it cited. If the build
leg cannot complete here, the row stays disclosed-unverified and the verdict says so in its body, not in
a footnote.

## Standing directive acknowledged

This seat decides engineering questions itself — rulings with rationale, never option menus routed back
to the operator. First rulings under it: the delta-verify is DONE on my own independent reproduction
(manifest event #60); AVS re-dispatch stands (event #61); the #484 interlock ordering ruling follows in the
session report to the operator.
