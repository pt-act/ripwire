# ripwire-fork (pt-act/ripwire) — Master Context

> **STALE — DO NOT ORIENT ON THIS FILE (marked 2026-11-10T21:25Z).**
> The last substantive edit here was **2026-11-04T18:03**. It predates, and knows nothing about:
> `workspace-key-containment` (APPROVED), `audit-validation-standalone` (the in-flight node), the
> `stdio-bare-edit-escape` terminal approval, and the 2026-11-10 AVS re-baseline (manifest events
> #55–#59). Its "Direction" lines describe a world where #484 was mid-review and WKC did not exist.
>
> **Read `active/CURRENT_STATE.md` instead** — it is the current orientation and names this file's
> superseded claims. This file is retained because its **architecture / key-files / active-decisions**
> sections are still largely accurate and useful as background; treat every *status* sentence here as
> superseded by the manifest `history`.

## Status: active

## Direction (primary): regex-screen-multiquantifier — UPSTREAM ROUND LIVE ON PR #484 through THREE review rounds; the proportionality round CLOSED 2026-11-02 at head 367dbfe4 (11 commits: CR-fix arc + maintainer-requested train-44 merge + the proportionality commit e2abe97f adopting all four of the reviewer's findings with his own measurements as thresholds + train-45 absorb to 745 gates). CI green on the pushed head; PR MERGEABLE/clean; the round's single results reply posted (issuecomment-6572668362); both toolchain legs verified locally pre- AND post-absorb; PBT monotone-admission holds vs the pre-lane base. Lane waits on joyful-ii-V-I's re-review. Two follow-ups offered in-thread, upstream's call (POSIX-class readability; engine step-count wrap). Standing watches further: release cut, #433 reply.

## Direction (second lane APPROVED 2026-11-04T18:05Z): mcp-token-hygiene — VALIDATED & APPROVED; lane merge-ready @ 0f1039b44 (3 commits: 9e29ae359 skeleton+registration, 7bd29ea4a the warning implementation, 0f1039b44 disclosed validator doc-fix — the period-splice byte; 7 files, +188/−5 base 50bc05e84). All five ACs MET with measured discrimination on both toolchains (fresh libc++ 11m19s + gcc leg 36m56s; base = the Phase-0 fresh build); full battery ALL PASS; loop 762 registered at the verified slot, GEN-DOCS-MERGE drift 9≤10 green. Verdict-validator.md + completion-verification.md in the spec's validation/ dir; spec approved per Q10 (a); selfcheck ALL PASS. OPERATIONAL: the Hoplite producer sandbox (restore interval 1–2 min) is an EDIT seat — route built-tree verification through the PM (twice-proven) or restore a stable sandbox before the build-dependent Tier-B pair (markitdown-bridge-hardening, parsepool-gate-guard). Upstream PR = PM's act, GATED on #484 concluding (one-lane-in-review).

## Lane mechanics UPDATE (2026-11-04, measured at 50bc05e84 — SUPERSEDES the five-file count-sites recipe for ALL future lanes): upstream's GEN-DOCS-MERGE mechanized the absorb — `scripts/merge_main.sh` + `scripts/merge_resolve.py` (set-union the one-gate-per-line absorb loop incl. across the old one-line reflow; regen generator-owned count lines; `--regen-after-build BIN` re-pins binary-pinned files after a build), published totals live in dated snapshot `docs/counts.tsv` (2026-11-03: gates.scripts=753; live loop 761) — a feature PR adds ONLY gate file + loop line + changelog fragment, never touches count sites/snapshot; drift arm `gendocsmergecheck` (MAX_DRIFT gates.scripts=10) is the new count authority; counts_snapshot refresh is a maintainer step. The next #484 merge request runs through merge_main.sh, NOT the hand recipe.
## Architecture:

- Pattern: fork of redhat-et/ripwire maintained as upstream + squash-merged work; sync per train (~2/day), test-merge before syncing, never Discard when fork commits are live content.
- Pattern: gate-first development — arms written red against the pre-change binary, then implementation greens them; counting gates treat comments as code (prose naming a counted token drifts the pin).
- Pattern: one-implementation rule — pageview.h owns the paging vocabulary; forpage.h owns both page renderers (file page + candidate page); twins (MCP) must serve byte-identical documents to CLI.
- Pattern: upstream-first for anything upstream should own (roster pin precedent: upstream adopted it and re-derived the roster themselves).
- Pattern: sink-form DISCLOSE (Diagnostics.h §4b) — every degrade emits through a sink the emitter reads; the sink-less pin only goes down.

## Stack: C++23 header-only, CMake, bash+python3 gate suite (test/pargates.py, ~400 gates), MCP JSON-RPC over stdio, zero runtime deps.

## Key Files:

- src/forpage.h — both page renderers incl. forCandidatePageDoc (the candidate page, all dialects)
- src/pageview.h — the one paging/truncation vocabulary (quintet)
- src/cli.h — guard carves (honorsPaging, validateShapingFlagsHonored)
- src/mcp.h + src/mcpverbs.h — MCP dispatch; forTaskText/packTaskText serve the twins
- test/mcpverbscheck.sh — roster pin (6b/6c, adopted upstream), twins arms (6d/6e)
- test/truncvocabcheck.sh, test/listingpagingcheck.sh, test/budgetpolicycheck.sh, test/packtaskcheck.sh — paging arms (H)/(G)/(D)/(E)
- CHANGELOG.md — manifest-growth claim asserted live by mcpmanifestcheck (1b)

## Active Decisions:

1. Roster pin (6b/6c) shipped upstream; upstream maintains it now — never re-pin from the fork (2026-09-21).
2. Candidate-page design: cliff computed ONCE over the full candidate set; continuation pages tier="below-cliff" — blessed by the #294 ruling (2026-09-28); all five page paths page ONE list, ranking= dropped (2026-10-07, B1).
3. Un-paged budgeted bundle stays byte-identical; its resume point is its own <sigs shown=> (2026-09-20).
4. Sync only after test-merge verifies zero conflicts; push via credential only when .github/ untouched, else operator's one click (2026-09-21).
5. 2026-09-14 audit remediation DAG: re-baselined (3 of 13 retired as landed upstream), re-drafted to the PROJECT_MANIFEST v2.5.1 schema (Amendment 3, 2026-09-29 — 14 specs incl. the rendered-dom-audit validation root; selfcheck ALL PASS), 0 executed; the regex High needs scoping against upstream's own regexguard.h (which landed after the 2026-09-14 draft). Orion-OS v2.5.1 framework installed at .agents/Orion-OS-V2.5.1/ (2026-10-11): AGENTS.md constitution, the five companions, six skills.

6. Authorship: every commit ships as pt-act <psychoactive28@gmail.com> (SR-2026-10-12-authorship-identity — set per-workspace before the first commit, every session; the #362 commits landed as usehoplite[bot] and the operator chose to earn the badge forward, not ask).
7. 2026-10-30 (#469 round): the marker-less-stream disclosure gap closes with ONE walker rule (bytes-without-marker + exit-0 → `unread`; zero-byte streams stay legitimate read-empty — the pinned format makes the classifier exact), NOT a per-consumer propagation schema — gitLogNameOnlyRaw already propagates the walk status, so K51's cache refusal and `history_unread="1"` engage automatically (AD-2026-10-30 pair; both measured: the exit-0-with-bytes shape is the only one that bypasses classification AND cache refusal, and the poisoned walk is served to later healthy runs). The follow-up lane is scoped and sequenced behind the maintainer's merge; nothing lands mid-review.
8. 2026-10-30 (dispatch): regex-screen-multiquantifier to the producer — dispatch-note.md is the alignment artifact (read-first: substrate lane terminal record incl. the maintainer-removed per-file budget, the p6 libstdc++ k-ladder, all SRs, MEMORY.md; verified liveness facts: refusal control PASSED, three family shapes ADMITTED, regexguard.h untouched on the merge path, g++-14 available); Phase 0 = the spec's own planning cycle pins draft interfaces/ACs BEFORE code; mechanism choice (screen rule / subject cap / both) is the producer's planning-cycle decision to make and record, not a dispatcher constraint; manifest reciprocity edges route through this seat; hand-back = completion-report + verdict + phase-log + pushed lane; validation and the upstream round are this seat's per the #397/#433 pattern.
