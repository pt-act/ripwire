# CURRENT_STATE.md — BANK FRESHNESS INDEX (not a summary of the bank)

**Written:** 2026-11-10T21:30Z by the local/producer seat.

**What this file is.** A **freshness index and trap list**, written so a cold-start seat does not orient on
stale state. Per `SEAT_ONBOARDING_PROTOCOL.md`'s own rule — *"Never summarize the bank for a seat — seats read
the bank"* — this file does **not** replace Stage 2. Read the bank. Use this to know **which parts of it are
current** and **which traps will cost you a round**.

## 1. Read order (Stage 1 then Stage 2, per the protocol)

1. `.agents/SEAT_ONBOARDING_PROTOCOL.md` — Stage 1 is **blocking**: Orion-OS alignment statement first.
2. `.agents/Orion-OS-V2.5.1/{AGENTS,OPERATOR_GUIDE,VALIDATION_PROTOCOL,PROJECT_MANIFEST,SPEC_FORMAT}.md`
3. **Stage 2:** `active/current_focus.md` → `active/PROGRESS.md` → `standing_requirements.md` →
   `ARCHITECTURAL_DECISIONS.md` → `active/open_questions.md` → `manifest.yml`
4. `manifest.yml` → `history` is **the authority**. Spec `status` fields and every journal entry are
   *summaries of events*; when they disagree, the events win.

## 2. Freshness map — verify before you trust

| Surface | Last real update | Trust it for |
| --- | --- | --- |
| `manifest.yml` history (**59 events**) | 2026-11-10T21:10Z | **everything** — the authority |
| `active/current_focus.md` | 2026-11-10T21:25Z (appended this act) | current state; **but its §"Current status (2026-10-16)" near the TOP is stale — the live state is at the BOTTOM** |
| `active/PROGRESS.md` | 2026-11-10T21:25Z (appended this act) | full round history; read the **last ~500 lines first** |
| `standing_requirements.md` | 2026-11-09 | binding SRs |
| `ARCHITECTURAL_DECISIONS.md` | 2026-11-04 | AD decisions; **does not know WKC / AVS** |
| `MASTER_CONTEXT.md` | 2026-11-04 + a stale marker this act | **architecture / key-files / active-decisions only. Every status sentence is superseded.** |
| `active/open_questions.md` | 2026-10-29 | Q1–Q11 closed as of 2026-11-04 — read the dispositions, do not act on an older "live" note. **Q8/Q9 are the live residual** (the unbounded multi-quantifier path). |

**The journals grew by prepend-append and their heads are old.** `current_focus.md` opens with a
2026-10-16 status block. Do not read top-down and conclude the project is in October.

## 3. Where the project is (short version; the events have the detail)

17 nodes / **7 approved / 10 planned**. Seven lanes built, evidenced, approved, **unpushed**, behind the
**#484 interlock** (OPEN @ `367dbfe45`, quiet since 2026-11-02). The only in-flight node is
**`audit-validation-standalone`**, halted at Phase 0 on a measured blocker, ruled **(A) re-baseline**, executed
by the producer today, now **waiting on the PM's delta-verify**.

## 4. The next act and who owns it

- **PM (validator-of-record — not substitutable):** delta-verify the re-baseline (P2 17/17 **and** P4 17/17 at
  `b8032471f`, with `^(ab|cd)+e$` in the admitted set; old log superseded; README dated; hashes re-recorded),
  then re-dispatch AVS on the same rotation ruling — no operator round-trip.
- **Producer (me):** resume AVS Phase 0 after that clears.
- **Carried open, PM's call:** the regenerated PBT log's **CLI-property row is `SKIP`, not green** (needs a
  built binary; clang-16 cannot build this tree at base). Documented as **UNVERIFIED at `b8032471f`**. It does
  not affect the P2/P4 contract.

## 5. Traps — each of these has already cost a seat a round

- **Fork main is `upstream/main`, not `main`.** In this clone `main` sits at `0e0f67c73` (old upstream point
  where `src/forfilesyms.h` **does not exist**); the real tip is `upstream/main` = `b8032471f`; `origin/main`
  does not resolve. Resolve base commits explicitly, always.
- **The main checkout is not the working tree.** Current work lives in scratch worktrees — `git worktree list`
  is the map (`wkc-r1`, `sbe-r1`, `sri-r1`, `rmq-r1`, `rsh-r1`, `mth-*`). A grep that finds nothing may be the
  wrong tree, not an absent file.
- **The binding host constraint is RAM AND CPU, not disk.** 8 GiB / 8 cores. Two `-j 7` builds = 14 compile
  streams → load 25+, swap exhausted, host thrashing. **One build at a time, `-j 3` max; never `rm -rf` a build
  dir a build is still writing into** (it silently corrupts objects); heavy builds belong in the 16 GB VM.
- **`/usr/bin/g++` and `/usr/bin/gcc` are Apple clang 16 stubs.** Real gcc is `/usr/local/bin/g++-14`. clang 16
  **cannot build this tree at `b8032471f`** (`std::ranges::find_last_if`, `src/forfilesyms.h:435`). Pin **both**
  `CMAKE_C_COMPILER` and `CMAKE_CXX_COMPILER`.
- **anaconda-ld trap:** `/opt/anaconda3/bin/ld` sits first on PATH and dies `unsupported tapi` on warm relink.
  Pin `PATH=/usr/bin:/bin:/usr/sbin:/sbin:/usr/local/bin` for any cmake build/link.
- **`shasum` with no flag is SHA-1** (40-hex). 64-hex is SHA-256. **Record the command, not just the number** —
  a hash that reproduces on no instrument is a dead cite.
- **The gate is `test/selfcheckcheck.sh`, not `test/_selfcheck.py`** — that file does not exist, and invoking
  it returns **rc=0 on a missing file**, a mis-shaped instrument that reads as success.
- **`.agents/` is git-excluded** (`.git/info/exclude:10`). Bank and spec edits are filesystem acts, invisible
  to `git status`, and not pushed.
- **A screen-admitted pattern does not imply a terminating match on libstdc++.** The engine complexity budget
  is libc++-only; on libstdc++ the admitted multi-quantifier family does not return — the **Q8/Q9 residual**,
  named, reachable, and not bounded by any round so far.

## 6. The interlock, in one line

`#484` OPEN @ `367dbfe45` → **nothing upstream-visible until it concludes** → on conclusion the PM executes
push + PRs for SRI / multiquantifier / SBE / WKC **without** an operator round-trip (that go is already given).
Do not push or open a PR on any other authority.
