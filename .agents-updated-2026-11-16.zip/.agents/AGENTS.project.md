# AGENTS.project.md — ripwire-fork (pt-act/ripwire)

## Extends

AGENTS.md v2.5 (base)

## Deviations

<!-- Only list rules that differ from the base. Absence = base rule applies. -->

### Scope note — two documents share the name `AGENTS.md`

- `AGENTS.md` / `CLAUDE.md` **at the repo root** are ripwire's own guide for coding agents (C++ style,
  guardrails G1–G5, the five non-negotiables). They stay authoritative for anything written *in* the
  source tree.
- `.agents/Orion-OS-V2.5.1/AGENTS.md` is the **Orion constitution**. This extension governs how the
  Orion pipeline (manifest → specs → validation → memory bank) applies to this project.
- When the two conflict on a code question, the repo-root guide wins; on a process question, the
  constitution wins.

### §03 · Code Editing — language and style (base has no language rule)

- **Language:** C++23, header-only, zero runtime dependencies. `src/` is ~192 headers; the only
  `.cpp` files are translation units for the heavy passes.
- **Style:** Allman braces; braces on every control-statement body (no braceless `if( x ) f();`);
  spaces inside parens (`f( x )`); wraps at ~160–200 columns, broken on logical-operator seams;
  index-vs-count naming (`nodeId` vs `nodeCount`); structured-binding returns; tolerance-band float
  tests. Full rules: `CONTRIBUTING.md` §3.
- **Containers — a hard prohibition:** never `std::map` / `std::unordered_map`. Use `HashMap<>` for
  hash lookup, `gtl::btree_map` for ordered iteration, `dynamic_map` for bounded hot paths.
- **Emission:** output goes through `rw::emitTo` (`src/infra/emit.h`). Never add a new
  printf-family call site.

### §04 · Engineering Heuristics — the five guardrails (G1–G5)

`CLAUDE.md` names five guardrails that bind every change:

- **G1** memory safety, adversarially verified (`-fno-sanitize-recover=all` is the linchpin).
- **G2** cache locality over abstraction (DOD, POD, SoA, 32-bit handles, no generic graph library).
- **G3** one deterministic build step — CMake only, deps pinned and vendored, tree-sitter linked
  statically, no host-installed dependencies, no OpenMP. Never pass `-static`.
- **G4** maximum token density — minified XML, terse attributes, the legend emitted once per answer.
- **G5** modular zero-dependency CLI — hand-rolled argument parser; every flag purely additive.

### §08 · Verification — gate first, and the build-flavour rule

- **Gate first, code second.** Write the arm *before* the implementation it measures, and prove it red
  against the pre-change binary. A ranking, a token estimate, and a call graph all look plausible
  whether or not they are correct. This strengthens the base §08 "Tested" checkbox into a build order.
- **Never configure a local dev tree with `-DCMAKE_BUILD_TYPE=Release`.** Release defines `NDEBUG`,
  which compiles the `DISCLOSE( msg )` trace out, so any gate asserting a degrade path passes blind.
  CI builds both flavours deliberately; locally, use the plain build.
- **Never edit the tree while a build is running.** Make compares mtimes; a header changed under an
  in-flight build yields objects newer than the header but older in content, and the build then
  reports success forever while shipping a binary no single commit can produce. After any branch
  switch, `--clean-first`.
- **Gate registration is part of the change:** a new `test/*check.sh` must be listed in
  `test/regression.sh` in the same commit, or `test/manifestcheck.sh` fails.
- **A `--help` change is a three-file commit** — see `SR-2026-09-29-help-output-triplets` below.

### §09 · Memory Bank — paths for this project

- The memory bank lives at `.agents/memory_bank/` and the DAG manifest at
  `.agents/ripwire-audit-remediation-specs/manifest.yml` (not `manifest.yml` at the project root, and
  specs under `.agents/ripwire-audit-remediation-specs/specs/<id>/`). Both are local workflow state.
- `.agents/` is git-ignored **locally** via `.git/info/exclude`, deliberately *not* via the tracked
  `.gitignore`: fork main must stay byte-identical to upstream main, so no local-state line may enter
  the committed tree. `git check-ignore -v .agents/` names the rule.

### §03.6 · Version Control — fork-specific rules

Base §03.6 (commit on validation, one commit per approved spec) applies unchanged. Additions:

- **`git add` takes an explicit path list** — never `-A`, `-u`, or `.`. A sweep has already leaked
  private workspace files into a public branch once. Provenance: `SR-2026-09-28-explicit-path-add`.
- **Authorship is fixed:** every commit ships as `pt-act <psychoactive28@gmail.com>`, set at
  repo-local level **every session, before the first commit** — fresh clones do not inherit it.
  Provenance: `SR-2026-10-12-authorship-identity`.
- **Never commit `.agents/`.** The memory bank, specs, and validation artifacts are local workflow
  state. A commit that leaks them is a defect, not a mistake.
- **Fork hygiene:** fork main stays byte-identical to upstream main (the upstream nightly on shared
  main is the green record; GitHub disables fork Actions for scheduled use — leave them off). The
  feature branch is the only fork divergence. **Sync is a rebase, never a merge commit** — a merge
  commit broke the capture generator's history window.
- **Derived artifacts belong to the merge-time owner.** A contributor's capture/deck/COMMANDS regen
  recorded on a dirty local tree goes stale on the integration branch and publishes local branch
  names. The feature ships only the help-derived lines; the maintainer regenerates at merge time.

### §03.7 · Seat changes, ship keys, and the seat ledger (added 2026-10-23; operator-approved)

Provenance: the 2026-10-23 porcelain incident — a producer session resumed under a different model
(StepFun Step-5-Preview replacing the DeepSeek seat) without re-onboarding, which self-authored its
plan, shipped unvalidated work upstream, and opened PR #433 without a completion report. The operator
ruled the onboarding miss his own and approved three guards:

- **A model change is a seat change.** Any different model occupying a seat is a NEW seat, whatever the
  session continuity. Its first round does not dispatch until a Stage 1 alignment statement is accepted
  by the dispatcher (PM). "Resumed the session and forgot to switch back" is the exact trigger this
  clause exists to catch.
- **The seat ledger is the tripwire.** The top of
  `.agents/memory_bank/active/current_focus.md` carries a SEAT LEDGER; every seat signs in with its model
  id, client, and onboarding status at session start. Before any task work, a seat compares its model id
  to the last signer of its seat — a mismatch or an inherited session means: stop, run
  `.agents/SEAT_ONBOARDING_PROTOCOL.md`, sign the ledger. The bank is the enforcement channel because it
  is the one artifact every seat has demonstrably read.
- **Ship keys are role-bound.** Nothing crosses to a shared or public channel (push to origin's shared
  branches, any upstream PR, issue/review comment) without the completion-report → PM-validation
  handshake, or an explicit operator waiver recorded in the bank. Push-to-a-fork-lane for rollback
  survival remains permitted; the PR-open step is what is gated. Until a seat's Stage 1 alignment is
  accepted, the PM holds its ship keys.
- **The plan pen is dispatcher-owned.** "Next actions" that a producer would execute are written or
  countersigned by the PM/dispatcher seat — never self-authored and self-executed by the same session.

### §13 · Inheritance — documentation authority

`./build/ripwire --help` is generated from the binary's own flag table and is always current. **When
`--help` and a document disagree, `--help` wins and the document is the bug.**

### Standing requirements in force

Injected into every new spec at drafting time (`standing_requirements.md`):

| Id | Rule |
| --- | --- |
| `SR-2026-09-21-counted-prose` | Prose that names a counted token is a counted line — reword, never bump the pin. |
| `SR-2026-09-21-degrades-need-sinks` | Every degrade emits through a sink the emitter reads (`DISCLOSE( sink, why )`). |
| `SR-2026-09-21-gate-sweep-is-owned` | Name the affected-gate set by reading what owns each surface. |
| `SR-2026-09-28-explicit-path-add` | `git add` by explicit path list, never `-A`. |
| `SR-2026-09-29-help-output-triplets` | A `--help` output change is a three-file commit. |
| `SR-2026-10-12-authorship-identity` | Every commit is authored as `pt-act`. |
| `SR-2026-10-23-seat-ledger` | Sign the SEAT LEDGER (current_focus.md) at session start; a model change in a seat is a new seat — onboarding before work, PM holds ship keys until alignment is accepted (§03.7). |

### Determinism and honesty (strengthened from §00 / §04 H-3)

- **Determinism is a contract, not a nicety.** Crawl order is sorted before IDs are assigned;
  reductions use fixed block partials in canonical order; the PageRank translation unit is compiled
  without floating-point reassociation. Anything that makes output depend on thread timing is a bug
  even when the ranking still "looks right".
- **Honesty in output is a feature.** Counts that cannot be totals are labelled floors
  (`counts_floor="1"`); a zero means "none found", never "none exists"; every truncation is disclosed
  in the header. Do not add a surface that quietly rounds, guesses, or omits.
- **Never `ASSUME( false )` on a degrade path** — release deletes the fallback behind it. Guard the
  path and disclose it: `DISCLOSE( sink, why )`, or `DISCLOSE( Diagnostics::answerUnchanged, "…" )`
  when the answer truly cannot change. A one-argument `DISCLOSE( msg )` ships nothing and may not be
  added. External input is `VALIDATE`d, never `ASSUME`d.
