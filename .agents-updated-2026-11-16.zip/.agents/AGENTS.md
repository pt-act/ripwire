# AGENTS.md — local entry point (ripwire fork, pt-act/ripwire)

**This file is LOCAL-ONLY.** `.git/info/exclude` keeps `.agents/` out of the tracked tree because fork
main must stay byte-identical to upstream main — which is also why this router cannot live at the repo
root: the root `AGENTS.md`/`CLAUDE.md` are **upstream's** coding guide, not ours to edit. If you are a
seat reading this file for the first time in a resumed session, that is expected: no client auto-reads
this path, so the trigger that brought you here lives in the memory bank (see step 3).

Any seat — producer, validator, PM, advisor; any model, any client — working in this repo reads, in order:

1. `.agents/Orion-OS-V2.5.1/AGENTS.md` — the Orion constitution (behavioral rules; §15 role boundaries,
   §03.6 commit-on-validation).
2. `.agents/AGENTS.project.md` — the ripwire extension: C++ style and the container prohibition,
   guardrails G1–G5, gate-first, fork VCS rules, **§03.7 seat changes and ship authority**.
3. **The SEAT LEDGER at the top of `.agents/memory_bank/active/current_focus.md`.** Compare your model id
   to the last signer of your seat. Different, unknown, or this is a resumed session you did not start?
   **You are a NEW seat**: stop before any task work and run `.agents/SEAT_ONBOARDING_PROTOCOL.md` Stage 1
   (alignment statement) — no directives before alignment. Sign the ledger when you begin.
4. The memory bank: `current_focus.md`, then `PROGRESS.md` (recent entries), `standing_requirements.md`.

Authority split: the repo-root `AGENTS.md`/`CLAUDE.md` govern code written in the source tree; this tree
governs process. When they conflict on code, the root guide wins; on process, this tree wins.
