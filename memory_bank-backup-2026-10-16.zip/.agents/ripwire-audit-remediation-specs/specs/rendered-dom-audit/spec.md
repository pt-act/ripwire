# Rendered-DOM Audit — WCAG/CSP findings before UI execution

## Header

```yaml
id: rendered-dom-audit
type: validation
version: 1.0.0
manifest: ../../manifest.yml
```

## Objective

Verify, against a rendered DOM in a real browser, that the audit's HTML-export and graph-canvas findings still reproduce on current main — findings #5/#8–13 (WCAG/CSP on the HTML export) and #9/#10 (graph keyboard/motion accessibility) — before either remediation spec executes. Folded into the DAG by operator directive (2026-09-29, open_questions Q3) so the RE-BASELINE rows marked "UNVERIFIED — needs rendered-DOM audit" resolve to reproduced (execute) or not-reproduced (retire), with evidence.

## Scope

**In scope:**
- Generate a real HTML report from a fixture root with the current binary, then audit the rendered DOM: axe-core (WCAG A/AA), the served document's CSP posture, contrast on rendered text, the graph canvas's keyboard reachability, and its `prefers-reduced-motion` path.
- Record each finding (#5, #8–13, #9, #10) as `reproduced` / `not reproduced` / `not verified` with evidence (DOM snippets, axe violation ids, gitstamp, date) in `specs/rendered-dom-audit/audit-note.md`.
- Feed the outcomes to the re-baseline rule: non-reproducing findings retire their remediation specs with a one-line note; reproduced findings unblock their specs.

**Out of scope:**
- Implementing any remediation — that is `html-export-template-remediation` / `graph-interaction-accessibility`.
- Non-rendered checks (source greps, gate arms) — already covered by the gate suite.
- The informational-tier unverified specs (`markitdown-bridge-hardening`, `parsepool-gate-guard`) and `mcp-token-hygiene` — not rendered-DOM questions; separate re-verification before they execute.

## Interfaces

### Produces

None — the audit note (`specs/rendered-dom-audit/audit-note.md`) is this spec's own artifact, not a consumed contract.

### Consumes

None — dependency-free root; can run at any time against current main.

## Acceptance Criteria

1. **Report generated**: a real HTML report is produced from a fixture root with the current binary. **Verifier:** the audit note names the gitstamp and the exact command used.
2. **axe-core pass recorded**: an axe-core run against the rendered report, every violation mapped to finding #5/#8–13 or filed as a new observation. **Verifier:** audit-note table complete for #5, #8–13.
3. **CSP recorded**: the served document's CSP posture (present/absent/what) captured verbatim. **Verifier:** audit-note row.
4. **Canvas checks recorded**: graph keyboard reachability and reduced-motion behavior observed and written down. **Verifier:** audit-note rows for #9, #10.
5. **Honest outcome per finding**: every row ends `reproduced` (spec proceeds), `not reproduced` (retire per RE-BASELINE with evidence), or `not verified` (with the reason). **Verifier:** no row blank, no finding silently dropped.
6. **No source changes**: this spec changes no code and no gate. **Verifier:** working tree clean of `src/`/`test/` changes at audit time.

## Implementation Notes

- Run against current main at execution time and record the gitstamp — the point is verifying today's tree, not c1915d21.
- Write generated report artifacts outside the crawled tree (the determinism recipe writes outputs outside the crawled tree) or into an ignored path.
- This spec is verification work: a passing run produces evidence, not a code commit.

## Failure Modes

### Audit tooling unavailable
- **Trigger:** no browser / axe-core in the execution environment.
- **Expected handling:** record `not verified — tooling unavailable` honestly; do not mark findings closed; the two UI specs stay gated.
- **Validator check:** audit note shows explicit `not verified` rows rather than omitted ones.

### Findings assumed stale without evidence
- **Trigger:** pressure to start the UI specs before this audit runs.
- **Expected handling:** the manifest `depends_on` gates them; any bypass is an operator-recorded decision, never an omission.
- **Validator check:** `html-export-template-remediation.depends_on` lists `rendered-dom-audit`.

### Audit note over-claims
- **Trigger:** a row says "fixed" or "not an issue" without a DOM artifact.
- **Expected handling:** only `reproduced` / `not reproduced (evidence)` / `not verified (reason)` are valid row states.
- **Validator check:** every row carries an evidence pointer or an explicit reason.

## Dependencies

None — dependency-free root (operator-directed fold-in, 2026-09-29).

## Consumers

- **Spec:** html-export-template-remediation — manifest `depends_on` gates it behind this audit. **Constraints:** if a finding does not reproduce, retire it per the RE-BASELINE rule instead of executing.
- **Spec:** graph-interaction-accessibility — gated transitively (depends on html-export-template-remediation). **Constraints:** same verify-then-execute rule.
- **Document:** threads/_audit-dag-2026-09-14/RE-BASELINE.md — its "UNVERIFIED — needs rendered-DOM audit" rows resolve from this audit's evidence.

## Status

**Status:** planned
**Last updated:** 2026-09-29T11:05:00+01:00
**Updated by:** co-founder (Amendment 2), operator-directed fold-in

## Validation Strategy

Tier 1 — focused verification suffices: this spec IS the standalone validation for the rendered-DOM findings (no implementation exists to test; the audit note is the artifact). Components assessed: the generated report's rendered DOM (axe-core + CSP + contrast), the graph canvas input and motion paths (observed behavior). No PBT-suitable component: no parsing, no crypto, no state machine.

## Progress Tracking

- [ ] Phase 1: Generate the report from a fixture root on current main; record gitstamp + command in the audit note
- [ ] Phase 2: axe-core + CSP + canvas (keyboard, reduced-motion) runs; audit-note table filled for every finding
- [ ] Phase 3: Outcomes applied — reproduced findings unblock their specs; non-reproducing findings retired per RE-BASELINE with evidence; RE-BASELINE rows updated
