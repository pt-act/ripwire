# Phase Log — regex-screen-hardening

Working record of decisions and deviations per phase. Not narration; the completion report is the handoff artifact.

Round: **1** (first production round). Base commit `0e0f67c7`. Scratch tree `/Users/rna/ripwire-scratch/rsh-r1`.
Spec version at execution: **2.0.2** (v2.0.1 anchor refresh + v2.0.2 PM-directed errata, both applied in this round).

---

## Phase 0 — the pre-code anchor refresh (spec v2.0.1)

**Decision.** Every line anchor was re-located by direct read of the tree at `main = 0e0f67c7` before any code was
written, as the operator ordered. The verified table is the authority and lives in the spec under Implementation Notes.

**Finding.** Two anchors had moved 588 commits past where they were written: the fault switch is `regexguard.h:1212`
(not 1205), and `src/search.h ~L1090–1115` is no longer a try/catch region at all — it is `grepWholeLine` now, the
line loop having moved into the guard (`GuardedRegex::forEachLineMatch`, `regexguard.h:1275`), exactly as the
re-scope predicted. Everything else held.

**Deviation.** None. The refresh produced no implementation artifact and needed no dispatch, so it was executed
without a manifest write (the manifest lock came later, in Phase 1 of the round proper).

---

## Phase 1 — the structural-overlap alternation arm (`src/regexguard.h`)

**Decision (the rule).** The spec's Refuse list and its three structural-overlap bullets disagree about
`^(ab|cd)+e$` (disjoint, fixed-width — caught by none of the three bullets). Raised as **Q5**; the PM ruled **option
(a) is the contract** (2026-10-12, glm-5.3). The rule as implemented is one sentence: *a group's top-level `|` under
an unbounded outer quantifier is refused UNLESS every branch consumes exactly one character and all those characters
are pairwise disjoint.* That satisfies every enumeration the spec writes.

**Decision (the machinery).** A `GroupFrame` stack replaces the bare flag vector (a frame carries the group's body
start and its own top-level `|` offsets); a `RegexCharSet` (dense over ASCII 0..127 + a `matchesNonAscii` flag) so
`\D`/`\W`/`\S`/`[^…]`/`.` are answerable without a Unicode table; a one-character-branch parser that **refuses rather
than guesses** on `\b`, a backreference, `\x`/`\u`/`\c`, `[[:alpha:]]` or an empty branch.

**Fixed (found by the arm, not by inspection).** `regexGroupModifierLength` returned "characters skipped" (1 for
`(?:`), so a non-capturing group's body offset landed on the `:` — harmless for the old quantifier scan, fatal to
the new alternation parse (`(?:a|b)+` was refused). It now returns the whole modifier length, and the two `<` forms
(`(?<name>`, `(?<=`/`(?<!`) are handled.

**Deviation (PM-1, required).** The refusal message originally asserted the branches "can match the same text" and
taught "factor the branches". For `(cat|dog)+` — which the header comment itself admits is disjoint — both claims
are false. PM condition **PM-1** required an honest rewording: the message now says the screen **cannot PROVE** the
branches disjoint, that a multi-character branch is refused because its SHAPE is indistinguishable (without matching
it) from one that overlaps, and the only workaround offered is **make the OUTER bounded**. The gates pin
'backtrack' and 'bounded'; both survive. Header comment block updated to match.

**Verified.** `evidence/probe-green.txt` — the Phase 1 arm, 50/50 GREEN. Negative control: the same arm against the
pre-change header fails on exactly the 17 alternation rows. `evidence/corpus-sweep.txt` — 99,845 tree literals,
**33 newly refused, 0 newly admitted**.

---

## Phase 2 — the per-file match budget (`src/regexguard.h`, `src/search.h`, `src/verbs_grep.h`)

**Decision (the mechanism).** The spec offered two shapes: "a `steady_clock` check per K line-match attempts, or a
visit/step counter in the wrap around `std::cregex_iterator`". Chose a **per-file COUNT of engine line-match
attempts** — deterministic (a clock is not, and this project gates on byte-identical output), platform-independent,
and it is exactly the quantity the spec's Failure Mode names ("a very large file matched by a cheap pattern").

**Decision (reuse the verdict).** The budget reuses `RegexVerdict::Exhausted` rather than adding a verdict, so no
consumer can miss it: `RegexLineScan` gains only a `budgeted` flag, and `budgeted` selects a budget-specific reason
sentence (`kRegexBudgetReason`) in place of `kRegexAbandonedReason`. `-Werror=switch` means nothing switches on
`RegexVerdict` — verified, nothing does.

**Decision (the constant).** `kRegexFileMatchBudget = 1000000` attempts per file — far above this tree's own gate
corpus (the spec's >=10x headroom; the gate corpus peaks at a few thousand attempts per file).

**Decision (keep it out of the literal paths).** The cap is checked only inside the `isCandidate` engine branch. A
literal-plan hit and a required-literal-prefilter rejection never reach the engine, so they are never budgeted.

**Deviation (the fault vehicle).** The spec's Phase 2 example says "with the **screen fault-switched off** … the run
emits the disclosed skip". There is no screen-disable switch in this tree, and post-Phase-1 there is no
screen-admitted bomb left to hand the engine — a screen-disable switch would only re-open the hole Phase 1 closed.
The arm instead caps the budget itself through a new fault switch, `RIPWIRE_FAULT_REGEX_BUDGET` (the
`RIPWIRE_FAULT_REGEX_LINE_BOUND` idiom: non-NDEBUG, read once per process, exact `"1"`). Same class of evidence —
the budget path is reachable, disclosed by name, bounded, and the run terminates — without inventing a seam that
undoes Phase 1. Recorded in the completion report's Known Deviations.

**Deviation (AC2's "subsequent-file hits are present").** That clause describes the **pre-seam** shape, which
upstream already replaced: an abandoned file used to be skipped with an NDEBUG-deleted alert while the run printed
`hits=` at exit 0. The current contract — mandated by the spec's own Phase 2 text two paragraphs earlier ("the same
Exhausted-shaped refusal fires … the hits collected before that point would be a floor this verb cannot state") — is
a **fail-closed refusal**: exit 1, no `hits=` element. The arm proves the refusal, not the presence of later hits.
Disclosed in the completion report; the same stale-premise class as Q7.

**Verified.** The budget arm (regexbombcheck section 6) plus `evidence/gate-final-regexbombcheck.txt`.

---

## Phase 3 — the gate arms

**Decision (both gates).** Per the v2.0.2 errata (Q7, PM-authorised), Phase 3 names **both** gates under one rule:
*no guarantee may lose its arm.*

`test/regexbombcheck.sh`:
- Section (5) replaces the INFO gap line with a five-arm alternation battery: `(a|a)+b`, `^(a|aa)+b$`, `(x|xy)+c$`,
  `(\w|\d)+$`, `^(ab|cd)+e$`. Each asserts exit 1, no `hits=`, the pattern named, 'backtrack' present, and (PM-1)
  `'prove|disjoint'` present.
- `(a|a*)+` moved from the alternation battery to the nested `bombCase` battery: its group contains a `*`, so it is
  refused by the **nested** arm, whose message is not the honesty-bearing one. Caught by the arm itself.
- Section (6) adds the budget arm: a fault-flavour probe, a `budgetfix/` fixture, a no-switch control (exit 0, hits
  present), the switched run (exit 1, no `hits=`, stderr names 'match budget' and quotes `kRegexBudgetReason`), and
  an exact-`"1"` control (`=10` must not change the answer).

`test/regexguardcheck.sh` (the Q7 re-scope):
- **(b2)** re-scoped from "the gap is open, the engine abandons it" to a `closedStatically()` helper asserting the
  gap is **closed statically at all four entry points** (`--graph-query file()`, `--arch`, `--match`, `--regex`).
  The old libc++ gate now prints an INFO.
- **(i)** re-scoped to a **portable** match-time-undecided vehicle: `allow path zz/(.*) -> a{2,\1}` (an invalid
  interval after substitution, held undecided by `undecidedPathRule` on every standard library). Three legs kept.
- The real-engine abandonment path stays proven by (b1)'s fault switch and by the budget arm — no guarantee lost
  its arm.

**Fixed (PM-2, pre-existing, disclosed).** `regexbombcheck.sh:141` used `grep -qi 'collapse\|bounded'` — GNU BRE
alternation, which **BSD grep reads as a literal pipe**, so the arm failed on every macOS host *including with the
pristine upstream binary*. Fixed in the same edit to `grep -qiE 'collapse|bounded'`. Not a scope expansion: a
portability repair on an arm this round already touches.

**Fixed (arm (i) fixture bug, caught by the arm).** `printf '...\1...'` lets the shell turn `\1` into an octal
escape (byte 0x01), so the TO template became `a{2,}` — mismatched braces, rejected at load. Fixed to
`printf '%s\n' '...' '...'`, the way arm (e) already writes its fixtures. The arm caught this itself: gate-first
working as designed.

**Verified.** `evidence/gate-baseline-*.txt` (RED, Phase-1-only binary) → `evidence/gate-final-*.txt`
(**regexbombcheck 99 PASS / 0 FAIL; regexguardcheck 135 PASS / 0 FAIL**, both exit 0).

---

## Phase 4 — the PBT bundle

**Decision (the narrow TU).** `pbt-regex-screen.cpp` includes only `src/regexguard.h` (~12-header dependency cone),
so it exercises the **real** `screenRegexPattern()` / `compileGuardedRegex()` in seconds instead of paying the
~1.2 GiB full-TU cost. Same device as the Phase 1 arm.

**Decision (P6).** The one property a pure-function test cannot state — every ADMITTED pattern must also terminate
on a pathological subject — is asserted in-process (`forEachLineMatch` over a 200-byte line) and again at the CLI
under a wall-clock cap by `pbt-run.sh`.

**Fixed (seed parsing — found by reading the log, not by a failure).** The first full-scale run logged the second
seed as `seed=0`: `--seed` was parsed with `strtoull( …, 10 )`, so `seeds.txt`'s `0x9E3779B9` parsed as `0` and the
`Rng` silently substituted its default constant — a log line that looked truthful and did not match the seed list.
Fixed to base 0; `seeds.txt` now states the log prints seeds in decimal. Re-run and re-captured.

**Found (a scope boundary, NOT fixed — out of this spec's scope).** The group-free multi-quantifier bomb
`a*a*a*a*a*b` is **ADMITTED**: Phase 1's arm targets a group with a top-level `|`, and this pattern has no group to
inspect. On libstdc++ it is the audit's hang shape. Disclosed to the PM as **Q8** rather than silently widening the
round.

**Verified.** `evidence/pbt-regex-screen.log` — 3 seeds × 20,000 cases = 60,000 generated patterns; P1 20000/20000
per seed; P2 17/17; P3 17/17; P4 17/17; P6 every admitted pattern terminated; CLI property 8/8. **Zero failures.**
