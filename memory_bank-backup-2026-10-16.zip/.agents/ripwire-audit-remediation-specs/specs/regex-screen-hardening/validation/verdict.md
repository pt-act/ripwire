# Verdict — regex-screen-hardening — round 1

## Header

spec_id: regex-screen-hardening
validator: glm-5.3 (PM seat, per manifest `execution.interpreters.validator`)
validator_distinct_from_producer: true
reviewed_completion_report: specs/regex-screen-hardening/validation/completion-report.md
verdict_timestamp: 2026-10-13 19:14 UTC

**Verify tree.** `repo@0e0f67c7 + patch@round-1` (sha256 `fba4ca68…`), rebuilt independently at
`/Users/rna/ripwire-scratch/pm-verify-r1`, patched binary sha256 `45f3fb0b…`. Producer's scratch
tree (`rsh-r1`, binary `f6b861cc…`) was **not** used as evidence.

**Well-formedness gate (§C).** The completion report carries a per-criterion self-check with
evidence and provenance, an Interfaces Delivered section, an 11-item Known Deviations list, and a
State Management section. **Well-formed** — implementation inspection proceeded.

---

## Decision

status: **needs_revision**

---

## Per-Criterion Assessment

- Criterion 1: **Alternation family refused** — a fixture corpus whose single line is 200 `a` bytes;
  the battery exits before timeout with a message naming the construct.
  - Producer's claim: **met**
  - Validator's finding: **confirmed**
  - Evidence reviewed: re-ran `test/regexbombcheck.sh` in the verify tree — **ALL PASS, exit 0**;
    `evidence/ac1-alternation-refusal.txt`; `evidence/gate-final-regexbombcheck.txt`. The emitted
    message now names the construct through the PM-1 wording ("an alternation whose branches the
    structural screen cannot PROVE are disjoint"), which is the construct-naming AC1 asks for. The
    gates pin `backtrack` and `bounded`, both present.
  - Notes: AC1's own text still says "naming the **overlapping-alternation** construct" — pre-PM-1
    wording. Substance holds; see Issue 6.

- Criterion 2: **Budget degrade disclosed** — with the screen fault-switched off, the run emits the
  disclosed skip, exits per the degrade contract, subsequent-file hits present.
  - Producer's claim: **partially met** (degrade disclosed/bounded/by-name; vehicle and the
    "subsequent-file hits" clause differ, both disclosed)
  - Validator's finding: **confirmed** (as disclosed)
  - Evidence reviewed: `RIPWIRE_FAULT_REGEX_BUDGET=1` in the verify tree reproduces the fault
    switch; the switched run exits 1 with no `hits=` and stderr carrying `'match budget'` and the
    full `kRegexBudgetReason` sentence; the `=10` exact-value control leaves the answer unchanged.
    Both deviations (deviation 5: no screen-disable switch exists; deviation 6: "subsequent-file
    hits" is the pre-seam shape) are honest and match the code.
  - Notes: the AC's *literal* vehicle does not exist and the delivered vehicle is a different (and
    better) one. Accepted as disclosed; the spec text should be corrected (Issue 6).

- Criterion 3: **No refusal regression** — existing catastrophic-family arms still refused; precision
  arms unchanged; (b2)/(i) re-scoped (errata v2.0.2).
  - Producer's claim: **met** (substance) / named verifier could not complete (environment)
  - Validator's finding: **confirmed** (substance)
  - Evidence reviewed: `test/regexbombcheck.sh` **ALL PASS (exit 0)** and
    `test/regexguardcheck.sh` **ALL PASS (exit 0)** re-run in the verify tree; `grepcheck` and
    `regexrefusecheck` ALL PASS; `evidence/corpus-sweep.txt` reproduced exactly — **99,845
    patterns, 33 newly refused, 0 newly admitted** (no refusal lost, no admission gained).
  - Notes: `pargates.py` (683 gates) could not complete — environmental (disk + the sandbox's
    `safe-delete` shim), disclosed as deviation 8 with per-failure triage. The two gates the spec's
    Phase 3 scope names are the substance of this criterion and are green. Accepted.

- Criterion 4: **No admission regression** — golden-output diff against pre-change output,
  byte-identical.
  - Producer's claim: **met, by the transitive method** (a literal binary-vs-binary diff was not run)
  - Validator's finding: **confirmed** — and **upgraded from transitive to direct**
  - Evidence reviewed: the validator rebuilt the pristine binary (`fee29b79…`, `repo@0e0f67c7`
    unpatched) and diffed it against the patched binary (`45f3fb0b…`) over the admit set:
    **17/17 patterns byte-identical on stdout, stderr and exit code** (a wider earlier pass over 34
    cases was likewise 34/34). Combined with the corpus sweep (33 newly refused, **0 newly
    admitted**) this closes deviation 7: the missing artifact is supplied by the validator.
  - Notes: producer's AC4 evidence gap (deviation 7) is now **remedied by the validator's direct
    run** — it is no longer an open deviation.

- Criterion 5: **Both standard libraries bounded** — libstdc++ demonstrates the budget degrade;
  libc++ keeps the Exhausted path live; same alert shape on both.
  - Producer's claim: **not met** (the named artifact — both-platform CI logs — does not exist)
  - Validator's finding: **refuted** (the guarantee) / **unverifiable** (the named artifact)
  - Evidence reviewed: `validation/validator-evidence/p6-libstdcxx-repro.log`,
    `pbt-libstdcxx.log`. Under libstdc++ (g++-14) an **ADMITTED** pattern hangs the engine inside a
    single `std::cregex_iterator` call on **one 403-byte line**:
    - `^(ab\w|((.|.){1,3}){1,3}){1,3}$` (the producer's own PBT generator's culprit) — libstdc++
      **hangs >25 s**; libc++ **returns** (`verdict=2 Exhausted, budgeted=0`); libstdc++ **with
      `RIPWIRE_FAULT_REGEX_BUDGET=1` still hangs**.
    - Alternation-free multi-quantifier family: `^(a)*(a)*$` instant, `^(a)*(a)*(a)*$` ~1 s,
      `^(a)*(a)*(a)*(a)*$` ~2 s, `^(a)*(a)*(a)*(a)*(a)*$` **>20 s** — polynomial in line length,
      degree ≈ (quantified atoms − 1).
    The guard's budget is checked **before** the engine is handed the line
    (`src/regexguard.h:1657`) and counts **lines, not work**; with one candidate line it never
    fires. The AC's *heading* ("both standard libraries bounded") is therefore **false**, not
    merely un-evidenced. The AC's *body* (the degrade path is reachable on libstdc++) remains
    unverifiable here for want of a libstdc++ CI run.
  - Notes: this is the same class the producer disclosed as **Q8** (deviation 9), but the report
    files it as a scope boundary and marks AC5 "not met" **only** for the missing CI artifact. See
    Issues 1 and 2.

- Criterion 6: **Determinism preserved** — two runs byte-identical with and without regex in the
  mix.
  - Producer's claim: **met**
  - Validator's finding: **confirmed**
  - Evidence reviewed: `evidence/determinism-ritual.txt` reproduced — three modes, each twice,
    stdout **and** stderr byte-identical. Independently: the PBT's P1 asserts determinism 20,000×
    per seed on libc++ (`pbt-regex-screen.log`) and the admission probe re-checks each row.

- Criterion 7: **Manifest unchanged** — gate already registered; `test/manifestcheck.sh` passes.
  - Producer's claim: **met**
  - Validator's finding: **confirmed**
  - Evidence reviewed: `test/manifestcheck.sh` re-run in the verify tree — **exit 0, ALL PASS**,
    including gate registration, the 683-gate count agreement, and both mutation controls.

---

## Interface Verification

- **matchBudgetDegrade** — Shape match: **mismatch** (four ways; see Issue 3).
  - Declared Shape says "hits collected so far are kept … the run continues with the next file" —
    the delivered and upstream contract is a **fail-closed refusal** (exit 1, no `hits=`). The
    spec's own Phase 2 text mandates the fail-closed form two paragraphs earlier.
  - Declared Invariant "a run over an adversarial corpus always terminates" — **false** on
    libstdc++ (Issue 1).
  - Declared Examples name a "screen fault-switched off" switch that **does not exist**, and
    `--regex='^(a|aa)+b$'`, which Phase 1 now **statically refuses** — so it can never reach the
    budget it is meant to exercise.
  - Declared Location `src/regexguard.h:1275` / `:1125` / `:1210` — **stale**. Actual:
    `forEachLineMatch` at `:1755`, the line-loop comment at `:1593`, `regexScanLines` at `:1596`,
    the fault seam `throwIfMatchFaultInjected` at `:1690`, the budget constant at `:1581`.

- **patternAdmission** — Shape match: **compatible** (verdict behaviour exact; the Examples line is
  stale). The delivered message says the screen "cannot PROVE are disjoint" (PM-1); the spec's
  Examples still describe a message that "names the overlapping alternation". Verdict semantics are
  unaffected.

- **pbtEvidenceBundle** — Shape match: **compatible with a defect** (Issue 2). The bundle contains
  the property-test source, seed list and raw log as declared; but §H's negative-control requirement
  is unmet, and the log records only a libc++ run, where the P6 property cannot fail.

- **All other declared interfaces** (RegexVerdict, the refusal sites, the fault switches) —
  **exact/compatible**; inspected in the verify tree.

---

## Issues Found

1. **Severity: major**
   Location: `src/regexguard.h:1657` (budget check) / spec AC5 / spec `matchBudgetDegrade` invariant
   Description: The per-file match budget **cannot bound a single line**, and an admitted pattern
   hangs libstdc++ inside one `std::cregex_iterator` call on a 403-byte line — with the fault switch
   on or off. Reproduced two ways: (a) the producer's own PBT fails to complete at its own
   `cases=20000` setting under libstdc++, naming
   `^(ab\w|((.|.){1,3}){1,3}){1,3}$`; (b) a minimal reproducer hangs >25 s on that pattern and >20 s
   on `^(a)*(a)*(a)*(a)*(a)*$`. libc++ is safe only because its **engine** throws
   `error_complexity` — i.e. the libstdc++ half of AC5's guarantee rests on a mechanism that does
   not exist there. This is a reachable unbounded-work path on the platform Phase 2 exists to
   protect (`--regex` / `--match` / `--arch` / `--graph-query` / `file()`).
   Suggested remedy: correct AC5 and the `matchBudgetDegrade` invariant to state the guarantee the
   mechanism actually provides (**aggregate** boundedness across a file, not per line), record Q8 as
   a named residual risk with the reachable surface, and carry the real fix (a per-line step bound,
   or a screen rule for adjacent/nested quantifier ambiguity) as a follow-on spec. A per-line
   wall-clock bound is *not* available: this tree's contract requires the verdict to be a pure
   function of file and pattern.

2. **Severity: major**
   Location: `evidence/pbt-regex-screen.log`, `evidence/pbt-regex-screen.cpp:246–256`
   Description: **P6 is not load-bearing as run.** P6 asserts "an ADMITTED pattern must match a
   pathological line and RETURN", but it was executed on **libc++ only**, where the engine's own
   complexity budget throws before any hang can occur — so P6 *cannot fail* on the platform it was
   run on, and its `9882/9882` pass is not evidence for the property it names. §H requires a
   negative control per named property; the completion report contains none for P6. The validator's
   re-performed control (P6 on libstdc++, a control the producer did not run) makes it **fail**.
   Suggested remedy: add the libstdc++ P6 leg (or a fault switch that forces the engine path) and
   record the negative control; until then, P6's pass must not be cited as boundedness evidence.

3. **Severity: major**
   Location: `specs/regex-screen-hardening/spec.md:88–95` (`matchBudgetDegrade`)
   Description: The interface block is stale in four independent ways — a Shape that contradicts the
   delivered fail-closed contract, an Invariant that is **false** on libstdc++, Examples naming a
   non-existent screen-disable switch and a pattern Phase 1 now statically refuses, and stale
   Location line numbers. The block is a consumer contract (`audit-validation-standalone`,
   `security-regression-integration`), so a stale block is a downstream hazard.
   Suggested remedy: a spec errata (v2.0.3) correcting Shape, Invariants, Examples and Location,
   in the same manner as the v2.0.2 errata.

4. **Severity: minor**
   Location: `evidence/screen-probe.cpp`, `evidence/probe-green.txt`, `evidence/README.md:26,80`
   Description: The declared Phase-1 admission arm **does not reproduce**. `README.md:80` gives the
   reproduction ("build `screen-probe.cpp` against the working tree … expect: 50 passed, 0 failed,
   RESULT: GREEN") and `probe-green.txt` records 50/50 GREEN; a fresh build of the shipped source
   against the shipped patch gives **33/50 RED** on **both** compilers. All 17 failures are
   `want REFUSE got REFUSE` — **message-substring only**; the arm's 17 `wantMessageContains` rows
   still assert the **pre-PM-1** wording `"overlapping alternation"`, which the header now emits
   **nowhere** (it survives only in comments, `:30` and `:177`). Changing exactly those 17
   substrings to `"cannot PROVE are disjoint"` restores **50/50 GREEN**, so **all 50 verdicts are
   correct** — the defect is a stale assertion and a log that was not regenerated after PM-1.
   Suggested remedy: update the 17 assertions to a PM-1-stable substring (the gates pin
   `backtrack`/`bounded`), regenerate `probe-green.txt`, and re-verify the RED-before-GREEN pairing.

5. **Severity: minor**
   Location: `evidence/README.md:41–52` ("Final state: both gates GREEN")
   Description: The README states the two gates are green "against the Phase-1+2 binary
   (`build/ripwire`, sha256 `f6b861cc…`)" — the **producer's** binary. That binary is not the
   artifact the spec ships (the patch is), and the README presents it as the bundle's evidence
   without the §H caveat that scratch output is a claim. The validator independently reproduced both
   gates green from the patch, so the claim is **true** — but the README should cite the
   reproduction command, not the producer's binary hash.
   Suggested remedy: reword to cite the patch and the reproduction command.

6. **Severity: minor**
   Location: `specs/regex-screen-hardening/spec.md` AC1 (wording), AC2 (vehicle), `patternAdmission`
   Examples
   Description: Three spec texts still carry pre-PM-1 / pre-delivery wording: AC1 says "naming the
   **overlapping-alternation** construct"; AC2 says "with the screen **fault-switched off**";
   `patternAdmission` Examples describes a message that "names the overlapping alternation". All
   three are disclosed in the report (deviations 1, 4, 5) but the spec text was not corrected.
   Suggested remedy: fold into the v2.0.3 errata with Issue 3.

---

## Negative Controls Performed (§H)

The validator re-performed a control the producer did not run, and one in-tree control:

1. **P6 on libstdc++** (the producer ran libc++ only) — **FAILS**; the property it names is false on
   the platform Phase 2 targets. Recorded: `validator-evidence/pbt-libstdcxx.log`,
   `validator-evidence/p6-libstdcxx-repro.log`.
2. **Budget fault switch** — with `RIPWIRE_FAULT_REGEX_BUDGET=1` the budget still does not stop the
   single-line hang, confirming the budget's scope is the aggregate, not a line.
3. **Probe assertion mutation** — changing only the 17 message substrings flips the arm from RED 17
   to GREEN 50, confirming the message rows are load-bearing and the verdict rows are not at fault.

---

## Memory Bank Audit

Declared in the completion report's State Management section; each verified in the verify tree's
`.agents/memory_bank/`.

- File: `.agents/memory_bank/active/PROGRESS.md`
  - Declared action: appended
  - Verified: **yes** — entry for 2026-10-12 with all four fields (Implemented / Decided / Blocked /
    Next) present and non-blank.
- File: `.agents/memory_bank/active/current_focus.md`
  - Declared action: updated
  - Verified: **yes** — names `regex-screen-hardening` and the next resumption point.
- File: `.agents/memory_bank/active/open_questions.md`
  - Declared action: appended (Q5–Q8)
  - Verified: **yes** — Q5, Q6, Q7 present with PM rulings; Q8 present.
- File: `.agents/memory_bank/ARCHITECTURAL_DECISIONS.md`
  - Declared action: appended (`AD-2026-10-12-regex-budget-count`)
  - Verified: **yes** — entry present.

All required and declared state writes are present and consistent. No memory-bank issue.

---

## Verdict Rationale

Six of seven acceptance criteria are confirmed — and AC4 is confirmed *more strongly* than the
producer claimed, because the validator rebuilt the pristine binary and ran the golden diff the
producer could not (Issue 4's counterpart). The spec cannot be approved because AC5's guarantee
("both standard libraries bounded") is **refuted**, not merely un-evidenced: the guard's per-file
budget counts lines, and an admitted pattern hangs libstdc++ inside a single line, so the one
mechanism the spec relies on to protect Linux does not bound the hazard it names (Issues 1, 2). Two
independent defects compound it — the PBT's P6 property is non-load-bearing on the platform it was
run on, and the `matchBudgetDegrade` interface block is stale in four ways including a false
invariant (Issue 3). The probe-staleness defect (Issue 4) is minor and fully explained: the arm's
verdicts are all correct and only 17 message substrings lag PM-1. The correct disposition is
`needs_revision`: correct the spec's claims to match the mechanism, make P6 load-bearing on
libstdc++, and decide Q8's scope — rather than approve a boundedness claim the code does not make
good on.

---

## Handoff Notes

- Verify tree: `/Users/rna/ripwire-scratch/pm-verify-r1` (`repo@0e0f67c7 + patch@round-1`);
  patched binary `45f3fb0b…`, pristine binary `fee29b79…` at
  `/Users/rna/ripwire-scratch/ripwire-0e0f67c7-pristine`.
- A libstdc++ toolchain **is** available natively on this host: `g++-14`
  (`/usr/local/bin/g++-14`, links GNU libstdc++ 7.33.0) compiles the narrow TU with
  `-B/usr/bin`. The full-tree build was not attempted (disk); the narrow TU is sufficient for the
  screen, the budget and P6, and is how the evidence above was produced.
- The producer's `evidence/probe-green.txt` and `evidence/screen-probe.cpp` are the **stale** pair;
  do not regenerate them from a stale binary — the arm must be re-run after the message rows are
  corrected.
- `spec.md:88–95` (`matchBudgetDegrade`) is the block the PM authorised for errata; the v2.0.2
  errata did not touch it.
- Q8 (group-free **and** bounded-nested multi-quantifier bombs) is **confirmed real** by the
  validator and is broader than the report's example: the report names `a*a*a*a*a*b`; the
  validator also confirmed `^(a)*(a)*(a)*(a)*(a)*$` and
  `^(ab\w|((.|.){1,3}){1,3}){1,3}$`. The PM ruling on scope is recorded in
  `.agents/memory_bank/active/open_questions.md`.
