# Completion Report — regex-screen-hardening — round 2 (revision)

## Header

spec_id: regex-screen-hardening
producer: WorkBuddy AI / Deepseek-V4.1-Flash
round: 2 (revision, after the round-1 verdict `needs_revision`)
started: 2026-10-13T20:26:00+01:00
completed: 2026-10-13T20:45:00Z
spec_version: 2.0.3
supersedes: `validation/completion-report.md` (round 1) for the AC5, P6 and probe claims

Round base: `0e0f67c7` (post-0.6.7, train 27). Scratch tree `/Users/rna/ripwire-scratch/rsh-r1`.
Round patch: `patches/round-1.patch` — **UNCHANGED in round 2** (sha256 `fba4ca68…`, 5 files, +753/−93).

**Round 2 changes NO `src/` or `test/` file.** It corrects the spec's *claims* (errata v2.0.3), regenerates the
admission probe, and makes the P6 property load-bearing on libstdc++. Everything below is either a claim correction
or new evidence; the shipped artifact is byte-identical to round 1's. That is deliberate: the round-1 verdict found
that the *words* overstated the mechanism, not that the mechanism was wrong.

## What the round-1 verdict found, and what round 2 did

| # | Verdict issue | Severity | Round-2 disposition |
| --- | --- | --- | --- |
| 1 | AC5's guarantee **refuted** — the budget cannot bound a single line | major | AC5 rewritten (errata v2.0.3) to the guarantee the mechanism makes good; the residual recorded as a **named, reachable** risk; independently reproduced in `evidence/p6-negative-control.log` |
| 2 | **P6 not load-bearing as run** (libc++ only) | major | `pbt-run.sh` gained a **libstdc++ leg** that records the kill; `p6-negative-control.{cpp,sh}` is the §H control; P6's in-file comment now says it is library-dependent |
| 3 | `matchBudgetDegrade` block stale in four ways | major | corrected in place — Shape (fail-closed), Location (re-located), Invariants (the false "always terminates" replaced), Examples (the non-existent switch and the now-refused pattern removed) |
| 4 | The probe **does not reproduce** (17 stale message assertions) | minor | the 17 assertions updated to the delivered clause; regenerated and re-run under **both** toolchains |
| 5 | README cited the producer's binary, not the patch | minor | README now cites the patch and the reproduction command; the producer's binary is labelled a claim |
| 6 | AC1 / AC2 / `patternAdmission` carried pre-PM-1 wording | minor | all three corrected in place |

**The "clang GREEN / gcc RED" alarm is resolved as a STALE BINARY, not a compiler-dependent screen.** The round-1
`screen-probe` was built 2026-10-12 10:56, *before* PM-1 reworded the refusal message, so it emitted the old text
and its 17 message rows asserted a phrase the delivered header emits **nowhere** (it survives only in comments,
`regexguard.h:30`, `:177`). A fresh build against the delivered header goes RED 33/50 on **both** compilers —
byte-for-byte the same failure mode — and changing only those 17 substrings restores 50/50. All 50 *verdicts* were
always correct; only the assertions lagged the contract. Regenerated evidence: `evidence/probe-green.txt`, now
carrying **both** toolchains side by side (clang/libc++ and g++-14/libstdc++, both 50/50 GREEN).

## Acceptance Criteria Self-Check

- Criterion 1: **Alternation family refused** — met.
  - Evidence: `evidence/ac1-alternation-refusal.txt` (the spec's exact fixture; all five battery patterns exit 1 in 2.2–4.3 s, no `hits=`, 'backtrack' present, **and the PM-1 honesty clause present**); `evidence/gate-final-regexbombcheck.txt` section (5). AC1's wording was corrected to the PM-1 clause at errata v2.0.3.
- Criterion 2: **Budget degrade disclosed** — met (as corrected).
  - Evidence: `evidence/gate-final-regexbombcheck.txt` section (6) — the no-switch control scans cleanly at exit 0; the switched run (`RIPWIRE_FAULT_REGEX_BUDGET=1`) exits 1, prints no `hits=`, and stderr carries `'match budget'` and the full `kRegexBudgetReason` sentence; the exact-`"1"` control leaves the answer unchanged. The AC's original vehicle ("screen fault-switched off … subsequent-file hits are present") named a switch that does not exist and the pre-seam behaviour upstream replaced; corrected at errata v2.0.3 to the budget-cap vehicle the arm actually drives.
- Criterion 3: **No refusal regression** — met (substance) / the named verifier could not complete here (environment).
  - Evidence: `evidence/gate-final-regexbombcheck.txt` (**99 PASS / 0 FAIL**, exit 0) and `evidence/gate-final-regexguardcheck.txt` (**135 PASS / 0 FAIL**, exit 0); `evidence/corpus-sweep.txt` reproduced by the validator **exactly** — 99,845 literals, **33 newly refused, 0 newly admitted**. The validator independently re-ran both gates green **from the patch**.
  - Notes: `pargates.py` (683 gates) cannot complete in this environment — see Known Deviation 3.
- Criterion 4: **No admission regression** — met, and now **directly**.
  - Evidence: the round-1 verdict **upgraded this criterion from transitive to direct**: the validator rebuilt the pristine binary (`fee29b79…`, `repo@0e0f67c7` unpatched) and diffed it against the patched binary (`45f3fb0b…`) — **17/17 patterns byte-identical on stdout, stderr and exit code**. Round-1 Known Deviation 7 (the literal golden diff was not run) is therefore **remedied by the validator**, and the producer did not need to re-run it (a pristine rebuild drives this volume to ~100 MiB free).
- Criterion 5: **The degrade is reachable on both standard libraries, and the file-level aggregate is bounded** — met (as corrected).
  - **Corrected at errata v2.0.3.** The heading was "Both standard libraries bounded", which asserted a **per-line** guarantee the mechanism does not provide; the round-1 verdict refuted it. The corrected criterion asserts what the code does: the budget bounds a file's **aggregate** cost, and the disclosed fail-closed degrade is reachable on both libraries with the same alert shape (one `RegexVerdict::Exhausted`, one refusal site, one exit code, two reason sentences).
  - Evidence: the budget arm (platform-independent — it drives the budget through its own fault switch, so it needs no bomb); `evidence/pbt-run.sh` **leg 2** (libstdc++); `evidence/p6-negative-control.log`.
  - **The single-line residual is explicitly NOT covered by this criterion** and is recorded as a named reachable risk (Q8/Q9) — see below.
  - Notes: the **both-platform CI logs** remain the AC's named artifact and must come from CI. They are *not* the whole of the evidence any more: the native `g++-14` route (Q6 update #2) produced the libstdc++ behaviour directly.
- Criterion 6: **Determinism preserved** — met.
  - Evidence: `evidence/determinism-ritual.txt` — three modes, each twice, stdout AND stderr byte-identical. The gates carry their own determinism arms; the PBT asserts it 20,000×3 (P1).
- Criterion 7: **Manifest unchanged** — met.
  - Evidence: `evidence/manifestcheck.txt` — exit 0, ALL PASS (gate registration, the 683-gate count agreement, both mutation controls). No new gate was added.

## The residual, stated plainly (Q8/Q9)

An **ADMITTED** multi-quantifier pattern meeting a subject that holds its required literal and then a long run is
**unbounded work on libstdc++**, and the guard's per-file budget cannot see it: the budget counts **engine line-match
attempts**, and the check sits **before** the engine is handed a line (`src/regexguard.h:1657`). One `std::regex`
call is atomic to its caller. The family has at least three members the Phase-1 rule cannot see — group-free flat
(`a*a*a*a*a*b`), grouped-but-alternation-free (`^(a)*(a)*(a)*(a)*(a)*$`), and bounded-nested
(`^(ab\w|((.|.){1,3}){1,3}){1,3}$`, where `(.|.)` *is* an overlapping alternation but its outer `{1,3}` is bounded).

Reproduced by the producer, independently of the validator (`evidence/p6-negative-control.log`):

| k | libc++ | libstdc++ |
| --- | --- | --- |
| 2 | verdict=1, 6.7 ms | verdict=1, 0.8 ms |
| 3 | verdict=2 (Exhausted), 41.7 ms | verdict=1, 44.8 ms |
| 4 | verdict=2 (Exhausted), 45.9 ms | verdict=1, **2252.6 ms** |
| 5 | verdict=2 (Exhausted), 42.8 ms | **KILLED after 20 s** |
| 6 | verdict=2 (Exhausted), 43.3 ms | **KILLED after 20 s** |

`budgeted=0` on every row — the budget never fires. libc++ survives only because its **engine** has a complexity
budget. This is **not closed by this spec** and is **not** claimed to be; the scope decision (a follow-on spec, an
in-round widening, or an accepted residual) is operator-gated as **Q9**.

## Interfaces Delivered

- Name: `patternAdmission` — unchanged shape; the delivered refusal now states the screen **cannot PROVE the branches
  disjoint** (PM-1). Examples in the spec corrected at errata v2.0.3.
- Name: `matchBudgetDegrade` — **corrected to the delivered contract**: fail-closed (exit 1, no `hits=`), an aggregate
  per-file budget (`kRegexFileMatchBudget`, a deterministic **count** of engine line-match attempts, not a clock),
  disclosure selected by a `budgeted` flag, reason `kRegexBudgetReason`. Location corrected to
  `GuardedRegex::forEachLineMatch` (`src/regexguard.h:1755`), `regexScanLines` (`:1596`), constant (`:1581`), cap
  check (`:1657`), fault seam (`:1690`).
- Name: `pbtEvidenceBundle` — unchanged shape plus the **§H negative control** required by the round-1 verdict:
  `p6-negative-control.{cpp,sh}` and the libstdc++ leg inside `pbt-run.sh`.

## Known Deviations

1. **The single-line residual is NOT bounded (the round-1 verdict's Issue 1).** Recorded as a **named, reachable**
   risk in the spec (`§Failure Modes`, the errata block, the corrected AC5) and here. It is not fixed — a fix is a
   new structural rule or a per-line step bound, which needs its own admit-set analysis and negative controls, and is
   operator-gated (Q9). **This is the one deviation that matters.**
2. **The both-platform CI logs (AC5's named artifact) are still absent.** Only macOS is available to this session.
   The libstdc++ *behaviour* is nonetheless evidenced directly via Homebrew `g++-14` (Q6 update #2), which is how the
   residual was found and confirmed. The CI job that would emit the canonical log is what is missing.
3. **`pargates.py` (683 gates) cannot complete in this environment** — two independent environmental causes: the
   suite exhausts the volume (Q6, observed twice), and this client's `safe-delete` shim turns a gate's own bulk
   `rm -rf` cleanup into a false non-zero exit **with every assertion green** (proven: `astrocheck.sh` exits 1
   shimmed, 0 under `env -i`). All seven gates the partial runs reddened **pass** on a clean sequential re-run in a
   scrubbed environment (2 s to 630 s). Full triage: `evidence/pargates-partial.txt`.
4. **PM-1 and PM-2** (round 1) remain in force and unchanged: the honest refusal wording, and the BSD-grep
   portability fix at `regexbombcheck.sh:141` (`grep -qiE`, since BSD grep reads a BRE `\|` as a literal pipe).
5. **Q7's (b2)/(i) re-scope** (round 1, errata v2.0.2) remains in force and unchanged.
6. **The probe's staleness (Issue 4)** is disclosed rather than quietly fixed: the round-1 `probe-green.txt` recorded
   50/50 GREEN from a binary built **before** PM-1 reworded the message, and the arm was not re-run when the message
   changed. Round 2 regenerates it against the delivered header under both toolchains and says so in the file.

## State Management

### Memory Bank

- File: `.agents/memory_bank/active/PROGRESS.md` — **appended**: the round-2 entry (four fields).
- File: `.agents/memory_bank/active/current_focus.md` — **updated**: resumption point is the re-validation handoff.
- File: `.agents/memory_bank/active/open_questions.md` — **updated**: Q8's premise recorded as refuted (the budget
  does not bound the family) with the producer's independent reproduction; Q9 recorded as operator-gated.
- File: `.agents/ripwire-audit-remediation-specs/manifest.yml` — **appended**: one history event recording the
  round-2 revision and the unchanged patch.
- File: `.agents/memory_bank/ARCHITECTURAL_DECISIONS.md` — **unchanged** (no new decision; the budget's count-vs-clock
  row stands, and the corrected scope is a claim fix, not an architecture change).

### Progress Tracking

- Spec file `spec.md`: version **2.0.3**; Progress Tracking carries Phases 1–4 checked plus the round-2 line.
- Phase log: `phase-log.md` (round 1). Round 2 is documented here and in the errata block.

## Handoff Notes

- **The artifact is `patches/round-1.patch`, unchanged.** To verify: apply it to a tree at `0e0f67c7`, build, run the
  two gates (both ALL PASS) and, for the new evidence, `bash evidence/pbt-run.sh` and
  `bash evidence/p6-negative-control.sh`.
- **The one question for the validator:** does the corrected AC5 state the guarantee the mechanism makes good, and is
  the residual recorded at the right severity? The producer's answer is yes on both — the residual is real,
  reachable and named, and it is **not** claimed closed.
- **Q9 awaits the operator.** The producer recommends option (a): a follow-on spec (`regex-screen-multiquantifier`,
  depending on this one) that closes the family with its own admit-set analysis and negative controls. The producer
  has **not** created that spec — creating a DAG node is a manifest-level act and the decision is operator-gated.
- **Status is deliberately left `in_progress`.** Per AGENTS.md §15 the producer does not self-validate.
