// p6-libstdcxx-repro.cpp — validator's minimal reproducer for the P6 gap.
//
// CLAIM UNDER TEST (P6, spec §Validation Strategy): "an ADMITTED pattern must match a pathological
// line and RETURN" — the property the spec's Phase 2 budget exists to make true on libstdc++, which
// has no engine complexity budget of its own.
//
// FINDING: the claim is FALSE on libstdc++. An admitted pattern hangs the engine inside a SINGLE
// std::cregex_iterator call on ONE 403-byte line. The guard's per-file match budget counts LINES,
// not work (src/regexguard.h:1657 checks it BEFORE the engine is handed the line), so with one
// candidate line it never fires — with the fault switch ON or OFF.
//
// This is the SAME line the producer's own PBT uses (evidence/pbt-regex-screen.cpp:216):
//     std::string(200,'a') + "\n" + std::string(200,'a') + "z\n"
//
// Build (against the verify tree = repo@0e0f67c7 + patch@round-1):
//   /usr/local/bin/g++-14 -std=c++23 -O2 -B/usr/bin -I <verify-tree>/src -o /tmp/hang-gcc p6-libstdcxx-repro.cpp
//   /usr/bin/clang++      -std=c++23 -O2                  -I <verify-tree>/src -o /tmp/hang-clang p6-libstdcxx-repro.cpp
//
// Run:  <binary> '<pattern>'      (default: the PBT's own culprit)

#include "regexguard.h"

#include <cstdio>
#include <string>

int main( int argc, char** argv )
{
    const char* pat = ( argc > 1 ) ? argv[1] : "^(ab\\w|((.|.){1,3}){1,3}){1,3}$";

    const std::optional<std::string> v = rw::screenRegexPattern( pat );
    std::printf( "screen(%s) = %s\n", pat, v ? "REFUSED" : "ADMITTED" );
    std::fflush( stdout );
    if( v )
    {
        return 0;
    }

    const rw::RegexCompile rc = rw::compileGuardedRegex( pat, rw::kRegexEcmaScript );
    if( rc.refusal )
    {
        std::printf( "compile refused: %s\n", rc.refusal->c_str() );
        return 0;
    }

    // the producer's own pathological line, verbatim from evidence/pbt-regex-screen.cpp:216
    const std::string patho = std::string( 200, 'a' ) + "\n" + std::string( 200, 'a' ) + "z\n";
    std::printf( "calling forEachLineMatch on %zu bytes ...\n", patho.size() );
    std::fflush( stdout );

    const rw::RegexLineScan scan = rc.regex.forEachLineMatch( patho, rw::RegexLinePolicy{},
                                                             []( std::uint32_t, std::size_t ) { return true; } );
    std::printf( "RETURNED: verdict=%d budgeted=%d\n", int( scan.verdict ), int( scan.budgeted ) );
    return 0;
}
