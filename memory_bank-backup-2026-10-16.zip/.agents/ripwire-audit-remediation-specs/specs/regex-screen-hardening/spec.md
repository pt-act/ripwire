# Regex Screen Hardening

## Header

```yaml
id: regex-screen-hardening
type: unit
version: 2.0.3
manifest: ../../manifest.yml
```

## Objective

Close the one remaining catastrophic-regex hole — overlapping alternation — by extending upstream's own guard, and add a match-time budget for patterns the widened screen must still admit. (Re-scoped 2026-10-11: the 2026-09-14 draft targeted src/search.h admission and a from-scratch screen+budget; upstream has since shipped src/regexguard.h + test/regexbombcheck.sh delivering most of that plan, so this spec is now the GAP-FILL against their guard.)

## Scope

### What upstream already delivers (do not rebuild — verified live 2026-10-11)

- The structural screen: `catastrophicRegexConstruct()` (regexguard.h:257) refuses every unbounded quantifier over a group containing ANY quantifier at any depth — `(a+)+`, `(X?)+`, `(X{1,3})+`, `(X+|Y)+`, `((ab|c){2})+d` — on EVERY user-authored pattern surface (--regex, --graph-query file(), --arch path-rules, #match?/#not-match?).
- The match-time catch: `GuardedRegex::search/forEachMatch` returns `RegexVerdict::Exhausted` when the ENGINE gives up (libc++ error_complexity/error_stack), stops scanning that file, and the verb refuses the answer by name (search.h:1217, "grep: the regex engine abandoned a match ... the verb refuses the answer") — fail-closed (exit 1, no `hits=`; the file's partial hits are not reported as a floor) — a disclosed degrade, never a silent floor. `Skipped` covers the oversize subject identically.
- The gate: `test/regexbombcheck.sh` (registered) with refusal battery, precision controls, determinism arms, honest-pattern golden — ALL PASS on the current tree.

### What remains open (the gap-fill)

1. **The static screen's documented gap: overlapping alternation.** A group with NO quantifier inside whose branches match overlapping text passes by design ("a group with no quantifier inside passes however it is quantified"); regexguard.h:173 names it: "The known GAP is overlapping alternation — (a|a)+b is a real bomb whose branches only overlap semantically". The audit's PoC `^(a|aa)+b$` SCANS live (no refusal; the engine runs the bomb). regexbombcheck prints the gap as an INFO line ("ran past 30 s — a KNOWN gap") instead of an arm.
2. **No runtime backstop on libstdc++.** The Exhausted catch fires only when the engine itself gives up; libc++ has a complexity budget, libstdc++ does not (regexguard.h:137–141: "it never throws, so that catch is never reached and the process simply backtracks"). A screen-passed pattern meeting a pathological line backtracks without bound on Linux. On benign corpora the admitted bomb answers correctly (measured: `(a|a)+b` over this repo, 5 hits, fast) — the danger is the crafted subject. **What the budget half actually buys (errata v2.0.3, from the round-1 verdict):** the per-file match budget bounds the AGGREGATE cost of a file — many candidate lines — NOT the cost of a single `std::regex` call. It is checked *before* the engine is handed a line, so ONE crafted line is unbounded work the budget cannot see, and the engine gives no step counter the caller could bound instead. The residual is therefore **named, reachable and NOT closed by this spec** (Q8/Q9); see the errata block below and §Failure Modes.

### Errata v2.0.3 (2026-10-13, PM-authorised by the round-1 verdict)

The round-1 verdict (`validation/verdict.md`) returned `needs_revision`. Six of seven acceptance criteria were
confirmed; AC5 was **refuted on its guarantee**, and the `matchBudgetDegrade` interface block was found stale in four
independent ways. This errata corrects the spec's **claims** to match the mechanism the code actually provides. It
changes no rule, no objective and no code — the round patch is unchanged; only the words that describe it move.

1. **AC5 and the `matchBudgetDegrade` invariant overstated the mechanism.** "Both standard libraries bounded" and "a
   run over an adversarial corpus always terminates" are both **false as written**: they assert per-line boundedness,
   and the delivered budget is an *aggregate* bound over a file. Corrected to the guarantee the mechanism makes good
   (aggregate boundedness; the degrade path reachable and disclosed on both libraries), with the single-line residual
   recorded as a named reachable risk rather than claimed away.
2. **The residual is real and reproduced, not hypothetical.** `evidence/p6-negative-control.log` (producer, both
   toolchains): the alternation-free family `^(a)*(a)*…(a)*$` is ADMITTED; on libc++ every member returns (the
   engine's complexity budget throws `Exhausted` in ~43 ms), on libstdc++ the cost grows polynomially and k>=5 does
   not return inside a 20 s cap, with `budgeted=0` throughout. The family has at least three members the Phase-1 rule
   cannot see: group-free flat (`a*a*a*a*a*b`), grouped-but-alternation-free (`^(a)*(a)*…$`), and bounded-nested
   (`^(ab\w|((.|.){1,3}){1,3}){1,3}$`, where `(.|.)` *is* an overlapping alternation but its outer `{1,3}` is
   bounded).
3. **P6 must be load-bearing on the library where it can fail.** The round-1 PBT ran libc++ only, where the engine's
   own complexity budget makes P6 unfalsifiable. The PBT runner now carries a libstdc++ leg (`pbt-run.sh` leg 2) that
   records the kill, and `p6-negative-control.{cpp,sh}` is the minimal §H control.
4. **The probe's message assertions were stale.** `evidence/screen-probe.cpp`'s 17 REFUSE rows asserted the pre-PM-1
   phrase "overlapping alternation", which the delivered header emits nowhere. Regenerated against the delivered
   wording ("cannot PROVE are disjoint") and re-run under **both** toolchains — which also settles that round 1's
   "clang GREEN / gcc RED" split was a stale binary, not a compiler-dependent screen.
5. **AC1/AC2/`patternAdmission` Examples carried pre-PM-1 / pre-delivery wording** and are corrected in place (below).

The scope question the residual raises — a new screen rule or a per-line step bound for the multi-quantifier family
— is **operator-gated** (Q9) and is **not** authorised for this round: it is a new structural rule needing its own
admit-set analysis (it must still admit `.*.*`, `\s*\w+`, `(get|getResponse){1,5}`). The producer recommends a
follow-on spec (`regex-screen-multiquantifier`, depending on this one), which is how the family gets its own negative
controls rather than loading an unsettled rule into a round whose criteria are already fixed.

### Phase 1 — extend the admission verdict to overlapping alternation

Extend `catastrophicRegexConstruct()` (src/regexguard.h:257) — or the structural scan feeding it — to refuse a group containing a top-level `|` under an unbounded outer quantifier (`*`, `+`, `{n,}`) when the ALTERNATIVES CAN MATCH OVERLAPPING TEXT. The screen cannot see semantics in general, so the conservative cut is STRUCTURAL overlap:

- an alternative is a prefix of another (`a` / `aa`);
- two alternatives can match the empty string (`a` / `a*`);
- a character-class alternative intersects another (`\w` | `\d`).

Refuse: `^(a|aa)+b$`, `^(ab|cd)+e$`, `(a|a)+b`, `(x|xy)+c$`, `(\w|\d)+$`, `(a|a*)+`, `((a|aa)+)+`.

Admit (MUST stay admitted): `(a|b)+` — VERIFIED LIVE a `safeCase` arm of their gate (regexbombcheck:192, "plain alt") that answers today; refusing it turns the precision arm red. Likewise `foo.*bar`, `(abc)+`, `TODO|FIXME` (top-level alternation, no quantified group), and the documented workaround shape `(\s*\w+){1,20}` (bounded outer).

Reuse and extend THEIR refusal-message vocabulary (the screen already teaches workarounds — "collapse the two repetitions into one", "make the OUTER bounded" — the alternation arm teaches in the same voice: state that the screen **cannot PROVE the branches disjoint**, and offer **make the OUTER bounded** as the actionable workaround — PM-1; it must NOT claim the branches overlap, and must NOT teach "factor the branches", which is impossible for an already-disjoint alternation). Preserve every existing refusal (the nested battery, icase/escaped-literal arms, the `\Q\E` platform split); `regexguardcheck.sh` precision arms pass unchanged.

### Phase 2 — the match-time budget the Exhausted catch cannot provide on libstdc++

Add a per-file match budget to the engine path in `GuardedRegex` (regexguard.h), so a pattern that still passes the widened screen cannot backtrack unbounded on libstdc++ **across a file**:

- **Delivered shape (errata v2.0.3).** A deterministic **count of engine line-match attempts per file**
  (`kRegexFileMatchBudget`), checked *before* the engine is handed each candidate line — not a clock (the project
  gates on byte-identical output and a clock is not deterministic), and not a visit/step counter inside the wrap
  around `std::cregex_iterator` (the engine exposes no step count to its caller).
- **Scope, stated honestly (errata v2.0.3).** The budget bounds the **AGGREGATE** — the cost of a file's many
  candidate lines — **NOT** the cost of a single `std::regex` call. One crafted line is atomic to its caller and is
  unbounded work the budget cannot see. That residual is named and reachable (Q8/Q9, errata block above) and is
  **not** closed by this spec.
- On exceedance: scanning stops for that file and the same Exhausted-shaped refusal fires, with a budget-specific
  sibling sentence (`kRegexBudgetReason`) selected by a `budgeted` flag on the verdict so no existing consumer can
  miss it. The contract is **fail-closed** — the file's partial hits are NOT reported as a floor (exit 1, no
  `hits=`), matching the abandonment contract upstream already ships; reporting them would be exactly the silent
  floor the project forbids.
- Keep the budget OUT of the literal paths (the literal plan and required-literals prefilter never recurse;
  budgeting them is dead cost).
- Location is the guard (`GuardedRegex::forEachLineMatch` owns the line loop), NOT search.h as the original draft
  had it.
- Reachable on every platform through a non-NDEBUG fault switch (`RIPWIRE_FAULT_REGEX_BUDGET`, the
  `RIPWIRE_FAULT_REGEX_LINE_BOUND` idiom): post-Phase-1 there is no screen-admitted bomb left for a disabled screen
  to expose, so the arm caps the budget rather than disabling the screen.
- Choose the constant so the existing gate corpus never trips it — measured against their fixture sizes, >=10x
  headroom.

### Phase 3 — gate arms turn the INFO gap line into PASS

**Errata v2.0.2 (2026-10-12, PM-authorised).** The original text named `test/regexbombcheck.sh` alone, and AC3
asserted "regexguardcheck precision arms pass unchanged". But `test/regexguardcheck.sh` also carries MATCH-TIME arms
whose premise Phase 1 removes: **(b2)** (267–284) and the libc++ halves of **(i)** (476–484) both asserted `(a|a)+z`
PASSES the screen and is abandoned mid-match, and the PORTABLE first half of (i) (469–475) used the same pattern as
an allow rule. Phase 1 closes that gap, so all seven red on a libc++ host — the PM's gate run (2026-10-12) confirmed
it empirically, and that `--arch` compiles rules EAGERLY at load, so the portable half reds too. The scope therefore
names BOTH gates, under one rule: **no guarantee may lose its arm.**

- `test/regexbombcheck.sh` — add the overlapping-alternation battery to the REFUSAL battery: `(a|a)+b`, `^(a|aa)+b$`,
  `(x|xy)+c$`, `(\w|\d)+$` — each refused at exit 1, bounded wall time, message names the construct AND states the
  screen cannot PROVE disjointness (PM-1). The existing INFO line about the known gap is REPLACED by these arms.
- `test/regexbombcheck.sh` — add the budget arm: with the guard's per-file match budget capped by its own non-NDEBUG
  fault switch (`RIPWIRE_FAULT_REGEX_BUDGET`, the `RIPWIRE_FAULT_REGEX_LINE_BOUND` idiom), a fixture whose file
  exceeds the cap completes with the disclosed budget refusal rather than hanging, the run continues (the refusal
  reports the file count), and the control (no switch) scans the same corpus cleanly. Post-Phase-1 there is no
  screen-admitted BOMB left to hand the engine — the screen refuses them, which is the point — so the budget's job is
  the AGGREGATE (the spec's own Failure Mode, "a very large file matched by a cheap pattern").
- `test/regexguardcheck.sh` — RE-SCOPE (b2) (267–284) from "the gap is open, the engine abandons it" to "the gap is
  CLOSED statically at every entry point" (`--graph-query file()`, `--arch`, `--match`, `--regex`), and RE-SCOPE (i)
  (468–487) to a PORTABLE match-time-undecided vehicle (a substituted-TO refusal, `a{2,\1}`), which preserves the
  deny-first guarantee on every standard library instead of only where libc++ is linked. No guarantee loses its arm:
  the real-engine abandonment path stays proven by (b1)'s fault switch and by the budget arm above.
- Honest-pattern golden: the precision battery byte-identical pre/post change. No new registration — both gates
  already exist; manifestcheck already lists them.

## Interfaces

### patternAdmission (extension, not new)
- **Shape:** `std::optional<std::string> catastrophicRegexConstruct( const std::string& pat )` — unchanged signature; `std::nullopt` = admit, `std::string` = refuse with user-facing reason. Post-change verdict additionally covers the structural-overlap alternation family above.
- **Location:** src/regexguard.h:257 (was src/search.h in the 2026-09-14 draft — the admission site moved upstream).
- **Invariants:** every previously refused pattern remains refused with a message naming the construct; the admit set above is unchanged semantically; the verdict is a pure function of the pattern string.
- **Examples (errata v2.0.3):** `^(a|aa)+b$` => refused, and the message states the screen **cannot PROVE the branches disjoint** (PM-1 wording — it no longer claims the branches "can match the same text", which was false for the disjoint-but-refused class); `^(ab|cd)+e$` => refused (prefix-adjacent branches, conservative rule); `(a|b)+` => admitted (disjoint plain alternation); `foo.*bar` => admitted.
- **Consumers:** security-regression-integration, audit-validation-standalone

### matchBudgetDegrade (relocated into the guard)
- **Shape (errata v2.0.3 — the block was stale in four ways; the round-1 verdict found them).** Behavioral contract — during per-line verification, when a file's budget (a count of engine line-match attempts) is exceeded, matching stops for that file, the file's partial hits are **discarded, not reported as a floor** (the refusal is **fail-closed**: exit 1, no `hits=`), an Exhausted-shaped refusal line naming the budget is emitted, and the run reports that refusal — exactly the abandonment contract upstream already ships. (The old Shape said "hits collected so far are kept … the run continues with the next file"; that contradicted the fail-closed form the code and upstream both use.)
- **Location (errata v2.0.3 — re-located).** `GuardedRegex::forEachLineMatch` at **src/regexguard.h:1755**; the line loop behind it (`regexScanLines`) at `:1596` with its comment at `:1593`; the budget constant at `:1581`; the cap check at `:1657`; the fault seam `throwIfMatchFaultInjected` at `:1690`. The 2026-09-14 draft's `src/search.h ~L1090–1115` try/catch region no longer exists there — those lines are now `grepWholeLine`, and the loop has moved into the guard, exactly as the re-scope predicted.
- **Invariants (errata v2.0.3).** The budget bounds a file's **AGGREGATE** engine cost, so a run over an adversarial corpus of MANY candidate lines terminates; the degrade is always disclosed (never a silent partial result); the literal path never budgets. **NOT an invariant — the round-1 verdict is why:** a single `std::regex` call is atomic to its caller, so ONE crafted line is unbounded work this mechanism cannot see. The old invariant "a run over an adversarial corpus always terminates" was false on libstdc++ and is replaced by the aggregate statement above; see the errata block and Q8/Q9.
- **Examples (errata v2.0.3).** With the budget capped by its own fault switch (`RIPWIRE_FAULT_REGEX_BUDGET=1`), a fixture whose file exceeds the cap completes with the disclosed budget refusal — exit 1, no `hits=`, stderr naming "the per-file bound on engine line-match attempts" — and the no-switch control scans the same corpus cleanly at exit 0. (The old example — "with the screen fault-switched off, `--regex='^(a|aa)+b$'`" — named a switch that does not exist AND a pattern Phase 1 now statically refuses, so it could never reach the budget it was meant to exercise.)
- **Consumers:** security-regression-integration, audit-validation-standalone

### pbtEvidenceBundle (unchanged shape; one §H control added at errata v2.0.3)
- **Shape:** directory `specs/regex-screen-hardening/evidence/` containing the property-test source, the seed list, the raw pass/fail log, and — required by §H — a **negative control for each named property**. The P6 control is `p6-negative-control.{cpp,sh}` (the minimal reproducer) plus the libstdc++ leg inside `pbt-run.sh`; its log is `p6-negative-control.log`.
- **Location:** committed beside this spec (evidence is produced at execution time; the bundle path is the contract).
- **Invariants:** every property in §Validation Strategy appears with its case count and result; failures are never edited out of the log; a property that **cannot fail on the platform it was run on** must say so — P6 on libc++ was exactly that case in round 1, and the libstdc++ leg now makes it falsifiable.
- **Examples:** `evidence/pbt-regex-screen.log` with a header line `cases=20000 seed=... result=pass`; `evidence/p6-negative-control.log` showing the libstdc++ kill that makes P6 load-bearing.
- **Consumers:** audit-validation-standalone

## Acceptance Criteria

1. **Alternation family refused**: a fixture corpus containing one file whose single line is 200 `a` bytes; `./build/ripwire <corpus> --regex='^(a|aa)+b$'` exits before a 60 s cap (macOS has no coreutils `timeout`; the cap is the gate's own background+poll+kill idiom) with a message that names the construct AND states the screen cannot PROVE the branches disjoint (PM-1 wording — errata v2.0.3); same for the full battery. **Verifier:** the new regexbombcheck refusal arms.
2. **Budget degrade disclosed**: with the budget capped by its own fault switch in a test build (`RIPWIRE_FAULT_REGEX_BUDGET=1`), a file that exceeds the cap produces the disclosed budget refusal — exit 1, no `hits=`, stderr naming the per-file bound on engine line-match attempts — and the no-switch control scans the same corpus cleanly at exit 0. **Verifier:** the budget arm. *(Errata v2.0.3: the AC's original "with the screen fault-switched off … subsequent-file hits are present" named a switch that does not exist and the pre-seam behaviour upstream replaced with a fail-closed refusal. The delivered vehicle caps the budget instead; same class of evidence — reachable path, disclosed, bounded, run terminates — and the better one, since post-Phase-1 there is no screen-admitted bomb for a disabled screen to expose.)*
3. **No refusal regression**: every pattern in the existing catastrophic-family gate arms is still refused. The regexguardcheck PRECISION arms pass unchanged; its MATCH-TIME arms whose premise Phase 1 removes — (b2) and (i), which asserted `(a|a)+z` is ADMITTED and abandoned mid-match — are RE-SCOPED (errata v2.0.2) to assert the gap is now closed statically, and for (i) to a portable undecided vehicle. **Verifier:** both gates under `python3 test/pargates.py . ./build/ripwire -j 6`.
4. **No admission regression**: the honest corpus — the existing --grep gate fixtures plus the admit set above (`(a|b)+` included) — matches identically. **Verifier:** golden-output diff against pre-change output, byte-identical.
5. **The degrade is reachable on both standard libraries, and the file-level aggregate is bounded** *(errata v2.0.3 — the heading was "Both standard libraries bounded", which asserted a per-line guarantee the mechanism does not provide; the round-1 verdict refuted it).* libstdc++ demonstrates the budget degrade; libc++ keeps the Exhausted path live; the alert shape is the same on both — one `RegexVerdict::Exhausted`, one refusal site (`refuseAbandonedRegexScan`), one exit code (1), two reason sentences. **The single-line residual is explicitly NOT covered by this criterion** (a single `std::regex` call is unbounded to its caller) — see the errata block and Q8/Q9. **Verifier:** the budget arm (platform-independent: it drives the budget through its own fault switch, so it needs no bomb and runs identically on both libraries) plus the PBT's libstdc++ leg (`pbt-run.sh` leg 2, `p6-negative-control.log`); the both-platform CI logs remain the named artifact and are supplied by CI, not by this session.
6. **Determinism preserved**: two runs byte-identical with and without regex in the mix (the AGENTS.md ritual), logged in the evidence bundle.
7. **Manifest unchanged**: the gate is already registered; `test/manifestcheck.sh` passes.

## Implementation Notes

- The audit measured the live bypass: `^(a|aa)+b$` over a 34-byte non-matching line took 1.238 s under g++ 11.5/libstdc++ and grows ~2^n. Upstream's own gate INFO measured `(a|a)+b` past 30 s. Use their fixture discipline, not the audit sandbox's repro file.
- The structural-overlap rule (prefix / empty-match / class-intersection) is deliberately CONSERVATIVE in the refuse direction but bounded in the admit direction: it must not refuse `(a|b)+` — their safeCase control — and must not refuse bounded outers or unquantified groups. When in doubt, refuse with the honest message; a refusal is a safe failure, a hang is not (their own screen's stated philosophy).
- The budget constant is measured, not guessed, against their gate corpus with >=10x headroom; a clock check per K attempts is simpler and platform-independent than a visit counter.
- House style: Allman braces, spaces inside parens, no new headers without need; the degrade reuses the Exhausted disclosure channel — never a silent floor; `DISCLOSE`, never `VERIFY`, on an input-dependent path.
- **Anchor refresh — VERIFIED on the post-0.6.7 tree (2026-10-12).** The anchors written 2026-10-11 were
  train-25-era; `main` has since moved 588 commits past them (train 26c merged, 0.6.7 shipped, train 27 on
  top). Every anchor below was re-located by direct read of the tree at `main = 0e0f67c7`. **This table is
  the authority**; the prose above keeps the older numbers only where they are already marked historical.

  | Anchor as written | Verified location now | Status |
  | --- | --- | --- |
  | `regexguard.h:257` — `catastrophicRegexConstruct()` | `src/regexguard.h:257` | unchanged |
  | `regexguard.h:173` — "The known GAP is overlapping alternation" | `src/regexguard.h:173` | unchanged |
  | `regexguard.h:137–141` — "it never throws, so that catch is never reached and the process simply backtracks" | `src/regexguard.h:141` (the sentence); the M2 comment block spans 132–143 | unchanged |
  | `regexguard.h:1205` — `rw::faultSwitchOn` | **`src/regexguard.h:1212`** — the call site inside `throwIfMatchFaultInjected`; 1203–1209 is its comment block | **moved (+7)** |
  | `search.h:1217` — "the regex engine abandoned a match … the verb refuses the answer" | `src/search.h:1217` (the `RegexVerdict::Exhausted` guard) / `:1220` (the message) | unchanged |
  | `src/search.h ~L1090–1115` — "the try/catch region" | **gone** — those lines are now `grepWholeLine`. The line loop lives at `src/regexguard.h:1275` (`GuardedRegex::forEachLineMatch`), comment at `:1125` | relocated into the guard, as predicted |
  | `regexbombcheck:192` — the `(a\|b)+` "plain alt" `safeCase` | `test/regexbombcheck.sh:192` | unchanged |
  | the INFO gap line ("ran past 30 s — a KNOWN gap") | `test/regexbombcheck.sh:231` (the `printf`; its section header at `:222`, the second INFO at `:236`) | located |
  | `kRegexAbandonedReason` (Phase 2 reuses it) | `src/regexguard.h:419` | located |

- **Gate registration re-confirmed:** `regexbombcheck.sh` and `regexguardcheck.sh` are both listed in
  `test/regression.sh`, and `test/manifestcheck.sh` asserts exactly that (every top-level `*check.sh` is
  owned by `regression.sh`) — so AC7 needs no new registration, as the spec states.
- **Tree check:** `src/regexguard.h` is 1365 lines, `src/search.h` 2729, `test/regexbombcheck.sh` 241,
  `test/regexguardcheck.sh` 954. Line anchors this close to EOF are the ones that drift first; re-verify
  again if the spec is executed on a later train.

## Failure Modes

### False-positive refusal of a legitimate pattern
- **Trigger:** a user pattern with overlap-shaped alternation under an unbounded quantifier that would not backtrack catastrophically (e.g. `(get|getResponse)+`).
- **Expected handling:** refuse with the honest message — the screen **cannot PROVE the branches disjoint** (PM-1), with "make the OUTER bounded" as the actionable workaround; a refusal is a safe failure, a hang is not.
- **Validator check:** the refusal arm asserts the message names the construct AND states the honesty clause; the known false-positive class is listed in the commit message.

### Budget trips on a slow-but-legitimate match
- **Trigger:** a very large file matched by a cheap pattern on a slow machine.
- **Expected handling:** the degrade discloses the refusal (fail-closed: exit 1, no `hits=` — the file's partial hits are not a floor); the constant is chosen so the gate corpus never trips it — measured, >=10x headroom in the evidence bundle.

### A single crafted line is NOT bounded by the budget (the named residual — errata v2.0.3)
- **Trigger:** an ADMITTED multi-quantifier pattern (`a*a*a*a*a*b`, `^(a)*(a)*…$`, `^(ab\w|((.|.){1,3}){1,3}){1,3}$`) meeting a subject that HOLDS its required literal and then a long run before it — ONE line, ONE `std::regex` call.
- **Expected handling (as shipped):** on libc++ the engine's own complexity budget throws `Exhausted` and the run is bounded; on **libstdc++ the call does not return** — the guard's budget is checked *before* the engine is handed the line, so with one candidate line it never fires. This is the reachable unbounded-work path the round-1 verdict confirmed (`p6-negative-control.log`). It is **accepted as a named residual risk** pending the operator's Q9 decision, **NOT** claimed closed.
- **Validator check:** `p6-negative-control.log` (both toolchains) and `pbt-run.sh` leg 2; the completion report records it under Known Deviations, not under "bounded".

### Screen and budget across standard libraries
- **Trigger:** libc++ throws error_complexity where libstdc++ does not.
- **Expected handling:** for the AGGREGATE case (many candidate lines) both funnels produce the same disclosed-refusal outcome and alert shape. For the single-line case above they do **not**, and the spec says so rather than implying otherwise (errata v2.0.3).
- **Validator check:** `p6-negative-control.log` shows the divergence explicitly.

## Dependencies

None — root spec. **Precondition satisfied:** 26c reached `main` on 2026-10-11 and the tree has been
re-synced past it — train 27, 0.6.7 shipped, `main` = `0e0f67c7`. The anchors were re-verified on that tree
on 2026-10-12 (table under Implementation Notes): two moved, the rest held.

## Consumers

- **Spec:** security-regression-integration — needs the final refusal text and the budget degrade's exact shape for byte-precise assertions. **Constraints on evolution:** changing the message wording breaks its greps; version together.
- **Spec:** audit-validation-standalone — needs the evidence bundle at the declared path with the declared log header. **Constraints on evolution:** renaming `patternAdmission` or the evidence path breaks its manifest-closure check.

## Status

**Status:** in_progress
**Last updated:** 2026-10-13T20:40:00Z
**Updated by:** producer session — **round 2 complete; handoff back to validation.** The round-1 verdict (`validation/verdict.md`) returned `needs_revision`: six of seven ACs confirmed, AC5 refuted on its guarantee, the `matchBudgetDegrade` block stale in four ways, P6 not load-bearing, and the Phase-1 probe stale. Round 2 corrects the **claims** (errata v2.0.3, above), regenerates the probe under both toolchains, and makes P6 load-bearing on libstdc++ — **no `src/` or `test/` file changed, so `patches/round-1.patch` is unchanged.** The residual (a single crafted line is unbounded on libstdc++) is recorded as a **named, reachable** risk (Q8/Q9), not claimed closed; its scope decision is operator-gated. Status is deliberately NOT flipped to `approved`: per AGENTS.md §15 the producer does not self-validate — the next actor is the validator (`glm-5.3`, PM). v2.0.1 was an anchor/version-only revision; v2.0.2 was the Q7 errata (Phase 3 names both gates); **v2.0.3** is this verdict-driven errata.

## Validation Strategy

Tier 2 — property-based testing required (input validation/sanitization of a hostile-controllable pattern language; security-sensitive availability boundary).

- **Components requiring PBT:** `catastrophicRegexConstruct()` (admission, regexguard.h) and the guarded match loop's budget accounting.
- **Formal properties:**
  - ∀ pattern p: `refused(p)` => no match attempt occurs.
  - ∀ pattern p: `admitted(p)` => the screen made no false refusal of the honest corpus, and a run over a file whose **aggregate** exceeds the budget is disclosed-refused rather than hanging. *(Errata v2.0.3: the old property — "∀ p, ℓ: `admitted(p)` => `match(p, ℓ)` terminates within budget B" — is **FALSE**. A single `std::regex` call is unbounded to its caller and the round-1 verdict reproduced it; the property is restated at the level the mechanism actually guarantees.)*
  - Negative/positive pair: ∀ p ∈ bomb corpus => `refused(p)`; ∀ p ∈ honest corpus => `admitted(p)` ∧ results byte-identical to pre-change.
  - ∀ p: the verdict is deterministic across runs and platforms.
- **§H negative control:** every property must be shown capable of failing on the platform it is run on. For P6 that means the libstdc++ leg (`pbt-run.sh` leg 2) and the minimal reproducer `p6-negative-control.{cpp,sh}` — on libc++ alone P6 cannot fail, so a libc++-only P6 pass is not evidence.
- **Input domains:** random pattern generator over the ECMAScript subset the verb documents (groups, alternation, classes, quantifiers, anchors), seeded; plus the fixed bomb corpus: `(a|aa)+b$`, `(x|xy)+c$`, `(\w|\d)+$`, `(a|a*)+`, nested `((a|aa)+)+` — and the admit corpus incl. `(a|b)+`, `(abc)+`, `TODO|FIXME`, `(\s*\w+){1,20}`.
- **Case budget:** ≥10,000 generated patterns plus the fixed corpora; the PBT run under a **wall-clock cap** (the runner kills a non-returning run — that kill is the P6 control, not a flake).
- **Evidence bundle:** property-test source, seeds, platform, case counts, result logs, the §H controls, both-platform CI logs in `specs/regex-screen-hardening/evidence/`. PBT does not prove absolute security; it evidences the properties hold over the generated domain.

## Progress Tracking

- [x] Phase 1: extend catastrophicRegexConstruct (regexguard.h) to structural-overlap alternation + message arm
- [x] Phase 2: match-time budget in GuardedRegex (the file-level AGGREGATE backstop), disclosed fail-closed degrade on exceed
- [x] Phase 3: regexbombcheck arms (battery + budget via fault-switch) replace the INFO gap line; honest-pattern golden
- [x] Phase 4: PBT harness + evidence bundle — 3 seeds × 20,000 cases, 0 failures on libc++, plus a **libstdc++ leg**
      (`pbt-run.sh` leg 2) and the §H control `p6-negative-control.log`. `docs/`/`--help` wording NOT changed (the
      refusal text is a runtime message, not a help surface). The both-platform CI logs remain the named AC5 artifact
      and come from CI; the native g++-14 route (Q6 update #2) is what produces the local libstdc++ evidence.
- [x] Round 2 (errata v2.0.3, after the round-1 `needs_revision` verdict): corrected AC5, the `matchBudgetDegrade`
      block, AC1/AC2, the `patternAdmission` examples and the Failure Modes; regenerated the probe under both
      toolchains; made P6 load-bearing on libstdc++. **No `src/` or `test/` file changed — the round patch is unchanged.**
