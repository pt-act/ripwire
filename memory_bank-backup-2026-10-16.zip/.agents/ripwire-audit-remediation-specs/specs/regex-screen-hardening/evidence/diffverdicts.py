#!/usr/bin/env python3
"""Diff two `VERDICT<TAB>pattern` files and report every pattern whose verdict changed."""
import sys

old_path, new_path = sys.argv[1], sys.argv[2]


def load(path):
    table = {}
    raw = 0
    with open(path, "r", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            raw += 1
            line = line.rstrip("\n")
            if "\t" not in line:
                continue
            verdict, pattern = line.split("\t", 1)
            table[pattern] = verdict
    sys.stderr.write(f"{path}: {raw} raw lines, {len(table)} distinct patterns\n")
    return table


old, new = load(old_path), load(new_path)
shared = [p for p in old if p in new]
newly_refused = sorted(p for p in shared if old[p] == "ADMIT" and new[p] == "REFUSE")
newly_admitted = sorted(p for p in shared if old[p] == "REFUSE" and new[p] == "ADMIT")

print(f"distinct patterns compared : {len(shared)}")
print(f"newly REFUSED              : {len(newly_refused)}")
print(f"newly ADMITTED             : {len(newly_admitted)}   <- must be 0 (no refusal may be lost)")
print()
for pattern in newly_refused:
    print(f"  REFUSED  {pattern[:120]!r}")
if newly_admitted:
    print()
    for pattern in newly_admitted:
        print(f"  ADMITTED {pattern[:120]!r}")
