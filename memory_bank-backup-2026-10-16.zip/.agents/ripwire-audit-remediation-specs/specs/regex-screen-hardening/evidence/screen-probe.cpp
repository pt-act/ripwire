// screen-probe.cpp — the Phase 1 admission arm, run WITHOUT the full build.
//
// WHY THIS EXISTS. Gate-first discipline requires every new arm proven RED against the pre-change
// tree before any code moves. The full tree (≈1100 headers per TU) cannot be compiled on this
// machine right now — the volume is at 100% and the last attempt drove swap to 1.79 GiB of 3 GiB
// before being stopped at 69 objects (Q6 in the spec's open_questions). But the unit under change,
// catastrophicRegexConstruct()/screenRegexPattern(), is a PURE FUNCTION OF THE PATTERN STRING whose
// whole dependency cone is regexguard.h → {infra/emit.h, infra/stackthreads.h, infra/strkern.h} →
// {Diagnostics.h, os.h, shquote.h, os_win32_logic.h}. One TU, a dozen headers, seconds to build.
//
// WHAT THIS IS NOT. It is not a substitute for test/regexbombcheck.sh, which is the spec's declared
// verifier for AC1 and drives the real CLI end to end. This probe evidences the ADMISSION VERDICT
// only. The contractual arms still land in regexbombcheck.sh (Phase 3).
//
// Build (from the scratch tree root; build*/ is gitignored, so this never enters the round patch).
// It is a narrow TU with no standard-library-specific behaviour, so it builds and runs identically
// under BOTH toolchains — which is the point: round 1's "clang GREEN, gcc RED" was a STALE BINARY
// (built before PM-1 reworded the message), not a compiler-dependent screen. Always build fresh:
//   /usr/bin/clang++ -std=c++23 -O2 -march=x86-64-v3 -ffast-math -fno-finite-math-only -I src -o build-harness/screen-probe-clang build-harness/screen-probe.cpp
//   /usr/local/bin/g++-14 -std=c++23 -O2 -B/usr/bin -I src -o build-harness/screen-probe-gcc build-harness/screen-probe.cpp
//
// MESSAGE ASSERTIONS ARE PM-1-SCOPED. The 17 REFUSE rows assert the honesty clause the delivered
// header emits — "cannot PROVE are disjoint" (regexguard.h:641). The phrase "overlapping alternation"
// survives only in COMMENTS (:30, :177) and is never emitted, so asserting it is a stale-contract bug.
// The CLI gates pin the looser pair 'backtrack'/'bounded'; this probe pins the stronger clause. If a
// future errata rewords the message, re-run this probe (do not regenerate the log from a stale binary).
//
// House style follows the project (Allman braces, spaces inside parens) — scaffolding is still code.

#include "regexguard.h"

#include <cstdio>
#include <string>
#include <string_view>
#include <vector>

namespace
{

struct Arm
{
    const char* pattern;
    bool        wantRefused;
    const char* wantMessageContains; // "" = any refusal message is acceptable
    const char* why;
};

// The table IS the Phase 1 contract, transcribed from spec.md §Phase 1 and §Interfaces.
//   REFUSE — the structural-overlap alternation family (the spec's five) …
//   REFUSE — the existing catastrophic family, kept as REGRESSION GUARDS (any message)
//   ADMIT  — the precision controls; refusing any of these turns a gate red
const std::vector<Arm> kArms = {
    // ── Phase 1: the new structural-overlap family. These are the arms that must go GREEN ────────
    { "^(a|aa)+b$",        true,  "cannot PROVE are disjoint", "prefix overlap; the audit's live PoC" },
    { "^(ab|cd)+e$",       true,  "cannot PROVE are disjoint", "spec: conservative rule refuses it" },
    { "(a|a)+b",           true,  "cannot PROVE are disjoint", "identical branches (equal is a prefix)" },
    { "(x|xy)+c$",         true,  "cannot PROVE are disjoint", "prefix overlap" },
    { "(\\w|\\d)+$",       true,  "cannot PROVE are disjoint", "class intersection (\\d ⊂ \\w)" },

    // ── Phase 1 precision on the NEW rule: overlap-shaped but NOT under an unbounded outer ────────
    { "^(a|aa)$",          false, "", "overlapping branches, but no quantifier at all" },
    { "(a|aa)b",           false, "", "overlapping branches, unquantified group" },
    { "(get|getResponse){1,5}", false, "", "overlapping branches under a BOUNDED outer" },

    // ── Phase 1 edge cases of the new rule's own machinery ────────────────────────────────────────
    { "(?:a|b)+",          false, "", "non-capturing: disjoint single characters" },
    { "(?<n>a|b)+",        false, "", "NAMED group: the modifier must not swallow the body" },
    { "([0-9]|[a-z])+",    false, "", "disjoint class ranges" },
    { "(.)+",              false, "", "no alternation at all — the arm must not fire" },
    { "([a-c]|[b-d])+",    true,  "cannot PROVE are disjoint", "intersecting class ranges" },
    { "(.|a)+",            true,  "cannot PROVE are disjoint", "'.' intersects a literal" },
    { "(a|b|cd)+",         true,  "cannot PROVE are disjoint", "ONE multi-character branch is enough" },
    { "(cat|dog)+",        true,  "cannot PROVE are disjoint", "KNOWN FALSE POSITIVE — documented class" },
    { "(get|getResponse)+", true, "cannot PROVE are disjoint", "the spec's own accepted false positive" },
    { "(|a)+",             true,  "cannot PROVE are disjoint", "an EMPTY branch matches the empty string" },
    { "(a|)+",             true,  "cannot PROVE are disjoint", "same, the empty branch second" },
    { "(\\b|a)+",          true,  "cannot PROVE are disjoint", "zero-width branch: not a one-char atom" },
    { "(\\x41|a)+",        true,  "cannot PROVE are disjoint", "undecoded escape: refuse, do not guess" },
    { "([^a]|[ab])+",      true,  "cannot PROVE are disjoint", "negated class intersects a positive one" },

    // ── The existing catastrophic family — REGRESSION GUARDS. Refused today, must stay refused ───
    { "(a|a*)+",           true,  "", "empty-match alternative, caught by the existing arm" },
    { "((a|aa)+)+",        true,  "", "nested; existing arm fires on the inner '+' " },
    { "(a+)+",             true,  "", "the canonical bomb" },
    { "(a*)+",             true,  "", "unbounded inner" },
    { "(a?)+",             true,  "", "bounded inner, still ambiguous (M2-b)" },
    { "(a{1,3})+",         true,  "", "exact-count inner (M2-b)" },
    { "((ab|c){2})+d",     true,  "", "the fixed-count-inner bomb the header names" },
    { "(a+|b)+",           true,  "", "unbounded inner inside an alternation" },
    { "(?:a+)+b",          true,  "", "non-capturing group is still a group" },
    { "(a*|b*)+",          true,  "", "unbounded inner branches" },

    // ── The precision controls. Every one of these must stay ADMITTED ─────────────────────────────
    { "(a|b)+",            false, "", "spec's safeCase control — a real gate arm at regexbombcheck:192" },
    { "foo.*bar",          false, "", "no quantified group" },
    { "(abc)+",            false, "", "no quantifier inside the group" },
    { "TODO|FIXME",        false, "", "top-level alternation, no quantified group" },
    { "(\\s*\\w+){1,20}",  false, "", "the documented workaround shape — bounded outer" },
    { "(a)+b",             false, "", "no quantifier inside" },
    { "(a+)b",             false, "", "unquantified group over a quantified body" },
    { "(a?)b",             false, "", "same, bounded body" },
    { "(a+)(b)+",          false, "", "two independent quantified groups" },
    { "[a+]+",             false, "", "'+' inside a class is a literal" },
    { "(\\+)+",            false, "", "'\\+' is a literal plus" },
    { "(?:abc)+",          false, "", "'?' after '(' is a group MODIFIER, not a quantifier" },
    { "a|b",               false, "", "bare alternation" },
    { "(a|b)",             false, "", "unquantified disjoint group" },
    { "(a|b|c)+",          false, "", "three disjoint branches" },
    { "(\\d|[a-z])+",      false, "", "disjoint classes — must NOT be read as intersecting" },
    { "(abc|abd)+",        true,  "cannot PROVE are disjoint", "shared prefix, no shared first char class" },
    { "(a|[ab])+",         true,  "cannot PROVE are disjoint", "literal 'a' intersects the class [ab]" },
};

int g_pass = 0;
int g_fail = 0;

void report( const Arm& arm, bool refused, const std::string& message )
{
    const bool verdictOk = ( refused == arm.wantRefused );
    bool       messageOk = true;
    if( arm.wantRefused && arm.wantMessageContains[0] != '\0' )
    {
        messageOk = refused && message.find( arm.wantMessageContains ) != std::string::npos;
    }

    const char* want = arm.wantRefused ? "REFUSE" : "ADMIT ";
    if( verdictOk && messageOk )
    {
        ++g_pass;
        std::printf( "  PASS  %-5s %-24s  %s\n", want, arm.pattern, arm.why );
        return;
    }

    ++g_fail;
    const char* got = refused ? "REFUSE" : "ADMIT ";
    std::printf( "  FAIL  want %-5s got %-5s  %-24s  %s\n", want, got, arm.pattern, arm.why );
    if( !messageOk )
    {
        std::printf( "        message does not contain \"%s\"; got: %s\n", arm.wantMessageContains,
                     message.empty() ? "(no refusal message)" : message.c_str() );
    }
}

} // namespace

int main()
{
    std::printf( "screen-probe — regexguard.h admission verdicts (Phase 1 arm)\n" );
    std::printf( "source: %s\n\n", __FILE__ );

    for( const Arm& arm : kArms )
    {
        const std::optional<std::string> verdict = rw::screenRegexPattern( arm.pattern );
        const bool                       refused = verdict.has_value();

        // determinism: the verdict is a pure function of the pattern string (§Interfaces invariant)
        const std::optional<std::string> again    = rw::screenRegexPattern( arm.pattern );
        const bool                       unstable = ( refused != again.has_value() )
                                                    || ( refused && *verdict != *again );
        if( unstable )
        {
            ++g_fail;
            std::printf( "  FAIL  NON-DETERMINISTIC verdict for %s\n", arm.pattern );
            continue;
        }

        report( arm, refused, verdict.has_value() ? *verdict : std::string() );
    }

    std::printf( "\n%d passed, %d failed, %zu arms\n", g_pass, g_fail, kArms.size() );
    if( g_fail != 0 )
    {
        std::printf( "RESULT: RED (%d arm(s) not yet satisfied)\n", g_fail );
        return 1;
    }
    std::printf( "RESULT: GREEN\n" );
    return 0;
}
