// pbt-regex-screen.cpp — Phase 4 property-based test for the regex screen (spec `regex-screen-hardening`).
//
// NARROW TU, on purpose. It includes ONLY src/regexguard.h, whose dependency cone is ~12 headers (see README.md), so
// it compiles in seconds and exercises the REAL screenRegexPattern() / compileGuardedRegex() from the tree — not a
// re-implementation. The same device the Phase 1 gate-first proof used.
//
// Build (from the repo root, on a tree with the round applied):
//     clang++ -std=c++23 -O2 -I src -o /tmp/pbt evidence/pbt-regex-screen.cpp
// Run:
//     /tmp/pbt --cases=20000 --seed=20261012
//
// PROPERTIES (spec §Validation Strategy), each counted and reported:
//
//   P1 DETERMINISM   ∀ p: screenRegexPattern(p) is the same on every call, and independent of call order.
//   P2 BOMB⇒REFUSED  every pattern in the fixed bomb corpus is refused.
//   P3 HONEST⇒ADMIT  every pattern in the fixed admit corpus is admitted — (a|b)+, (abc)+, TODO|FIXME, (\s*\w+){1,20}.
//   P4 REFUSAL SAYS  ∀ refused p: the message is non-empty and names the construct ('backtrack').
//   P5 GENERATED     over `cases` generated patterns: determinism holds, and a refusal always names the construct.
//   P6 ADMITTED⇒MATCHES ∀ ADMITTED generated p: a pathological line is matched and the call RETURNS (the property
//                    Phase 1 exists to make true — an admitted pattern that hung here would be the bug). This is the
//                    one property that can only fail by the whole run timing out; the runner caps it.
//
// PBT does not prove absolute security; it evidences the screen's contract over the generated domain plus the fixed
// corpora. Failures are printed and never edited out of the log.

#include "regexguard.h"

#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <string_view>
#include <vector>

namespace
{
// ── a tiny seeded PRNG (xorshift64*), so a run is reproducible from --seed alone ────────────────────────────────
struct Rng
{
    std::uint64_t state;
    explicit Rng( std::uint64_t seed ) : state( seed ? seed : 0x9E3779B97F4A7C15ull ) {}

    std::uint64_t next()
    {
        std::uint64_t x = state;
        x ^= x >> 12;
        x ^= x << 25;
        x ^= x >> 27;
        state = x;
        return x * 0x2545F4914F6CDD1Dull;
    }
    std::uint32_t below( std::uint32_t n ) { return n == 0 ? 0 : std::uint32_t( next() % n ); }
};

// ── the ECMAScript-subset grammar the verb documents: literals, classes, groups, alternation, quantifiers, anchors ──
const char* kAtoms[]  = { "a", "b", "c", "x", "y", "z", "ab", "cd", "foo", "\\d", "\\w", "\\s", ".", "[a-z]", "[0-9]", "[^a]" };
const char* kQuants[] = { "*", "+", "?", "{2}", "{1,3}", "{2,}", "" };
const char* kAnchors[] = { "", "^", "$" };

std::string gen( Rng& rng, int depth );

std::string genBranch( Rng& rng, int depth )
{
    const std::uint32_t n = 1 + rng.below( 3 );
    std::string         out;
    for( std::uint32_t i = 0; i < n; ++i )
    {
        if( depth > 0 && rng.below( 4 ) == 0 )
        {
            out += gen( rng, depth - 1 );                 // a nested group as a branch atom
        }
        else
        {
            out += kAtoms[ rng.below( sizeof( kAtoms ) / sizeof( kAtoms[0] ) ) ];
        }
    }
    return out;
}

std::string gen( Rng& rng, int depth )
{
    std::string body;
    if( rng.below( 2 ) == 0 )
    {
        body = genBranch( rng, depth );                   // single branch
    }
    else
    {
        const std::uint32_t branches = 2 + rng.below( 2 );
        for( std::uint32_t i = 0; i < branches; ++i )
        {
            if( i != 0 )
            {
                body += "|";
            }
            body += genBranch( rng, depth );
        }
    }
    const char* q = kQuants[ rng.below( sizeof( kQuants ) / sizeof( kQuants[0] ) ) ];
    return std::string( "(" ) + body + ")" + q;
}

std::string genPattern( Rng& rng )
{
    std::string out = kAnchors[ rng.below( sizeof( kAnchors ) / sizeof( kAnchors[0] ) ) ];
    const std::uint32_t parts = 1 + rng.below( 3 );
    for( std::uint32_t i = 0; i < parts; ++i )
    {
        if( rng.below( 3 ) == 0 )
        {
            out += kAtoms[ rng.below( sizeof( kAtoms ) / sizeof( kAtoms[0] ) ) ];
        }
        else
        {
            out += gen( rng, 2 );
        }
    }
    out += kAnchors[ rng.below( sizeof( kAnchors ) / sizeof( kAnchors[0] ) ) ];
    return out;
}

// ── the fixed corpora ──────────────────────────────────────────────────────────────────────────────────────────
const char* kBomb[] = {
    "^(a|aa)+b$", "(a|a)+b", "(x|xy)+c$", "(\\w|\\d)+$", "(a|a*)+", "((a|aa)+)+", "^(ab|cd)+e$",
    "(a+)+b", "(a*)*b", "(a+)*b", "(a{2,})+b", "((a+))+b", "((a)+)+b", "(a+|b)+c", "(a?)+b", "(a{1,3})+b", "(?:a+)+b",
};
const char* kHonest[] = {
    "(a|b)+", "(abc)+", "TODO|FIXME", "(\\s*\\w+){1,20}", "foo.*bar", "a+b", "(a)+b", "[a+]+b", "(a+)b", "(a+)(b)+",
    "(?:abc)+", "(a?)b", "^#include", "\\bword\\b", "a{2,5}", "[0-9]{3}-[0-9]{4}", "(cat|dog)s?",
};

bool contains( const std::string& hay, const char* needle )
{
    return hay.find( needle ) != std::string::npos;
}

int  gFail  = 0;
void fail( const std::string& what )
{
    ++gFail;
    std::printf( "  FAIL  %s\n", what.c_str() );
}

} // namespace

int main( int argc, char** argv )
{
    std::uint64_t cases = 20000;
    std::uint64_t seed  = 20261012;
    for( int i = 1; i < argc; ++i )
    {
        if( std::strncmp( argv[i], "--cases=", 8 ) == 0 )
        {
            cases = std::strtoull( argv[i] + 8, nullptr, 10 );
        }
        else if( std::strncmp( argv[i], "--seed=", 7 ) == 0 )
        {
            seed = std::strtoull( argv[i] + 7, nullptr, 0 );   // base 0: honour seeds.txt's 0x… entries verbatim
        }
    }

    std::printf( "pbt-regex-screen: cases=%llu seed=%llu\n", (unsigned long long) cases, (unsigned long long) seed );

    // P2 — bomb corpus ⇒ refused
    std::uint32_t bombOk = 0;
    for( const char* p : kBomb )
    {
        const std::optional<std::string> v = rw::screenRegexPattern( p );
        if( !v.has_value() )
        {
            fail( std::string( "P2 bomb NOT refused: " ) + p );
        }
        else
        {
            ++bombOk;
        }
    }
    std::printf( "P2 bomb->refused:      %u/%u\n", bombOk, (unsigned) ( sizeof( kBomb ) / sizeof( kBomb[0] ) ) );

    // P3 — honest corpus ⇒ admitted
    std::uint32_t honestOk = 0;
    for( const char* p : kHonest )
    {
        const std::optional<std::string> v = rw::screenRegexPattern( p );
        if( v.has_value() )
        {
            fail( std::string( "P3 honest pattern REFUSED: " ) + p + " -> " + *v );
        }
        else
        {
            ++honestOk;
        }
    }
    std::printf( "P3 honest->admitted:   %u/%u\n", honestOk, (unsigned) ( sizeof( kHonest ) / sizeof( kHonest[0] ) ) );

    // P4 — a refusal always names the construct
    std::uint32_t refusalNamed = 0;
    for( const char* p : kBomb )
    {
        const std::optional<std::string> v = rw::screenRegexPattern( p );
        if( v.has_value() && !v->empty() && contains( *v, "backtrack" ) )
        {
            ++refusalNamed;
        }
        else
        {
            fail( std::string( "P4 refusal does not name the construct: " ) + p );
        }
    }
    std::printf( "P4 refusal names the construct: %u/%u\n", refusalNamed, (unsigned) ( sizeof( kBomb ) / sizeof( kBomb[0] ) ) );

    // P1/P5/P6 — generated patterns
    Rng           rng( seed );
    std::uint32_t detOk = 0, genRefused = 0, genAdmitted = 0, admitTerminated = 0;
    const std::string pathological = std::string( 200, 'a' ) + "\n" + std::string( 200, 'a' ) + "z\n";

    for( std::uint64_t i = 0; i < cases; ++i )
    {
        const std::string pat = genPattern( rng );

        // P1 determinism: same verdict twice, and a copy gives the same answer
        const std::optional<std::string> a = rw::screenRegexPattern( pat );
        const std::optional<std::string> b = rw::screenRegexPattern( std::string( pat ) );
        if( a.has_value() != b.has_value() || ( a.has_value() && *a != *b ) )
        {
            fail( "P1 non-deterministic verdict: " + pat );
        }
        else
        {
            ++detOk;
        }

        if( a.has_value() )
        {
            ++genRefused;
            // P5: a refusal names the construct
            if( a->empty() || !contains( *a, "backtrack" ) )
            {
                fail( "P5 refusal does not name the construct: " + pat );
            }
        }
        else
        {
            ++genAdmitted;
            // P6: an ADMITTED pattern must match a pathological line and RETURN. compileGuardedRegex admits it (the
            // screen is the admission gate); forEachLineMatch then runs under the guard's budget. NOTE (round 2):
            // P6 is load-bearing ONLY on libstdc++. On libc++ the engine's own complexity budget throws before any
            // hang, so this call always returns and P6 cannot fail there — a libc++-only P6 pass proves nothing. On
            // libstdc++ the run is killed at this call (see pbt-run.sh leg 2 and p6-negative-control.log): that kill
            // is the §H negative control, and it is the Q8/Q9 residual made visible rather than asserted away.
            const rw::RegexCompile rc = rw::compileGuardedRegex( pat, rw::kRegexEcmaScript );
            if( rc.refusal )
            {
                fail( "P6 admitted by the screen but refused by compile: " + pat + " -> " + *rc.refusal );
                continue;
            }
            const rw::RegexLineScan scan = rc.regex.forEachLineMatch( pathological, rw::RegexLinePolicy{},
                []( std::uint32_t, std::size_t ) { return true; } );
            (void) scan;
            ++admitTerminated;
        }
    }

    std::printf( "P1 determinism:        %llu/%llu\n", (unsigned long long) detOk, (unsigned long long) cases );
    std::printf( "P5 generated refused:  %u  admitted: %u\n", genRefused, genAdmitted );
    std::printf( "P6 admitted terminated: %u/%u\n", admitTerminated, genAdmitted );

    // OBSERVATION (not a property, reported so it is not silently lost): the screen's Phase 1 arm targets a GROUP
    // with a top-level '|'. The multi-quantifier family has at least three members it cannot see, all ADMITTED:
    //   (i)   group-FREE flat     a*a*a*a*a*b                        — no group to inspect;
    //   (ii)  grouped, no '|'     ^(a)*(a)*(a)*(a)*(a)*$             — no top-level '|' to inspect;
    //   (iii) bounded-nested      ^(ab\w|((.|.){1,3}){1,3}){1,3}$    — (.|.) IS an overlapping alternation, but its
    //                                                                 outer {1,3} is BOUNDED, so the unbounded-outer
    //                                                                 rule never fires.
    // On libstdc++ (no engine complexity budget) the failing path backtracks inside ONE line and the guard's
    // per-file budget cannot bound it — the budget is checked BEFORE the engine is handed the line. CONFIRMED, not
    // hypothetical: p6-negative-control.log shows ^(a)*(a)*…$ returning on libc++ (Exhausted) and hanging on
    // libstdc++ at k>=5 with budgeted=0. Recorded as a NAMED reachable residual risk (open_questions Q8/Q9), NOT as
    // a bounded residual, and carried by a follow-on spec — not fixed here.
    {
        const char* family[] = { "a*a*a*a*a*b", "^(a)*(a)*(a)*(a)*(a)*$", "^(ab\\w|((.|.){1,3}){1,3}){1,3}$" };
        for( const char* p : family )
        {
            const std::optional<std::string> v = rw::screenRegexPattern( p );
            std::printf( "OBSERVATION multi-quantifier family %-32s %s\n", p,
                         v.has_value() ? "REFUSED" : "ADMITTED (NOT bounded by the budget — see Q8/Q9)" );
        }
    }

    std::printf( "cases=%llu seed=%llu result=%s\n", (unsigned long long) cases, (unsigned long long) seed, gFail == 0 ? "pass" : "fail" );
    return gFail == 0 ? 0 : 1;
}
