#!/usr/bin/env bash
# p6-negative-control.sh — build p6-negative-control.cpp under BOTH toolchains and time the family
# under a wall-clock cap. Writes p6-negative-control.log beside it.
#
# This is the §H negative control the round-1 bundle lacked. P6 was run on libc++ only, where the
# engine's own complexity budget makes it unfalsifiable (the call returns before any hang, so the
# property cannot fail). On libstdc++ the same admitted family does not return. The cap is enforced
# with the project's own background+poll+kill idiom — macOS has no coreutils `timeout`.
#
# Usage:  bash evidence/p6-negative-control.sh [REPO_ROOT]
# Env:    CAP_TENTHS (default 200 = a 20 s cap per invocation), CLANG, GXX
set -u
HERE="$( cd "$( dirname "$0" )" && pwd )"
ROOT="${1:-$( cd "$HERE/../../../../.." && pwd )}"
LOG="$HERE/p6-negative-control.log"
CAP_TENTHS="${CAP_TENTHS:-200}"                       # 200 x 0.1s = 20 s
CLANG="${CLANG:-/usr/bin/clang++}"
GXX="${GXX:-/usr/local/bin/g++-14}"
TMP="$( mktemp -d )"; trap 'rm -rf "$TMP"' EXIT

run_capped() {                                        # $1 = binary; $2.. = args
    local bin="$1"; shift
    "$bin" "$@" &
    local pid=$! waited=0
    while kill -0 "$pid" 2>/dev/null; do
        if [ "$waited" -ge "$CAP_TENTHS" ]; then
            kill -9 "$pid" 2>/dev/null; wait "$pid" 2>/dev/null
            printf '  KILLED after %ss cap (did not return)\n' "$(( CAP_TENTHS / 10 ))"
            return 124
        fi
        sleep 0.1; waited=$(( waited + 1 ))
    done
    wait "$pid"; return $?
}

{
    echo "# p6-negative-control.log — the §H negative control for P6 (an ADMITTED pattern must RETURN)."
    echo "# tree:      $ROOT"
    echo "# captured:  $(date -u +%Y-%m-%dT%H:%M:%SZ)"
    echo "# family:    ^(a)*(a)*...(a)*\$   (k quantified groups; ADMITTED — no '|' for Phase 1 to see)"
    echo "# subject:   the PBT's own pathological line (N 'a', newline, N 'a', 'z', newline; N=200 = 403 bytes)"
    echo "# cap:       $(( CAP_TENTHS / 10 ))s per invocation, the project's background+poll+kill idiom"
    echo "#"
    echo "# EXPECTED, and this is the whole point: libc++ returns for every k because its ENGINE throws"
    echo "# error_complexity; libstdc++ has no such engine budget, and the guard's per-file budget is"
    echo "# checked BEFORE the engine is handed the line, so a single line is unbounded work it cannot see."
    echo

    echo "################################################################################"
    echo "## 1. clang++ / libc++  (the tree's default toolchain)"
    echo "################################################################################"
    if "$CLANG" -std=c++23 -O2 -march=x86-64-v3 -I "$ROOT/src" -o "$TMP/ctl-clang" "$HERE/p6-negative-control.cpp" 2>"$TMP/clang.err"; then
        for k in 2 3 4 5 6; do
            printf -- "--- k=%s\n" "$k"
            run_capped "$TMP/ctl-clang" --k="$k" --n=200 || true
        done
    else
        echo "COMPILE FAILED"; cat "$TMP/clang.err"
    fi
    echo

    echo "################################################################################"
    echo "## 2. g++-14 / libstdc++  (Homebrew GCC; -B/usr/bin so it uses Apple's linker)"
    echo "################################################################################"
    if command -v "$GXX" >/dev/null 2>&1; then
        if "$GXX" -std=c++23 -O2 -B/usr/bin -I "$ROOT/src" -o "$TMP/ctl-gcc" "$HERE/p6-negative-control.cpp" 2>"$TMP/gcc.err"; then
            for k in 2 3 4 5 6; do
                printf -- "--- k=%s\n" "$k"
                run_capped "$TMP/ctl-gcc" --k="$k" --n=200 || true
            done
        else
            echo "COMPILE FAILED"; cat "$TMP/gcc.err"
        fi
    else
        echo "  SKIP   no $GXX — the libstdc++ leg is the whole point of this control; install g++-14"
    fi
    echo

    echo "## Reading"
    echo "# On libc++ every k returns (the engine's complexity budget fires: verdict=2 Exhausted, budgeted=0)."
    echo "# On libstdc++ the cost grows polynomially in the line length with degree ~ (quantified groups - 1),"
    echo "# so k>=5 does not return inside the cap. This is the reachable unbounded-work path AC5's heading"
    echo "# claimed did not exist; it is recorded as a named residual risk (Q8/Q9) and carried by a follow-on spec."
} 2>&1 | tee "$LOG"

echo "log written to $LOG"
