#!/usr/bin/env bash
# pbt-run.sh — build and run the Phase 4 property test for `regex-screen-hardening`, writing the raw log beside it.
#
# The property test itself is pbt-regex-screen.cpp (a NARROW TU: it includes only src/regexguard.h, whose dependency
# cone is ~12 headers, so it compiles in seconds and exercises the REAL screen — see README.md). This runner adds the
# one property the C++ file cannot state: every ADMITTED pattern must also terminate at the CLI, under a wall-clock
# cap, on the built binary.
#
# It runs TWO legs, because P6 is only meaningful on the library where it CAN fail:
#   leg 1 — libc++ (clang++, the tree's default): every seed at --cases=20000.
#   leg 2 — libstdc++ (g++-14): the screen properties at --cases=200 (they hold there too), then the full run under
#           a wall-clock cap, where P6 does NOT hold and the run is killed. That kill IS the §H negative control;
#           the minimal reproducer is p6-negative-control.{cpp,sh} -> p6-negative-control.log.
# Round 1 ran libc++ only, where the engine's own complexity budget makes P6 unfalsifiable (the call returns before
# any hang, so the property cannot fail). Do NOT cite a libc++-only P6 pass as boundedness evidence.
#
# Usage:
#     bash evidence/pbt-run.sh [REPO_ROOT] [RIPWIRE_BIN]
#   REPO_ROOT    defaults to the tree four directories up (the repo the spec lives in)
#   RIPWIRE_BIN  defaults to $REPO_ROOT/build/ripwire; the CLI property is SKIPPED (and said so) if it is missing
#
# Seeds: the fixed list in seeds.txt. Determinism is a property (P1), so a seed list is a record of what was run,
# not a source of variation to hide behind.
set -u
HERE="$( cd "$( dirname "$0" )" && pwd )"
ROOT="${1:-$( cd "$HERE/../../../../.." && pwd )}"
BIN="${2:-$ROOT/build/ripwire}"
CXX="${CXX:-clang++}"
GXX="${GXX:-/usr/local/bin/g++-14}"
CAP_TENTHS="${CAP_TENTHS:-600}"          # 600 x 0.1s = a 60 s cap for the libstdc++ full run
LOG="$HERE/pbt-regex-screen.log"
TMP="$( mktemp -d )"; trap 'rm -rf "$TMP"' EXIT

run_capped() {                            # $1 = binary; $2.. = args
    local bin="$1"; shift
    "$bin" "$@" &
    local pid=$! waited=0
    while kill -0 "$pid" 2>/dev/null; do
        if [ "$waited" -ge "$CAP_TENTHS" ]; then
            kill -9 "$pid" 2>/dev/null; wait "$pid" 2>/dev/null
            printf '  KILLED after %ss cap (P6 does NOT hold on this library)\n' "$(( CAP_TENTHS / 10 ))"
            return 124
        fi
        sleep 0.1; waited=$(( waited + 1 ))
    done
    wait "$pid"; return $?
}

{
    echo "# pbt-regex-screen.log — raw pass/fail log, written by pbt-run.sh. Failures are never edited out."
    echo "# tree:     $ROOT"
    echo "# compiler: $($CXX --version 2>/dev/null | head -1)"
    echo "# platform: $(uname -sm)  $( ( command -v otool >/dev/null && otool -L "$BIN" 2>/dev/null | grep -qi libc++ && echo libc++ ) || echo 'libstdc++/unknown' )"
    echo

    echo "## leg 1 — screen properties (narrow TU) — libc++ / $CXX"
    if ! "$CXX" -std=c++23 -O2 -I "$ROOT/src" -o "$TMP/pbt" "$HERE/pbt-regex-screen.cpp" 2>"$TMP/build.err"; then
        echo "COMPILE FAILED"; cat "$TMP/build.err"; exit 2
    fi
    while read -r seed; do
        [ -z "$seed" ] && continue
        case "$seed" in \#*) continue;; esac
        "$TMP/pbt" --cases=20000 --seed="$seed" || true
    done <"$HERE/seeds.txt"
    echo

    echo "## leg 2 — screen properties — libstdc++ / $GXX   (§H negative control for P6)"
    echo "# P6 is load-bearing only where it CAN fail. libc++'s engine throws error_complexity before any hang,"
    echo "# so a libc++-only P6 pass proves nothing. On libstdc++ the same admitted family does not return."
    if command -v "$GXX" >/dev/null 2>&1; then
        if "$GXX" -std=c++23 -O2 -B/usr/bin -I "$ROOT/src" -o "$TMP/pbt-gcc" "$HERE/pbt-regex-screen.cpp" 2>"$TMP/build-gcc.err"; then
            echo "# --cases=200 (completes; the screen properties P1-P5 hold on libstdc++ as well):"
            "$TMP/pbt-gcc" --cases=200 --seed=20261012 || true
            echo "# --cases=20000 under a $(( CAP_TENTHS / 10 ))s cap (P6 does NOT hold — this kill is the control):"
            run_capped "$TMP/pbt-gcc" --cases=20000 --seed=20261012 || true
            echo "# Minimal reproducer: p6-negative-control.{cpp,sh} -> p6-negative-control.log"
        else
            echo "COMPILE FAILED"; cat "$TMP/build-gcc.err"
        fi
    else
        echo "  SKIP   no $GXX — the libstdc++ leg is the §H control; install g++-14 (Homebrew)"
    fi
    echo

    echo "## CLI property: every admitted corpus pattern terminates under a 1 s cap"
    if [ -x "$BIN" ]; then
        mkdir -p "$TMP/fix"; { printf '# bait\n'; head -c 200 /dev/zero | tr '\0' 'a'; printf 'z\n'; } >"$TMP/fix/bait.md"
        for pat in '(a|b)+' '(abc)+' 'foo.*bar' '(\s*\w+){1,20}' '(a)+b' '[a+]+b' '(?:abc)+' '(a?)b'; do
            "$BIN" "$TMP/fix" --regex="$pat" --no-cache >/dev/null 2>&1 &
            pid=$!; waited=0
            while kill -0 "$pid" 2>/dev/null; do
                [ "$waited" -ge 10 ] && { kill -9 "$pid" 2>/dev/null; wait "$pid" 2>/dev/null; echo "  HANG   $pat (killed after 10x0.1s cap)"; continue 2; }
                sleep 0.1; waited=$(( waited + 1 ))
            done
            wait "$pid"; echo "  ok     $pat (exit $?)"
        done
    else
        echo "  SKIP   no binary at $BIN — build first (cmake --build build -j)"
    fi
} 2>&1 | tee "$LOG"

echo "log written to $LOG"
