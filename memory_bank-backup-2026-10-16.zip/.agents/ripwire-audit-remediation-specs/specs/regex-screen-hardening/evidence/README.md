# regex-screen-hardening — evidence bundle

Produced by the producer session, base commit `0e0f67c7` (train 27, 0.6.7 shipped), against the round patch
`patches/round-1.patch`. **This is the Phase 1–4 bundle, revised at round 2** — after the round-1 `needs_revision`
verdict: the admission probe was stale (built before PM-1 reworded the message), P6 was not load-bearing on the
library where it can fail, and the AC5 claim overstated what the budget bounds. All three are corrected here; the
**code is unchanged** (no `src/` or `test/` file differs from `patches/round-1.patch`). One thing the spec asks for
is still missing and is said so below: the **both-platform CI logs** — but note that BOTH toolchains ARE available
natively, so the libstdc++ *behaviour* is evidenced directly (that is how the AC5 defect was found and confirmed).

## The narrow-TU device (why most of this is cheap and reproducible)

The unit under change, `catastrophicRegexConstruct()` / `screenRegexPattern()`, is a pure function of the pattern
string. Its whole dependency cone is `regexguard.h` → {`infra/emit.h`, `infra/stackthreads.h`, `infra/strkern.h`} →
{`Diagnostics.h`, `os.h`, `shquote.h`, `os_win32_logic.h`} — about a dozen headers, not the ~1100 a full translation
unit pays. A single-TU harness therefore exercises the **real function from the real tree** in ~8 s / ~132 MB peak
RSS, instead of ~1.2 GiB. That device is what made gate-first possible at all (Q6), and it is what the PBT uses too.

It is **not** a substitute for `test/regexbombcheck.sh` and `test/regexguardcheck.sh`, which the spec names as the
AC1/AC3 verifiers and which drive the real CLI end to end. The contractual arms land there (Phase 3).

## Files

| File | What it is |
| --- | --- |
| `screen-probe.cpp` | The Phase 1 admission arm. 50 pattern → expected-verdict rows, plus a determinism re-check per row. Exit 0 = GREEN. |
| `screen-scan.cpp` | Reads patterns from stdin, prints `VERDICT<TAB>pattern`. Paired with a pre-change copy of `regexguard.h` it produces the before/after diff. |
| `harvest.py` | Over-inclusive harvester: every quoted literal 1..2048 bytes containing a regex metacharacter, plus structured `--regex=` / `#match?` / `file()` / `--arch` forms. |
| `diffverdicts.py` | Reports every pattern whose verdict changed between two verdict tables. |
| `probe-green.txt` | The arm against the delivered implementation: **50 passed, 0 failed, GREEN under BOTH toolchains** (clang/libc++ and g++-14/libstdc++). **Regenerated at round 2** — the round-1 copy was built before PM-1 reworded the message and asserted the pre-PM-1 phrase, so a fresh build went RED 33/50 (message-only; all 50 verdicts correct). |
| `corpus-sweep.txt` | The before/after sweep over the tree's own literals: 99,845 distinct patterns, **33 newly refused, 0 newly admitted**. |
| `pbt-regex-screen.cpp` | **Phase 4** property test (narrow TU, real screen): P1 determinism, P2 bomb⇒refused, P3 honest⇒admit, P4 refusal names the construct, P5 generated, P6 admitted⇒terminates on a pathological line. Its `OBSERVATION` lines name the three ADMITTED multi-quantifier family members the Phase-1 rule cannot see. |
| `pbt-run.sh` | Builds and runs the PBT under **both toolchains** — leg 1 libc++ (every seed at 20,000), leg 2 libstdc++ (200 cases, then the full run under a wall-clock cap, where it is killed) — then runs the admitted corpus through the real binary. Writes `pbt-regex-screen.log`. |
| `seeds.txt` | The fixed seed list (a record, not a knob — determinism is itself a property). |
| `pbt-regex-screen.log` | The raw pass/fail log — **two legs**: libc++ 3 seeds × 20,000, all pass; libstdc++ 200 cases pass, then the full run **KILLED** under the cap (that kill is the P6 control). |
| `p6-negative-control.cpp` / `.sh` | **Round 2, the §H negative control for P6.** Times the alternation-free multi-quantifier family `^(a)*(a)*…$` on the PBT's own 403-byte pathological subject, under both toolchains, with a shell cap. |
| `p6-negative-control.log` | Its raw log: libc++ returns at every k (verdict=2 Exhausted, ~43 ms); libstdc++ grows polynomially (k=4 ≈ 2.3 s) and **hangs at k>=5**, `budgeted=0` throughout. This is the reachable unbounded-work path, reproduced. |
| `gate-baseline-regexbombcheck.txt` | The Phase-1 baseline run of `regexbombcheck.sh` — the **gate-first RED** evidence (see below). |
| `gate-baseline-regexguardcheck.txt` | The Phase-1 baseline run of `regexguardcheck.sh`. |
| `gate-final-regexbombcheck.txt` | The **final GREEN** run of `regexbombcheck.sh` against the Phase-1+2 binary: **99 PASS, 0 FAIL**, exit 0. Carries a provenance header (binary sha256, src-diff sha256, tree HEAD). |
| `gate-final-regexguardcheck.txt` | The **final GREEN** run of `regexguardcheck.sh` against the same binary: **135 PASS, 0 FAIL**, exit 0. Same provenance header. |
| `ac1-alternation-refusal.txt` | AC1's exact fixture (one file, a 200-byte all-`a` first line): all five battery patterns exit 1 in 2.2–4.3 s, no `hits=`, 'backtrack' present, and the PM-1 honesty clause present. |
| `determinism-ritual.txt` | AC6 — the AGENTS.md ritual in three modes (no regex / regex in the mix / a refused pattern), each run twice: stdout **and** stderr byte-identical. |
| `manifestcheck.txt` | AC7 — `test/manifestcheck.sh`, exit 0, ALL PASS (gate registration + the 683-gate count agreement + both mutation controls). |
| `pargates-partial.txt` | The record of the two partial `pargates.py` runs, the classification of every failure they reported, and the clean sequential re-run that cleared them. Read this before believing a `pargates` red from this environment. |

## Final state: both gates GREEN

The artifact this bundle ships is the **patch**, not any binary: apply `patches/round-1.patch` to a tree at
`0e0f67c7`, build it, and both gates pass. The producer's scratch binary (sha256 `f6b861cc…`) is a *claim*; the
validator independently reproduced both gates green **from the patch** in its own verify tree, so the result below
is not a scratch-tree artifact.

```bash
cd <tree at 0e0f67c7> && git apply <this dir>/../patches/round-1.patch
cmake -S . -B build && cmake --build build -j6
RIPWIRE_BIN=build/ripwire bash test/regexbombcheck.sh    # expect: ALL PASS, exit 0
RIPWIRE_BIN=build/ripwire bash test/regexguardcheck.sh   # expect: ALL PASS, exit 0
```

| Gate | Result | Rows |
| --- | --- | --- |
| `test/regexbombcheck.sh` | **exit 0 — ALL PASS** | 99 PASS / 0 FAIL (incl. the 5-row PM-1 honesty battery and the 6-row budget block) |
| `test/regexguardcheck.sh` | **exit 0 — ALL PASS** | 135 PASS / 0 FAIL (incl. the re-scoped (b2) and the re-scoped (i) three legs) |

The producer's own logs (`gate-final-*.txt`) carry a provenance header with the binary hash, the src-diff hash and
the tree HEAD. They are the *producer's* run; the reproduction command above is what makes the claim checkable.

One `INFO` row is expected and is not a failure: `(l)` reports that this engine discloses no `regex_line_max=` (an
engine with no per-byte recursion has no finite line bound), so there is no bound for that arm to test.

## Gate-first: RED before GREEN

`test/regexbombcheck.sh` and `test/regexguardcheck.sh` were run against a **Phase-1-only** binary (`0e0f67c7` +
`round-1.patch`, built in the scratch tree) **before** Phase 2 was applied. `gate-baseline-regexbombcheck.txt` records
the result: **9 failures** —

- **5** are the new PM-1 honesty assertion (`refusal does not state the screen cannot PROVE disjointness`) on every
  alternation row — the Phase-1 message still asserts the branches "can match the same text", which is false for the
  multi-character class. PM-1 is therefore load-bearing, not cosmetic.
- **4** are the whole budget block — exit 0, `hits=` printed, no budget reason. Phase 2 is genuinely new.

`gate-baseline-regexguardcheck.txt` records the other half: **(b2) is green** against the baseline (the re-scoped arm
asserts the static closure Phase 1 delivers) and only the three **(i)** legs fail — because the arm itself caught a
fixture bug (`printf '...\1...'` lets the shell turn `\1` into an octal escape; the fix is `printf '%s\n'`, the way
arm (e) writes its fixtures).

## Reproduce

```bash
cd <scratch tree>                     # git worktree at 0e0f67c7, round-1.patch applied
mkdir -p build-harness
cp <this dir>/screen-probe.cpp <this dir>/screen-scan.cpp <this dir>/harvest.py <this dir>/diffverdicts.py build-harness/

# the arm, against the working tree — build BOTH toolchains; they must agree
/usr/bin/clang++ -std=c++23 -O2 -march=x86-64-v3 -ffast-math -fno-finite-math-only -I src -o build-harness/screen-probe-clang build-harness/screen-probe.cpp
/usr/local/bin/g++-14 -std=c++23 -O2 -B/usr/bin -I src -o build-harness/screen-probe-gcc build-harness/screen-probe.cpp
./build-harness/screen-probe-clang                # expect: 50 passed, 0 failed, RESULT: GREEN
./build-harness/screen-probe-gcc                  # expect: 50 passed, 0 failed, RESULT: GREEN

# the sweep: build the SAME scanner twice, once against the pre-change header
mkdir -p build-harness/oldinc
git show 0e0f67c7:src/regexguard.h > build-harness/oldinc/regexguard.h
ln -sfn ../../src/infra build-harness/oldinc/infra
/usr/bin/clang++ -std=c++23 -O0 -I build-harness/oldinc -o build-harness/scan-old build-harness/screen-scan.cpp
/usr/bin/clang++ -std=c++23 -O0 -I src               -o build-harness/scan-new build-harness/screen-scan.cpp
/usr/local/bin/python3 build-harness/harvest.py . > build-harness/corpus.txt
./build-harness/scan-old < build-harness/corpus.txt > build-harness/verdicts-old.txt
./build-harness/scan-new < build-harness/corpus.txt > build-harness/verdicts-new.txt
/usr/local/bin/python3 build-harness/diffverdicts.py build-harness/verdicts-old.txt build-harness/verdicts-new.txt

# the Phase 4 property test — both toolchain legs (needs only src/, ~8 s per build)
bash <this dir>/pbt-run.sh <repo root> <scratch tree>/build/ripwire

# the §H negative control for P6 — both toolchains, under a shell cap
bash <this dir>/p6-negative-control.sh <repo root>   # expect: libc++ returns at every k; libstdc++ KILLED at k>=5
```

`build-harness/` is ignored by the tree's own `.gitignore` (`build*/`, line 2), so nothing here enters the round patch.

## Result of the sweep

99,845 distinct literals harvested. **118 → 151 refusals: 33 newly refused, 0 newly admitted** — no refusal was lost.

Of the 33, every one falls into one of two groups:

1. **The intended fix** — `(a|a)+b`, `(a|a)+z` and the `--regex=` / `--arch` / `#match?` / `file()` / `--graph-query`
   fixture text around them, plus the `INFO` lines in `regexbombcheck.sh` that Phase 3 replaces, plus the `--regex`
   refusal hint text in `verbs_grep.h`.
2. **The documented false-positive class** — nine shapes of the form `X | [^X]…`, e.g. `"(?:[^"\\]|\\.)*"`,
   `[^{}]|\{\}`, `File:\s*'((?:[^']|'')*)'…`. Their branches are provably **disjoint** (`[^"\\]` excludes the
   backslash that `\\.` requires), so they cannot backtrack; they are refused because `ab|cd` and `cat|dog` are the
   same SHAPE as the spec's own refused `^(ab|cd)+e$`. **Every one of these lives in a test script as a Python
   `re.compile` pattern** (`test/fixedbufsweep.sh:314`, `test/compactlegendcheck.sh:2464-2465,2548`, …) or in prose —
   none is passed to ripwire's `--regex`, `--match`, `--arch` or `--graph-query`. **No behavioural regression in this
   tree.**

## Phase 4 — the property test, at full scale

`pbt-regex-screen.log` is the raw log. It now runs **two legs**.

**Leg 1 — libc++ (clang++), 3 seeds (`seeds.txt`) × 20,000 generated patterns = 60,000 cases**, plus the two fixed
corpora, plus the CLI property. Zero failures.

| Property | Result (libc++) |
| --- | --- |
| P1 determinism | **20000/20000** on each of the three seeds |
| P2 bomb ⇒ refused | **17/17** (the fixed bomb corpus, incl. `^(a|aa)+b$`, `(a\|a*)+`, `((a\|aa)+)+`) |
| P3 honest ⇒ admitted | **17/17** (`(a\|b)+`, `(abc)+`, `TODO\|FIXME`, `(\s*\w+){1,20}`, …) |
| P4 refusal names the construct | **17/17** |
| P5 generated patterns | 10118/9882, 9976/10024, 10093/9907 refused/admitted — no refusal lacked the construct |
| P6 admitted ⇒ terminates | **every admitted pattern returned** (9882, 10024, 9907) |
| CLI property | all 8 admitted corpus patterns exit 0 under a 1 s wall-clock cap |

**Leg 2 — libstdc++ (g++-14): P6 is FALSE here, and that is the point.** At `--cases=200` the run completes and
P1–P5 hold on libstdc++ too; at the full `--cases=20000` the run is **KILLED under the 60 s cap**, because an
ADMITTED multi-quantifier pattern does not return. **Round 1 ran libc++ only**, where the engine's own complexity
budget throws `error_complexity` before any hang — so P6 could not fail there and its pass was not evidence for the
property it names (§H requires a negative control; round 1 had none). The control is now the leg itself plus the
minimal reproducer:

`p6-negative-control.log` — `^(a)*(a)*…(a)*$` (k quantified groups, ADMITTED) on the PBT's own 403-byte subject:

| k | libc++ | libstdc++ |
| --- | --- | --- |
| 2 | verdict=1, 6.7 ms | verdict=1, 0.8 ms |
| 3 | verdict=2 (Exhausted), 41.7 ms | verdict=1, 44.8 ms |
| 4 | verdict=2 (Exhausted), 45.9 ms | verdict=1, **2252.6 ms** |
| 5 | verdict=2 (Exhausted), 42.8 ms | **KILLED after 20 s** |
| 6 | verdict=2 (Exhausted), 43.3 ms | **KILLED after 20 s** |

`budgeted=0` on every row: the guard's per-file budget never fires, because it is checked *before* the engine is
handed a line and there is only one line. libc++ survives only because its **engine** has a complexity budget. This
is the residual Q8/Q9 — a named, reachable unbounded-work path on the platform Phase 2 exists to protect, **not**
bounded by this round.

**Defect found and fixed in this bundle (disclosed):** the first full-scale run logged the second seed as `seed=0`.
Cause: `pbt-regex-screen.cpp` parsed `--seed` with `strtoull( …, 10 )`, so `seeds.txt`'s `0x9E3779B9` parsed as `0`
and the `Rng` silently substituted its default constant — a truthful-looking log line that did not match the seed
list. Fixed to `strtoull( …, 0 )` (base 0), so a `0x…` entry is honoured verbatim; `seeds.txt` now states that the
log prints seeds in decimal (`0x9E3779B9` → `2654435769`). Re-run: the log above is the post-fix one.

## What is NOT here, and why

- **Both-platform CI logs** (AC5's named artifact). This session runs macOS, so the CI-produced Linux leg must come
  from CI — but the *toolchain* is not missing: Homebrew `g++-14` links libstdc++ natively, and it is what produced
  `p6-negative-control.log`, `pbt-run.sh` leg 2 and the probe's second column. The libstdc++ **behaviour** is
  therefore evidenced here; only the CI job that would emit the canonical log is absent.
- **A screen-admitted BOMB for the budget to catch.** Post-Phase-1 there is none: the screen refuses the shapes that
  backtrack, which is the point of Phase 1. The budget's job is the AGGREGATE (the spec's own Failure Mode, "a very
  large file matched by a cheap pattern"), so the arm exercises it with a capped budget rather than a bomb. **This is
  also why the budget cannot be shown to bound a single line** — see the residual section below.
- **A completed `pargates.py` run.** The 683-gate suite cannot finish in this environment: it exhausts the volume
  (the Q6 disk hazard — observed twice, the second time as an explicit `OSError: [Errno 28] No space left on
  device`), and this client injects a `safe-delete` shim that turns a gate's own bulk `rm -rf` cleanup into a
  **false non-zero exit with every assertion green**. Both partial runs' failures were classified and re-run
  cleanly — see `pargates-partial.txt`. The two gates the spec's Phase 3 scope names are green.

## The residual the PBT found — CONFIRMED, and NOT bounded by the budget (Q8/Q9)

`pbt-regex-screen.cpp` reports, on every run, that the multi-quantifier family is **ADMITTED**. Phase 1's arm targets
"a group containing a top-level `|`", and the family has at least three members the rule cannot see:

1. **group-free flat** — `a*a*a*a*a*b` (no group to inspect);
2. **grouped, no `|`** — `^(a)*(a)*(a)*(a)*(a)*$` (no top-level `|` to inspect);
3. **bounded-nested** — `^(ab\w|((.|.){1,3}){1,3}){1,3}$` (where `(.|.)` *is* an overlapping alternation, but its
   outer `{1,3}` is **bounded**, so the unbounded-outer rule never fires).

Round 1 described this as a scope boundary **bounded by the budget**. The round-1 verdict refuted that, and
`p6-negative-control.log` confirms the refutation: the budget counts **lines**, is checked **before** the engine is
handed a line, and with one candidate line it never fires. On libstdc++ a crafted single line is **unbounded work**.
The residual is therefore recorded as a **named, reachable** risk (open_questions Q8/Q9), **not** as a bounded one,
and the real fix (a per-line step bound, or a screen rule for adjacent/nested quantifier ambiguity) is a **follow-on
spec**, not this round. This spec does not claim to close it.
