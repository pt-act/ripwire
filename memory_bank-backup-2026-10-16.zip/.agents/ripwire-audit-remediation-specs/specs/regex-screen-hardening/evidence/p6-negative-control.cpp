// p6-negative-control.cpp — the §H negative control for PBT property P6.
//
// WHY THIS EXISTS. P6 (evidence/pbt-regex-screen.cpp) asserts that an ADMITTED pattern RETURNS on a
// pathological line. Run on libc++ only, P6 cannot fail: libc++'s ENGINE enforces its own complexity
// budget and throws error_complexity before any hang, so the call returns and P6 passes trivially.
// On libstdc++ there is no such engine budget, and an admitted multi-quantifier pattern backtracks
// inside ONE forEachLineMatch call. The guard's per-file budget is checked BEFORE the engine is handed
// a line, so with a single candidate line it never fires — the work is unbounded and the budget cannot
// see it. This control makes that difference explicit and reproducible, on the tree's real functions.
//
// WHAT IT BUILDS. The alternation-free multi-quantifier family ^(a)*(a)*…(a)*$ with K quantified
// groups. It is ADMITTED by the screen — there is no '|' anywhere, so Phase 1's structural-overlap rule
// cannot fire, and the pre-existing nested-repetition arm does not either (the group (a) holds no
// quantifier) — and it is exactly the shape P6 is meant to bound.
//
// Usage (run under a shell wall-clock cap — see p6-negative-control.sh):
//     ./p6-negative-control --k=5 --n=200
// Prints the pattern and the screen verdict, then the scan's verdict, its budgeted flag and the
// elapsed milliseconds. On libc++ every K returns; on libstdc++ K>=5 does not.
//
// THE SUBJECT MUST NOT MATCH. A line of all 'a' bytes MATCHES ^(a)*(a)*…$ and returns instantly on
// every engine — the blowup is on the FAILING path. This control therefore uses the PBT's own
// pathological subject (pbt-regex-screen.cpp): N 'a' bytes, a newline, N 'a' bytes, 'z', a newline —
// the 'z' on the second line is what the pattern cannot match, and that is what backtracks.
//
// House style follows the project (Allman braces, spaces inside parens) — scaffolding is still code.

#include "regexguard.h"

#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>

int main( int argc, char** argv )
{
    int         k = 5;
    std::size_t n = 200;   // 'a' bytes per line of the two-line pathological subject (PBT's own line)
    for( int i = 1; i < argc; ++i )
    {
        if( std::strncmp( argv[i], "--k=", 4 ) == 0 )
        {
            k = std::atoi( argv[i] + 4 );
        }
        else if( std::strncmp( argv[i], "--n=", 4 ) == 0 )
        {
            n = static_cast<std::size_t>( std::strtoull( argv[i] + 4, nullptr, 10 ) );
        }
    }
    if( k < 1 )
    {
        k = 1;
    }

    std::string pat = "^";
    for( int i = 0; i < k; ++i )
    {
        pat += "(a)*";
    }
    pat += "$";

    // The PBT's own pathological subject: N 'a', newline, N 'a', 'z', newline. The 'z' is what the
    // pattern cannot match, and the failing path is what backtracks.
    const std::string line = std::string( n, 'a' ) + "\n" + std::string( n, 'a' ) + "z\n";

    const std::optional<std::string> screen = rw::screenRegexPattern( pat );
    std::printf( "k=%d bytes=%zu pattern=%s screen=%s\n", k, line.size(), pat.c_str(),
                 screen.has_value() ? "REFUSED" : "ADMITTED" );
    if( screen.has_value() )
    {
        std::printf( "  (the screen refused it: %s)\n", screen->c_str() );
        return 2;
    }

    const rw::RegexCompile rc = rw::compileGuardedRegex( pat, rw::kRegexEcmaScript );
    if( rc.refusal )
    {
        std::printf( "  compile refused: %s\n", rc.refusal->c_str() );
        return 3;
    }

    const auto t0 = std::chrono::steady_clock::now();
    const rw::RegexLineScan scan = rc.regex.forEachLineMatch( line, rw::RegexLinePolicy{},
                                                             []( std::uint32_t, std::size_t ) { return true; } );
    const auto   t1 = std::chrono::steady_clock::now();
    const double ms = std::chrono::duration<double, std::milli>( t1 - t0 ).count();
    std::printf( "  verdict=%d budgeted=%d elapsed_ms=%.1f\n", static_cast<int>( scan.verdict ),
                 scan.budgeted ? 1 : 0, ms );
    return 0;
}
