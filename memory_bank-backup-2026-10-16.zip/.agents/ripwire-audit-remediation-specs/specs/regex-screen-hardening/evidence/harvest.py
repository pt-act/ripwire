#!/usr/bin/env python3
"""Harvest every regex-SHAPED string literal in the tree, for a before/after screen diff.

Deliberately over-inclusive: a literal is kept when it is 1..2048 bytes and contains at least one
regex metacharacter. False candidates cost nothing — the diff only reports verdict CHANGES, and a
non-regex cannot change verdict. Structured forms (--regex=, #match?, file(), --arch rules) are
extracted first so their exact text is present even when it has no metacharacter.
"""
import os
import re
import sys

ROOTS = ["test", "src", "queries", "docs", "skills", "scripts", "prompts", "bench"]
EXTS = {".sh", ".h", ".cpp", ".hpp", ".inl", ".scm", ".md", ".py", ".rb", ".json", ".yml", ".yaml"}
METACHARS = set("+*?[]()|\\{^$.")
QUOTED = re.compile(r"'([^'\\\n]*(?:\\.[^'\\\n]*)*)'|\"([^\"\\\n]*(?:\\.[^\"\\\n]*)*)\"")
STRUCTURED = [
    re.compile(r"--regex=(?:'([^']*)'|\"([^\"]*)\")"),
    re.compile(r"#(?:not-)?match\?\s+@[\w]+\s+\"((?:[^\"\\]|\\.)*)\""),
    re.compile(r"file\(\s*\w+\s*,\s*\"((?:[^\"\\]|\\.)*)\"\s*\)"),
    re.compile(r"(?:deny|allow)\s+path\s+\S+\s*->\s*(\S+)"),
]


def harvest(root):
    seen = set()
    for base, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in {".git", "build", "node_modules", ".agents"}]
        for name in files:
            if os.path.splitext(name)[1] not in EXTS:
                continue
            path = os.path.join(base, name)
            try:
                text = open(path, "r", encoding="utf-8", errors="replace").read()
            except OSError:
                continue
            for pattern in STRUCTURED:
                for match in pattern.finditer(text):
                    for group in match.groups():
                        if group:
                            seen.add(group)
            for match in QUOTED.finditer(text):
                lit = match.group(1) if match.group(1) is not None else match.group(2)
                if lit and 1 <= len(lit) <= 2048 and METACHARS & set(lit):
                    seen.add(lit)
    return seen


def main():
    root = sys.argv[1] if len(sys.argv) > 1 else "."
    found = set()
    for sub in ROOTS:
        path = os.path.join(root, sub)
        if os.path.isdir(path):
            found |= harvest(path)
    for lit in sorted(found):
        if "\n" not in lit:
            sys.stdout.write(lit + "\n")
    sys.stderr.write(f"harvested {len(found)} candidate literals\n")


if __name__ == "__main__":
    main()
