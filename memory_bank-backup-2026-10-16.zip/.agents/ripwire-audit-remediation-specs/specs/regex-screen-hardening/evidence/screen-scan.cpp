// screen-scan.cpp — read patterns (one per line) from stdin, print "VERDICT<TAB>pattern" for each.
// Paired with a copy of the PRE-change regexguard.h, this turns a corpus of real patterns into a
// before/after verdict diff — the admission-regression evidence AC4 asks for.
#include "regexguard.h"

#include <cstdio>
#include <iostream>
#include <string>

int main()
{
    std::string line;
    while( std::getline( std::cin, line ) )
    {
        if( line.empty() )
        {
            continue;
        }
        const std::optional<std::string> r = rw::screenRegexPattern( line );
        std::printf( "%s\t%s\n", r ? "REFUSE" : "ADMIT", line.c_str() );
    }
    return 0;
}
