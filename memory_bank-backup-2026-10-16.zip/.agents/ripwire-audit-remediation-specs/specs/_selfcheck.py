#!/usr/bin/env python3
"""spec-architect self-check — machine-run portion, extended 2026-09-29 (co-founder
Amendment 3): the manifest is now PROJECT_MANIFEST.md v2.5.1 schema, so the framework's
seven DAG invariants (§C) are checked where testable — including history monotonicity.
Checks: heading order, id/header/manifest consistency, unique ids, acyclicity,
interface closure, integration arity, leaf declarations, status consistency, seven invariants.
Relaxed at the 2026-10-12 manifest lock: the status check now asserts the spec file's Status line
AGREES with the manifest (it used to pin every spec to `planned`, which cannot express an executing
DAG), and §C invariant 5 (dependency gating) is now checked too.
Relaxed 2026-10-12 (producer round 1): the progress-tracking check now accepts a CHECKED phase list
too — the old pin was the UNCHECKED form `- [ ] Phase 1`, the same planning-era artifact as the status
pin, and it made VALIDATION_PROTOCOL.md §C's "the producer checks the boxes off" unsatisfiable."""
import re, sys, yaml, pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
REQ = ["## Header","## Objective","## Scope","## Interfaces","## Acceptance Criteria",
       "## Implementation Notes","## Failure Modes","## Dependencies","## Consumers",
       "## Status","## Validation Strategy","## Progress Tracking"]
DECLARED_LEAVES = {"keyboardModelContract","exceptionSafeGate","threatModelDoc","validationReport"}

fails = []
man = yaml.safe_load((ROOT/"manifest.yml").read_text())
mspecs = {s["id"]: s for s in man["specs"]}

# unique ids (yaml would collapse dupes in the dict — check the raw list length)
ids = [s["id"] for s in man["specs"]]
if len(ids) != len(set(ids)): fails.append("duplicate spec ids in manifest")

for sid, s in mspecs.items():
    f = ROOT/s["file"]
    if not f.exists(): fails.append(f"{sid}: missing {s['file']}"); continue
    txt = f.read_text()
    heads = [l.strip() for l in txt.splitlines() if l.startswith("## ")]
    if heads != REQ: fails.append(f"{sid}: heading order/content mismatch: {heads}")
    m = re.search(r"```yaml\n(.*?)\n```", txt, re.S)
    hdr = yaml.safe_load(m.group(1)) if m else {}
    if hdr.get("id") != sid: fails.append(f"{sid}: header id {hdr.get('id')}")
    if hdr.get("manifest") != "../../manifest.yml": fails.append(f"{sid}: bad manifest path")
    if hdr.get("type") != s["type"]: fails.append(f"{sid}: type mismatch header={hdr.get('type')} manifest={s['type']}")
    if f.parent.name != sid: fails.append(f"{sid}: dir/file mismatch")
    if s["status"] not in ("planned", "in_progress", "in_review", "approved", "blocked"):
        fails.append(f"{sid}: manifest status {s['status']} not in vocabulary")
    # status consistency (relaxed AT LOCK 2026-10-12): this used to pin every spec to `planned`, which
    # cannot express an executing DAG. It now asserts the spec file's Status line AGREES with the manifest.
    if f"**Status:** {s['status']}" not in txt:
        fails.append(f"{sid}: spec file Status line does not match manifest status {s['status']}")
    if "Validation Strategy" not in txt or ("Tier 1" not in txt and "Tier 2" not in txt and "IS the standalone validation" not in txt):
        fails.append(f"{sid}: validation strategy missing tier")
    # progress-tracking presence (relaxed 2026-10-12, producer round 1): this used to pin the UNCHECKED
    # form `- [ ] Phase 1`, which cannot express a producer's checked-off phases — the same planning-era
    # pin as the status check above. The invariant is that the phase list is PRESENT; either checkbox
    # state satisfies it (VALIDATION_PROTOCOL.md §C expects the producer to check the boxes off).
    if "- [ ] Phase 1" not in txt and "- [x] Phase 1" not in txt:
        fails.append(f"{sid}: progress tracking absent")
    # leaf declarations
    for p in s.get("produces", []):
        if not p["consumers"] and p["name"] not in DECLARED_LEAVES:
            fails.append(f"{sid}: orphan produces {p['name']} (not declared leaf)")

# dependency existence + acyclicity (Kahn)
deps = {sid: list(s.get("depends_on", [])) for sid, s in mspecs.items()}
for sid, ds in deps.items():
    for d in ds:
        if d not in mspecs: fails.append(f"{sid}: depends on missing {d}")
indeg = {k: len(v) for k, v in deps.items()}
ready = sorted([k for k, d in indeg.items() if d == 0]); seen = []
while ready:
    n = ready.pop(0); seen.append(n)
    for k, ds in deps.items():
        if n in ds:
            indeg[k] -= 1
            if indeg[k] == 0: ready.append(k)
if len(seen) != len(deps): fails.append("dependency cycle detected")

# interface closure + reciprocal consumers
for sid, s in mspecs.items():
    for c in s.get("consumes", []):
        src = mspecs.get(c["from"])
        if not src: fails.append(f"{sid}: consumes {c['name']} from missing {c['from']}"); continue
        prod = next((p for p in src.get("produces", []) if p["name"] == c["name"]), None)
        if not prod: fails.append(f"{sid}: consumes {c['name']} not produced by {c['from']}"); continue
        if sid not in prod["consumers"]: fails.append(f"{sid}->{c['name']}: not reciprocal in {c['from']} produces")
for sid, s in mspecs.items():
    for p in s.get("produces", []):
        for cons in p["consumers"]:
            cs = mspecs.get(cons)
            if not cs: fails.append(f"{sid}.{p['name']}: consumer {cons} missing"); continue
            if not any(c["name"] == p["name"] and c["from"] == sid for c in cs.get("consumes", [])):
                fails.append(f"{sid}.{p['name']}: consumer {cons} does not declare consumption")

# integration arity + type-extension recording
for sid, s in mspecs.items():
    if s["type"] == "integration":
        n = sum(1 for d in deps[sid] if mspecs[d]["type"] == "unit")
        if n < 2: fails.append(f"{sid}: integration spec with <2 unit deps")
    if s["type"] not in ("unit", "integration", "validation"): fails.append(f"{sid}: unknown type {s['type']}")

# —— PROJECT_MANIFEST.md v2.5.1 §C · the seven DAG invariants (where testable) ——
# (1 unique ids, 2 acyclicity, 3 interface closure, 4 integration arity are checked above.)
VOCAB = {"planned", "in_progress", "in_review", "approved", "blocked"}
for s in man["specs"]:  # 5 status validity + execution provenance for review/approved
    if s.get("status") not in VOCAB:
        fails.append(f"{s['id']}: status {s.get('status')} not in vocabulary")
    if s.get("status") in ("in_review", "approved") and not (s.get("execution") or {}).get("producer"):
        fails.append(f"{s['id']}: {s['status']} without execution.producer")
    if s.get("status") in ("in_progress", "approved"):  # 5 dependency gating (added at lock 2026-10-12)
        bad = [d for d in s.get("depends_on", []) if mspecs.get(d, {}).get("status") != "approved"]
        if bad:
            fails.append(f"{s['id']}: {s['status']} with unapproved dependencies {bad}")
    e = s.get("execution") or {}  # 6 heterogeneity: validator must differ from producer
    if e.get("producer") and e.get("validator") and e["producer"] == e["validator"]:
        fails.append(f"{s['id']}: validator == producer (heterogeneity violated)")
ts = [str(h.get("timestamp", "")) for h in man.get("history", [])]  # 7 history monotonicity
if ts != sorted(ts):
    fails.append("history timestamps not monotonic (invariant 7)")
if man["project"].get("status") not in {"planning", "executing", "paused", "complete"}:
    fails.append(f"project.status {man['project'].get('status')} invalid (§B)")

# longest chain (critical path), for the record
memo = {}
def depth(sid):
    if sid in memo: return memo[sid]
    memo[sid] = 1 + max([depth(d) for d in deps[sid]] or [0])
    return memo[sid]
crit = max(((depth(s), s) for s in deps))
topo = seen

print(f"specs={len(mspecs)} units={sum(1 for s in mspecs.values() if s['type']=='unit')} "
      f"integration={sum(1 for s in mspecs.values() if s['type']=='integration')} "
      f"validation={sum(1 for s in mspecs.values() if s['type']=='validation')}")
print(f"topological order: {' -> '.join(topo)}")
print(f"longest chain: {crit[0]} specs (ends at {crit[1]})")
if fails:
    print("FAILURES:"); [print("  -", f) for f in fails]; sys.exit(1)
print("ALL MACHINE-RUN CHECKS PASS")
