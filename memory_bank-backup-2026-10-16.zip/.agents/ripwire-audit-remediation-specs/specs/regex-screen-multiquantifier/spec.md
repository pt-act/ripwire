# Regex Screen Hardening II — the multi-quantifier family

## Header

```yaml
id: regex-screen-multiquantifier
type: unit
version: 0.1.0
manifest: ../../manifest.yml
```

## Objective

Close the **multi-quantifier backtracking family** that `regex-screen-hardening` disclosed and did **not** fix (its
Q8/Q9): a pattern carrying several quantified atoms that can match the same text, meeting a subject that fails to
match, backtracks with cost polynomial in the subject length and exponential in the number of atoms — and on
**libstdc++** nothing bounds it, because the guard's per-file budget counts *lines*, not *work*, and is checked
*before* the engine is handed a line (`src/regexguard.h:1657`).

This is a **different structural family** from the one `regex-screen-hardening` closes. That spec's rule refuses a
group's top-level `|` under an unbounded outer quantifier; every member below is admitted by it, by construction.
Closing this family needs its own admit-set analysis and its own negative controls — it is not a widening of the
first rule.

## Scope

### The family (all ADMITTED by the current screen)

Reproduced in `specs/regex-screen-hardening/evidence/p6-negative-control.log` — libc++ returns at every `k` because
its engine throws `error_complexity`; libstdc++ runs 2.25 s at `k=4` and does not return at `k>=5`, with the budget
never firing (`budgeted=0` throughout).

| # | shape | example | why the current screen misses it |
| --- | --- | --- | --- |
| i | group-free flat | `a*a*a*a*a*b` | no group to inspect |
| ii | grouped, no `|` | `^(a)*(a)*(a)*(a)*(a)*$` | no top-level `|` to inspect |
| iii | bounded-nested | `^(ab\w\|((.\|.){1,3}){1,3}){1,3}$` | `(.\|.)` **is** an overlapping alternation, but its outer `{1,3}` is **bounded**, so the unbounded-outer rule never fires |

### The hard constraint that shapes every option

**The verdict must be a pure function of (file, pattern).** This tree gates on byte-identical output, so a per-line
**wall-clock** bound is unavailable — the result would depend on the machine and the run. Any per-line bound must
therefore be a **count**. And `std::regex` exposes **no step/visit count** to its caller: a single `match` call is
atomic, so a caller-side counter cannot observe the work inside it. That is the whole reason
`regex-screen-hardening`'s budget is an aggregate and not a per-line bound.

### Candidate mechanisms (for this spec's own design phase — NOT decided here)

1. **A screen rule for adjacent/nested quantifier ambiguity.** Refuse a pattern where two or more quantified atoms
   can consume the same text under a repetition — flat adjacency (`a*a*`), grouped adjacency (`(a)*(a)*`), and
   nested bounded quantifiers whose product overlaps (`(X{1,3}){1,3}` where `X` can match what `X` matches).
   - **The admit-set analysis is the work, and it is non-trivial.** It must still admit `.*.*`-free shapes that are
     legitimate in this tree — `\s*\w+`, `(get|getResponse){1,5}`, `(a|b)+`, `(abc)+`, `TODO|FIXME` — and it must
     not refuse a pattern merely because two quantified atoms *could* overlap when their character sets are
     provably disjoint. Every analysis rule is a soundness surface: a missed overlap is a live bomb, an over-broad
     rule eats working patterns (the false-positive class `regex-screen-hardening` already names).
   - Precedent for the conservative direction: `regex-screen-hardening`'s Q5(a) ruling — "a refusal is a safe
     failure, a hang is not" — but the false-positive budget here is **larger**, because `a*a*`-shaped adjacency is
     far more common in real patterns than a `|` under an unbounded outer.
2. **A subject-length cap for the risk class.** For a pattern the screen cannot prove single-atom-per-repetition,
   bound the line length handed to the engine — a **count**, deterministic, cheap. This trades a refusal for a
   bound rather than for a false positive, and it is closer to what the tree already does for engine recursion
   (`regexMaxSubjectBytes`).
3. **Both** — a screen rule for the clear cases, a subject cap for the residual.

A **fourth** possibility — replacing or wrapping the engine to expose a step count — is out of scope for a gap-fill
spec and would be its own proposal.

### Phase 0 — the mechanism decision (planning, 2026-10-14; measured on the branch @ 77de7863)

- **The existing subject bound does NOT see this family.** `regexMaxSubjectBytes` models recursion DEPTH per byte
  (`RegexShapeCount.visitsPerByte`), and `^(a)*(a)*(a)*(a)*(a)*$` costs almost nothing per byte — its danger is
  backtracking MULTIPLICITY (the ~n^5 split of a single run across five quantifiers), which no depth model can see.
  Empirically: a 100-byte subject is NOT Skipped (the line is handed to the engine and costs ~5 s), while n>=200
  exceeds a 60 s cap. Candidate 2 as literally stated ("bound the line length for the risk class") therefore
  REQUIRES a new cost axis in the model — it is not a tuning of the existing bound.
- **The existing shape algebra is the right substrate for EITHER candidate.** `regexShapeSequence` /
  `regexShapeRepeat` / `regexShapeDisjunction` already compose per-alternative character-class summaries (the
  screen's PROVE-disjoint analysis reads them); a multiplicity axis (e.g. `visitsPerByte` raised by a product of
  adjacent quantifiers' branching) or an adjacency test between the shape nodes of sibling quantifiers is expressible
  in the same pass that computes the shape today. No new parser.
- **The false-positive surface is small on THIS tree's corpus but the burden of proof stays with the rule.**
  The honest corpus (the 99,845-literal sweep) must be re-run against the candidate rule BEFORE it is chosen: the
  count of newly-refused honest patterns is the deciding number, and candidate 1's admit-set analysis (adjacent
  quantifiers whose classes PROVE disjoint stay admitted, e.g. `\s*\w+` is NOT this family — its atoms are
  disjoint classes) is exactly the analysis the sweep prices.

**Ruling (PM recommendation, operator-ratified at dispatch): candidate 3 — both, in this order:**

1. **Screen rule first** (candidate 1), built on the shape algebra: refuse a pattern where two or more quantified
   atoms are ADJACENT (flat `a*a*`, grouped `(a)*(a)*`, or bounded-nested whose product overlaps) AND their
   character-class summaries are NOT provably disjoint. The PM-1 honesty clause applies: the refusal says the
   screen cannot prove the repetitions split the text unambiguously, never "this pattern backtracks".
   - Rationale: it is the only candidate that protects the OTHER verb surfaces (`--arch` rules, `#match?`
     predicates, `--graph-query file()`) at admission time, where no subject exists to cap.
2. **Subject cap second** (candidate 2), as the belt-and-braces for admitted-but-risky shapes: a multiplicity-aware
   per-pattern subject bound (a COUNT derived from the new cost axis), refusing-with-Skipped semantics identical to
   the existing oversize path — the vocabulary already exists (`kRegexOversizeReason`).
   - Rationale: any admission rule has a soundness margin; a class-summary is conservative and WILL admit shapes
     whose real backtracking is bounded only by subject length. The cap closes that margin deterministically.

**What Phase 1 becomes concretely:** extend `regexShapeCount` with the multiplicity axis (or an adjacency list of
quantified-shape siblings); the rule reads it at admission; the cap reads it at line-hand-off. Both reuse the
PM-1 refusal vocabulary; both feed Phase 2's mandatory libstdc++ leg; Phase 3's sweep prices the false-positive
class against the 99,845 corpus as the acceptance number.

**Deferred with reason:** the engine-wrap (candidate 4) stays out of scope — the determinism contract makes a
caller-side step count impossible without replacing std::regex, which is an architecture change upstream must
own, not a gap-fill spec.

**Status of this record:** the mechanism is DECIDED at planning level; the spec's interfaces (the new axis's name,
the refusal message wording, the cap's constant) remain the producer's Phase-1 design work under this constraint.

### Phases

- **Phase 1 — the admission rule (or the subject cap).** Extend `catastrophicRegexConstruct()` / the structural
  scan with the chosen mechanism. The admit set above MUST stay admitted; the false-positive class MUST be
  enumerated and measured, exactly as `regex-screen-hardening` did for its own class.
- **Phase 2 — the gate arms.** The refusal battery gains the three family shapes; each arm asserts a bounded wall
  time and a message that names the construct honestly. **A `libstdc++` leg is mandatory** (Homebrew `g++-14`,
  `-B/usr/bin`): the whole point is the platform where the engine does not throw. A libc++-only arm proves
  nothing — the round-1 `regex-screen-hardening` verdict is the precedent.
- **Phase 3 — evidence.** A §H **negative control per property**, with the kill recorded where the property can
  fail, and the corpus sweep re-run (99,845 literals) to measure the new false-positive class in-tree.


## Interfaces

Provisional — this spec is `planned`, and its interface contract is settled in its own planning cycle. The manifest
entry therefore declares none yet (`produces: []`, `consumes: []`); the shapes below are the draft's starting point,
not a commitment.

- **`patternAdmission`** — extends the existing verdict (`catastrophicRegexConstruct()`); signature unchanged, the
  refusal set widened. Consumed from `regex-screen-hardening`; if the planning cycle makes this a formal `consumes`
  edge, `regex-screen-hardening`'s `patternAdmission.consumers` must gain this spec id (the manifest's reciprocity
  check).
- **A new evidence interface** for the family, since `pbtEvidenceBundle`'s properties are the first spec's.

## Acceptance Criteria

1. Every family member above is refused (or bounded) with a bounded wall time on **both** toolchains.
2. The admit set is unchanged: `(a|b)+`, `(abc)+`, `TODO|FIXME`, `foo.*bar`, `(\s*\w+){1,20}` still admitted.
3. No refusal regression against `regex-screen-hardening`'s battery.
4. Determinism preserved (the AGENTS.md ritual).
5. The §H control exists and is load-bearing on libstdc++.

## Implementation Notes

- **`regex-screen-hardening` lands first** and is the substrate: this spec reuses its screen, its refusal-message
  vocabulary and its gate discipline. The `depends_on` edge is what keeps that ordering honest.
- **The refusal must not overclaim.** The PM-1 clause is the house style — say what the screen *cannot prove*, not
  what the pattern *is*. A new rule that says "this pattern backtracks" is a claim the screen cannot support.
- **Determinism is a contract.** Any bound chosen must be a count derived from the input, never a clock; the
  `--regex` refusal path already distinguishes a budget stop from an engine abandonment
  (`kRegexBudgetReason` vs `kRegexAbandonedReason`), and this spec must extend that vocabulary rather than blur it.
- **The false-positive class is measured, named and disclosed** — a rule that quietly eats a common pattern is the
  primary risk, and it is a disclosure duty, not a tuning detail.

## Failure Modes

- **The new rule refuses a legitimate pattern** — the primary risk, and the reason for the admit-set analysis. The
  false-positive class must be measured, named and disclosed, not discovered by users.
- **The rule misses a family member** — a soundness failure. The gate battery must include each of the three shapes
  explicitly, plus generated patterns.
- **The bound is a clock, not a count** — the determinism contract fails on the first machine whose timing differs.
  A wall-clock bound is not available here for exactly this reason.
- **The rule is written against libc++** — a libc++-only arm passes while libstdc++ hangs. The mandatory libstdc++
  leg exists to make this failure visible; the round-1 verdict found it by exactly this route.

## Dependencies

`regex-screen-hardening` — **must land first**: this spec closes what that one discloses, and reuses its screen, its
refusal-message vocabulary and its gate discipline. `depends_on: [regex-screen-hardening]`.

## Consumers

- **Spec:** security-regression-integration — the family's refusal text, for byte-precise assertions.
- **Spec:** audit-validation-standalone — the new evidence bundle at the declared path.

## Status

**Status:** planned
**Last updated:** 2026-10-13T21:05:00Z
**Updated by:** producer session — **promoted from `drafts/regex-screen-multiquantifier.spec.md` at the operator's
Q9 ruling (option (a))**, recorded as manifest event `spec_added` with `depends_on: [regex-screen-hardening]`. This
is a **draft-stage spec**: it is in the DAG but **NOT dispatched**, and its interfaces, ACs and failure modes are
sharpened in its own planning cycle (the scope, family table and the hard constraint above are settled; the ACs are
explicitly marked draft in the source). It was written because the round-2 record of `regex-screen-hardening` names
this family as a **confirmed, reachable, unbounded-on-libstdc++** residual rather than a bounded one — the honest
follow-up is a spec that closes it, not a claim that it is closed.

## Validation Strategy

Tier 2 — property-based testing required (input validation/sanitization of a hostile-controllable pattern language;
security-sensitive availability boundary — the same surface and the same tier as `regex-screen-hardening`).

- **Components requiring PBT:** `catastrophicRegexConstruct()` (the widened admission rule) and, if mechanism 2 is
  chosen, the subject-length cap.
- **Formal properties (draft — to be pinned in the planning cycle):**
  - ∀ p ∈ the three family shapes: `refused(p) ∨ bounded(p)`, and the scan returns within the wall-clock cap on
    **both** toolchains.
  - ∀ p ∈ the admit set: `admitted(p)`, with results byte-identical to pre-change.
  - ∀ p: the verdict is deterministic across runs and platforms.
- **§H negative control:** every property must be shown capable of failing on the platform it is run on. For this
  spec that means a **libstdc++ leg is mandatory** — on libc++ alone the properties cannot fail, because the engine
  throws, so a libc++-only pass is not evidence.
- **Input domains:** a random pattern generator over the ECMAScript subset the verb documents (groups, alternation,
  classes, quantifiers, anchors), seeded; plus the three fixed family shapes and the admit corpus.
- **Case budget:** ≥10,000 generated patterns plus the fixed corpora; the run under a **wall-clock cap** whose kill
  is the negative control, not a flake.
- **Evidence bundle:** property-test source, seeds, platform, case counts, result logs, the §H controls — in
  `specs/regex-screen-multiquantifier/evidence/`. PBT does not prove absolute security; it evidences the properties
  hold over the generated domain.

## Progress Tracking

- [ ] Phase 1: extend `catastrophicRegexConstruct()` (or add the subject cap) with the chosen mechanism; enumerate
      and measure the false-positive class
- [ ] Phase 2: gate arms for the three family shapes, each asserting a bounded wall time and an honest message,
      with a mandatory `libstdc++` leg
- [ ] Phase 3: the §H negative control per property, and the 99,845-literal corpus sweep re-run
