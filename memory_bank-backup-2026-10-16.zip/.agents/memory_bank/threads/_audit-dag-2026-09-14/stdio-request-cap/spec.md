# Stdio Request Cap

## Header

```yaml
id: stdio-request-cap
type: unit
version: 1.0.0
manifest: ../../manifest.yml
```

## Objective

Bound the stdio MCP request loop's per-line memory growth, closing audit finding #6 (Low). `readByteSafeLine` (`src/infra/stdinline.h` L44) grows one `std::string` per line with no ceiling and `runMcp` (`src/mcp.h` ~L1999) reads request lines straight from it, so a single multi-gigabyte "line" grows the server heap without bound — the HTTP transport has an 8 MB body cap (`kMaxBodyBytes`, `mcpserver.h` L64) and stdio has none.

## Scope

**In scope:**
- A capped stdio request read at the `runMcp` loop: lines longer than a ceiling (8 MiB, mirroring `kMaxBodyBytes` so both transports share one number and one story) are refused with the framing gate's existing JSON-RPC error shape (`id:null`, `-32700`-family parse/refusal wording from `mcprefuse`), the remainder of the over-long line is drained to the next `\n`, and the server stays alive for the next request.
- The cap lives in the MCP loop (or a capped sibling reader), **not** inside `readByteSafeLine`, which is shared with git-output parsing (`gitmine.h`) that has its own contracts.
- A new gate `test/mcplinecapcheck.sh` registered in `test/regression.sh` in the same commit.

**Out of scope:**
- Per-argument size limits inside well-formed requests (the JSON scanner reads bounded spans of an already-capped line; a separate concern).
- HTTP transport changes (already capped).
- Any change to `readByteSafeLine`'s byte-safe semantics for its other callers.

## Interfaces

### Produces

#### boundedStdioLine
- **Shape:** behavioral contract — the stdio loop accepts request lines up to 8 MiB; an over-long line produces exactly one framing-gate JSON-RPC error response, consumes input through the terminating newline, and leaves the loop ready to serve the following line. Memory growth per request is bounded by the cap plus parse overhead.
- **Location:** `src/mcp.h` `runMcp` request loop; optional capped sibling in `src/infra/stdinline.h`.
- **Invariants:** at-or-under-cap lines behave byte-identically to today; over-cap lines yield one error and resynchronization at the next newline; the server never exits and never blocks on the over-long line after the cap fires.
- **Examples:** a 9 MiB single-line `tools/call` → one `-32700`-family error; the next line, a well-formed `tools/list`, answers normally.
- **Consumers:** security-regression-integration

### Consumes

None — root spec.

## Acceptance Criteria

1. **Over-long line refused, server alive**: pipe a 9 MiB newline-free JSON-RPC prefix followed by `\n`, then a well-formed `tools/list` line, into `ripwire --mcp`. **Verifier:** `test/mcplinecapcheck.sh` asserts exactly one framing-gate error with `id:null`, then a successful `tools/list` response, then clean EOF exit.
2. **Memory bounded**: the same run under `/usr/bin/time -v` (or `ps` sampling) shows RSS below a recorded ceiling (cap + parse slack; pin the number in the gate after one measurement on CI hardware). **Verifier:** arm (b) compares against the pinned ceiling.
3. **At-cap boundary correct**: a line of exactly the cap length is processed; cap+1 is refused. **Verifier:** arm (c) boundary pair.
4. **Git parsing untouched**: `readByteSafeLine`'s git callers behave identically — full `python3 test/pargates.py . ./build/ripwire -j 6` green. **Verifier:** suite log.
5. **Gate registered**: in `test/regression.sh`; `./test/manifestcheck.sh` passes. **Verifier:** run it.

## Implementation Notes

- Drain-then-continue is the load-bearing detail: refusing without consuming to the next newline would desynchronize every subsequent request.
- Share the constant with `mcpserver.h` (`kMaxBodyBytes`) by including the one header or hoisting the constant — do not fork the number.
- The error should reuse `mcprefuse`'s framing refusal vocabulary; no new refusal dialect.

## Failure Modes

### Legitimate giant request
- **Trigger:** an edit verb whose `new_body` legitimately exceeds 8 MiB (a generated file rewrite).
- **Expected handling:** refused with a message naming the 8 MiB limit and pointing at the CLI edit flags, which operate on files directly.
- **Validator check:** arm (a) asserts the message names the limit.

### Cap placed in the shared reader
- **Trigger:** implementing inside `readByteSafeLine` silently changes git-output parsing.
- **Expected handling:** cap lives in the MCP loop / capped sibling; the shared reader's contract is unchanged.
- **Validator check:** arm (d) suite green + code grep showing `readByteSafeLine` untouched (diff-gated).

### Slow drip under the cap
- **Trigger:** a client dribbles 7 MiB one byte at a time (stdio has no read timeout).
- **Expected handling:** accepted residual — stdio's client is co-located; documented in the spec, no code. HTTP has SO_RCVTIMEO already.
- **Validator check:** documented in `specs/stdio-request-cap/phase-log.md` at execution.

## Dependencies

None.

## Consumers

- **Spec:** security-regression-integration — replays the 9 MiB line end-to-end. **Constraints:** the refusal wording and the resync behavior are asserted byte-precisely; change them together.

## Status

**Status:** planned
**Last updated:** 2026-09-14T07:45:00+01:00
**Updated by:** spec-architect@2.0.0 (planning; provisional — manifest not locked)

## Validation Strategy

Tier 1 — focused testing sufficient. Components assessed: the bounded read loop (a fixed ceiling with deterministic boundary behavior — boundary arms (a)/(c) cover it), the drain/resync path (arm (a)), and the refusal wording (arm (a)). No sanitization logic, no state machine, no security decision is taken on the line's *contents* — the cap is a size check — so no PBT-suitable component is identified.

## Progress Tracking

- [ ] Phase 1: Capped read + drain-and-refuse in the runMcp loop, sharing kMaxBodyBytes
- [ ] Phase 2: test/mcplinecapcheck.sh arms (a)–(c) + RSS ceiling pin, registered in regression.sh
- [ ] Phase 3: Full pargates + determinism runs logged; phase-log entry for the slow-drip residual
