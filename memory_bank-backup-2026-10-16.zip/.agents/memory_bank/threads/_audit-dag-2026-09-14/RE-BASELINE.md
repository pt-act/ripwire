# Re-Baseline — the 2026-09-14 audit DAG vs current main (2026-09-24)

The audit targeted redhat-et/ripwire @ c1915d21; main is now 7+ trains ahead.
Status verified live on 2026-09-24 unless noted. The DAG's own statuses are all
`planned` — this table is the execution-ready truth.

| spec (finding) | re-baseline status | evidence |
| --- | --- | --- |
| regex-screen-hardening (#1, High) | OPEN — execute first | `^(a|aa)+b$` ran live: no refusal, 6.6 s scan; alternation family bypasses the screen (src/search.h admission) |
| edit-workspace-pin (#2) | LANDED upstream — do not execute | assumedRoot pin tiers exist (mcp.h:319-370) |
| atomic-write-tempfile (#3) | LANDED upstream — do not execute | createExclTempFile + DISCLOSE fallbacks (mcpedit.h:738) |
| git-porcelain-framing (#4) | OPEN | exact-match vs 5-byte-prefix `__C__` split persists (gitmine.h:1487 vs :1576) |
| stdio-request-cap (#6) | LANDED upstream — do not execute | readByteSafeLineBounded (stdinline.h) |
| mcp-token-hygiene (#7) | UNVERIFIED this pass | argv/env channel — check before executing |
| html-export-template-remediation (#5/#8–13) | UNVERIFIED — needs rendered-DOM audit | chrome had no CSP/ARIA at thread start; confirm on a generated report |
| graph-interaction-accessibility (#9/#10) | UNVERIFIED — needs rendered-DOM audit | zero key handlers / motion query at thread start |
| markitdown-bridge-hardening (#14) | UNVERIFIED this pass | informational tier |
| parsepool-gate-guard (§2) | UNVERIFIED this pass | informational tier |
| security-threatmodel-docs (#15) | OPEN in principle — docs gap | SECURITY.md exists and is strong; the ask is the HTTP/threat-model additions |
| security-regression-integration | follow the unit specs that survive re-baseline | depends on the above |
| audit-validation-standalone | follow the unit specs that survive re-baseline | depends on the above |

Rule: verify-then-execute. Any spec whose finding no longer reproduces on
current main is retired with a one-line note here, not executed.


---

## Re-verification pass — 2026-10-11 (post-26c-acceptance, against train-25-era tree)

Live checks on the workspace binary (879a54b48, train-25 base; upstream main has moved further —
re-check line anchors on the post-26c tree when the DAG starts):

- **regex-screen-hardening (#1, High) — STILL OPEN, but REFRAMED.** Upstream shipped their own
  guard (src/regexguard.h + test/regexbombcheck.sh, joyful-ii-V-I). It refuses the nested-unbounded
  battery ((a+)+, (a?)+, (a{1,3})+, (a|b)+, (a+|b)+c, ((ab|c){2})+d) — but OVERLAPPING ALTERNATION
  ((a|a)+b) is a DOCUMENTED KNOWN GAP (regexbombcheck INFO line: "ran past 30 s"), and the audit's
  exact PoC `^(a|aa)+b$` scanned live (hits="0", no refusal; the engine ran the bomb). The spec's
  Phase-1 extension (any top-level `|` inside an unbounded outer quantifier => refuse) is precisely
  their missing arm. Execute as a GAP-FILL against their guard: extend their admission verdict,
  add the (a|a)+b / ^(a|aa)+b$ arms to THEIR gate (their INFO line becomes a PASS), keep their
  refusal-message vocabulary. NOT a from-scratch screen — src/search.h as drafted no longer exists
  as the sole admission site.
- **git-porcelain-framing (#4) — STILL OPEN, anchors moved.** The exact-match (gitmine.h:~1496,
  `s == "__C__"`) vs 5-byte-prefix (gitmine.h:~1585, `s.rfind("__C__",0)==0`) split persists, plus
  a third spelling at :1571 (`tformat:__C__%x20%ct`). Re-locate on the post-26c tree.
- **mcp-token-hygiene (#7) — STILL OPEN, small.** --mcp-token= exists (cli.h:3186) with env
  RIPWIRE_MCP_TOKEN; the argv-exposure warning + stderr hint (the spec's ask) is not present.
- **markitdown-bridge-hardening (#14) — STILL OPEN (docparse.h shell-out on PATH).** Opt-out and
  PATH-pinning not found in the tree.
- **parsepool-gate-guard — site exists (ingest_prewarm / ingest_crawl grammar-prewarm).** The
  exception-safe prewarm gate as specced needs a code read on the post-26c tree.
- **LANDED, do not execute (unchanged):** edit-workspace-pin (#2), atomic-write-tempfile (#3),
  stdio-request-cap (#6).
- **rendered-dom-audit — still the gate for both UI specs; unverified until run on a generated
  report.** Nothing since 2026-09-24 suggests upstream touched the export template's CSP/ARIA, but
  26b/26c brought html/export changes worth one grep before the audit runs.
