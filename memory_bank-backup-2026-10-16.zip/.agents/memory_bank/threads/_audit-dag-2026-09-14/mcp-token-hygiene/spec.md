# MCP Token Hygiene

## Header

```yaml
id: mcp-token-hygiene
type: unit
version: 1.0.0
manifest: ../../manifest.yml
```

## Objective

Stop encouraging bearer-token exposure through the process list, closing audit finding #7 (Low). `--mcp-token=SECRET` (`src/main.cpp` ~L3151) places the shared bearer in argv, readable by any local user via `ps` for the process's lifetime; the safer `RIPWIRE_MCP_TOKEN` env channel already exists but nothing steers operators to it.

## Scope

**In scope:**
- A one-time stderr warning at MCP HTTP startup when the token was supplied via `--mcp-token` (argv): names the exposure (visible in the process list to other local users) and the safer channel (`RIPWIRE_MCP_TOKEN` or a reverse proxy's auth), in the existing `rw::emitTo( stderr, … )` style.
- No warning when the token comes from the environment; no behavior change to authentication itself.
- Docs: the `--listen`/`--mcp-token` section of the reference docs and `mcpserver.h`'s header posture comment updated to recommend the env var.
- A new gate `test/mcptokencheck.sh` registered in `test/regression.sh` in the same commit.

**Out of scope:**
- Removing the argv form (a breaking change; the warning is the remediation for this cycle).
- Token storage, rotation, or TLS termination (documented "reverse-proxy it" posture unchanged).
- The constant-time compare (already correct — do not touch).

## Interfaces

### Produces

#### tokenWarningContract
- **Shape:** behavioral contract — HTTP MCP startup with `--mcp-token=<v>` emits exactly one stderr line matching `ripwire: .*--mcp-token.*process list.*RIPWIRE_MCP_TOKEN` (wording pinned in the gate); startup with `RIPWIRE_MCP_TOKEN` set and no argv token emits no such line; authentication behavior is otherwise identical.
- **Location:** `src/main.cpp` (flag parse / `runMcpHttp` config assembly).
- **Invariants:** the token value itself never appears in the warning (or any log); the warning fires once per process; stdout (the protocol channel) is never touched.
- **Examples:** `ripwire . --listen 8080 --mcp-token=hunter2` → one warning, server starts; `RIPWIRE_MCP_TOKEN=hunter2 ripwire . --listen 8080` → no warning.
- **Consumers:** security-threatmodel-docs

### Consumes

None — root spec.

## Acceptance Criteria

1. **argv token warns**: run with `--mcp-token` against a fixture root on a free port. **Verifier:** `test/mcptokencheck.sh` arm (a) greps stderr for the pinned warning regex and asserts the token string `hunter2`-fixture never appears in stderr/stdout.
2. **env token silent**: same run with the env var instead. **Verifier:** arm (b) asserts no warning line and a successful authenticated request (curl with the Bearer header returns 200).
3. **Auth unchanged**: wrong/missing token still 401 in both channels. **Verifier:** arm (c) asserts 401s.
4. **Docs updated**: the reference docs mention the env channel first. **Verifier:** arm (d) greps the docs file for `RIPWIRE_MCP_TOKEN`.
5. **Gate registered**: in `test/regression.sh`; `./test/manifestcheck.sh` passes. **Verifier:** run it.

## Implementation Notes

- Keep the warning to one line; `mcpserver.h` already prints a loud banner for non-loopback binds — this warning belongs at startup config assembly, before the accept loop, and must not fire for stdio mode (no token there at all).
- The docs regenerate from the binary's `--help` where applicable; follow the existing doc-drift gates rather than hand-editing generated files.

## Failure Modes

### Warning fatigue on legitimate argv use
- **Trigger:** ephemeral local testing where ps exposure is acceptable.
- **Expected handling:** one line, once, no repetition per request; no opt-out flag (it is a warning, not a refusal).
- **Validator check:** arm (a) counts exactly one line.

### Token echoed in an error path
- **Trigger:** a startup failure message that prints config.
- **Expected handling:** no diagnostic prints the token value; gate arm (a) asserts absence.
- **Validator check:** arm (a) absence grep.

## Dependencies

None.

## Consumers

- **Spec:** security-threatmodel-docs — documents the recommended token channel and the warning's meaning. **Constraints:** renaming the env var or the flag breaks the doc's verbatim guidance.

## Status

**Status:** planned
**Last updated:** 2026-09-14T07:45:00+01:00
**Updated by:** spec-architect@2.0.0 (planning; provisional — manifest not locked)

## Validation Strategy

Tier 1 — focused testing sufficient. Components assessed: startup config assembly (a boolean provenance check — focused arms (a)/(b) cover both channels), the warning emitter (single-line, value-free — arm (a) covers), and the unchanged auth path (arm (c) covers). No PBT-suitable component identified: no input parsing, no crypto, no state machine.

## Progress Tracking

- [ ] Phase 1: Token-provenance tracking in flag parsing + one-line startup warning
- [ ] Phase 2: Docs and --help recommendation updated; doc-drift gates green
- [ ] Phase 3: test/mcptokencheck.sh arms (a)–(d), registered in regression.sh
