# Audit Validation (Standalone)

## Header

```yaml
id: audit-validation-standalone
type: validation
version: 1.0.0
manifest: ../../manifest.yml
# TYPE EXTENSION NOTICE: `validation` is not a type defined by SPEC_FORMAT.md
# v1.0 (which allows only unit|integration). The operator explicitly approved
# this extension on 2026-09-14 during DAG review. Recorded per the spec-architect
# compatibility rule; if the framework's PROJECT_MANIFEST.md later defines a
# conflicting validation contract, this spec conforms to that, not to this draft.
```

## Objective

Produce the single trust artifact answering "did the audit fixes actually land, and is the evidence real?" — an independent validation pass over the four Tier-2 security specs' PBT evidence bundles and the integration spec's adversarial regression report, issuing a mechanical ship / do-not-ship verdict. This exists as its own DAG node (rather than folding into review) because five distinct security contracts need cross-component evidence checking that no unit gate performs.

## Scope

**In scope:**
- A validation checklist + harness (`specs/audit-validation-standalone/run/` at execution time) that mechanically verifies: each Tier-2 evidence bundle exists at its declared path, contains the named properties with case counts and seeds, and shows `result=pass`; each property list includes the required negative property (e.g. edit pin's `¬inside ⇒ refused ∧ bytes unchanged`); the regression report's five attack rows are all `repelled` with shape-exact matches.
- Re-execution spot-checks: the validator re-runs a sampled subset (≥10%) of each bundle's cases from their committed seeds and asserts identical results (evidence is reproducible, not just present).
- The verdict rule, mechanical: `ship` iff (all four blocking-gate units carry validator approval) ∧ (all five attack rows repelled) ∧ (all PBT spot-checks reproduce); else `do-not-ship` with the failing items named.
- The validation report itself (below).

**Out of scope:**
- Re-auditing the whole codebase (the 2026-09-14 audit is the scope boundary; new code outside the five contracts is not re-reviewed here).
- Approving the accessibility/docs/specs with `none` gates (their producer evidence suffices by DAG design).
- Any claim of absolute security — the report states what was checked, over what domains, with what seeds.

## Interfaces

### Produces

#### validationReport
- **Shape:** `specs/audit-validation-standalone/report/validation-report.md` with pinned sections: bundle inventory (spec id, path, properties, case counts, seeds, results), spot-check reproduction table (case id, seed, reproduced y/n), regression-report row restatement, verdict line (`VERDICT: ship` / `VERDICT: do-not-ship — <reasons>`), and an explicit scope-and-limits paragraph.
- **Location:** committed under this spec's directory at validation time.
- **Invariants:** no `ship` verdict exists without all blocking approvals and all repelled rows recorded; every number in the report traces to a raw log committed beside it; the verdict rule is the one in Scope, applied mechanically.
- **Examples:** a failing spot-check row ⇒ `VERDICT: do-not-ship — pbtEvidenceBundle(edit-workspace-pin) case 417 failed reproduction`.
- **Consumers:** none — deployment-facing leaf (the operator's release decision; declared in manifest).

### Consumes

#### pbtEvidenceBundle (×4)
- **From:** regex-screen-hardening, edit-workspace-pin, atomic-write-tempfile, git-porcelain-framing
- **Shape:** `specs/<id>/evidence/` with property source, seeds, case counts, result logs (each unit spec's Produces pins the header format).
- **Usage:** inventory verification + seeded re-execution of a ≥10% sample.

#### auditRegressionReport
- **From:** security-regression-integration
- **Shape:** five attack rows + suite-invariant trailers, `repelled` verdicts requiring shape-exact matches.
- **Usage:** row verification and restatement.

#### patternAdmission / editPathAdmission / atomicPublish / gitRecordFraming
- **From:** the four Tier-2 unit specs
- **Shape:** the behavioral contracts as declared in each spec's Interfaces.
- **Usage:** the validator checks the evidence actually exercises these contracts (not adjacent behavior), and the negative properties are present.

## Acceptance Criteria

1. **Bundle inventory enforced**: running the harness with a missing or malformed bundle fails that spec's row. **Verifier:** `run/inventorycheck.sh` against a fixture with one bundle deleted asserts the row failure and a `do-not-ship` verdict.
2. **Seeded reproduction real**: spot-check re-execution of ≥10% of each bundle's cases reproduces the committed results. **Verifier:** the harness's own log shows the sampled case ids and `reproduced=y` for each; a tampered-log fixture (one edited case) is caught by arm (2b) with a named mismatch.
3. **Verdict rule mechanical**: with all inputs green the verdict is exactly `VERDICT: ship`; with any named failure it is `do-not-ship` and names it. **Verifier:** fixtures for both branches, asserted by grep on the exact verdict strings.
4. **Negative properties present**: each Tier-2 bundle's property list contains its negative/access-denial property (for edit-workspace-pin: the unauthorized-implies-denied form). **Verifier:** arm (d) greps the bundle property manifests.
5. **Scope honesty**: the report contains the scope-and-limits paragraph and makes no absolute-security claim. **Verifier:** arm (e) presence/absence greps.
6. **Report committed**: the report and all raw logs exist at the declared paths. **Verifier:** arm (f) path existence + non-empty checks.

## Implementation Notes

- The validator role must be a *different interpreter* than any producer per the framework's distinctness rule; since interpreter configuration is a recorded gap (framework files missing), the manifest lists validators as unassigned and this spec's executor must still not be the producer of the specs it validates — record who ran what in the report header.
- Keep the harness POSIX shell + the repo's own binary only (house rule G3); the seeded PBT re-runs invoke each spec's committed harness with `--seed`/`--cases` arguments those harnesses must document in their evidence READMEs.
- This spec does not gate the HTML/docs work; those are `none`-gated by operator-approved DAG design and say so in the report's scope paragraph.

## Failure Modes

### Evidence theater (logs present, never run)
- **Trigger:** a bundle hand-written rather than produced.
- **Expected handling:** the seeded re-execution arm (2) — evidence must reproduce from seeds, which fabrication cannot survive.
- **Validator check:** arm (2b)'s tamper fixture proves detection works.

### Verdict pressure
- **Trigger:** a failing row hand-edited to `repelled`.
- **Expected handling:** rows are restated from the regression report by the harness, not copied by hand; a mismatch between the source report and the restated row fails arm (3).
- **Validator check:** tamper fixture.

### Scope creep into re-audit
- **Trigger:** new code appears outside the five contracts during execution.
- **Expected handling:** the report's scope paragraph names the audit boundary; anything new is recorded as out-of-scope observation, not silently validated or silently ignored.
- **Validator check:** arm (e).

## Dependencies

- **Specs:** regex-screen-hardening, edit-workspace-pin, atomic-write-tempfile, git-porcelain-framing — provide the contracts and the evidence bundles under validation. **What breaks if they change:** bundle paths, property names, or header formats renamed without updating this harness.
- **Spec:** security-regression-integration — provides the composition report. **What breaks if it changes:** the report row schema.

## Consumers

None — deployment-facing leaf (the operator's release decision). Declared in the manifest.

## Status

**Status:** planned
**Last updated:** 2026-09-14T07:45:00+01:00
**Updated by:** spec-architect@2.0.0 (planning; provisional — manifest not locked)

## Validation Strategy

This spec IS the standalone validation node. Tier assignment is not self-applicable; its own harness code is Tier 1 (shell checks, seeded re-execution drivers — focused testing). The Tier 2 burden it *administers*: property-based evidence for the four security-critical contracts (input validation, access control, filesystem write safety, adversarial parsing), each with positive and negative properties, named input domains, ≥10k/5k/2k/20k case budgets respectively, and seeded reproducibility. The report must state that PBT over generated domains is evidence, not proof of absolute security.

## Progress Tracking

- [ ] Phase 1: Harness skeleton — inventory check + verdict rule + report emitter
- [ ] Phase 2: Seeded spot-check re-execution drivers for the four bundles
- [ ] Phase 3: Tamper fixtures (deleted bundle, edited log, hand-edited row) proving detection
- [ ] Phase 4: Live run against completed bundles + committed validation-report.md
