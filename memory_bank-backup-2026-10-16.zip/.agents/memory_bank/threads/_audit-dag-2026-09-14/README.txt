PROVISIONAL DRAFT — spec-architect@2.0.0 output — 2026-09-14
Project: ripwire-audit-remediation (addresses the 2026-09-14 audit of redhat-et/ripwire @ c1915d21)

This package is a PLANNING ARTIFACT, not committed code. The operator approved
the DAG on 2026-09-14; the drafted specs inside await operator review. The
manifest is NOT locked and MUST NOT be treated as executing: the Orion-OS
framework contracts (PROJECT_MANIFEST.md et al.) were unavailable, so the
manifest schema is provisional and one operator-approved type extension
(`validation`) is recorded in the manifest header.

Layout:
  manifest.yml                  provisional project DAG
  specs/<spec-id>/spec.md       13 spec files (SPEC_FORMAT.md v1.0 headings +
                                v2 Validation Strategy / Progress Tracking)
  specs/_selfcheck.py           the machine-run invariant checker (all pass)
