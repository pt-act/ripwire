# Atomic Write Tempfile Hardening

## Header

```yaml
id: atomic-write-tempfile
type: unit
version: 1.0.0
manifest: ../../manifest.yml
```

## Objective

Make the MCP edit publish path's temp file immune to pre-placed symlinks and stale reuse, closing audit finding #3 (Medium). `mcpedit.h` `atomicWrite` (~L716) currently builds `<path>.<pid>.tmp` — a predictable name in a potentially shared directory — and opens it `O_WRONLY | O_CREAT | O_TRUNC` with no `O_NOFOLLOW` and no `O_EXCL`, the one writer in the tree that `pathguard.h`'s atomic-open treatment never reached.

## Scope

**In scope:**
- `atomicWrite()` in `src/mcpedit.h`: create the temp with `O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC`, route the open through the `pathguard.h` helper family so the rule keeps living in one place, and on `EEXIST` retry with a bounded counter suffix (`<path>.<pid>.<n>.tmp`) rather than truncating a stranger's file.
- Defined stale-temp behavior: a leftover temp from a crashed run is never silently truncated-and-reused; either unlinked after ownership checks or sidestepped by the counter.
- Preservation of the existing contract: mode restore from the original file, `fsync` before rename, cleanup of the temp on every failure path.
- A new gate `test/editwritecheck.sh` (or new arms on the existing sidecar/edit gates, per house convention) registered in `test/regression.sh` in the same commit.

**Out of scope:**
- The three sidecar writers already converted to `openNoFollowTruncate` (done pre-audit; do not rework).
- Hard-link/xattr carry-over across rename — already documented as an honest limit in `mcpedit.h`; unchanged.
- Cross-filesystem temp placement (temp stays beside the target so `rename(2)` stays atomic).

## Interfaces

### Produces

#### atomicPublish
- **Shape:** `bool atomicWrite( const std::string& path, const std::string& bytes )` — publishes `bytes` to `path` via a freshly created temp in the same directory + atomic rename. New guarantees: the temp open never follows a symlink (`O_NOFOLLOW`), never reuses an existing entry (`O_EXCL` with bounded retry), and on any failure the target and any foreign file are byte-untouched.
- **Location:** `src/mcpedit.h`; helper shared with `src/pathguard.h`.
- **Invariants:** temp name is unpredictable enough in practice (pid + counter, created exclusively); a pre-existing symlink at the temp name causes refusal/cleanup, never a follow; mode-restore and fsync-before-rename are preserved; no path through the function writes to any file other than the temp it created and the rename target.
- **Examples:** pre-create `target.py.<pid>.1.tmp` as a symlink to `victim.txt`, then run an edit: the publish fails (or retries past the planted names), `victim.txt` is byte-identical, and the edit reports failure honestly.
- **Consumers:** security-regression-integration, audit-validation-standalone

#### pbtEvidenceBundle
- **Shape:** directory `specs/atomic-write-tempfile/evidence/` with property-test source, seeds, logs.
- **Location:** committed beside this spec at execution time.
- **Invariants:** includes the race-arm results and the mode/xattr preservation checks; logs unedited.
- **Examples:** `evidence/pbt-atomic-write.log` header `cases=2000 seed=… result=pass`.
- **Consumers:** audit-validation-standalone

### Consumes

None — root spec. (Reuses `rw::pathguard` predicates — pre-existing code, not a spec-produced interface.)

## Acceptance Criteria

1. **Symlink pre-placement loses safely**: a fixture script predicts the temp name (pid observable), plants a symlink to a victim file, then drives an edit through the MCP stdio loop. **Verifier:** the new gate asserts the victim's sha256 is unchanged, the target file is either unchanged or correctly edited (never a follow-through), and stderr/receipt discloses the failure or the retry.
2. **Exclusive create**: `strace`/`fs_usage` or an `LD_PRELOAD` open-log on the edit path shows `O_EXCL | O_NOFOLLOW` on the temp open. **Verifier:** gate arm greps the syscall log for the flags on the `.tmp` path.
3. **Stale temp not clobbered**: pre-create a regular file at the would-be temp name with sentinel content; run an edit. **Verifier:** sentinel file's content survives (retry-suffix path taken) and the edit succeeds on a fresh name.
4. **Mode preservation regression-free**: editing an executable file keeps its mode bits (existing A3-F7 behavior). **Verifier:** the existing edit-mode gate arm still passes under `python3 test/pargates.py . ./build/ripwire -j 6`.
5. **Durability order preserved**: fsync precedes rename in the published path. **Verifier:** code-inspection assertion in the gate (ordered grep of the fsync/rename calls) plus the existing crash-durability arms.
6. **Gate registered**: registered in `test/regression.sh`; `./test/manifestcheck.sh` passes. **Verifier:** run it.

## Implementation Notes

- `pathguard.h`'s header comment explains the exact CWE-59 mechanism and why the rule must live in one header — extend that home rather than open-coding flags in `mcpedit.h`.
- `O_EXCL` + counter retry is preferred over unlink-then-recreate, which would reintroduce a check-then-act window.
- The pid is visible to local processes, so unpredictability comes from exclusive creation, not secrecy; the counter bounds worst-case work when many stale temps exist (cap retries, then refuse honestly).

## Failure Modes

### Attacker plants every pid-predicted name
- **Trigger:** a local process pre-creates `<target>.<pid>.*.tmp` for all counter values.
- **Expected handling:** after the bounded retry count, refuse with a named error; nothing is truncated.
- **Validator check:** gate arm with the full counter range planted asserts refusal + victim intact.

### Crash leaves a temp behind
- **Trigger:** process death between temp create and rename.
- **Expected handling:** the next edit does not truncate the leftover (`O_EXCL`); leftover may accumulate until swept — documented.
- **Validator check:** arm 3 of the gate.

### Non-POSIX build target
- **Trigger:** the project targets macOS/Linux only; `O_NOFOLLOW` is POSIX and present on both (pathguard.h already relies on it).
- **Expected handling:** no portability scaffolding is added; a compile error on an unsupported target is the honest failure.
- **Validator check:** CI build matrix green.

## Dependencies

None.

## Consumers

- **Spec:** security-regression-integration — needs the final temp-name pattern and failure disclosure text to write assertions. **Constraints:** renaming the pattern or the alert text breaks its greps.
- **Spec:** audit-validation-standalone — needs the evidence bundle at the declared path.

## Status

**Status:** planned
**Last updated:** 2026-09-14T07:45:00+01:00
**Updated by:** spec-architect@2.0.0 (planning; provisional — manifest not locked)

## Validation Strategy

Tier 2 — property-based testing required (security-sensitive filesystem state transition; external write boundary).

- **Components requiring PBT:** `atomicWrite()` temp-name generation, open flags, retry loop, and cleanup paths.
- **Formal properties:**
  - ∀ target t, ∀ pre-existing directory entries E: `publish(t, bytes)` writes to no path outside {fresh temp it created, t}; in particular ∀ e ∈ E that is a symlink, its referent's bytes are unchanged.
  - ∀ failures f in {open, write, fsync, rename}: after `publish` fails with f, t holds its original bytes and no temp owned by this call remains (cleanup) or the leftover is documented and never reused.
  - ∀ successful publishes: `read(t)` after return equals `bytes` (atomicity: no torn intermediate state observable).
- **Input domains:** randomized directory states (stale temps, planted symlinks, permission-denied dirs), randomized payloads (empty, binary, 8 MiB), planted-name collisions across the counter range.
- **Case budget:** ≥2,000 randomized publishes, plus the deterministic race arms.
- **Evidence bundle:** `specs/atomic-write-tempfile/evidence/`. PBT is evidence over the generated domain, not a proof of absolute security.

## Progress Tracking

- [ ] Phase 1: Exclusive no-follow temp open via pathguard + bounded counter retry
- [ ] Phase 2: Stale-temp policy implemented and documented
- [ ] Phase 3: Gate arms (symlink race, syscall flags, stale temp, mode/durability regressions), registered
- [ ] Phase 4: PBT harness + evidence bundle; sanitizer build (`-DRIPWIRE_ASAN=ON`) clean
