# Security Threat-Model Documentation

## Header

```yaml
id: security-threatmodel-docs
type: unit
version: 1.0.0
manifest: ../../manifest.yml
```

## Objective

Write down the security posture the audit had to reverse-engineer, closing finding #15's documentation gap and the audit's residual notes: the HTTP transport's single-threaded head-of-line posture and "token is a tripwire" model, the prompt-injection reality of serving adversarial repo content to agents, the markitdown supply-chain note, and the edit-verb trust tiers (including the new assumedRoot pin from edit-workspace-pin).

## Scope

**In scope:**
- A new `docs/SECURITY-MODEL.md` (or a major `SECURITY.md` extension — producer picks per repo convention; the file must be linked from `README.md` and `SECURITY.md`) covering, as named sections: (1) trust model of stdio vs HTTP MCP transports incl. single-threaded head-of-line blocking and the accepted slow-client DoS residual; (2) the bearer token's tripwire status, the env-var-first guidance, and the argv warning (consumes tokenWarningContract); (3) edit-verb trust tiers — pinnedRoot / defaultRoot / assumedRoot / escape hatch (consumes editPathAdmission); (4) adversarial-repo posture: what ripwire neutralizes (fsmonitor hooks, clone transports, symlink escapes) and what it deliberately does not (prompt-injection content aimed at the consuming agent, markitdown parsing untrusted binary docs — consumes docBridgePolicy); (5) how to report a vulnerability (pointer to SECURITY.md).
- A `test/securitydoccheck.sh` drift gate: asserts the named sections exist and that the flag/env names it quotes match the binary's `--help` (the repo's own "docs must not drift from the binary" rule, per `AGENTS.md`).
- Registered in `test/regression.sh` in the same commit.

**Out of scope:**
- Marketing-style security claims; this document states mechanisms and residuals, in the repo's existing honest-output voice.
- Restating the README's feature documentation.
- A formal threat-model framework (STRIDE etc.) — a clear prose contract serves the project better than ceremony.

## Interfaces

### Produces

#### threatModelDoc
- **Shape:** `docs/SECURITY-MODEL.md` with the five named sections above, every referenced flag/env var spelled exactly as the binary spells it, and a "residuals we accept" subsection per transport.
- **Location:** `docs/SECURITY-MODEL.md`, linked from `README.md` and `SECURITY.md`.
- **Invariants:** every command/flag/env var quoted in the doc is asserted against `--help` or the source by the drift gate; no claim in the doc contradicts a measured posture (e.g. it must not call the token an authentication boundary).
- **Examples:** section 2 contains `RIPWIRE_MCP_TOKEN` and the argv-warning text's key phrase; section 3 names all three edit trust tiers and the escape hatch.
- **Consumers:** none — documentation-facing leaf (declared).

### Consumes

#### tokenWarningContract
- **From:** mcp-token-hygiene
- **Shape:** the argv-warning's pinned message regex and the env-var channel name.
- **Usage:** section 2 quotes the warning's meaning and the recommended channel verbatim.

#### docBridgePolicy
- **From:** markitdown-bridge-hardening
- **Shape:** the opt-out flag/env names and the resolver's world-writable refusal.
- **Usage:** section 4's markitdown paragraph states exactly how to disable the bridge and what the tool does/doesn't trust about it.

#### editPathAdmission
- **From:** edit-workspace-pin
- **Shape:** the four-tier pin policy (pinnedRoot / defaultRoot / assumedRoot / escape hatch) and refusal shapes.
- **Usage:** section 3 documents the tiers and the bare-server behavior verbatim.

## Acceptance Criteria

1. **Document exists with all five sections**: `docs/SECURITY-MODEL.md` present, linked from README and SECURITY.md. **Verifier:** `test/securitydoccheck.sh` arm (a) greps for the five section anchors and the two inbound links.
2. **No drift in quoted names**: every `RIPWIRE_*` env var and `--*` flag quoted in the doc appears in `./build/ripwire --help` or `grep -rn getenv src/`. **Verifier:** arm (b) extracts backticked tokens from the doc and asserts each against the binary/help output.
3. **Honest posture wording**: the doc never calls the bearer token an authentication boundary and does name the reverse-proxy TLS posture. **Verifier:** arm (c) presence/absence greps for the pinned phrases.
4. **Pin tiers match the code**: the doc's tier list matches the policy struct's fields. **Verifier:** arm (d) greps `src/mcp.h` for `pinnedRoot`/`defaultRoot`/`assumedRoot` and the doc for the same three names.
5. **Gate registered**: in `test/regression.sh`; `./test/manifestcheck.sh` passes. **Verifier:** run it.

## Implementation Notes

- The repo's writing voice is direct and mechanism-first ("the token is a tripwire, not a security boundary" is already the transport's own banner) — match it; no reassurance language.
- SECURITY.md (vulnerability reporting) already exists; this doc links to it rather than duplicating it.
- Prompt-injection section: state plainly that ripwire serves adversarial repo text to agents and that content-level filtering is out of the tool's power; point at the edit-pin tiers as the control that exists.

## Failure Modes

### Doc rots as flags evolve
- **Trigger:** a rename in a later change.
- **Expected handling:** arm (b) fails — the drift gate is the whole point.
- **Validator check:** run the gate.

### Overclaiming
- **Trigger:** wording that implies guarantees the code doesn't provide.
- **Expected handling:** arm (c)'s absence greps plus review; the doc quotes mechanisms, not adjectives.
- **Validator check:** arm (c).

### Duplication drifts against mcpserver.h's banner
- **Trigger:** banner text edited later.
- **Expected handling:** the doc references the banner's posture in prose without pinning its full text; only short phrases are grep-pinned.
- **Validator check:** arm (c) uses short stable phrases.

## Dependencies

- **Spec:** mcp-token-hygiene — provides the final warning wording and env-var name for section 2. **What breaks if it changes:** section 2's quoted names.
- **Spec:** markitdown-bridge-hardening — provides the flag/env names for section 4. **What breaks if it changes:** section 4's disable instructions.
- **Spec:** edit-workspace-pin — provides the tier policy for section 3. **What breaks if it changes:** the tier list and escape-hatch name.

## Consumers

None — documentation-facing leaf (declared in manifest).

## Status

**Status:** planned
**Last updated:** 2026-09-14T07:45:00+01:00
**Updated by:** spec-architect@2.0.0 (planning; provisional — manifest not locked)

## Validation Strategy

Tier 1 — focused testing sufficient. Components assessed: the document itself (static text — drift-gate arms cover), its link graph (arm (a)), and its name accuracy (arms (b)/(d)). No PBT-suitable component identified.

## Progress Tracking

- [ ] Phase 1: Draft docs/SECURITY-MODEL.md with all five sections against the consumed contracts
- [ ] Phase 2: README/SECURITY.md inbound links
- [ ] Phase 3: test/securitydoccheck.sh arms (a)–(d), registered; full suite green
