# Edit Workspace Pin

## Header

```yaml
id: edit-workspace-pin
type: unit
version: 1.0.0
manifest: ../../manifest.yml
```

## Objective

Extend the MCP edit-verb workspace pin so that a bare stdio server (`ripwire --mcp`, no startup root) confines the three write verbs to the launch directory tree, closing audit finding #2 (Medium). Today the X7 gate at `src/mcp.h` ~L1143 fires only when `defaultRoot` (startup root) or `pinnedRoot` (HTTP) is set, so the most common server configuration — the bare one every `wrap`-generated MCP recipe produces — applies no pin at all.

## Scope

**In scope:**
- The gate condition in `src/mcp.h` (~L1143, the `if( !pathsUsageError && policy.pinnedRoot.empty() && !policy.defaultRoot.empty() )` block) extended so a non-empty `assumedRoot` (the canonicalized launch cwd, R2a) also pins the three edit verbs.
- The refusal sentence in `src/mcprefusal.h` for the new tier, distinct from the startup-root wording (the assumed root was inferred, and the refusal must say so).
- An explicit operator escape hatch (advisory: a `--allow-edits-beyond-root`-style flag — final name must follow the binary's `--help` conventions) that restores today's unpinned behavior for users who want it.
- A new gate `test/mcpeditpincheck.sh` registered in `test/regression.sh` in the same commit.
- `docs/COMMANDS.md`/`--help` regeneration if the flag surface changes (`--help` is generated from the binary; per `AGENTS.md`, the doc follows the binary).

**Out of scope:**
- Read-verb path freedom (the documented stdio contract "a request may name ANY path" stays for reads).
- The HTTP transport's existing `pinnedRoot` behavior (already refuses off-workspace edits).
- Any prompt-injection content filtering of served source (documented as a threat-model note by security-threatmodel-docs instead).

## Interfaces

### Produces

#### editPathAdmission
- **Shape:** policy contract — for a `tools/call` to one of `replace_symbol_body`, `insert_before_symbol`, `insert_after_symbol` with argument `path`: if `policy.pinnedRoot` or `policy.defaultRoot` is non-empty, current behavior applies unchanged; else if `policy.assumedRoot` is non-empty, `mcpPathInsideRoot( policy.assumedRoot, path )` must hold or the call is refused with the new JSON-RPC error and **no index build and no byte written**; the escape-hatch flag disables only the assumedRoot tier.
- **Location:** `src/mcp.h` dispatch chain (X7/R2a region) and `src/mcprefusal.h` (wording).
- **Invariants:** refusal precedes `getIndex()`; refusal shape matches the existing `-32602` "path outside workspace" family; read verbs are unaffected on every tier; when `assumedRoot` is empty (launch cwd is `/` or `$HOME`, per `mcpResolveAssumedRoot`), bare-server edits are refused outright.
- **Examples:** server started bare in `/repo`: `replace_symbol_body` with `path:"/repo"` ⇒ allowed; with `path:"/tmp/other"` ⇒ refused, file byte-identical; same call with the escape-hatch flag ⇒ allowed.
- **Consumers:** security-regression-integration, audit-validation-standalone, security-threatmodel-docs

#### pbtEvidenceBundle
- **Shape:** directory `specs/edit-workspace-pin/evidence/` with property-test source, seeds, and result logs.
- **Location:** committed beside this spec at execution time.
- **Invariants:** contains the negative access-control property's pass log; no edited logs.
- **Examples:** `evidence/pbt-edit-pin.log` header `cases=5000 seed=… result=pass`.
- **Consumers:** audit-validation-standalone

### Consumes

None — root spec. (Reads the existing `McpDispatchPolicy` tiers and `mcpPathInsideRoot` — pre-existing code, not spec-produced interfaces.)

## Acceptance Criteria

1. **Bare-server escape refused**: start `ripwire --mcp` (no root) in fixture dir A; `tools/call` `analyze` then `replace_symbol_body` against fixture dir B's file. **Verifier:** `test/mcpeditpincheck.sh` arm (a) asserts the JSON-RPC error code `-32602`, the inferred-root wording, and `sha256sum` of B's file unchanged across the call.
2. **Bare-server in-tree edit still works**: same server, edit a symbol under the launch cwd. **Verifier:** arm (b) asserts `applied=true` receipt and the file's new bytes match the expected splice.
3. **Omitted path still rebinds**: a read verb with no `path` on the bare server returns the `_assumed_root` disclosure (R2a behavior preserved). **Verifier:** arm (c) greps the envelope for `_assumed_root`.
4. **Startup-root and HTTP tiers unchanged**: existing pin gates pass unmodified. **Verifier:** the pre-existing MCP pin/refusal gate scripts pass under `python3 test/pargates.py . ./build/ripwire -j 6`.
5. **Escape hatch restores old behavior**: with the new flag, the arm-(a) call succeeds. **Verifier:** arm (d).
6. **Rootless launch refuses edits**: server launched with cwd `/` refuses any edit with the named refusal (no silent pin to `/`). **Verifier:** arm (e).
7. **Gate registered**: `test/mcpeditpincheck.sh` in `test/regression.sh`; `./test/manifestcheck.sh` passes. **Verifier:** run it.

## Implementation Notes

- The smallest correct change is widening the gate condition to also fire when `assumedRoot` is set, then routing the refusal through `mcprefuse` so the wording says the root was *inferred from the launch directory* — the honesty rule (an assumed answer says it assumed) applies to refusals too.
- The incident class this closes is prompt-injection steering an agent into editing a tree the user never opened; the docs spec records the residual (a determined agent can still ask the user to restart with a flag).
- Keep `isMcpEditVerb` as the single source of "which verbs write" — do not re-enumerate the three names in the new condition.

## Failure Modes

### Legitimate cross-tree edit workflow breaks
- **Trigger:** a user who runs the bare server in `$HOME/src` and intentionally edits a sibling checkout.
- **Expected handling:** the refusal names the escape-hatch flag; the flag restores the behavior explicitly.
- **Validator check:** arm (d) and a docs grep for the flag name.

### Symlinked launch cwd defeats a string comparison
- **Trigger:** cwd reached through a symlink (`/tmp` vs `/private/tmp` on macOS).
- **Expected handling:** the pin compares through `mcpCanonRoot`/`mcpPathInsideRoot` (realpath on both sides) — reuse, never a new string-prefix check.
- **Validator check:** arm with a symlinked cwd path asserts containment still resolves.

### Assumed root empty
- **Trigger:** launch cwd is `/` or `$HOME`.
- **Expected handling:** edits refuse with the named refusal; reads fall through to the existing missing-path behavior.
- **Validator check:** arm (e).

## Dependencies

None.

## Consumers

- **Spec:** security-regression-integration — needs the exact refusal code/wording and the no-index-build side-effect to assert. **Constraints:** message or code changes break its greps.
- **Spec:** audit-validation-standalone — needs the evidence bundle at the declared path.
- **Spec:** security-threatmodel-docs — documents the final policy tiers verbatim. **Constraints:** tier renames or flag renames must be reflected in the doc.

## Status

**Status:** planned
**Last updated:** 2026-09-14T07:45:00+01:00
**Updated by:** spec-architect@2.0.0 (planning; provisional — manifest not locked)

## Validation Strategy

Tier 2 — property-based testing required (authorization / access-control boundary).

- **Components requiring PBT:** the extended pin gate in `src/mcp.h` and `mcpPathInsideRoot()` as used by it.
- **Formal properties:**
  - ∀ verb v ∈ EditVerbs, ∀ path p: `¬inside(canonRoot, canon(p))` ⇒ `refused(v, p)` ∧ `bytes(p) unchanged` ∧ `no index build`. (Negative property — unauthorized implies denied — required, not just the positive direction.)
  - ∀ verb v ∈ EditVerbs, ∀ path p: `inside(canonRoot, canon(p))` ∧ freshness holds ⇒ edit proceeds exactly as pre-change.
  - ∀ v ∈ ReadVerbs: admission behavior identical to pre-change on every tier.
- **Input domains:** generated paths — in-tree, sibling, parent, prefix-sibling (`/repo` vs `/repo-foo`), symlinked spellings, `..`-carrying spellings, relative spellings; all three root-policy tiers × all edit verbs × escape-hatch on/off.
- **Case budget:** ≥5,000 generated (verb, path, tier, flag) tuples against a fixture pair of directories.
- **Evidence bundle:** `specs/edit-workspace-pin/evidence/` with source, seeds, logs. PBT evidences the boundary over the generated domain; it is not a proof of absolute security.

## Progress Tracking

- [ ] Phase 1: Gate condition extended to assumedRoot + refusal wording in mcprefusal.h
- [ ] Phase 2: Escape-hatch flag parsed, documented in --help, docs regenerated
- [ ] Phase 3: test/mcpeditpincheck.sh arms (a)–(e), registered in test/regression.sh
- [ ] Phase 4: PBT harness + evidence bundle; full pargates + determinism runs logged
