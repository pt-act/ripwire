# Regex Screen Hardening

## Header

```yaml
id: regex-screen-hardening
type: unit
version: 1.0.0
manifest: ../../manifest.yml
```

## Objective

Make it impossible for a `--regex=` / MCP `grep` pattern to run unbounded backtracking on any supported platform, by extending the admission screen in `src/search.h` to the ambiguous-alternation family and adding a hard per-file match budget with a disclosed degrade. This closes audit finding #1 (High), the audit's only High — one request must never be able to wedge a worker thread or the single-threaded MCP HTTP server.

## Scope

**In scope:**
- `catastrophicRegexConstruct()` in `src/search.h` (~L1311) and its call site (~L1405): extend the refusal beyond the inner-quantifier family to groups whose alternation branches can match the same prefix (conservatively: any group containing a top-level `|` alternation that carries an outer unbounded quantifier `*`, `+`, or `{n,}`), reusing the existing `catastrophicRegexMessage()` refusal shape.
- A per-file match budget around the per-line `std::cregex_iterator` loop (~L1097): a wall-clock or step ceiling after which the file is skipped via the existing `DEGRADED_PATH_ALERT` channel (the `catch( const std::regex_error& )` arm at ~L1111 is the model), so libstdc++ — which never throws `error_complexity` — is still bounded.
- A new gate `test/regexbombcheck.sh` registered in `test/regression.sh` in the same commit (per `AGENTS.md`, or `test/manifestcheck.sh` fails).
- `--help`/docs wording for the widened refusal, if the user-facing message changes.

**Out of scope:**
- Replacing the `std::regex` engine or adding a dependency (G3 zero-dependency constraint is binding; RE2 or similar is a future, separate decision).
- Multiline match support or any change to the line-oriented match contract documented at `src/search.h` ~L1387.
- The literal (non-regex) search path, which has no backtracking surface.

## Interfaces

### Produces

#### patternAdmission
- **Shape:** `std::optional<std::string> catastrophicRegexConstruct( const std::string& pat )` — `std::nullopt` = admit, `std::string` = refuse with user-facing reason. Post-change verdict additionally covers: any group containing a top-level `|` under an unbounded outer quantifier ⇒ refuse.
- **Location:** `src/search.h`, called from the grep entry point (~L1405) and thus by both the CLI `--regex=` verb and the MCP `grep` tool on both transports.
- **Invariants:** every previously refused pattern (`(a+)+`, `(a?)+`, `(a{1,3})+`, `((a+))+` family) remains refused with a message naming the construct; admitted patterns are unchanged semantically; the verdict is a pure function of the pattern string.
- **Examples:** `^(a|aa)+b$` ⇒ refused, message names the ambiguous alternation; `^(ab|cd)+e$` ⇒ refused (branches differ but the conservative rule refuses any alternation under unbounded quantifier); `foo.*bar` ⇒ admitted; `(abc)+` ⇒ admitted (no alternation).
- **Consumers:** security-regression-integration, audit-validation-standalone

#### matchBudgetDegrade
- **Shape:** behavioral contract — during per-line verification, when the budget for a file is exceeded, matching stops for that file, one `DEGRADED_PATH_ALERT( "grep: regex match budget exceeded — file skipped" )`-shaped line is emitted, hits collected so far are kept, and the run continues with the next file.
- **Location:** the `try/catch` region around the `std::cregex_iterator` loop in `src/search.h` (~L1090–L1115).
- **Invariants:** a run over an adversarial corpus always terminates; the degrade is always disclosed (never a silent partial result); the literal path never budgets.
- **Examples:** `--regex='^(a|aa)+b$'` over a fixture file with a 200-byte all-`a` line completes and reports a disclosed skip rather than hanging.
- **Consumers:** security-regression-integration, audit-validation-standalone

#### pbtEvidenceBundle
- **Shape:** directory `specs/regex-screen-hardening/evidence/` containing the property-test source, the seed list, and the raw pass/fail log.
- **Location:** committed beside this spec (evidence is produced at execution time; the bundle path is the contract).
- **Invariants:** every property in §Validation Strategy appears with its case count and result; failures are never edited out of the log.
- **Examples:** `evidence/pbt-regex-screen.log` with a header line `cases=10000 seed=… result=pass`.
- **Consumers:** audit-validation-standalone

### Consumes

None — root spec.

## Acceptance Criteria

1. **Alternation family refused**: a fixture corpus `test/fixtures/rebomb/` containing one file whose single line is 200 `a` bytes; running `timeout 60 ./build/ripwire test/fixtures/rebomb --regex='^(a|aa)+b$'` exits before the timeout and the pattern is refused with a message naming the alternation construct. **Verifier:** `test/regexbombcheck.sh` arm (a) asserts refusal text on stderr and wall time < 60 s.
2. **Budget degrade disclosed**: with the admission screen deliberately bypassed in a test build (or a budget-exceeding admitted pattern), the run emits the `DEGRADED_PATH_ALERT` skip line and continues to the next file. **Verifier:** `test/regexbombcheck.sh` arm (b) greps stderr for the alert and asserts exit code 0 and subsequent-file hits present in stdout.
3. **No refusal regression**: every pattern in the existing catastrophic-family gate arms is still refused. **Verifier:** the pre-existing grep/regex gate scripts pass unchanged under `python3 test/pargates.py . ./build/ripwire -j 6`.
4. **No admission regression**: a corpus of honest patterns (the ones exercised by the existing `--grep` gates, e.g. `escapeXml`, `TODO|FIXME` at top level — note top-level alternation with no group must NOT be refused) still match identically. **Verifier:** golden-output diff of the existing grep gate fixtures against pre-change output; byte-identical.
5. **Both standard libraries bounded**: the gate passes on libstdc++ (Linux CI) and libc++ (macOS CI). **Verifier:** CI logs for both platforms attached to the evidence bundle.
6. **Gate registered**: `test/regexbombcheck.sh` appears in `test/regression.sh`. **Verifier:** `./test/manifestcheck.sh` passes.
7. **Determinism preserved**: `./build/ripwire . > a; ./build/ripwire . > b; diff -q a b` is clean with and without regex runs in the mix. **Verifier:** commands from `AGENTS.md` run and logged in the evidence bundle.

## Implementation Notes

- The audit measured the live bypass: `^(a|aa)+b$` over a 34-byte non-matching line took 1.238 s under g++ 11.5/libstdc++ and grows ~2ⁿ — reuse `/data`-independent fixtures, not the audit sandbox's repro file.
- Prefer the conservative refusal (any top-level-`|` group under an unbounded outer quantifier) over prefix-overlap analysis; the existing message style already teaches the workaround ("collapse the two repetitions", "make the OUTER bounded"), extend it in the same voice.
- The budget can be a line count × pattern-cost heuristic or a `steady_clock` check per K lines; a clock check is simpler and platform-independent. Keep it out of the hot literal path.
- House style: Allman braces, spaces inside parens, no new headers without need; `DEGRADED_PATH_ALERT` for the degrade, never `VERIFY` on an input-dependent path (`AGENTS.md`).

## Failure Modes

### False-positive refusal of a legitimate pattern
- **Trigger:** a user pattern with alternation under an unbounded quantifier that would not backtrack catastrophically (e.g. `^(get|post)+$`).
- **Expected handling:** refuse with the same honest message shape naming the construct and the bounded-quantifier workaround; a refusal is a safe failure, a hang is not.
- **Validator check:** arm (a) of the gate asserts the refusal names the construct; the spec author must list the known false-positive class in the commit message.

### Budget trips on a slow-but-legitimate match
- **Trigger:** a very large file matched by a cheap pattern on a slow machine.
- **Expected handling:** the degrade discloses the skip; the budget constant is chosen so the existing gate corpus (incl. llvm-scale fixtures where available) never trips it — measured, not guessed.
- **Validator check:** evidence bundle includes the timing table for the gate corpus showing ≥10× headroom.

### Screen and budget disagree across standard libraries
- **Trigger:** libc++ throws `error_complexity` where libstdc++ hangs.
- **Expected handling:** both funnels (throw-catch and budget) produce the same disclosed-skip outcome.
- **Validator check:** CI logs on both platforms show the same alert text.

## Dependencies

None.

## Consumers

- **Spec:** security-regression-integration — needs the final refusal text and the degrade alert shape to write byte-precise assertions. **Constraints on evolution:** changing the message wording breaks its greps; version together.
- **Spec:** audit-validation-standalone — needs the evidence bundle at the declared path with the declared log header. **Constraints on evolution:** renaming `patternAdmission`'s signature or the evidence path breaks its manifest-closure check.

## Status

**Status:** planned
**Last updated:** 2026-09-14T07:45:00+01:00
**Updated by:** spec-architect@2.0.0 (planning; provisional — manifest not locked)

## Validation Strategy

Tier 2 — property-based testing required (input validation/sanitization of a hostile-controllable pattern language; security-sensitive availability boundary).

- **Components requiring PBT:** `catastrophicRegexConstruct()` (admission) and the per-line match loop's budget accounting in `src/search.h`.
- **Formal properties:**
  - ∀ pattern p: `refused(p)` ⇒ no match attempt occurs (no matcher invocation on p).
  - ∀ pattern p, line ℓ: `admitted(p)` ⇒ `match(p, ℓ)` terminates within the configured budget B, else the file is disclosed-skipped.
  - Negative/positive pair: ∀ p ∈ bomb corpus ⇒ `refused(p)`; ∀ p ∈ honest corpus ⇒ `admitted(p)` ∧ results byte-identical to pre-change.
  - ∀ p: verdict is deterministic — `admit/refuse(p)` identical across runs and platforms.
- **Input domains:** random pattern generator over the ECMAScript subset the verb documents (groups, alternation, classes, quantifiers, anchors), seeded; plus the fixed bomb corpus: `(a|aa)+b$`, `(x|xy)+c$`, `(\w|\d)+$`, `(a|a*)+`, nested `((a|aa)+)+`.
- **Case budget:** ≥10,000 generated patterns plus the fixed corpus; every admitted pattern executed against a pathological-line fixture under a 1 s per-pattern harness timeout.
- **Evidence bundle:** property-test source, seeds, platform, case counts, and result logs in `specs/regex-screen-hardening/evidence/`. PBT does not prove absolute security; it evidences the two funnels hold over the generated domain.

## Progress Tracking

- [ ] Phase 1: Extend `catastrophicRegexConstruct` to the alternation family + refusal message wording
- [ ] Phase 2: Per-file match budget with disclosed degrade in the match loop
- [ ] Phase 3: `test/regexbombcheck.sh` (refusal arms, degrade arm, honest-pattern golden diff) registered in `test/regression.sh`
- [ ] Phase 4: PBT harness, evidence bundle, both-platform CI logs, docs/`--help` wording if changed
