# Parsepool Gate Guard

## Header

```yaml
id: parsepool-gate-guard
type: unit
version: 1.0.0
manifest: ../../manifest.yml
```

## Objective

Make the parse pool's prewarm gate exception-safe, closing the audit's concurrency residual (§2, Informational): if anything throws between worker launch and `installCompiledQueriesAndOpenGate` (`src/ingest_parsepool.h` ~L837–L855 — e.g. `bad_alloc` in the order build), the gate never opens, workers block on the condition variable, and the process dies by `std::terminate` from joinable-thread destruction — against the server's stated never-terminate contract for a long-lived MCP process.

## Scope

**In scope:**
- An RAII scope guard in `runParsePool` that, on any unwind between worker launch and clean completion, opens the prewarm gate (mutex-protected store + `notify_all`, the same A4-F1 shape) so workers drain their queues and exit, and joins the pool during unwinding instead of leaving joinable threads to terminate the process.
- A fault-injection path that forces a throw in the window (the repo already has env-gated fault hooks, e.g. `RIPWIRE_FAULT_CHARGE_BUFFER`; add the equivalent seam here), used only by the gate.
- A new gate `test/parsepoolguardcheck.sh` registered in `test/regression.sh` in the same commit.
- TSan-clean run of the fault-injection scenario.

**Out of scope:**
- The per-worker `try/catch` (already correct — workers degrade per file).
- The lost-wakeup publication protocol (already correct — A4-F1; do not rework).
- Making OOM survivable in general (out of scope for the whole tool; this spec covers only the terminate-vs-clean-degrade difference).

## Interfaces

### Produces

#### exceptionSafeGate
- **Shape:** behavioral contract — for any exception escaping the region between worker launch and gate open, `runParsePool` (a) opens the gate, (b) joins every worker, (c) propagates the original exception to `ingest()`'s caller-visible degrade path (no `std::terminate`, no deadlock, no worker left blocked).
- **Location:** `src/ingest_parsepool.h` (runParsePool body), optionally a small guard type beside `QueryReadyGate` in `src/ingest_prewarm.h`.
- **Invariants:** the normal path is byte-identical in behavior (gate opens exactly once, same publication order); the guard fires only on unwind; the fault-injection seam is compiled into test builds the same way existing fault env hooks are, and is inert without its env var.
- **Examples:** `RIPWIRE_TEST_FAULT=parsepool-post-launch ./build/ripwire fixtures/small-repo` exits with a disclosed error (no hang, no `terminate called` on stderr).
- **Consumers:** none — internal reliability leaf (declared).

### Consumes

None — root spec.

## Acceptance Criteria

1. **Fault injection exits cleanly**: with the fault env var set, a parse run over a multi-file fixture terminates within 60 s, exits non-zero with a disclosed error, and `stderr` contains no `terminate called`/`std::thread` diagnostics. **Verifier:** `test/parsepoolguardcheck.sh` arm (a) with `timeout`.
2. **Normal path unchanged**: without the env var, ingest output on the fixture is byte-identical pre/post change. **Verifier:** arm (b) golden diff.
3. **Workers observed joined**: the fault run's stderr/log shows no leaked-thread LSAN report under the sanitizer build (`cmake -S . -B asan -DRIPWIRE_ASAN=ON`, `LSAN_OPTIONS=suppressions=lsan_suppressions.txt`). **Verifier:** arm (c) sanitizer log clean.
4. **TSan clean**: the fault scenario under the project's TSan build shows no warnings. **Verifier:** arm (d) TSan log empty.
5. **Gate registered**: in `test/regression.sh`; `./test/manifestcheck.sh` passes. **Verifier:** run it.

## Implementation Notes

- The guard's destructor runs during unwind before the `pool` vector's destructor — order matters: open the gate first, then join, then let the exception continue. Declare the guard after `pool` so destruction order is correct (reverse declaration order), or hold the threads inside the guard.
- Reuse the existing fault-injection naming convention (`RIPWIRE_*` env, inert by default) — discoverable via `grep -rn getenv src/`.
- Keep the per-worker try/catch as the per-file layer; this guard is the orchestration layer. The two compose; neither replaces the other.

## Failure Modes

### Guard opens the gate twice
- **Trigger:** exception after `installCompiledQueriesAndOpenGate` already ran.
- **Expected handling:** gate open is idempotent (store + notify under the same mutex); the guard checks a "disarmed" flag set on the normal path.
- **Validator check:** arm with the fault placed *after* the gate-open asserts identical behavior to no-fault.

### Join itself throws/deadlocks under fault
- **Trigger:** a worker that cannot make progress even with the gate open.
- **Expected handling:** workers always make progress with the gate open (their only blocking point is the gate); the 60 s `timeout` in arm (a) is the mechanical bound.
- **Validator check:** arm (a) wall-time assertion.

### Fault seam left armed in production
- **Trigger:** env var set in a real environment.
- **Expected handling:** same exposure as the repo's existing fault env hooks — documented in the gate header; the seam does nothing without its exact variable.
- **Validator check:** grep the emitted `--help`/docs absence (fault seams are not user-facing) + arm (b) normal-run parity.

## Dependencies

None.

## Consumers

None — internal reliability leaf (declared in manifest). The contract is consumed implicitly by every long-lived MCP deployment, but no spec asserts against it; if a future reliability-integration spec appears, it should consume this.

## Status

**Status:** planned
**Last updated:** 2026-09-14T07:45:00+01:00
**Updated by:** spec-architect@2.0.0 (planning; provisional — manifest not locked)

## Validation Strategy

Tier 1 — focused testing sufficient. Components assessed: the RAII guard (single deterministic unwind path — arm (a) plus the post-open disarm case cover it), the join ordering (arm (c) LSAN and arm (d) TSan evidence), and normal-path parity (arm (b)). Concurrency correctness here is a single narrow interleaving (unwind-during-blocked-workers), exercised deterministically by fault injection; broad PBT over thread schedules is explicitly not substituted for the sanitizer evidence. No PBT-suitable component identified.

## Progress Tracking

- [ ] Phase 1: RAII gate-guard with correct destruction order + disarm flag
- [ ] Phase 2: Fault-injection seam (env-gated, inert by default)
- [ ] Phase 3: test/parsepoolguardcheck.sh arms (a)–(d), registered; sanitizer + TSan evidence
- [ ] Phase 4: Full pargates + determinism runs logged
