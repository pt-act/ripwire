# Markitdown Bridge Hardening

## Header

```yaml
id: markitdown-bridge-hardening
type: unit
version: 1.0.0
manifest: ../../manifest.yml
```

## Objective

Put the optional `markitdown` subprocess bridge under explicit operator control, closing audit finding #14 (Informational). `docparse.h` `runMarkitdown()` (~L547) `popen`s a PATH-resolved, network-capable third-party Python tool against adversarial binary documents in whatever tree is being analysed, with no opt-out short of removing the binary from PATH.

## Scope

**In scope:**
- An opt-out flag (advisory name `--no-doc-bridge`, final spelling per the binary's `--help` conventions) that disables the bridge entirely; when set, binary doc formats degrade exactly as they do today when markitdown is absent (no-doc path, disclosed).
- Environment-level control consistent with the project's env-var conventions (e.g. `RIPWIRE_NO_DOC_BRIDGE=1`), so CI and agent hosts can disable it without touching argv.
- Resolution hardening: the bridge resolves the `markitdown` binary once (absolute path via PATH walk) and refuses to execute if the resolved file is world-writable, in addition to the existing argument single-quoting (which is correct and stays).
- `--help`/docs wording for the new flag (`--help` is generated from the binary; docs follow it per `AGENTS.md`).
- A new gate `test/docbridgecheck.sh` registered in `test/regression.sh` in the same commit.

**Out of scope:**
- Auditing markitdown itself (third-party; the residual risk is documented by security-threatmodel-docs).
- Changing which file extensions route to the bridge.
- Sandboxing the subprocess (bwrap/seatbelt — a separate, larger decision; recorded as a non-goal for this cycle).

## Interfaces

### Produces

#### docBridgePolicy
- **Shape:** behavioral contract — binary doc extraction runs if and only if: markitdown resolves to a non-world-writable executable on PATH, AND the opt-out flag/env is unset. Otherwise the no-doc degrade path runs and is disclosed through the existing channel. The subprocess is always invoked by absolute resolved path with the existing single-quoted argument.
- **Location:** `src/docparse.h` (`runMarkitdown` + resolution helper), flag parse in `src/cli.h`/`src/main.cpp`.
- **Invariants:** flag set ⇒ zero subprocess spawns for doc formats (provable by a PATH shim that logs invocation); absent tool ⇒ identical output to flag-set output; the `2>/dev/null` degrade and the `DEGRADED_PATH_ALERT` on popen failure are preserved.
- **Examples:** `ripwire repo-with-docx --no-doc-bridge` never execs markitdown; `RIPWIRE_NO_DOC_BRIDGE=1 ripwire repo-with-docx` likewise; default behavior unchanged when the tool is present.
- **Consumers:** security-threatmodel-docs

### Consumes

None — root spec.

## Acceptance Criteria

1. **Flag disables the bridge**: a fixture tree containing a `.docx`, with a PATH shim `markitdown` that appends its argv to a log. **Verifier:** `test/docbridgecheck.sh` arm (a) asserts the log is empty after a flagged run and non-empty after an unflagged run.
2. **Env disables the bridge**: same fixture with `RIPWIRE_NO_DOC_BRIDGE=1`. **Verifier:** arm (b) asserts empty log.
3. **World-writable binary refused**: shim marked `chmod 666`+x; unflagged run. **Verifier:** arm (c) asserts no invocation and a disclosed degrade line on stderr.
4. **Output parity of the degrade**: flagged-run output equals the no-markitdown-on-PATH output byte-for-byte. **Verifier:** arm (d) diff.
5. **Help documents the flag**: `--help` output names the flag. **Verifier:** arm (e) grep.
6. **Gate registered**: in `test/regression.sh`; `./test/manifestcheck.sh` passes. **Verifier:** run it.

## Implementation Notes

- The existing comment in `docparse.h` already treats the bridge as a degrade-tolerant extra; this spec adds control, not a new pipeline — keep the diff small and the flag's semantics boring.
- Resolve-then-check (PATH walk → realpath → stat for world-writable bit) avoids a double resolution; do not stat one path and exec another spelling of it.
- House rule: flags are kebab-case and the env overrides share the `RIPWIRE_` prefix; check `cli.h` for the parse-table shape before naming.

## Failure Modes

### Operator depends on doc extraction silently losing it
- **Trigger:** flag/env set in CI and forgotten.
- **Expected handling:** the degrade is disclosed per-run (existing skipped/disclosure channel), so a diff in extracted-doc counts is visible, not silent.
- **Validator check:** arm (d) also asserts the disclosure line exists when the bridge is off and a docx is present.

### PATH shim swaps between resolve and exec
- **Trigger:** local attacker racing the check.
- **Expected handling:** accepted residual for a local-tool threat model (the attacker able to rewrite PATH entries can already alter the user's tools); documented in the spec, no code.
- **Validator check:** phase-log entry records the decision.

### Shim writes to stdout and pollutes the map
- **Trigger:** markitdown (or a shim) emitting non-doc bytes on stdout.
- **Expected handling:** unchanged from today — extracted text is ingest input, already size-capped and content-scanned downstream; no new surface.
- **Validator check:** arm (a)'s unflagged run output diffed against expectation with the shim's payload.

## Dependencies

None.

## Consumers

- **Spec:** security-threatmodel-docs — documents the flag, the env var, and the residual third-party risk verbatim. **Constraints on evolution:** renaming the flag/env breaks the doc; version together.

## Status

**Status:** planned
**Last updated:** 2026-09-14T07:45:00+01:00
**Updated by:** spec-architect@2.0.0 (planning; provisional — manifest not locked)

## Validation Strategy

Tier 1 — focused testing sufficient. Components assessed: the flag/env provenance check (boolean — arms (a)/(b) cover), the resolver's world-writable refusal (arm (c)), and the degrade parity (arm (d)). No PBT-suitable component identified: no parsing logic changes; the change is a policy gate around an existing subprocess call.

## Progress Tracking

- [ ] Phase 1: Flag + env parsing, resolver with world-writable refusal
- [ ] Phase 2: test/docbridgecheck.sh arms (a)–(e) with PATH-shim fixture, registered
- [ ] Phase 3: --help/docs wording; determinism + full pargates run logged
