# Graph Interaction Accessibility

## Header

```yaml
id: graph-interaction-accessibility
type: unit
version: 1.0.0
manifest: ../../manifest.yml
```

## Objective

Give the HTML export's force-directed canvas two things it entirely lacks — a `prefers-reduced-motion` path and a keyboard operability model — closing audit findings #9 and #10 (Low). The emitted JS currently has zero key handlers and no motion query: the settle animation runs for every visitor, and pan/zoom/node-open are pointer-only (WCAG 2.2.2/2.3.3 and 2.1.1 territory).

## Scope

**In scope** (all in the emitted JS/CSS of `src/htmlexport.h`, building on unifiedShellContract):
- Reduced motion: when `matchMedia('(prefers-reduced-motion: reduce)')` matches at load, the simulation skips the animated settle and paints the settled layout directly (the existing settle-before-paint driver already computes the end state — jump to it), and continuous rAF animation is not started.
- Keyboard model: the node list is already partially reachable via the DOM (search hits and module cards are links); complete the model — Tab reaches the graph's focusable node list, arrow keys move selection between nodes, Enter opens the node detail route, Escape returns focus to the search field; a visible `:focus-visible` style using the existing `#7fb2ff` accent.
- A short, in-page "keyboard: tab / arrows / enter / esc" hint in the chrome so the model is discoverable.
- Gate coverage via headless Chromium (`--force-prefers-reduced-motion`) plus static byte checks on the emitted JS.

**Out of scope:**
- Full screen-reader graph semantics (a live-annotated canvas tree); the DOM views remain the SR-equivalent and this spec keeps them at parity rather than reinventing canvas a11y.
- Touch/gesture work (pointer model unchanged).
- Changes to the force simulation's physics or layout output (settled positions must be identical — determinism contract).

## Interfaces

### Produces

#### keyboardModelContract
- **Shape:** behavioral contract of the emitted document — (1) with reduced motion requested, the first paint is the settled layout and no rAF loop runs; (2) the node list is focusable in DOM order, arrows move a visible focus indicator, Enter activates, Escape returns focus to `#search`; (3) `:focus-visible` styling is present in the stylesheet; (4) the keyboard hint text is present in the chrome.
- **Location:** `src/htmlexport.h` emitted JS sections (event handling, sim driver) and CSS block.
- **Invariants:** settled node positions byte-identical to the animated path (determinism); no change to pointer behavior; all new interactive elements reachable in a logical tab order with visible focus.
- **Examples:** headless Chromium with `--force-prefers-reduced-motion` loads `map.html`; a probe script asserts no rAF callbacks fire after first paint and `document.querySelector('[data-motion]')` reports `reduced`.
- **Consumers:** none — user-facing leaf (declared).

### Consumes

#### unifiedShellContract
- **From:** html-export-template-remediation
- **Shape:** the single head/shell emission for both document variants, with labelled chrome and the CSP meta (see that spec's Produces).
- **Usage:** this spec's JS mounts inside that shell; its keyboard hint joins the labelled `#bar` chrome; its CSP compatibility (no new external resources, inline event wiring via addEventListener only) is required.

## Acceptance Criteria

1. **Reduced-motion path**: generate `map.html` from a fixture repo; load in headless Chromium with `--force-prefers-reduced-motion`; assert (via injected probe through `--dump-dom` or a devtools-protocol script) that the container carries the reduced-motion marker attribute and that the sim's rAF loop is not running. **Verifier:** `test/htmlmotioncheck.sh` arm (a).
2. **Default motion unchanged**: without the flag, the settle animation runs and the final camera/layout state equals the reduced path's. **Verifier:** arm (b) compares a pinned probe of final node positions (JSON dump of first K nodes) between modes — byte-identical.
3. **Keyboard reaches nodes**: the emitted bytes contain a `keydown`/`keyup` handler wired to the node list and Arrow/Enter/Escape branches. **Verifier:** arm (c) byte greps plus a headless-DOM assertion that node items carry `tabindex`.
4. **Focus visible**: stylesheet contains a `:focus-visible` rule using the accent color. **Verifier:** arm (d) grep.
5. **Escape restores focus**: probe script asserts focus returns to `#search` after Escape. **Verifier:** arm (e) headless assertion.
6. **Hint present**: chrome contains the keyboard hint string. **Verifier:** arm (f) grep.
7. **No CSP violation introduced**: no inline `onclick=` attributes; all wiring via `addEventListener` (CSP `script-src 'unsafe-inline'` still blocks inline *attributes* — this arm keeps the two specs compatible). **Verifier:** arm (g) absence grep.
8. **Gate registered**: in `test/regression.sh`; `./test/manifestcheck.sh` passes. **Verifier:** run it.

## Implementation Notes

- The settle driver already has a "settled" terminal state; the reduced-motion path is a jump to it, not a second layout — keep one source of truth or the two modes will drift.
- Node focus order: reuse the existing DOM lists (search hits, module cards) as the tabbable surface and mirror selection onto the canvas highlight; do not make `<canvas>` itself a focus soup.
- Chromium headless flags available in CI today: `--headless --dump-dom`, `--force-prefers-reduced-motion`; where a probe needs JS evaluation, a tiny CDP script (Node is already a CI dependency for other gates, verify before relying) or an in-page probe writing into `document.title` for `--dump-dom` capture both work — pick one and pin it in the gate header.

## Failure Modes

### CI without Chromium
- **Trigger:** a runner image lacking the browser.
- **Expected handling:** the gate detects `chromium` absence and skips with a disclosed SKIP line (house convention), never a false pass; CI matrix that has Chromium must run it.
- **Validator check:** arm headers contain the capability probe; CI log shows the arm ran (not skipped) on the primary platform.

### Layout drift between motion modes
- **Trigger:** the reduced path computes layout differently from the animated path.
- **Expected handling:** arm (b) fails; the fix is routing both through the same terminal-state computation.
- **Validator check:** arm (b).

### Keyboard model rots
- **Trigger:** a later template edit drops the handlers.
- **Expected handling:** byte-grep arms (c)/(g) fail.
- **Validator check:** run the gate.

## Dependencies

- **Spec:** html-export-template-remediation
- **What this spec assumes from it:** one head-emitting path for all document variants; labelled `#bar` chrome with stable element ids (`#search`, `#hits`, `#cards`, `#crumb`, `#c`); the CSP meta present.
- **What breaks if it changes:** renamed chrome ids break the keyboard wiring and the probe scripts; a CSP that disallows inline event wiring style used here would break mounting (the arm-(g) convention prevents exactly this).

## Consumers

None — user-facing leaf (declared in manifest).

## Status

**Status:** planned
**Last updated:** 2026-09-14T07:45:00+01:00
**Updated by:** spec-architect@2.0.0 (planning; provisional — manifest not locked)

## Validation Strategy

Tier 1 — focused testing sufficient. Components assessed: the motion-mode branch (two deterministic terminal states — arms (a)/(b) cover both directions), the keyboard event wiring (declarative DOM behavior — arms (c)/(e) cover), and the focus/hint styling (static — arms (d)/(f) cover). No PBT-suitable component identified: no sanitization, auth, or arithmetic surface; correctness here is behavioral and fixture-pinned.

## Progress Tracking

- [ ] Phase 1: prefers-reduced-motion detection + jump-to-settled path, marker attribute
- [ ] Phase 2: Keyboard model (tabindex, arrows/enter/escape, focus-visible, hint)
- [ ] Phase 3: test/htmlmotioncheck.sh arms (a)–(g) with headless Chromium probes, registered
- [ ] Phase 4: Determinism verification between motion modes; evidence notes logged
