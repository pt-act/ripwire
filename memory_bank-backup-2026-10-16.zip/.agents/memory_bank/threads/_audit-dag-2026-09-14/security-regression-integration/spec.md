# Security Regression Integration

## Header

```yaml
id: security-regression-integration
type: integration
version: 1.0.0
manifest: ../../manifest.yml
```

## Objective

Verify that the five security fixes compose correctly in the real binary — that the exact attack reproductions from the 2026-09-14 audit now fail safely end-to-end through both the CLI and the MCP stdio transport, and that the hardening did not disturb the project's determinism, honesty, or suite-wide invariants. This is the closed loop between "each fix passed its unit gates" and "the shipped tool repels the audited attacks."

## Scope

**In scope:**
- A composed adversarial fixture tree (`test/fixtures/audit-reef/`) combining: a minified-style single-line file (≥100 KB one line with long repeated-token runs), a file named `__C__x|1694000000`, a filename containing `\n`, a `.docx`, and a symlink farm aimed at the edit temp-name pattern.
- A driver gate `test/auditregresscheck.sh` (registered in `test/regression.sh`) replaying every audit reproduction end-to-end: (1) regex bomb over the fixture completes bounded on both transports; (2) bare-stdio edit escape refused with file bytes unchanged; (3) pre-placed temp symlink never followed; (4) hostile git filenames attributed correctly; (5) 9 MiB stdio line refused with the server alive afterward.
- Cross-transport parity: the same grep refusal and the same edit refusal occur over stdio and over the loopback HTTP transport (with token), byte-comparable at the JSON-RPC error-shape level.
- Whole-suite invariants after composition: `python3 test/pargates.py . ./build/ripwire -j 6` green, determinism (`>a; >b; diff -q a b`) clean, `xmllint --noout` clean, ASan/LSan build clean over the adversarial fixture.
- The verification report artifact this spec produces (below).

**Out of scope:**
- New application functionality (integration specs produce verification, not features).
- Performance benchmarking (the perf gates already exist; this spec asserts absence of deadlock/hang, not speed).
- The accessibility and docs fixes (verified by their own unit gates; not security composition).

## Interfaces

### Produces

#### auditRegressionReport
- **Shape:** a committed-format report block — `test/auditregresscheck.sh` summary plus raw logs — with one line per replayed attack: `attack_id, transport(s), expected_refusal_shape, observed_outcome, wall_time, verdict`. Verdicts are `repelled` only when the observed outcome matches the contracted refusal exactly.
- **Location:** `specs/security-regression-integration/report/` at execution time (the report path is the contract), plus CI log retention.
- **Invariants:** one row per audit attack id (A1 ReDoS, A2 stdio edit escape, A3 temp-symlink, A4 git framing, A5 stdio line flood); a row cannot be `repelled` unless its expected refusal shape string appears in the captured output; the full-suite and sanitizer summaries are appended verbatim.
- **Examples:** `A1, stdio+http, "catastrophic backtracking|match budget", refused+disclosed-skip, 0.8s, repelled`.
- **Consumers:** audit-validation-standalone

### Consumes

#### patternAdmission
- **From:** regex-screen-hardening
- **Shape:** the refusal/admission verdict contract incl. the widened alternation family and the disclosed budget-skip alert text.
- **Usage:** attack A1's assertions grep for this spec's exact refusal and alert strings.

#### editPathAdmission
- **From:** edit-workspace-pin
- **Shape:** the four-tier pin policy and `-32602` refusal wording for off-workspace edits.
- **Usage:** attack A2's assertions (refusal code, inferred-root wording, file-bytes-unchanged check).

#### atomicPublish
- **From:** atomic-write-tempfile
- **Shape:** temp-name pattern, exclusive/no-follow create, failure disclosure text.
- **Usage:** attack A3's symlink-plant assertions.

#### gitRecordFraming
- **From:** git-porcelain-framing
- **Shape:** NUL-framed parsing with full-field marker; hostile-name fixtures and their expected attributions.
- **Usage:** attack A4's fixture expectations (shared fixture, one source of truth).

#### boundedStdioLine
- **From:** stdio-request-cap
- **Shape:** the 8 MiB line cap, the framing-gate refusal, and the drain-and-continue resync.
- **Usage:** attack A5's assertions (one error, then a healthy next request).

## Acceptance Criteria

1. **A1 repelled on both transports**: the bomb patterns from the audit repro (`^(a|aa)+b$`, `(x|xy)+c$`, `(\w|\d)+$`) over the fixture are refused or bounded-degraded; wall time < 60 s each on CLI; MCP HTTP server remains responsive (a follow-up `tools/list` answers) after a bomb request. **Verifier:** `test/auditregresscheck.sh` arms A1a (CLI) / A1b (HTTP via curl).
2. **A2 repelled**: bare `ripwire --mcp` launched in fixture dir A; scripted `analyze`+`replace_symbol_body` against dir B refuses and B's file sha256 is unchanged. **Verifier:** arm A2.
3. **A3 repelled**: symlink farm pre-planted at predicted temp names; an edit run leaves every victim byte-identical; the edit reports honestly. **Verifier:** arm A3 sha256 assertions.
4. **A4 repelled**: `__C__x|1694000000` and the newline file attributed correctly in `--owners`-family output over the fixture repo. **Verifier:** arm A4 against git-porcelain-framing's fixture expectations.
5. **A5 repelled**: 9 MiB line → exactly one framing error; subsequent `tools/list` succeeds. **Verifier:** arm A5.
6. **Suite-wide invariants hold after composition**: pargates green, determinism diff clean, xmllint clean, ASan/LSan clean on the adversarial fixture. **Verifier:** arm B asserts all four logs, appended to the report verbatim.
7. **Gate registered**: `test/auditregresscheck.sh` in `test/regression.sh`; `./test/manifestcheck.sh` passes. **Verifier:** run it.
8. **Report emitted**: `specs/security-regression-integration/report/` contains the five attack rows + suite summaries, each row `repelled`. **Verifier:** arm C asserts report shape with a schema grep (`^A[1-5],` rows + trailer lines).

## Implementation Notes

- Reuse the unit specs' fixtures rather than duplicating them — the integration value is in composition and transport parity, not fixture novelty.
- HTTP arms need a free port: bind 127.0.0.1:0 is not supported by the CLI (check); if not, probe-and-retry a small port range with a bounded attempt count, and pin the token via env var (never argv — mcp-token-hygiene's warning is asserted elsewhere).
- Keep every attack's expected string imported from the unit spec's gate (sourced shell fragment) so a wording change fails in exactly one place per unit and here simultaneously — that coupling is intended; it is the drift alarm.
- Timing assertions exist to catch hangs, not to gate performance — use generous bounds (60 s) so CI variance never flakes.

## Failure Modes

### Port collision flakes the HTTP arm
- **Trigger:** occupied port on a busy runner.
- **Expected handling:** bounded probe-and-retry; after N failures, a disclosed SKIP with reason (never a false pass).
- **Validator check:** arm headers show the probe; CI logs show the arm actually ran on the primary platform.

### Composition passes but a unit silently regressed
- **Trigger:** a unit's gate weakened while integration still passes on happy paths.
- **Expected handling:** every arm asserts the refusal *shape strings* exported by the unit gates, so unit wording changes fail here too; `manifestcheck` + this gate run in the same suite.
- **Validator check:** arm C's report requires exact-shape matches, not exit codes alone.

### Fixture repo drifts from git behavior
- **Trigger:** git version differences in porcelain for the framing fixture.
- **Expected handling:** fixture expectations live in git-porcelain-framing's fixture directory with its version pin; this spec consumes them read-only.
- **Validator check:** arm A4 reads expectations from the fixture path, not inline copies.

## Dependencies

- **Spec:** regex-screen-hardening — refusal/alert strings for A1. **What breaks if it changes:** A1 greps.
- **Spec:** edit-workspace-pin — refusal code/wording for A2. **What breaks if it changes:** A2 greps and the tier semantics A2 relies on.
- **Spec:** atomic-write-tempfile — temp-name pattern and disclosure for A3. **What breaks if it changes:** the name-prediction fixture and A3's assertions.
- **Spec:** git-porcelain-framing — framing helper + fixture expectations for A4. **What breaks if it changes:** A4's shared fixture path.
- **Spec:** stdio-request-cap — cap constant and resync behavior for A5. **What breaks if it changes:** A5's boundary line length and response count.

## Consumers

- **Spec:** audit-validation-standalone — consumes the report as the composition-trust artifact for the ship verdict. **Constraints on evolution:** the report's row shape (`attack_id, transports, expected_shape, observed, wall, verdict`) is a contract; changing columns breaks the validator's schema grep.

## Status

**Status:** planned
**Last updated:** 2026-09-14T07:45:00+01:00
**Updated by:** spec-architect@2.0.0 (planning; provisional — manifest not locked)

## Validation Strategy

This spec is verification work; its own components are Tier 1 (shell harness, fixtures, curl probes — focused checks by construction). The composition-level properties it asserts: (C1) every audited attack's contracted refusal shape occurs on every applicable transport; (C2) no refusal path writes or corrupts target bytes; (C3) the composed binary preserves determinism, XML well-formedness, and sanitizer cleanliness over adversarial input. The harness contains no PBT-suitable logic of its own — the PBT burden lives in the four Tier-2 unit specs and is audited by audit-validation-standalone.

## Progress Tracking

- [ ] Phase 1: test/fixtures/audit-reef/ composed adversarial tree + port-probing HTTP helper
- [ ] Phase 2: Arms A1–A5 replaying the audit reproductions on CLI and MCP transports
- [ ] Phase 3: Arm B suite-invariant assertions (pargates, determinism, xmllint, ASan/LSan) + arm C report emission
- [ ] Phase 4: Register in test/regression.sh; run full suite on both platforms; report committed to report/
