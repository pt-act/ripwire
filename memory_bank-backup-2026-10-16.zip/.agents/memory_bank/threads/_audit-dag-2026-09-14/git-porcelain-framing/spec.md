# Git Porcelain Framing

## Header

```yaml
id: git-porcelain-framing
type: unit
version: 1.0.0
manifest: ../../manifest.yml
```

## Objective

Make git-history record framing unambiguous under adversarial repository contents, closing audit finding #4 (Medium). Today the `--format=tformat:__C__…` commit marker is matched **exactly** in one parser (`src/gitmine.h` ~L1453, `s == "__C__"`) and by **5-byte prefix** in another (~L2296, `s.compare( 0, 5, "__C__" ) == 0`), and `--name-only` output is newline-delimited, so a committed file named `__C__x|<epoch>` injects a forged (author, timestamp) row and any filename containing `\n` splits into phantom records.

## Scope

**In scope:**
- One shared framing helper in `src/gitmine.h` used by every `git log --name-only` / `--format=__C__…` consumer: NUL-delimited records (`-z` for name lists; `%x00` field separators in `--format`), with the commit marker carried in its own NUL-framed field rather than as a line prefix.
- The two parser call-families (per-commit file sets ~L1438+; per-file author/timestamp walk ~L2280+) migrated to the helper; the literal `__C__` prefix test deleted.
- Fixtures committed under `test/fixtures/`: a repo containing files named `__C__`, `__C__x|1694000000`, a filename containing `\n`, and one containing `\r`.
- A new gate `test/gitframingcheck.sh` registered in `test/regression.sh` in the same commit.
- Golden-output check that churn/co-change/ownership output on the ripwire repo itself is byte-identical before and after (no behavior change on honest trees).

**Out of scope:**
- `collectGitIgnored` (already `-z`-delimited — the model to imitate, not a target).
- Any change to which commits are walked (window logic, merge handling, `--since` semantics).
- Version tolerance for ancient gits lacking `-z`/`%x00` (both are decades old; a hard requirement is acceptable and honest).

## Interfaces

### Produces

#### gitRecordFraming
- **Shape:** one helper — advisory name `gitLogRecords()` — yielding `(commitMeta, [path, …])` records parsed from NUL-delimited `git log` output; all current `--name-only`/`--format` consumers call it. Field separators are NUL; the commit marker is a full-field sentinel, never a line prefix.
- **Location:** `src/gitmine.h`; call sites listed in Scope.
- **Invariants:** any POSIX-legal filename except one containing NUL (impossible) or `/` in a component round-trips exactly; marker recognition requires a full-field match; a filename can never be parsed as metadata; parse failure degrades through the existing `DEGRADED_PATH_ALERT` channel, never partial-silent.
- **Examples:** file `__C__x|1694000000` appears exactly once as a path, attributed to its true commit; file `a\nb` appears as one path.
- **Consumers:** security-regression-integration, audit-validation-standalone

#### pbtEvidenceBundle
- **Shape:** directory `specs/git-porcelain-framing/evidence/` with property-test source, seeds, logs.
- **Location:** committed beside this spec at execution time.
- **Invariants:** includes the round-trip property over generated hostile filenames; logs unedited.
- **Examples:** `evidence/pbt-git-framing.log` header `cases=20000 seed=… result=pass`.
- **Consumers:** audit-validation-standalone

### Consumes

None — root spec.

## Acceptance Criteria

1. **Spoof fixture neutralized**: in the fixture repo, churn/ownership output attributes `__C__x|1694000000` to its real commit and real author. **Verifier:** `test/gitframingcheck.sh` arm (a) greps `--owners`-family output for the fixture path and asserts the true author email, and asserts no `__C__x` author row exists.
2. **Newline filename round-trips**: the `a\nb` fixture file is attributed as one path. **Verifier:** arm (b) asserts exactly one record carrying the full name (fixture expectations stored beside the fixture).
3. **Exact-marker file survives**: a file named exactly `__C__` is parsed as a path, not a commit boundary. **Verifier:** arm (c).
4. **Honest-tree output unchanged**: `--owners`/churn/co-change output on the ripwire checkout is byte-identical pre/post change. **Verifier:** golden diff arm (d) over `git -C . log`-derived verbs listed in the gate.
5. **Single parser**: `grep -n '__C__' src/gitmine.h` shows marker recognition only inside the shared helper. **Verifier:** arm (e) count/location grep.
6. **Gate registered**: in `test/regression.sh`; `./test/manifestcheck.sh` passes. **Verifier:** run it.

## Implementation Notes

- `git log -z --name-only --format=…` interleaving needs care: with `-z`, both the format output and the names are NUL-terminated; prototype the exact byte stream (`git -c core.quotepath=false log -z --name-only --format='%x00__C__%x00%ae%x00%at%x00'`) in a scratch repo and pin the layout in the fixture before migrating the parsers.
- `readByteSafeLine` splits on `\n` and will not serve NUL framing; add a NUL-delimited reader sibling rather than complicating the shared line reader (also reused by stdio-request-cap's deliberations — keep the two readers distinct).
- Author emails containing `|` become harmless once fields are NUL-separated; no escaping scheme is needed.

## Failure Modes

### Git older than expected flag support
- **Trigger:** a platform git without `-z` on the used commands.
- **Expected handling:** startup probe or first-use failure degrades via `DEGRADED_PATH_ALERT` with the git version named; no partial parse.
- **Validator check:** gate arm with a shimmed `git` that rejects `-z` asserts the alert and the refusal to fabricate data.

### Fixture fragility across git versions
- **Trigger:** porcelain output differences across git versions.
- **Expected handling:** fixtures assert on semantics (which path, which author), never on unrelated formatting; minimum git version recorded in the gate header.
- **Validator check:** CI matrix logs across the supported git versions.

### Parser migration misses a consumer
- **Trigger:** a fourth `popen("git log …")` site keeps the old framing.
- **Expected handling:** arm (e) fails (marker literal count > helper's), blocking merge.
- **Validator check:** run arm (e).

## Dependencies

None.

## Consumers

- **Spec:** security-regression-integration — replays the hostile fixtures end-to-end through CLI and MCP. **Constraints:** helper name/location changes break its source-grep arm.
- **Spec:** audit-validation-standalone — needs the evidence bundle at the declared path.

## Status

**Status:** planned
**Last updated:** 2026-09-14T07:45:00+01:00
**Updated by:** spec-architect@2.0.0 (planning; provisional — manifest not locked)

## Validation Strategy

Tier 2 — property-based testing required (parsing of externally supplied, adversarially craftable byte streams; data-integrity boundary).

- **Components requiring PBT:** the shared `gitLogRecords()` framing helper and its per-field decoders.
- **Formal properties:**
  - ∀ committed filename f (any byte string not containing NUL): `parse(log(f))` contains exactly one record for f, attributed to f's true commit. (Round-trip integrity under adversarial names.)
  - ∀ output stream s: no record in `parse(s)` carries an author/timestamp that did not come from a commit field. (No injected metadata.)
  - ∀ streams s₁=s₂ byte-identical ⇒ `parse(s₁) = parse(s₂)` (determinism, matching the project's det-gate contract).
- **Input domains:** generated filenames over bytes 0x01–0xFF excluding `/` and NUL, length 1–255, with weighted injection of `__C__` prefixes, `|`, `\n`, `\r`, quotes, and UTF-8 boundaries; generated multi-commit streams with empty file sets and 10k-file commits.
- **Case budget:** ≥20,000 generated filename cases plus ≥1,000 generated streams.
- **Evidence bundle:** `specs/git-porcelain-framing/evidence/`. PBT evidences the round-trip over the generated domain; not a proof of absolute security.

## Progress Tracking

- [ ] Phase 1: NUL-framed byte-stream prototype + fixture repo + layout pin
- [ ] Phase 2: Shared gitLogRecords helper; both parser families migrated
- [ ] Phase 3: test/gitframingcheck.sh arms (a)–(e), registered; golden diff on ripwire itself
- [ ] Phase 4: PBT harness + evidence bundle; full pargates suite green
