# ripwire-fork (pt-act/ripwire) — Master Context

## Status: active

## Direction: paging PoC DELIVERED upstream (PR #362 accepted 2026-10-10, in train 26c); re-baseline the 2026-09-14 audit remediation DAG before executing it (the regex High needs a scope pass against upstream's own regexguard.h).

## Architecture:

- Pattern: fork of redhat-et/ripwire maintained as upstream + squash-merged work; sync per train (~2/day), test-merge before syncing, never Discard when fork commits are live content.
- Pattern: gate-first development — arms written red against the pre-change binary, then implementation greens them; counting gates treat comments as code (prose naming a counted token drifts the pin).
- Pattern: one-implementation rule — pageview.h owns the paging vocabulary; forpage.h owns both page renderers (file page + candidate page); twins (MCP) must serve byte-identical documents to CLI.
- Pattern: upstream-first for anything upstream should own (roster pin precedent: upstream adopted it and re-derived the roster themselves).
- Pattern: sink-form DISCLOSE (Diagnostics.h §4b) — every degrade emits through a sink the emitter reads; the sink-less pin only goes down.

## Stack: C++23 header-only, CMake, bash+python3 gate suite (test/pargates.py, ~400 gates), MCP JSON-RPC over stdio, zero runtime deps.

## Key Files:

- src/forpage.h — both page renderers incl. forCandidatePageDoc (the candidate page, all dialects)
- src/pageview.h — the one paging/truncation vocabulary (quintet)
- src/cli.h — guard carves (honorsPaging, validateShapingFlagsHonored)
- src/mcp.h + src/mcpverbs.h — MCP dispatch; forTaskText/packTaskText serve the twins
- test/mcpverbscheck.sh — roster pin (6b/6c, adopted upstream), twins arms (6d/6e)
- test/truncvocabcheck.sh, test/listingpagingcheck.sh, test/budgetpolicycheck.sh, test/packtaskcheck.sh — paging arms (H)/(G)/(D)/(E)
- CHANGELOG.md — manifest-growth claim asserted live by mcpmanifestcheck (1b)

## Active Decisions:

1. Roster pin (6b/6c) shipped upstream; upstream maintains it now — never re-pin from the fork (2026-09-21).
2. Candidate-page design: cliff computed ONCE over the full candidate set; continuation pages tier="below-cliff" — blessed by the #294 ruling (2026-09-28); all five page paths page ONE list, ranking= dropped (2026-10-07, B1).
3. Un-paged budgeted bundle stays byte-identical; its resume point is its own <sigs shown=> (2026-09-20).
4. Sync only after test-merge verifies zero conflicts; push via credential only when .github/ untouched, else operator's one click (2026-09-21).
5. 2026-09-14 audit remediation DAG: re-baselined (3 of 13 retired as landed upstream), re-drafted to the PROJECT_MANIFEST v2.5.1 schema (Amendment 3, 2026-09-29 — 14 specs incl. the rendered-dom-audit validation root; selfcheck ALL PASS), 0 executed; the regex High needs scoping against upstream's own regexguard.h (which landed after the 2026-09-14 draft). Orion-OS v2.5.1 framework installed at .agents/Orion-OS-V2.5.1/ (2026-10-11): AGENTS.md constitution, the five companions, six skills.

6. Authorship: every commit ships as pt-act <psychoactive28@gmail.com> (SR-2026-10-12-authorship-identity — set per-workspace before the first commit, every session; the #362 commits landed as usehoplite[bot] and the operator chose to earn the badge forward, not ask).
