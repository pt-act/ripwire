# Standing Requirements — Verdict-Time Rules With Provenance

## [SR-2026-09-21-counted-prose] Prose that names a counted token is a counted line

- **Rule:** never write an emitter-API name (formatTo, snprintf, …) in a comment inside src/ — the counting gates enumerate mentions line-by-line, comments included; reword the prose, never bump the pin.
- **Provenance:** PR #3 CI round 1 (fixedbufsweep 333→334) and round 3 (344→345, in the fix's own comment) — learned twice in one branch.
- **Scope:** any change touching src/ comments near serialize/emit surfaces.
- **Status:** active

## [SR-2026-09-21-degrades-need-sinks] Every degrade emits through a sink the emitter reads

- **Rule:** DISCLOSE takes (sink, why), never a bare message on an answer-changing path; the page IS the sink — a degraded render ships the honest document with reason=.
- **Provenance:** PR #3 CI round 2 (selfcheckcheck R: 49→51 sink-less sites).
- **Scope:** any new degrade path in verbs/emit code.
- **Status:** active

## [SR-2026-09-21-gate-sweep-is-owned] Name the affected-gate set by reading what owns each surface

- **Rule:** before claiming a sweep, enumerate the gates that own every touched surface (guard messages, schemas, counts, ceilings) — a sweep-miss is a CI round.
- **Provenance:** modifierguardcheck missed in PR #3's first sweep (16-gate list grew from 10); timing gates identified as flake-class only by comparing main's green runs.
- **Scope:** any verification claim.
- **Status:** active

## [SR-2026-09-28-explicit-path-add] git add by explicit path list, never -A

- **Rule:** on this workspace, `git add` takes an explicit path list (src/... test/...). `-A` / `-u` / `.` sweep the private workspace dirs (.hoplite/ attachments, .context/, specs/, .agents/) into public commits — .gitignore is the backstop, not the defense.
- **Provenance:** PR #362's review-fix commit (a1dcd742e) used `git add -A ':!.agents'` — it swept .hoplite/attachments (the operator's private audit/spec/memory-format files), .context/ and specs/ into the public branch and fork main. Both force-pushed clean within ~15 minutes; the unreachable commits linger on the provider until GC. Exposure: planning documents only, secret-scan clean.
- **Scope:** every commit on every branch of this fork.
- **Status:** active

## [SR-2026-09-29-help-output-triplets] A --help output change is a three-file commit

- **Rule:** any change that moves `--help` bytes lands as ONE commit with (1) the source change, (2) regenerated docs/COMMANDS.md (`python3 docs/docs_commands_build.py --bin ./build/ripwire`), and (3) the re-pinned `help_all` line in test/printf_parity.manifest. The pins exist to force exactly this.
- **Provenance:** the ci.yml full-matrix schedule failed on fork main at 9105b1979 — the #362 review round's help-text edit (run 36562387291, jobs release/docscommandscheck and fallback-emitter/printffmtparitycheck). Before re-pinning, prove the movement is identical on BOTH emitters (std::print build + the std::format+fputs fallback build) — identical movement = deliberate text change; different movement = a conversion drifted, and must be reverted instead.
- **Scope:** any src/ change that can alter --help or the flag surface.
- **Status:** active


## [SR-2026-10-12-authorship-identity] Every commit this project ships is authored as pt-act

- **Rule:** before ANY commit in any session, `git config user.name "pt-act"` and `git config user.email "psychoactive28@gmail.com"` at repo-local level, then verify with `git config user.email`. Applies to every workspace — fresh clones do NOT inherit this; it is set per-workspace, every session, before the first commit.
- **Provenance:** PR #362 merged 2026-10-11 with all commits authored by `usehoplite[bot]` (the platform's default identity) — the contributor badge accrued to the bot, not to the operator. The operator declined to ask for retroactive credit ("the badge should be earned, not begged for") and ordered the identity fixed for all future contributions: quote, "let's continue our contributions and the future will set it right." Authorship by git = the credit; PRs pushed from the fork pt-act/ripwire merge into redhat-et/ripwire with pt-act as author once this rule is applied.
- **Scope:** every repository, every session, the DAG phase's every PR.
- **Status:** active (set in this workspace 2026-10-12; verified `git config user.email` = psychoactive28@gmail.com)
