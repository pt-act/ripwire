## Current status (2026-10-16 midday — post-rollback, pre-rebuild)

- **PR #397 (regex-screen-hardening): DONE from our side, LIVE on GitHub** — head 3fb42b417 (rebased onto 1bcb65400), all review blockers closed, CI 36-pass clean incl. ASan, MERGEABLE/CLEAN. Awaiting joyful-ii-V-I re-review. Multiquantifier follow-on queued behind merge.
- **Porcelain Phase 2: COMPLETED THE MORNING OF 2026-10-16 but WIPED by the midday sandbox rollback before push.** Full round detail in PROGRESS.md (2026-10-16 entry). Rebuild-from-session-record is the active task: six commits (merge fix, gitframingcheck gate 685, dead-code removal, changelog), all content recoverable from the session record; ~40 min. CHECK UPSTREAM #413 ("Train 28: ... git child hardening") FOR OVERLAP BEFORE PUSHING.
- **Operator economics:** credits end before Nov 1; bank zip delivered 2026-10-16 as the survival artifact. If this workspace dies, the zip + GitHub (PR #397, fork) is the recovery corpus.
- Environment truths: sandbox replaced 12+ times (see PROGRESS.md findings #8-#10 + rollback entries); opencode+config auto-reinstall via project setup override; river auth via RIVER_API_KEY env var; ASan impossible in-VM (CI carries it); liveness = advancing log mtime.
- Standing rules: producer never validates own family; every claim = command + output; .agents never committed; identity pt-act via env; push-in-one-sequence after any rebuild.

## Immediate next actions
1. Read upstream #413 for overlap with git-porcelain surface.
2. Rebuild the six porcelain commits from session record, verify gates, PUSH IMMEDIATELY (one sequence: commit→push→PR), then bank+ping.
3. Watch PR #397 for re-review.
