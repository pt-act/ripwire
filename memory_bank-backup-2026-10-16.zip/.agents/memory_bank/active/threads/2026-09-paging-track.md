# Thread Summary — The Paging Track (2026-09-19 → 2026-09-24)

Worth preserving: the full lifecycle of the budgeted-bundle candidate page, because the upstream PR will retell it.

- The team's proposal round (30 ideas → 5) picked "budget receipt + cursor pagination" as #1; my verification pass corrected its premise (the file page already pages — forpage.h/forwidencheck; MCP for serves it; explore refuses limit) and the ask was re-scoped + filed as redhat-et issue #294 with the correction comment posted.
- Gate-first: arms A–F + (6d) written red against the pre-change binary; implementation in three slices (for; pack-task+explore; MCP twins + next=), each slice greening its arms; 16-gate local sweeps + full CI matrix per PR.
- The three CI lessons now standing rules: counted prose, sink-form degrades, owned sweep lists (see standing_requirements.md).
- Design decisions: cliff computed once with tier="below-cliff" continuations (contingent on the #294 ruling); un-paged bundle byte-identical (resume via its own <sigs shown=>); forpage.h as the pages' one home; twins byte-identical to CLI.
- Merged in fork main as PR #3 (7f04ff928) + PR #4 (bd90f226c); the roster pin from the earlier track was adopted upstream (PR #291 closed superseded — maintainer: "arms exactly right, no design changes").
- Open: the #294 cliff ruling gates the upstream PR; JSON dialects declared out of v1 scope.

## 2026-09-29 — the standing plan (operator decision)

PR #362 is open upstream, CI green, the CodeRabbit round done. The operator decided:
WAIT for #362's human feedback / integration-train merge, THEN resume the
audit-remediation DAG — the re-baselined set (3 of 15 retired as landed upstream),
the High (regex-screen-hardening) first, gate-first, one PR per spec, same method.
The WCAG/CSP specs need their rendered-DOM verification pass before executing.
The DAG's planning copy lives beside this file: threads/_audit-dag-2026-09-14/.

## 2026-10-11 — CLOSED: accepted upstream

Five review rounds after opening (Sep 28), PR #362 was accepted by joyful-ii-V-I on 2026-10-10 — "ready for the train" — and merged into integration/train-26c as c7147f761 (no-ff, @pt-act authorship kept, content 879a54b48). Train 26c is PR #384, all checks green. The maintainer's closing verdict: "Issue #294 asked for a page that agents can actually walk, and this delivers it: all five page paths page one list, a pasted handle continues it, and the gate proves both." What the rounds settled, upstream contract now: one list everywhere (B1), ranking flags ride next= (B2), the gate catches the class on a pruning-sensitive corpus (B1b), derived artifacts are merge-time-owned (B4). Fork main is byte-identical to upstream; the feature branch deletes after 26c reaches main. Full arc detail: PROGRESS.md 2026-10-03..2026-10-10.
