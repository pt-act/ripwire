# OPERATOR_GUIDE.md — The Human Role

The operator is the single human role in Orion-OS. Every other role is filled by an interpreter running a program. This document explains what the operator does, what the operator does not do, and how to do the operator's work well.

**Companion files:** `ARCHITECTURE.md` (the pattern), `AGENTS.md` (constitution), `PROJECT_MANIFEST.md` (DAG schema), `SPEC_FORMAT.md` (spec contract), `VALIDATION_PROTOCOL.md` (validation handshake), `MEMORY_FORMATS.md` (state operations).

**When to load this file:** The operator loads this file at the start of any session in which they will interact with Orion-OS. Interpreters do not load this file — they have their own role docs.

---

## §A · What the Operator Is

The operator is the **director and intent-holder** of the project. They decide what gets built, what "done" means at the project level, what the priorities are when resources are constrained, and what to do when the machine layers report they cannot decide. The operator is the **provenance of intent** — the one participant who knows what was wanted — not the top of a technical hierarchy.

The operator is **not** a reviewer in the classical sense. Validation is a machine activity performed by stranger interpreters and arbiters, per `VALIDATION_PROTOCOL.md`. The operator is not expected to read code, re-run tests, or second-guess technical verdicts. When the machine layers say a spec is approved, the operator trusts that verdict unless deployment tells them otherwise.

This is deliberate. The operator's attention is the scarcest and most valuable resource in the system. The operator's arbitration is _supplying missing input, in writing, to the record_ — not ruling on technical truth (ARCHITECTURE.md §J commitment 8: epistemic flatness; no participant holds epistemic authority — it lives in code, logic, and objectives). Orion-OS spends operator attention on:

- **Intent** — what the project is for, what success looks like.
- **Arbitration** — decisions the machine cannot make (scope, priority, cost tradeoffs, ambiguity in a spec's intent).
- **Deployment ground truth** — observing what the real world does with the system and recording failures.
- **Pattern review** — scanning the alignment log and emergent-failures log periodically to notice systemic issues.

Everything else is the machine's job.

---

## §B · The Operator's Five Jobs

In approximate time order across a project's life:

1. **Intake** — translate a goal into an initial manifest. Highest-leverage activity.
2. **Dispatching** (temporary) — select which approved spec's dependencies are now clear and assign the next producer. Eventually automated by a dispatcher program; today the operator does it.
3. **Arbitration** — respond to escalations from the validation protocol when the arbiter cannot resolve a dispute (spec-ambiguity, scope questions, resource tradeoffs).
4. **Deployment capture** — when the deployed system fails or surprises, write an `emergent_failures.md` entry with enough detail that the next planning cycle can encode a guard.
5. **Pattern review** — scan `ALIGNMENT_LOG.md` and `emergent_failures.md` on a cadence (monthly by default) for recurring patterns that indicate systemic issues.

Each job is described below with the decisions the operator must make and the failure modes to avoid.

---

## §C · Intake — Turning Intent Into a First Manifest

The highest-leverage time the operator ever spends on a project is the intake session — the conversation (with an interpreter running the `spec-architect` program) that produces the first version of `manifest.yml` and the first batch of spec files.

Per `ARCHITECTURE.md` §C: the manifest and specs are the program being executed. System reliability is bounded below by their quality. The operator's one job during intake is to surface everything that belongs in the specs — intent, constraints, edge cases, priorities — and to refuse shortcuts.

### What the operator brings to intake

- A **goal** — what the project is for, stated plainly. Not a feature list; an outcome.
- **Constraints** — what the project must not do, what it must work with, what the deadlines or budgets look like.
- **Environment** — where it will run, who will use it, what it has to integrate with.
- **Priorities** — which parts matter most if resources are constrained.
- **Non-goals** — what this project deliberately does not address, so scope creep can be detected.

The operator does not bring a solution. Producing the solution is the interpreters' job. If the operator arrives with implementation decisions already made, they are either (a) correct and should be recorded as constraints, or (b) premature and should be set aside until the specs are drafted. The `spec-architect` program will challenge premature solutions.

### What happens during intake

The `spec-architect` program (see `skills/spec-architect.md`) walks the operator through a structured interview, drafts a project manifest, decomposes the goal into a DAG of specs, drafts each spec file, and presents the result for review. The interpreter does the writing; the operator answers questions and reviews.

The operator's job during intake is to **not agree too fast**. The default failure mode of intake is the operator nodding along to a manifest that does not actually encode what they want, because the manifest looks reasonable on the surface. Specs that look reasonable but do not reflect real intent become faithfully-executed bad specs — every validation gate passes; the project ships the wrong thing.

### Review questions for the intake manifest

Before accepting the first manifest, the operator reads every spec file and asks, of each:

- **Does the Objective match what I actually want?** Not what sounds reasonable — what I actually want.
- **Is the Scope list specific enough that I can tell, spec by spec, what I'm getting?** "Authentication" is not specific; "email/password login with JWT session tokens, 24-hour expiry, no social login" is.
- **Are the Out-of-scope items what I want deferred?** Scope-creep begins when the operator lets a vague out-of-scope list through.
- **Do the Acceptance Criteria correspond to things I would check if I were validating personally?** If I read the criteria and think "sure, whatever" — that's too vague.
- **Do the Consumers lists look complete?** Forward awareness matters; a spec with no declared consumers is either a leaf node (rare) or has an unstated downstream dependency (usually).

If any answer is no, the operator says so. The `spec-architect` program iterates. Intake is not done until the operator would bet on the specs.

### Accepting the manifest

The operator accepts the manifest by responding to the `spec-architect` program's final presentation with an explicit approval. The program then commits the manifest to `manifest.yml` and the spec files to `specs/<id>/spec.md`, and the project state flips from planning to executing.

After acceptance, the operator's intake job is complete. The rest of the project happens under the validation protocol.

### Intake anti-patterns

- **The operator tries to write specs themselves.** Not the operator's job. The operator's job is to answer the interpreter's questions well. Writing specs is what the program is for.
- **The operator approves a manifest they did not read in full.** Every spec must be read. Skipping spec files because they look routine is the specific failure mode this process is designed to catch.
- **The operator frames the goal as "I want a thing that does X" rather than "I want outcome Y."** A feature description constrains the solution; an outcome description leaves room for the interpreter to propose the best shape.
- **The operator answers "use your judgment" to substantive questions.** The interpreter does not have the operator's intent. Questions about intent must be answered by the operator.

---

## §D · Dispatching (Interim Operator Responsibility)

Until a dispatcher program is implemented (see `DISPATCHER_SPEC.md`), the operator performs the dispatcher's role. This is mechanical work, but it has to be right.

### The dispatcher loop

At any moment during execution, the operator (acting as dispatcher) does the following:

1. Read `manifest.yml`. Find every spec with `status: planned` whose `depends_on` list contains only specs with `status: approved`.
2. Pick one. Priorities: (a) critical-path specs first, (b) specs unblocking the most downstream work, (c) specs explicitly marked priority in the manifest or operator preference.
3. Select a producer interpreter. Consult the `project.interpreters.producer` field for the default; override if the spec is unusual (e.g., needs a different capability profile). Confirm the chosen interpreter is not the validator for this spec.
4. Update the manifest:
   - `spec.status: planned → in_progress`
   - `spec.execution.producer: <interpreter-id> @ <timestamp>`
5. Append to `manifest.history`: `{date, event: dispatch, spec: <id>, role: producer, interpreter: <id>}`.
6. Start the producer session, loading the producer's session-start stack per `ARCHITECTURE.md` §I.

When the producer writes its completion report, the operator returns to dispatcher mode:

1. Read the completion report. Confirm it exists and is well-formed (§C of `VALIDATION_PROTOCOL.md`). Malformed reports go back to the producer without validator dispatch — do not spend validator time on malformed input.
2. Select a validator interpreter. Must be distinct from the producer per `VALIDATION_PROTOCOL.md` §B. Consult `project.interpreters.validator`; override if distinctness is not satisfied.
3. Update the manifest: `spec.execution.validator: <interpreter-id> @ <timestamp>` and `spec.status: in_progress → in_review`. Append history.
4. Start the validator session.

Similar mechanics for arbiter invocation and resolution-report writing. The operator is not making judgment calls here — they are running the state machine. The only judgment is interpreter selection, which is usually just "use the project default."

### When to break the default

The default interpreters in the manifest are fine for most specs. Override when:

- The spec calls for specialized capability the default doesn't have (e.g., a spec heavy in image work needs a vision-capable producer).
- The default producer or validator has been flagged in `ALIGNMENT_LOG.md` for repeated drift in a category relevant to this spec.
- The spec is critical-path and the operator wants the most capable available producer for this particular node.

Record the override reason in the history event.

---

## §E · Arbitration — When the Operator Is Invoked

`VALIDATION_PROTOCOL.md` §D names the escape hatches that route a dispute to the operator:

1. **Validator verdict is `rejected`.** The spec itself is the problem, not the implementation. The operator decides: revise the spec (back to planning) or override the rejection (rare; requires strong reasoning).
2. **Push-back category is `spec-ambiguity`.** The producer and validator cannot agree because the spec itself allows both readings. The operator decides which reading is intended, then updates the spec.
3. **Three or more `unverifiable` findings in a verdict.** The spec is not implementable as written. Back to planning.
4. **Arbiter's binding decision is `escalate_to_operator`.** The arbiter identified a question it cannot answer by reading artifacts — an intent, scope, or resource question.

In every case, the operator's response is a **decision + a written artifact**. The decision alone is not enough; without the written artifact, the machine layers have no record to act on.

### Arbitration response format

When the operator arbitrates, they write (or cause to be written) exactly one of the following:

- **Spec revision** — the spec file is updated, its `version` field increments, and the manifest `history` block gets a `spec_revised` event. The spec returns to `planned` status and the validation cycle restarts.
- **Operator note in the spec** — a clarifying note added to the spec's `Implementation Notes` or `Scope` section, resolving the ambiguity without changing the contract. The spec version increments; history records a `spec_clarified` event.
- **Manifest edit** — if the operator's decision affects the DAG (adding a spec, changing dependencies, deferring a spec), the manifest is edited and a `manifest_revised` event is appended.
- **Override** — the operator explicitly overrides a machine verdict. Rare and logged with full reasoning in `ARCHITECTURAL_DECISIONS.md`. The override is visible to every future interpreter and is flagged in the next pattern review.

Arbitration decisions that result only in a verbal "proceed" with no written artifact are invalid. The machine layers have no way to act on unwritten decisions.

### Arbitration anti-patterns

- **Deciding without writing.** The decision must produce an artifact.
- **Reflexively siding with the producer or validator.** The operator is not a tiebreaker by popularity; they decide on intent. If neither interpreter's reading is what the operator wanted, the operator says so and writes the actual intent into the spec.
- **Refusing to decide.** If the operator genuinely has no preference, they write `either reading is acceptable — producer may choose` into the spec and let execution proceed. Refusing to decide without recording that refusal leaves the dispute open.
- **Over-arbitrating.** If the machine layers did not escalate, the operator does not intervene. Arbitrating in cases the protocol did not route to the operator bypasses the validation system.

---

## §F · Deployment Capture — Writing `emergent_failures.md` Well

Locus 3 is the ground-truth layer. When the deployed system fails in a way no spec anticipated, the operator captures the failure in `.agents/memory_bank/emergent_failures.md` per the format in `MEMORY_FORMATS.md` §J.

This is the single most important sustained responsibility the operator has. Every entry here becomes an input to the next planning cycle. The architecture learns through this file.

### Writing a good entry

The four blocks of an emergent-failure entry (Surfacing, Causal Chain, Validation Gap, Remedy) are not decorative. Each block serves a specific downstream reader:

- **Surfacing** — the next operator (or the same operator weeks later) reading this to pattern-match against a new failure. Must be specific enough that a similar future failure can be recognized.
- **Causal Chain** — the next planning-time interpreter, deciding which specs' acceptance criteria need strengthening. Must name the specs in the blast radius and the direct cause precisely.
- **Validation Gap** — the `spec-architect` program's input when deciding whether this failure class deserves a new integration spec or a criterion in an existing unit spec. Must identify the earliest locus that could plausibly have caught the failure.
- **Remedy** — the durable architectural change. Must be a concrete guard, not "we'll be more careful."

### The encoded-guard test

Before marking an `emergent_failures.md` entry complete, the operator asks: **"If this exact failure class appeared in a different future project, would the encoded guard I've written catch it?"** If not, the guard is too specific. If the guard is just "we should have tested X," the guard is too vague. The guard must be concrete enough to become a criterion in a future spec and general enough to apply beyond the specific incident.

### Severity calibration

Severity levels are calibrated so the aggregate `emergent_failures.md` review can distinguish signal from noise.

- **low** — real, but did not affect anything critical. Record for pattern accumulation; no urgent remedy required.
- **medium** — blocked something, but there was a workaround. Plan the remedy into the next feature cycle.
- **high** — blocked something with no workaround, or affected many users. Plan the remedy as the next spec in the active manifest.
- **critical** — data loss, security breach, systemic outage. Halt new work until the remedy is planned, scoped, and either implemented or explicitly deferred with risk acknowledgment.

Operator bias toward the middle (labeling everything `medium`) defeats the severity signal. When in doubt, pick the higher level; false positives on severity cost little, false negatives can hide systemic issues.

### Capture cadence

Write the entry **while the failure is fresh**. A week later, half the details are lost. Ideally, the entry is written the same day the failure is observed, or within the same working session.

The entry does not need the remedy resolved before it is written. An entry with `Remedy: planned` and a clear `Pattern` field is a valid entry. Fill in the remedy details and the `Status: encoded` flag when the next planning cycle acts on the entry.

---

## §G · Pattern Review — Monthly Cadence

On a regular cadence (monthly is the default; adjust to project pace), the operator reviews three files:

### `ALIGNMENT_LOG.md` review

Scan for drift categories that repeat. Patterns the operator is looking for:

- **Same interpreter, same category, repeatedly.** Strong signal that this interpreter should be reassigned away from this role. Update `project.interpreters` in the manifest.
- **All interpreters, same category.** Strong signal that the constitution's clause on this category is under-specified. Consider proposing an update to `AGENTS.md`.
- **Rising frequency.** Drift getting more frequent over time suggests context pressure — the specs are getting longer or more complex than the interpreters handle well. Consider tightening spec scope.

The review produces either an interpreter reassignment, a constitution clarification, or a decision to accept the drift pattern as inherent (in which case it becomes an input to interpreter selection going forward).

### `emergent_failures.md` review

Scan for entries where `Status: planned` has not progressed to `Status: encoded`. An unencoded guard is a known-but-unaddressed risk; the operator decides whether to schedule it, defer it explicitly, or close it as no-longer-applicable.

Also scan for pattern clusters — three entries with the same `Pattern` field, even with different specific causes, signal that the pattern itself is the risk, not any one instance.

### Validator quality audit

Sample validator verdicts from the last month. Check for:

- **Rubber-stamping.** Verdicts that say `approved` without per-criterion evidence, or with evidence that is copy-paste from the completion report. A validator that doesn't do its own verification is worse than no validator — it creates false confidence.
- **Obstructionism.** Verdicts that reject trivial producer revisions as substantive, forcing unnecessary arbiter invocations.
- **Pattern blindness.** Verdicts that approved a spec whose implementation later caused an emergent failure. Was the failure class in the spec? If so, the validator missed it; that's a drift note. If not, the failure is a planning-time gap, not a validator gap.

A validator failing any of these checks is reassigned. Log the reassignment in `ARCHITECTURAL_DECISIONS.md` with the audit evidence.

---

## §H · Project-Level "Done"

The machine layers can decide when a spec is approved. The operator decides when a project is done.

### Project completion triggers

A project is candidate for `status: complete` when:

- Every spec in the manifest has `status: approved`.
- Every milestone in the manifest is satisfied.
- The deployment has been exercised against the project's original objective (per the `project.objective` field) and the operator judges the objective met.

The operator flips `project.status: executing → complete`, appends a `project_completed` event to `manifest.history`, and writes a final entry in `PROGRESS.md` summarizing what was built and any residual open items.

### Parking vs. completing

Projects that stop mid-execution are **paused**, not complete. Pausing is an operator decision; it requires a `PROGRESS.md` entry stating the reason and the conditions under which the project would resume. A paused project's memory bank is preserved; the manifest is frozen.

A paused project that will never resume is **archived** — the operator flips `project.status: complete` with a residual entry noting it was abandoned, and moves on. Archived projects' memory banks remain on disk as references for future projects.

---

## §I · Interpreter Selection and Cost Tradeoffs

The manifest's `project.interpreters` block names the default producer, validator, and arbiter. The operator chooses these at project start and revisits them during pattern review.

### Selection criteria

- **Producer:** the most capable model available for the project's implementation work. Producer capability caps implementation quality; do not economize here.
- **Validator:** a different training lineage than the producer. Capability can be lower — validator work is verification, which is easier than production. Cost optimization here is often fine.
- **Arbiter:** different from both prior roles. Invoked less frequently, so cost matters less. Prefer the third vendor available. Capability should match producer level or exceed it — the arbiter is the final technical authority.

### Cost management

Arbiter invocations are the most expensive role per invocation (they read everything the other two wrote) but also the rarest. Producer invocations are frequent and consume the most compute. Validator invocations are frequent but lighter.

If cost becomes a constraint, optimization order is: validator first (can use cheaper models), then producer (tighter spec scope reduces per-spec producer cost), then arbiter only as a last resort (the arbiter is the final backstop; weakening it weakens the whole system).

### The one tradeoff not to make

Do not use the same model family for producer and validator to save cost. This defeats the heterogeneity property that the entire validation protocol depends on. If only one vendor is available, the system still runs, but the operator accepts that Locus-1 validation is weaker than designed. Flag this in `ALIGNMENT_LOG.md` as a known architectural compromise.

---

## §J · What the Operator Never Does

Stated explicitly so they can be checked:

1. **Write code.** Implementation is the producer's job. An operator who writes code is acting as a producer without the producer's role assignment, bypassing the validation protocol.

2. **Validate specs technically.** Reading a verdict to understand it is fine. Re-running tests to second-guess a verdict is validator work. If the operator disagrees with a verdict, the response is to escalate or to adjust the spec, not to override the verdict by personal review.

3. **Write or edit validation artifacts.** Completion reports, verdicts, push-backs, and arbiter audits are interpreter artifacts. The operator does not author them or correct them. If a validation artifact is malformed, the operator returns it to the interpreter for correction.

4. **Skip the intake process.** "Just build a thing like X" is not intake. Without a manifest and spec files, no validation can occur.

5. **Write to the memory bank on an interpreter's behalf.** The operator writes to `emergent_failures.md` and answers `open_questions.md`; the interpreter writes everything else. Operator edits to `PROGRESS.md`, `MASTER_CONTEXT.md`, or `ALIGNMENT_LOG.md` are scope violations.

6. **Override the validation protocol silently.** Any protocol bypass is explicit, written, and flagged in `ARCHITECTURAL_DECISIONS.md` with reasoning. Silent bypasses defeat the architecture.

7. **Act on pattern review without writing.** Observations that don't produce a written action (reassignment, spec change, constitution update) are not complete pattern reviews.

---

## §K · Operator Commitments

Stated so they are auditable:

1. **Intent is the operator's exclusive domain.** No interpreter can infer intent the operator has not stated. Intake is where intent is captured; ambiguity escalations are where intent is clarified.

2. **Arbitration produces artifacts.** Every operator decision that affects the project produces a written change to specs, manifest, or memory bank. Unwritten decisions do not exist.

3. **Deployment capture is non-negotiable.** Every observed failure produces an `emergent_failures.md` entry. Failures without entries are known bugs the architecture cannot learn from.

4. **Pattern review is a recurring commitment.** Monthly cadence is the default; the operator commits to a cadence and keeps it.

5. **The operator does not act as an interpreter.** No writing code, no writing validation artifacts, no arbitrating technical disputes personally.

6. **Overrides are explicit and rare.** When the operator overrides a machine verdict, the reasoning is recorded in `ARCHITECTURAL_DECISIONS.md`. An override that is not recorded is an undocumented exception and will propagate silently.

7. **Scarce attention goes to scarce decisions.** The operator's time is spent on the jobs in §B. Time spent elsewhere is a signal that the machine layers are failing or that the operator has drifted from the role.

---

_End of OPERATOR_GUIDE.md v1.0_
