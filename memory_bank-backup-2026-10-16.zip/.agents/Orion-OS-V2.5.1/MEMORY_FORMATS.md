# MEMORY_FORMATS.md — State Operations Manual (v2)

This file is the complete reference for memory bank operations. `AGENTS.md` §09 defines _what_ the memory bank is and _that_ every interpreter must maintain it. This file defines _how_ — formats, writing rules, session procedures, cross-project memory, and the Orion-OS-specific artifacts that sit alongside the classic memory bank.

**Companion files:** `AGENTS.md` (constitution), `ARCHITECTURE.md` (the pattern), `PROJECT_MANIFEST.md` (the DAG), `SPEC_FORMAT.md` (spec contract), `VALIDATION_PROTOCOL.md` (validation handshake).

Both this file and `AGENTS.md` live in `.agents/`. The memory bank lives in `.agents/memory_bank/`. Add `.agents/` to `.gitignore` — this directory is local working context, not repository content.

**Path convention:** Inline references use bare filenames (e.g., `PROGRESS.md`) — the base path `.agents/memory_bank/` is implied. Procedural steps the interpreter executes directly use full paths (e.g., `.agents/memory_bank/active/PROGRESS.md`) for unambiguous file access.

**When to load this file:**

- At session start, when creating `.agents/memory_bank/` from scratch.
- At session start, to write the cross-client session log entry (§M-bis).
- When writing entries to any memory bank file.
- When auditing existing entries for compliance.
- When writing or reading an `emergent_failures.md` entry (see §K).

---

## §A · The Three Scopes of Project State

Before formats: state lives in three scopes, and interpreters must not confuse them. Writing into the wrong scope is the single most common memory bank failure.

| Scope              | Location                       | What belongs here                                                                                                    | What does not                                                                   |
| ------------------ | ------------------------------ | -------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------- |
| **Manifest**       | `manifest.yml` at project root | DAG, spec status, interface declarations, history of manifest mutations                                              | Implementation notes, session narrative, decisions not yet reflected in a spec  |
| **Spec artifacts** | `specs/<id>/`                  | The spec itself and its validation directory (`completion-report.md`, `verdict.md`, etc.)                            | Cross-spec learnings, project-wide decisions, the human's narrative of the work |
| **Memory bank**    | `.agents/memory_bank/`         | Human-facing development diary, AI-facing strategic compass, cross-spec decisions, emergent failures, open questions | Per-spec validation artifacts, the DAG itself, interface contracts              |

The **manifest** is the index. The **specs** are the chapters. The **memory bank** is the diary. Each answers a different question:

- _What exists and what's its status?_ → manifest.
- _What does this specific spec declare, and did its implementation pass validation?_ → spec directory.
- _Why did we choose the approach we did, what bit us in deployment, what's the human's narrative of the project?_ → memory bank.

Writing a validation verdict into `PROGRESS.md` is a scope violation. Writing a cross-spec architectural decision into `completion-report.md` is a scope violation. The three scopes are not redundant; they are complementary.

---

## §B · Why the Dual-Audience Split (within the memory bank)

The memory bank serves two readers who process information differently:

- **The interpreter** scans, locates, extracts. It needs compressed, structured, scan-first data — key-value pairs, not prose.
- **The human** reads narratively. They return after days away and need to know: what phase are we in, what was implemented on what date, what's still open, and how to ask the next session to resume.

The directory structure reflects this: root files are AI-optimized; the `active/` directory is the human's development diary.

Previous versions had `logs.md` (session logs) and `DEVELOPMENT_HISTORY.md` (feature chronology) as two separate files that said the same things differently. The AI wrote to `logs.md` but the human never read it. The human wanted a development diary but got session fragments instead. `PROGRESS.md` replaces both — it's the human's book (read top-to-bottom for the story, scan headers for the index) AND the AI's progress record (structured entries, file references, phase status).

---

## §C · Directory Layout

```
.agents/memory_bank/
├── MASTER_CONTEXT.md          # AI: Strategic compass — key-value, scan-first (max ~200 lines)
├── ARCHITECTURAL_DECISIONS.md # AI: Decisions — table format, scan Status column
├── ALIGNMENT_LOG.md           # AI: Drift tracking — per AGENTS.md §11 format. Review monthly.
├── standing_requirements.md   # AI: Verdict-time rules with failure provenance → injected into new specs
├── emergent_failures.md       # Locus-3 deployment failures → inputs to future planning
├── active/
│   ├── PROGRESS.md            # Human: Phase-indexed development diary
│   ├── current_focus.md       # Both: What's being worked on NOW + resumption point
│   ├── open_questions.md      # AI → Human: Questions the AI needs answered
│   └── threads/               # Optional: paste summaries worth preserving
```

All files in this tree are project-local. The cross-project memory file (§M) lives elsewhere.

---

## §D · MASTER_CONTEXT.md — AI-Optimized Strategic Compass

Audience: interpreter (scan-first, key-value format). Not a narrative — structured for random access.

```markdown
# [Project Name] — Master Context

## Status: [active/paused/blocked]

## Direction: [1-line current goal]

## Architecture: [key patterns — bullet list, not prose]

- Pattern: [description]
- Pattern: [description]

## Stack: [languages, frameworks, key dependencies]

## Key Files: [files the interpreter will touch most — path + 1-line purpose]

## Active Decisions: [numbered list — contradicted decisions struck through]

1. [decision] — [rationale] (YYYY-MM-DD)
   ~~2. [overruled decision] — [why overruled] (overruled YYYY-MM-DD)~~
```

**Rules:**

- Newest entries at top. If an entry contradicts one below, the top entry wins.
- Not a changelog, not a session log, not a wishlist — only committed decisions.
- Max ~200 lines. Prune entries that no longer reflect reality.
- **When to update:** At session-end checkpoint (Rule 4) if the session changed direction or produced a new architectural insight.

**Relationship to the manifest:** `MASTER_CONTEXT.md` records the _why_ — the rationale and active decisions shaping how specs are written. The manifest records the _what_ — the DAG and status. If a decision affects how a future spec should be structured, it goes here. If it affects what a specific spec must do, it goes in that spec.

---

## §E · ARCHITECTURAL_DECISIONS.md — Decision Lookup Table

Audience: interpreter (scan Status column) + human (read Rationale column).

```markdown
# Architectural Decisions

| #   | Date       | Decision           | Rationale | Alternatives Considered      | Status            |
| --- | ---------- | ------------------ | --------- | ---------------------------- | ----------------- |
| 1   | YYYY-MM-DD | [what was decided] | [why]     | [what else was on the table] | active/superseded |
```

**Rules:**

- One row per decision. Table format — no prose sections.
- **Ids are date+slug, not a global counter** (`AD-YYYY-MM-DD-<slug>`): no central counter, no cross-session numbering coordination, no collisions. Producers reference decisions by draft title until the row is committed; supersession references the full id.
- Status values: `active` or `superseded` (with reference to the decision that replaced it).
- Decisions reached through validation disputes that escalated to the operator (per `VALIDATION_PROTOCOL.md` §D) are recorded here with a reference to the arbiter audit that exposed them.

---

## §E-bis · standing_requirements.md — Verdict-Time Rules With Provenance

Audience: interpreter. The Locus-3 feedback path (emergent failures → next planning) exists in §J. This file is the **Locus-1 feedback path**: rules learned at validation time that must reach subsequent rounds' prompts. The resolution report's "Lessons for Future Specs" section no longer dies with its spec — it lands here.

```markdown
## [SR-YYYY-MM-DD-<slug>] <one-line rule>

- **Rule:** <imperative sentence>
- **Provenance:** <verdict or resolution-report path + one-line failure story>
- **Scope:** <spec types / component classes where it applies>
- **Status:** active | retired (reference to the retiring decision)
```

**Rules:**

- A standing requirement without provenance is malformed — same discipline as architectural decisions. Rules with provenance are cheap to honor and impossible to dismiss.
- **Producers:** validators, via the resolution report's Lessons section. **Consumers:** spec-architect (injects applicable SRs into each new spec at drafting time); producers (read at session start); validators (check compliance where an SR names a checkable condition).
- Entries are append-only. Retirement is a status flip with reference, never a deletion.

---

## §F · active/PROGRESS.md — The Human's Development Diary

Audience: human (read top-to-bottom for the story, scan headers for the index) + interpreter (structured entries, file references, phase status).

This is the file the human reads when they come back after a break. It tells the story of the project in phases, with dates, implementation status, and clear resumption pointers.

**The human should be able to:**

- Scan phase headers to see what's done vs. in-progress vs. blocked.
- Read a date entry to know exactly what was implemented that day.
- Find the "Next" pointer to know how to ask the next session to resume.
- Remind the interpreter "we implemented X on Y date" and the interpreter can verify it here.

```markdown
# Development Progress — [Project Name]

## Phase 1: [Phase Name] — ✅ Complete

### YYYY-MM-DD

- **Implemented:** [spec-id] — [one line: what was built]
- **Decided:** [key decisions, or "none"]
- **Blocked:** [what's blocked, or "none"]
- **Next:** [next spec or task, with dependency status]

## Phase 2: [Phase Name] — 🔄 In Progress

### YYYY-MM-DD

- **Implemented:** ...
- **Decided:** ...
- **Blocked:** ...
- **Next:** ...

## Phase 3: [Phase Name] — ⏳ Not Started

_(No entries yet — phase defined in specs but not begun)_
```

**Phase status markers:** ✅ Complete · 🔄 In Progress · ⏸ Paused · 🚫 Blocked · ⏳ Not Started

**Each date entry MUST include all four fields.** If a field has nothing, write `none` — never leave it blank. Blank = invisible gap. `none` = confirmed nothing.

**Entries are focused, not narrative.** The spec's checkmarks (`specs/<id>/spec.md` Progress Tracking) and phase-log (`specs/<id>/phase-log.md`) capture the detail. PROGRESS.md is the human's index — what was built, what was decided, what's blocked, what's next. Not a retelling of every step.

**When to create a new phase:** A phase is a coherent unit of work with a clear goal. Create one when:

- Starting a new feature, module, or architectural layer.
- The work's goal is distinct from the current phase.
- A milestone in the manifest (`milestones` block, per `PROJECT_MANIFEST.md`) is reached.

**Relationship to spec progress tracking:** Each spec has its own Progress Tracking section with checkboxes and an optional phase-log. PROGRESS.md references specs by id — the human can drill into `specs/<id>/spec.md` for phase-level detail or `specs/<id>/phase-log.md` for decisions. PROGRESS.md stays high-level; the spec directory has the detail.

**Relationship to manifest history:** The manifest's `history` block is the audit trail of DAG mutations — machine-readable, append-only. `PROGRESS.md` is the narrative companion. When a spec reaches `approved`, both files get an entry: the manifest records the event mechanically; `PROGRESS.md` records what that meant for the project.

**This is the human's file.** The interpreter does not prune it unilaterally. If the file grows large, flag it to the human and propose archiving older phases to `threads/archive-YYYY.md`. The human decides what stays.

---

## §G · active/current_focus.md — Fastest Onboarding

Audience: interpreter (scan one paragraph) + human ("where did we leave off?"). This is the first file both read at session start.

```markdown
# Current Focus

[1 paragraph: what's being worked on right now, which phase, which files or spec ids. Update this at session start and whenever focus shifts.]

## Resumption Point

- Spec or file: [where the next session should start — prefer spec id over file path when applicable]
- Task: [what to do next — specific, not vague]
- Blockers: [any questions from open_questions.md that must be resolved first, or "none"]
- Role context: [if currently in a validation cycle, the role the next session should assume: producer, validator, arbiter, operator]
```

The `Role context` field is new in v2. When a session ends mid-validation-cycle, the next session needs to know not just "what file to open" but "what role am I playing in the handshake."

---

## §H · active/open_questions.md — AI Questions to the Human

Audience: interpreter → human. This file contains questions the interpreter needs the human to answer in order to proceed. Not the human's questions — the interpreter's questions to the human.

```markdown
# Open Questions

## [YYYY-MM-DD] [Question topic]

- **Context:** [what situation produced this question]
- **Question:** [specific, answerable question — not vague]
- **Impact:** [what's blocked until this is answered]
- **Proposed options:** [if the interpreter has a recommendation, state it — but leave the decision to the human]
- **Source:** [optional — spec id, arbiter audit path, or "general" if not tied to a specific artifact]
```

**Rules:**

- Every question must be specific enough for the human to answer without needing to investigate first.
- Every question must state what's blocked until it's resolved.
- If the interpreter can propose a default answer, include it — but flag it as a proposal, not a decision.
- Remove questions once answered. Add the answer as a decision to `PROGRESS.md` and/or `ARCHITECTURAL_DECISIONS.md`.
- Questions originating from arbiter escalations (`VALIDATION_PROTOCOL.md` §D) reference the arbiter audit file in the `Source` field.

---

## §I · ALIGNMENT_LOG.md — Drift Tracking

Audience: interpreter (self-audit) + human (monthly review).

`AGENTS.md` §11 defines when an alignment log entry must be written: whenever an interpreter notices itself drifting from the constitution (taking shortcuts, softening claims, skipping validation steps, treating fast paths as defaults). This file is the record.

```markdown
# Alignment Log

## [YYYY-MM-DD HH:MM] [Drift category]

- **Session context:** [what was being worked on]
- **Drift observed:** [what the interpreter noticed itself doing that conflicted with the constitution]
- **Constitution clause:** [AGENTS.md §N that was in tension]
- **Correction:** [what the interpreter did to correct, or "deferred — flagged for human review"]
- **Pattern note:** [if this is the Nth time this category has appeared, note the count and suspected cause]
```

**Drift categories (not exhaustive; add new ones as observed):**

- `dishonest_report` — claimed completion or success that artifacts did not support.
- `validation_shortcut` — skipped or shallowed a check the protocol required.
- `scope_creep` — expanded work beyond the spec without operator authorization.
- `memory_skip` — completed significant work without a concurrent memory write.
- `role_confusion` — acted outside the role assigned for the current spec (e.g., validator started producing).

**Rules:**

- Entries are append-only. Prior entries are never rewritten; errors are corrected by new entries referencing the prior one.
- **Monthly review:** The human (or a dedicated alignment-review session) scans the log for recurring patterns. Recurring drift of the same category indicates either a constitution clause that needs clarifying or a systemic issue with the interpreter selection.
- Drift observed during validation (e.g., a validator rubber-stamping) is logged here, not in the spec's validation directory. The validation directory is write-once and spec-scoped; the alignment log is project-scoped and append-only.

---

## §J · emergent_failures.md — Locus-3 Deployment Failures

Audience: interpreter (next planning cycle) + human (project retrospective).

`ARCHITECTURE.md` §D defines Locus 3 as the layer where the system meets reality. `VALIDATION_PROTOCOL.md` §F defines the feedback loop. This file is the record that makes the loop work.

**Purpose.** When a deployed system fails in a way no spec anticipated, an entry here captures enough detail that the next planning cycle can encode a check against that failure class. The entry is the difference between "we had a bug" and "the architecture learned a new guard."

**Who writes:** The operator, or an interpreter acting on the operator's report of a failure. Entries are not written by a validator or arbiter — those layers are Locus-1 and Locus-2 concerns. An entry here is by definition a failure that passed all prior validation.

```markdown
# Emergent Failures — [Project Name]

## [YYYY-MM-DD] <short-title> (severity: low | medium | high | critical)

### Surfacing

- **Observed by:** [operator, user, monitoring system — name the source]
- **Environment:** [production, staging, real-device demo — be specific]
- **Symptom:** [what the failure looked like from outside — 1–3 sentences]
- **Reproduction:** [steps to reproduce, or "intermittent — see notes"]

### Causal Chain

- **Direct cause:** [the line, module, or interaction where the failure originated]
- **Contributing conditions:** [the preconditions that made the failure possible — environmental, data-shape, timing]
- **Spec(s) in the blast radius:** [list of spec ids whose artifacts were involved]

### Validation Gap

- **Which locus should have caught this:** [unit | integration | deployment — the earliest plausible catcher]
- **Why it didn't:**
  - If locus 1 (unit): which criterion was missing or too weak?
  - If locus 2 (integration): was there an integration spec covering this composition? If not, that is the gap.
  - If locus 3 (deployment — by design): state that no prior layer was expected to catch this.
- **Reasoning-based or data-based:** Was the failure a reasoning miss (all interpreters shared a blind spot) or a data miss (real-world input shape that no test exercised)? This distinction drives the remedy.

### Remedy

- **Immediate fix:** [what was changed to stop the failure — file/spec references]
- **Encoded guard:** [the check, criterion, or integration spec that will be added in the next manifest to catch this class. Concrete, not "we'll be more careful."]
- **Pattern:** [1–2 sentences naming the general class this specific failure belongs to, for future pattern matching]

### Status

- **Remedy status:** planned | in_progress | encoded
- **Encoded in spec:** [spec id of the spec that encodes the guard, once written]
- **Notes:** [open issues, partial fixes, dependencies]
```

**Rules:**

- Entries are append-only. Dated, newest at the top.
- Every entry must name at least one **encoded guard** — the durable output. "Be more careful next time" is not a guard. "Add an integration spec testing concurrent writes under load" is a guard.
- The `Pattern` field is critical. Specific failures are recorded for history; patterns are what the next planning cycle consults.
- When a future spec encodes a guard against this failure, update the entry's `Status` block (this is the one exception to append-only — the status block at the bottom of an entry is editable; the body is not).
- **Severity guidelines:**
  - `low` — cosmetic, non-blocking, affects few users.
  - `medium` — blocks a workflow, has a workaround.
  - `high` — blocks a workflow, no workaround, or affects many users.
  - `critical` — data loss, security breach, or systemic outage.
- **Planning-time consumption:** At the start of each planning cycle, `spec-architect` (or whichever planning program is in use) reads this file. Entries with unencoded guards become planning-time inputs — either a new spec is added to the manifest to encode the guard, or an existing spec's acceptance criteria are strengthened.

---

## §K · Resolution Report References

Resolution reports (`specs/<id>/validation/resolution-report.md`, per `VALIDATION_PROTOCOL.md` §C) live in the spec scope, not the memory bank. But the memory bank references them in two places:

1. **`PROGRESS.md`** — when a spec reaches `approved`, the date entry's `Implemented` field includes a reference to the resolution report path, so the human can trace narrative → audit trail without searching.

2. **`emergent_failures.md`** — when a deployment failure traces back to a specific spec cycle, the entry's `Spec(s) in the blast radius` field references the resolution report so the arbiter's and validator's reasoning are one click away.

This is the only coupling between memory bank and spec scope. The memory bank never copies or duplicates spec-scope content; it references.

---

## §L · Writing Protocol

**The core problem this solves:** Memory entries are the only continuity between sessions. When entries have gaps, the next session starts from a hole. The human shouldn't have to ask "update memory" — and when entries are written, they must be complete enough that a stranger can pick up exactly where you left off.

### Rule 1: Write concurrently, not deferred

Do not batch memory writes for "later." Write immediately after each significant action — within the same tool-call batch as the change itself when possible. "I'll log this at the end" means it won't get logged, or it'll be vague.

Memory writes are not narration — they are part of the work. Writing to `PROGRESS.md` is an engineering deliverable, not a commentary on one.

**Triggers that MUST produce an immediate entry:**

- Every file creation, deletion, or significant refactor.
- Every non-obvious decision (chose A over B — log _why_).
- Every question that blocks progress — when the interpreter can't proceed without human input (→ `open_questions.md` immediately).
- Every test failure that reveals something unexpected.
- Every spec approval or rejection (→ `PROGRESS.md` narrative entry referencing the resolution report).
- Every observed drift from the constitution (→ `ALIGNMENT_LOG.md`).
- Every deployment failure the operator reports (→ `emergent_failures.md`).

### Rule 2: No blank fields

Every entry must be complete. Incomplete entries are worse than no entry — they create false confidence. If you can't fill a field, write `TBD: [what's missing]` instead of leaving it blank. A TBD is visible; a blank is invisible. Write `none` for fields that genuinely have nothing — but confirm it's genuinely nothing, not "I forgot to check."

### Rule 3: Write verification

After writing an entry, ask yourself: **"If I vanished right now, could a stranger read this entry and know exactly what was done, why, and what's next?"** If not, the entry is incomplete. Fix it before moving on.

Specifically, verify each entry has:

- ✓ **Files or specs named** — not "implemented feature X" but "completed spec `storage-schema` — see resolution report at `specs/storage-schema/validation/resolution-report.md`".
- ✓ **Why stated** — not just what was done, but the reason for the approach.
- ✓ **Resumption point** — the next session knows exactly where to start (file, task, and if applicable, role).
- ✓ **No orphaned questions** — every question in `open_questions.md` is specific enough for the human to answer, or explicitly marked "blocked, needs human input."

### Rule 4: Session-end checkpoint

Before the session ends:

- Write the final `.agents/memory_bank/active/PROGRESS.md` entry for today's date — all four fields filled (Implemented, Decided, Blocked, Next).
- Update `.agents/memory_bank/active/current_focus.md` with the resumption point, including the role context if a validation cycle is mid-flight.
- If the session changed direction or produced a new architectural insight, update `.agents/memory_bank/MASTER_CONTEXT.md` before closing.
- If the session observed drift from the constitution, confirm there is a matching `ALIGNMENT_LOG.md` entry.
- If you can't fill a field, write `TBD: [what's missing]` — never leave it blank.

### Rule 5: Scope discipline

Every memory write must pass the scope check (§A). Before writing:

- Is this a validation artifact? → It goes in `specs/<id>/validation/`, not the memory bank.
- Is this a DAG mutation? → It goes in `manifest.yml`, not the memory bank.
- Is this a project-wide decision, narrative, or cross-spec learning? → Memory bank, in the appropriate file per §C.

Mis-scoped writes are silently corrosive: the right reader never looks in the wrong place. Catch scope errors at write time, not at audit time.

### Common failure modes

- ❌ `Implemented: feature X` — which files? which spec? what does it do?
- ❌ `Next: continue` — continue _what_? In _which_ spec? As which role?
- ❌ `Blocked: none` (when you actually haven't checked) — confirm it's genuinely none.
- ❌ Writing a spec's verdict details into `PROGRESS.md` — scope violation, verdict belongs in `specs/<id>/validation/verdict.md`.
- ✅ `Implemented: completed validation cycle for spec 'storage-schema' — resolution report at specs/storage-schema/validation/resolution-report.md; post-conflict arbiter (gemini-2.0) confirmed genuine correction on the schema.ts created_at omission.`
- ✅ `Next: dispatch spec 'url-repository' — its depends_on (storage-schema) is now approved; role for next session: dispatcher, selecting producer interpreter.`
- ✅ `Blocked: none — all Phase 2 specs approved, Phase 3 specs defined in manifest but not begun.`

---

## §M-bis · Session Log — Cross-Client Work Diary

A single, tool-agnostic work diary lives at `{HOME}/.rna/session_logs-01.md`. It records **every working session across every project and every AI client** (Qwen Code, cyberstrike CLI, Claude Code, or any other), so the human can open one file and answer: _"when did I work on project X for client Y, and which session id do I resume?"_

**Who writes:** the interpreter, as a **session-start housekeeping task** (step 0 of §M). Logging at session start — not only at session end — means even a crashed or forgotten session is recorded the next time work on that project resumes.

**This file is not project-scoped.** Unlike everything else in this manual, it is cross-project by design. Scope discipline (§A) does not apply to it; it is the one shared artifact.

### Entry format

```markdown
## YYYY-MM-DD HH:MM — <project-dir-name> — <Client Name> — <model> — <client app>
- session: `<session-id or TBD>`
- <one to three lines: what this session is about / resumption state>
```

Example:

```markdown
## 2026-09-28 14:20 — strix — Acme Corp — zai/glm-5.3-flash-high — qwen
- session: `3fb38849-bd0a-450b-bf06-40704d2e78d1`
- resumed after crash; auth token refresh bug fixed, regression test added. Next: retry-logic review in PR #12.
```

### Rules

1. **One entry per session, at session start.** If an entry for today's session already exists (same date + project + client app), update it instead of duplicating.
2. **Newest entries at top**, directly after the file's `# Session Log` header.
3. **Client name resolution:** check `{HOME}/.rna/session_logs-01.md` and `{HOME}/orion-os/MEMORY.md` for a known mapping of the project directory to a client. If unknown, ask the human once, then record the mapping in the log entry so future sessions can reuse it.
4. **Session id honesty:** look up the session id where the client exposes it (e.g. Qwen Code: `{HOME}/.qwen/projects/<project>/chats/*.runtime.json` → `session_id`). If it cannot be determined, write `TBD` — never invent an id.
5. **Model field:** use the actual model id when known (e.g. `zai/glm-5.3-flash-high`); otherwise the client app name alone is acceptable.
6. **No blank fields** — same discipline as §L Rule 2. `TBD` over blank, always.
7. **The log is append/replace-only.** Never rewrite historical entries; corrections are new entries or in-place updates to today's own entry only.

### When to load this file's rules

- At **session start** (§M step 0) — to write the entry.
- When the human asks "what did I work on for X" or "which session was Y" — to read from it.

---

## §M · Starting a Session

0. **Session log entry (§M-bis):** write today's entry to `{HOME}/.rna/session_logs-01.md` — date/time, project dir, client, model, session id (look it up; `TBD` if unknown), one line of context. This is housekeeping, not optional.
1. Read `.agents/memory_bank/active/current_focus.md` — immediate work context + resumption point + role context. Fastest onboarding.
2. Scan `.agents/memory_bank/active/PROGRESS.md` phase headers — understand what's done, what's in-progress, what's blocked.
3. Read `.agents/memory_bank/MASTER_CONTEXT.md` — strategic compass. Structured format enables fast scan.
4. Glance at `.agents/memory_bank/active/open_questions.md` — questions the interpreter needs the human to answer to proceed.
5. If executing against a project manifest, open `manifest.yml` and locate the spec(s) relevant to the resumption point. Read the current spec's spec.md.
6. If the resumption point places the session mid-validation, read the spec's `validation/` directory in full. If this session's role is validator or arbiter, also load `VALIDATION_PROTOCOL.md`.
7. **Audit last session's exit state** — check the most recent `PROGRESS.md` entry. If `Next:` is missing or vague, flag it: "Last session has no resumption point — context may be incomplete." Surface any `TBD` fields as unresolved items for this session.
8. Verify `.agents/` is in `.gitignore`. If not, add it and inform the human.
9. Begin. Recommend the next logical action — don't ask "what would you like to do?"

---

## §N · Cross-Project Memory

A system-wide memory file lives at `{HOME}/orion-os/MEMORY.md`.

- **"Save to memory: [thing]"** → append a timestamped entry to that file.
- **"Look in memory for [xyz]"** → read it and surface only what matches.
- **Never auto-load this file.** It is not part of the default session context.
- **Never proactively reference it.** Only surface when explicitly asked.
- This is for cross-project preferences, learnings, and notes that travel with the human — not project-specific architecture.

Cross-project content that specifically concerns recurring Orion-OS-level patterns (e.g., "interpreter X consistently rubber-stamps in validator role on short specs") belongs here, not in any project's `ALIGNMENT_LOG.md`. The alignment log is project-scoped; cross-project patterns propagate through this file.

---

## §O · First Session

If `.agents/memory_bank/` doesn't exist, create the full structure on first session — all files with their correct formats, even if some start empty (use `none` for empty fields, never blank). Also ensure `.agents/` is in `.gitignore`.

The first-session skeleton:

```
.agents/memory_bank/
├── MASTER_CONTEXT.md          # populated with project name, status=active, direction from operator intake
├── ARCHITECTURAL_DECISIONS.md # empty table with header row
├── ALIGNMENT_LOG.md           # empty, with header
├── emergent_failures.md       # empty, with header — this file exists from day one even though it has no entries until deployment
├── active/
│   ├── PROGRESS.md            # Phase 1 header, first date entry for the project kickoff
│   ├── current_focus.md       # points to the first spec being planned
│   ├── open_questions.md      # any questions from operator intake
│   └── threads/               # empty directory
```

Creating `emergent_failures.md` on first session (with no entries) matters: the file's presence is a signal that the project is Locus-3-aware from the start. A missing `emergent_failures.md` at deployment time is itself a Locus-3 risk — the operator has nowhere to write the first failure down.

---

## §P · Memory Bank Commitments

The design choices above, stated so the commitments are auditable:

1. **Three scopes, strictly separated.** Manifest, specs, memory bank. No scope duplicates another's content.

2. **Dual-audience within the memory bank.** Root files are AI-scannable; `active/` is the human's narrative. This is structural, not cosmetic.

3. **Write concurrently, not deferred.** Memory writes are engineering deliverables on the same footing as code.

4. **Stranger-readable entries.** Every entry stands alone. No "see above" or "as discussed."

5. **Append-only where integrity matters.** `emergent_failures.md` bodies, `ALIGNMENT_LOG.md`, and `PROGRESS.md` historical entries are append-only. Corrections append; they do not overwrite.

6. **Locus-3 is a first-class file.** `emergent_failures.md` exists from day one. Deployment feedback is not an afterthought bolted onto the process.

7. **The memory bank references the spec scope; it does not copy it.** Resolution reports, validation verdicts, and spec interfaces live in `specs/<id>/`. The memory bank references by path.

If a future extension violates any of these, it is not an extension of this format — it is a different format.

---

_End of MEMORY_FORMATS.md v2.0_
