# SPEC_FORMAT.md — Spec Contract

Every spec in the project manifest is backed by a spec file. This document defines what that file must contain.

**Per `ARCHITECTURE.md` §C:** The manifest and specs together are the program being executed. A faithfully-executed bad spec passes every validation gate. **System reliability is bounded below by spec quality.** Writing a spec is the highest-leverage activity in Orion-OS.

**File location:** `specs/<spec-id>/spec.md` — path declared in the manifest's `file` field.

---

## §A · What a Spec Is

A spec is a **complete, self-contained instruction** for a producer interpreter. It must be readable by a stranger — a fresh interpreter with no memory of the planning phase — and sufficient for that stranger to:

1. Understand what is being asked.
2. Know what context to load (dependencies, memory bank references).
3. Produce the required artifacts.
4. Self-check against acceptance criteria before signaling completion.

A validator interpreter reads the same spec and, separately, verifies the producer's claims against the artifacts. Both roles require the spec to be unambiguous and complete.

Per the stranger principle: if context required to execute the spec lives only in the operator's head or in a prior conversation, the spec is broken.

---

## §B · Required Sections

Every spec file contains these sections, in this order, using these exact headings:

```markdown
# <Spec Title>

## Header

## Objective

## Scope

## Interfaces

## Acceptance Criteria

## Implementation Notes

## Failure Modes

## Dependencies

## Consumers

## Status
```

Optional sections may be added after `## Status`; required sections may not be omitted or reordered. An omitted required section is a malformed spec.

---

## §C · Section Contracts

### Header

Machine-readable block (YAML code fence) that links the spec to the manifest:

```yaml
id: <must match the spec id in manifest.yml>
type: unit | integration
version: <semver; increments on revision>
manifest: ../../manifest.yml
```

The header is the binding between manifest and spec. The dispatcher verifies that the header's `id` matches the manifest entry before invoking any interpreter.

### Objective

One to three sentences. States:

- **What** this spec accomplishes — concrete outcome, not activity.
- **Why** this matters in the project context — one-line reference to the project objective.

Bad: "Implement the authentication system."

Good: "Issue and verify JWT tokens so that the API endpoints in `api-gateway` can authorize requests. Authentication is the prerequisite for every protected route in the project."

### Scope

Two explicit lists:

- **In scope** — what this spec covers. Be specific.
- **Out of scope** — what this spec deliberately does not address. Be explicit about deferrals.

Bad scopes are vague on both sides. A good scope section names at least three in-scope items and at least two out-of-scope items, even for small specs. The act of writing the out-of-scope list forces the author to notice where scope creep could occur.

### Interfaces

Two subsections, `Produces` and `Consumes`, that fully specify the machine-checkable contracts. Manifest-level summaries are short; this is where contracts live in detail.

#### Produces

For each interface this spec exposes to downstream consumers:

```markdown
### <interface name>

- **Shape:** <type signature, schema, endpoint contract, etc.>
- **Location:** <where the artifact lives — file path, endpoint URL, table name, etc.>
- **Invariants:** <properties that always hold>
- **Examples:** <at least one concrete example>
- **Consumers:** <spec ids that consume this, matching manifest>
```

The **shape** field must be precise enough that a validator can verify the artifact matches. Strings, handwaves, and "something like" language are rejected.

#### Consumes

For each interface this spec depends on:

```markdown
### <interface name>

- **From:** <spec id that produces this>
- **Shape:** <what this spec expects>
- **Usage:** <how this spec uses it>
```

The shape declared here must match the producer's declared shape. Mismatches violate the manifest's interface-closure invariant.

### Acceptance Criteria

A numbered list of checkable conditions. Each condition must be:

- **Testable** — a machine (validator interpreter) can verify it without ambiguity.
- **Specific** — names the exact artifact, file, endpoint, or behavior being checked.
- **Non-overlapping** — each criterion adds distinct information.

Format:

```markdown
1. **<short name>**: <specific condition>. **Verifier:** <how to check — command, file inspection, test to run>.
2. ...
```

Bad: "Code is high quality."

Good: "**Schema integrity**: Running `sqlite3 data/urls.db '.schema url_table'` returns a schema matching §Interfaces/Produces/url_table. **Verifier:** diff the output against `specs/storage-schema/reference-schema.sql`."

Rule of thumb: if the validator can't copy-paste or mechanically execute the verifier, the criterion is too soft.

**Two-directional criteria for precision-owning components (v1.1).** Any component that flags, detects, confirms, or disposes — owns precision — MUST state **both directions** as separate acceptance criteria:

- **True-positive (sensitivity):** the genuine violating case → finding emitted (right kind, right evidence class).
- **True-negative (precision):** the correct, secure behavior → **no finding**. This is the false-positive guard and is mandatory.

A detector spec that specifies only the true-positive direction is under-specified and returns to planning. The negative direction is not optional polish — it is where precision lives, and it is the direction that fails silently. If a precision-owning spec lacks a true-negative criterion, the validator records it as `major` (under-specified spec) and the spec returns to planning; the validator does not invent the missing criterion silently.

**Negative controls (mandatory with Tier 2).** Every named property in a Tier 2 spec's Validation Strategy carries at least one negative control: reintroduce the defect class the property names (in the scratch tree), confirm the suite fails, revert, and record the run — mutation applied → expected failure → observed failure → revert confirmed. The validator re-performs at least one control of its own choosing in the verify tree (VALIDATION_PROTOCOL.md §H). Recommended for Tier 1 suites gating `blocking` specs.

### Implementation Notes

Guidance for the producer. Not mandatory constraints — the producer may choose differently if justified. Includes:

- Recommended patterns or libraries (per project conventions).
- Known pitfalls or subtleties.
- References to existing code to reuse (per `AGENTS.md` §03 minimalism).
- Trade-offs the producer should be aware of.

This section is advisory. **Acceptance criteria are what the validator checks; implementation notes are what the producer reads for context.** Do not duplicate acceptance criteria here.

### Failure Modes

Explicit list of known ways this spec can fail, and expected handling.

```markdown
### <failure name>

- **Trigger:** <when this failure can occur>
- **Expected handling:** <what the producer should do>
- **Validator check:** <how the validator confirms the handling>
```

Specs that list no failure modes are either trivial (genuinely cannot fail) or under-analyzed (far more common). spec-architect should push back on any non-trivial spec with an empty failure modes section.

### Dependencies

A narrative version of the manifest's `depends_on`. For each dependency:

- **Spec:** <id>
- **What this spec assumes from it:** <specific properties, interfaces, behaviors>
- **What breaks if it changes:** <impact if the dependency is modified>

The "what breaks" field is the producer's documentation of its own fragility. Validators use it to check whether assumptions are still valid if a dependency is revised later.

### Consumers

A narrative version of the manifest's `produces.consumers`. For each consumer:

- **Spec:** <id>
- **What it needs from this spec:** <specific interfaces, behaviors>
- **Constraints on evolution:** <what must not change without breaking the consumer>

This section keeps producers aware that their work is not a leaf — other specs depend on their output shape. Forward awareness made explicit.

### Status

Matches the manifest's status field. Automatically synchronized by the dispatcher.

```markdown
**Status:** planned | in_progress | in_review | approved | blocked
**Last updated:** <ISO 8601 timestamp>
**Updated by:** <interpreter or operator>
```

When producer or validator updates status, they also append a line here. Appends are append-only; edits to the status history are logged in the manifest's history block.

---

## §D · The Stranger-Executable Test

A spec is correctly written if and only if a fresh interpreter — loaded only with the constitution, architecture, this format doc, the manifest, and the spec file — can successfully produce the required artifacts without asking for clarification.

This is the acid test. spec-architect runs it mentally before marking a spec as ready. pm-auditor (when gating the planning phase) runs it explicitly.

Failing the stranger-executable test means one of:

- Objective is ambiguous.
- Scope is unbounded.
- An interface is underspecified.
- An acceptance criterion is not verifiable.
- A dependency is implicit.
- A failure mode is missing.

**If the test fails, revise before execution.** Do not execute a spec that needs clarification; clarification after the fact is scope creep disguised as implementation.

---

## §E · Worked Example

Full spec file for `storage-schema` from the `short-url` project manifest in `PROJECT_MANIFEST.md` §F:

```markdown
# URL Storage Schema

## Header

​`yaml
id: storage-schema
type: unit
version: 1.0.0
manifest: ../../manifest.yml
​`

## Objective

Define and create the relational schema that stores URL mappings and click events. This schema is the foundation for the shortening API, the redirect service, and the analytics API — every other spec in the project reads from or writes to it.

## Scope

**In scope:**

- SQLite schema definition for `url_table` and `click_log_table`.
- Migration script to initialize the schema in an empty database.
- Reference schema file checked into the repository at `specs/storage-schema/reference-schema.sql`.

**Out of scope:**

- Database connection pooling or concurrency handling (addressed by each consuming spec).
- Data migration from existing systems (project is greenfield).
- Analytics queries (covered by `analytics-api`).
- User or auth tables (project does not require auth per the operator's objective).

## Interfaces

### Produces

#### url_table

- **Shape:**
  ​`sql
CREATE TABLE url_table (
  short_code TEXT PRIMARY KEY NOT NULL,
  long_url TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_url_long_url ON url_table(long_url);
​`
- **Location:** SQLite database at `./data/urls.db`; schema file at `specs/storage-schema/reference-schema.sql`.
- **Invariants:**
  - `short_code` is unique (primary key).
  - `long_url` is non-null and non-empty.
  - `created_at` is set automatically at insertion.
- **Examples:**
  ​`
short_code | long_url                    | created_at
abc123     | https://example.com/long/x  | 2026-01-15 10:30:00
​`
- **Consumers:** shortening-api, redirect-service, analytics-api.

#### click_log_table

- **Shape:**
  ​`sql
CREATE TABLE click_log_table (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  short_code TEXT NOT NULL REFERENCES url_table(short_code),
  clicked_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_click_short_code ON click_log_table(short_code);
​`
- **Location:** Same database as `url_table`.
- **Invariants:**
  - `short_code` must reference an existing row in `url_table` (foreign key).
  - `clicked_at` is set automatically at insertion.
- **Examples:**
  ​`
id | short_code | clicked_at
1  | abc123     | 2026-01-15 11:00:00
2  | abc123     | 2026-01-15 11:05:00
​`
- **Consumers:** redirect-service, analytics-api.

### Consumes

None. This spec has no upstream dependencies.

## Acceptance Criteria

1. **Schema file exists**: `specs/storage-schema/reference-schema.sql` exists and contains the exact SQL from §Interfaces/Produces. **Verifier:** `diff specs/storage-schema/reference-schema.sql <expected>` returns empty.
2. **Schema applies cleanly**: Running `sqlite3 data/urls.db < specs/storage-schema/reference-schema.sql` on an empty database succeeds with no errors. **Verifier:** exit code 0; `.schema` lists both tables.
3. **Tables match declared shape**: `sqlite3 data/urls.db ".schema url_table"` and `".schema click_log_table"` produce output matching the declared shapes. **Verifier:** regex match on the output.
4. **Foreign key enforced**: Inserting into `click_log_table` with a `short_code` that doesn't exist in `url_table` fails. **Verifier:** SQL insert returns a foreign key constraint error (after `PRAGMA foreign_keys = ON`).
5. **Indexes present**: `sqlite3 data/urls.db ".indexes"` lists `idx_url_long_url` and `idx_click_short_code`. **Verifier:** grep on the output.

## Implementation Notes

- SQLite chosen for simplicity; the project doesn't need concurrent writes at scale.
- Foreign key enforcement must be enabled per-connection in SQLite with `PRAGMA foreign_keys = ON;`. Downstream specs (especially redirect-service) must apply this pragma.
- The `long_url` index supports duplicate detection in `shortening-api`.

## Failure Modes

### Schema application fails on non-empty database

- **Trigger:** Running the migration against a database that already has tables with the same names.
- **Expected handling:** Producer must not auto-drop existing tables. Script should fail with a clear error and leave existing data untouched.
- **Validator check:** Attempt migration against a DB with a pre-existing `url_table`; verify exit code is non-zero and the table is unchanged.

### Missing data directory

- **Trigger:** The `./data/` directory doesn't exist when the script runs.
- **Expected handling:** Producer creates the directory if missing, with mode 0755.
- **Validator check:** Delete `./data/` and run the migration; verify it succeeds and directory is recreated.

## Dependencies

None. This is a root node in the DAG.

## Consumers

- **shortening-api**: Inserts into `url_table`. Requires primary key uniqueness and the `long_url` index for duplicate lookups. **Constraints on evolution:** Changing the `short_code` column type or removing the `long_url` index would break this consumer.
- **redirect-service**: Reads from `url_table` (lookup by `short_code`) and writes to `click_log_table`. Requires foreign key enforcement. **Constraints on evolution:** Removing the foreign key or renaming either column would break this consumer.
- **analytics-api**: Reads from `click_log_table`, joining on `short_code`. **Constraints on evolution:** Removing `clicked_at` or the `idx_click_short_code` index would break this consumer.

## Status

**Status:** approved
**Last updated:** 2026-01-15T10:41:00Z
**Updated by:** gpt-5 (validator)
```

---

## §F · Anti-Patterns

What a bad spec looks like:

- **Narrative objectives.** "We want to build a great user experience." Not a spec — a vision statement.
- **Soft acceptance criteria.** "The code should be clean and maintainable." Not verifiable; validator has no choice but to approve by taste.
- **Missing interface shapes.** "Produces a database." Tells the consumer nothing about what to expect.
- **Implicit dependencies.** Consumes something but doesn't list it in `depends_on`. Catchable by manifest lint.
- **No failure modes for non-trivial work.** Every real spec can fail. An empty failure modes section means the author didn't think about it.
- **Scope creep in implementation notes.** Adding "also, let's handle X" in notes where X is a separate concern. X should be its own spec.
- **Copy-pasted acceptance criteria.** Same pattern across multiple specs suggests the criteria weren't thought through for this specific spec.
- **Implementation-in-spec.** Spec tells the producer exactly what code to write. Specs describe outcomes; producers choose implementations.
- **No examples.** Interfaces described abstractly with no concrete example. Strangers can't execute what they can't visualize.
- **Ambiguous verifiers.** "Manual inspection confirms correctness." The validator is an interpreter, not a human — it needs a mechanical check.

---

## §G · Spec Review Checklist

Before a spec's status moves from `planned` to `in_progress`, spec-architect (or pm-auditor gating the planning phase) verifies:

- [ ] All required sections present, in order, with correct headings.
- [ ] Header `id` matches the manifest entry exactly.
- [ ] Objective is concrete and references the project-level goal.
- [ ] Scope has at least three in-scope items and at least two out-of-scope items.
- [ ] Every `produces` interface has shape, location, invariants, at least one example, and listed consumers.
- [ ] Every `consumes` interface has `from` pointing to a spec that produces it (interface closure).
- [ ] Every acceptance criterion is testable with a named, mechanical verifier.
- [ ] Failure modes are listed (or the spec is genuinely trivial).
- [ ] Dependencies section's spec ids match manifest `depends_on` exactly.
- [ ] Consumers section's spec ids match manifest `produces.consumers` exactly.
- [ ] The stranger-executable test passes.

A spec that fails any checklist item goes back to planning. Execution begins only after all items pass.

---

## §H · Integration Spec Specifics

Integration specs follow the same format but with distinguishing features:

- **Type field** is `integration` in the header and manifest.
- **Dependencies** are at least two unit specs per DAG invariant 4.
- **Scope** focuses on compositions, interfaces, and emergent behavior — not on any single unit's internals.
- **Acceptance criteria** describe scenarios that exercise multiple units together. Examples: "Request flows end-to-end from POST /shorten through GET /:short_code and produces a click in click_log_table." Each scenario must be mechanically runnable.
- **Failure modes** focus on composition failures: interface mismatches, race conditions, shared-state invariant violations, timing issues.
- **Produces** is typically a verification report, not new functionality. The integration spec's value is the verification itself.

Integration specs may also produce documentation artifacts (sequence diagrams, integration runbooks) that record the verified composition for future operators.

---

_End of SPEC_FORMAT.md v1.0_
