---
name: spec-architect
version: 2.1.0
role: producer
description: |
  Transforms operator intent into a committed project manifest and spec set.
  Planning-time producer: decomposes a project goal into a DAG of unit and
  integration specs with declared interfaces, acceptance criteria, and
  dependency chains. Produces manifest.yml and specs/<id>/spec.md files.

  This is the highest-leverage skill in Orion-OS. Per ARCHITECTURE.md §C:
  system reliability is bounded below by spec quality. The operator's hours
  in planning are worth more than their hours anywhere else.

  USE WHEN: operator initiates a new project, says 'plan', 'spec', 'design',
  'requirements', or a paused project's first session after resumption.
loads:
  - AGENTS.md
  - ARCHITECTURE.md
  - PROJECT_MANIFEST.md
  - SPEC_FORMAT.md
  - MEMORY_FORMATS.md
produces:
  - path: manifest.yml
    format: yaml
    purpose: project DAG — single source of truth for specs, dependencies, interfaces
  - path: specs/<spec-id>/spec.md
    format: markdown
    purpose: individual spec files per SPEC_FORMAT.md
consumes:
  - path: .agents/memory_bank/active/current_focus.md
    optional: true
  - path: .agents/memory_bank/MASTER_CONTEXT.md
    optional: true
  - path: .agents/memory_bank/emergent_failures.md
    optional: true
  - path: .agents/memory_bank/standing_requirements.md
    optional: true
  - path: .agents/memory_bank/active/open_questions.md
    optional: true
compatible_interpreters:
  - any
distinctness_requirements: {}
supersedes: spec-architect (legacy v1.x)
---

# spec-architect

## Purpose

Transform an operator's intent into a committed project manifest and spec set. The successful output is a manifest the operator would bet on — every spec is stranger-executable, every interface is declared, every acceptance criterion is mechanically verifiable, and the DAG is complete.

This is the most important skill in the program library. A faithfully-executed bad spec passes every validation gate. The execution layer amplifies whatever is in the specs — good specs get amplified into good outcomes, bad specs get amplified into bad outcomes with equal fidelity. Invest here.

## Role

producer

## When to Run

**Planning Triggers:**

- Operator initiates a new project ("plan X", "design Y", "spec Z").
- Operator says "let's plan", "create requirements", "write spec", "what are the dependencies?"
- A paused project resumes and needs its manifest revised or extended.

**Feedback Triggers:**

- An emergent failure (MEMORY_FORMATS.md §J) requires new specs or strengthened criteria.
- An arbiter escalation surfaces a spec-ambiguity that needs resolution.
- A deployment failure's encoded guard needs to be planned into the next manifest.

**Not Useful For:**

- Bug fixes that don't change the spec contract.
- Trivial changes (overkill).
- Refactoring existing code without changing external behavior (different workflow).

## Inputs

- Operator's stated goal, constraints, environment, priorities, and non-goals (gathered during the intake interview).
- `.agents/memory_bank/MASTER_CONTEXT.md` — project conventions and active decisions (optional, for existing projects).
- `.agents/memory_bank/emergent_failures.md` — deployment feedback that must be encoded into new specs (optional, for planning cycles after deployment).
- `.agents/memory_bank/active/open_questions.md` — unresolved questions from prior sessions (optional).
- Any existing `manifest.yml` — for projects being extended or revised.
- Any visual assets (mockups, designs, diagrams) the operator provides (optional).

## Outputs

- `manifest.yml` at project root — the full project DAG per PROJECT_MANIFEST.md.
- `specs/<spec-id>/spec.md` — one file per spec, conforming to SPEC_FORMAT.md.
- `.agents/memory_bank/active/PROGRESS.md` — appended entry for the planning session.
- `.agents/memory_bank/active/current_focus.md` — updated with resumption point.

## Process

### Phase 1: Intake Interview

The intake is the highest-leverage conversation in the entire project. The operator's job is to surface everything that belongs in the specs — intent, constraints, edge cases, priorities. The spec-architect's job is to ask until the answers are specific enough to write stranger-executable specs from.

1. Greet the operator. State the skill's purpose: "I will transform your intent into a committed manifest and spec set. My output is only as good as your input — I will ask questions until I have enough to produce specs you would bet on. The system's reliability is bounded below by the quality of what we plan here."

2. Gather the following through structured conversation. Do not proceed until all are answered. If the operator cannot answer a question now, write it to `open_questions.md` with a proposed default and proceed with what's available.

   **a. Goal — What are we building and why?**
   - Must be outcome-shaped, not feature-shaped.
   - Bad: "Build a URL shortener."
   - Good: "Accept long URLs and return short codes; accept short codes and redirect to the original URL; track click counts per short code."
   - The goal becomes `project.objective` in the manifest. One sentence, concrete, outcome-shaped.

   **b. Constraints — What limits us?**
   - Technical: existing systems to integrate with, required tech stack, deployment environment.
   - Time: deadlines, milestones, phasing requirements.
   - Budget: inference cost limits, infrastructure budget, human availability.
   - Integration: APIs, databases, auth systems, external services.
   - Ask: "What must this work with? What can't we change?"

   **c. Environment — Where does this run?**
   - Production environment (cloud, local, edge, mobile).
   - Who uses it (internal team, public users, other systems).
   - What it integrates with (list every external system).
   - Scale expectations (concurrent users, request volume, data size).
   - Ask: "Walk me through what happens when a real user interacts with this system."

   **d. Priorities — What matters most?**
   - If resources are constrained, which parts ship first?
   - What's the MVP vs. the full vision?
   - Which specs are on the critical path?
   - Ask: "If you could only ship three things, what would they be?"

   **e. Non-goals — What are we deliberately NOT building?**
   - This is the most important question for preventing scope creep.
   - Ask: "What might someone assume is in scope that you explicitly want deferred?"
   - Examples: "No social login", "No real-time sync", "No admin dashboard in v1", "No mobile app".
   - These become the Out-of-Scope lists in individual specs.

   **f. Execution-environment constraints — What boundaries does this project need, and why?**
   - Ask: "Do producers get scratch trees? Is the default cooperative posture right, or does this project need the adversarial posture (tool-level fencing)? What's the mutation policy?"
   - Defaults (ARCHITECTURE.md §E): scratch trees granted, cooperative posture, patch-only mutation. Record deviations explicitly with rationale — e.g. a compliance regime requiring preventive controls, or an untrusted external producer lineage.
   - The answer is encoded project-wide in the manifest header or per spec. It is reviewed at operator lock like every other constraint.
   - **Why this question exists:** structural constraints minted in dispatch directives instead of files cannot be examined, amended, or inherited. A directive may cite a constraint; it may not create one. A constraint discovered mid-run is a manifest history event (`constraint_amended`), then dispatched against.

3. If this is not a greenfield project, read the existing `manifest.yml` and `.agents/memory_bank/MASTER_CONTEXT.md` to understand current state. Note existing specs, their status, and any open questions.

4. If `.agents/memory_bank/emergent_failures.md` has entries with unencoded guards (`Status: planned`), list them explicitly. These become inputs to the new or revised specs — either new specs to encode the guard, or strengthened acceptance criteria in existing specs. Per ARCHITECTURE.md §D, this is the feedback loop from Locus 3 to Locus 1.

5. If `.agents/memory_bank/standing_requirements.md` exists, read it. Active entries whose Scope matches any spec being drafted are **injected into that spec** — as acceptance criteria, failure modes, or implementation notes, whichever the rule's shape suggests. An SR is a planning-time input with the same standing as an unencoded emergent-failure guard; its provenance travels with it (cite the SR id in the spec). This is the Locus-1 feedback loop: verdict-time rules reaching the next round's prompts.

6. If the operator provides visual assets (mockups, designs, diagrams), analyze them. Extract:
   - Implicit requirements not stated verbally.
   - UI components that will need their own specs.
   - Data flows visible in the design.
   - Edge cases the mockup suggests (empty states, error states, loading states).

7. Search the codebase for reusable patterns and components:
   - Similar features already implemented.
   - Shared utilities, base classes, common patterns.
   - Existing API endpoints that the new work should extend rather than duplicate.
   - Configuration patterns, deployment patterns, testing patterns.
   - Note every reusable component — it reduces spec scope and implementation risk.

8. Write the intake summary. Present it back to the operator:

   ```
   Intake Summary:
   - Goal: [one sentence]
   - Constraints: [bullet list]
   - Environment: [bullet list]
   - Priorities: [ordered list]
   - Non-goals: [bullet list]
   - Reusable components found: [list]
   - Emergent failure guards to encode: [list or "none"]
   - Standing requirements to inject: [list of SR ids or "none"]
   - Execution-environment constraints: [defaults confirmed | deviations with rationale]
   - Open questions: [list or "none"]

   Does this capture your intent? Adjust anything before I proceed to decomposition.
   ```

9. Incorporate operator feedback. This is the operator's last chance to correct the frame before decomposition begins.

### Phase 2: Decomposition

This is where the DAG is shaped. The spec-architect's judgment matters most here — too few specs and they become unmanageable mega-specs; too many and the overhead dominates.

9. Decompose the goal into a DAG of specs. Follow these principles:

   **a. Interface-first thinking.** Before naming what a spec does, name what it produces and what it consumes. Interfaces are the edges of the DAG. The DAG is defined by its edges, not its nodes.

   **b. One concern per spec.** A spec that produces interfaces for both "user authentication" and "payment processing" is two specs. Split on concern boundaries.

   **c. Spec sizing heuristics:**
   - A spec should be implementable by one interpreter in one session (roughly 2–5 iterations).
   - A spec that produces more than 3–4 interfaces is probably too large — consider splitting.
   - A spec that produces zero interfaces is either a leaf (documentation, deployment config) or under-specified.
   - A spec whose acceptance criteria list exceeds 10 items is probably covering multiple concerns.

   **d. Common decomposition patterns:**
   - **Data layer first.** Schema/model specs are root nodes — no dependencies. They produce interfaces (tables, types, schemas) that everything else consumes.
   - **API/service layer second.** These depend on data layer specs and produce endpoint contracts.
   - **Frontend/consumer layer third.** These depend on API layer specs and produce UI components or client libraries.
   - **Integration specs last.** These depend on multiple unit specs and verify emergent behavior.

   **e. Integration spec necessity check.** For every pair of unit specs that share an interface, ask: "Can the composition fail in ways that unit-level validation won't catch?" If yes, an integration spec is needed. Common triggers:
   - Two specs write to the same data store.
   - A spec consumes another's output in a non-trivial way (not just reading a table, but composing API calls).
   - Concurrency or ordering behavior matters.
   - The interface has implicit contracts not captured in the shape (e.g., "the producer must call this before that").

10. For each spec in the DAG, draft the manifest entry:

    a. A kebab-case `id` (unique, descriptive: `storage-schema`, `auth-endpoints`, `integration-e2e`).
    b. A one-line `title`.
    c. `type`: unit or integration.
    d. `depends_on`: list of spec ids this spec requires.
    e. `produces`: list of interfaces with name, shape summary, and consumer spec ids.
    f. `consumes`: list of interfaces with name and source spec id.
    g. `validation_gate`: one of `none`, `blocking`, or `standalone` (see step 10h).

10h. **Validation gate classification.** For each spec, decide its validation posture. This is a planning-time architectural decision — it determines what the dispatcher does after the producer completes, and whether downstream specs are blocked.

    **`none`** — The producer's self-report is trusted. No validator runs. Downstream specs can begin as soon as the completion report exists. Use for:
    - Specs with only Tier 1 components (UI, config, documentation).
    - Low-risk specs where a mistake is cheap to fix.
    - Specs that produce interfaces consumed only by integration specs (which will catch the error anyway).

    **`blocking`** — A validator must clear the spec before any downstream spec can begin. The dispatcher routes the completion report to a different interpreter, who issues a verdict per VALIDATION_PROTOCOL.md. Only `approved` or `needs_revision` → `approved` unblocks downstream. Use for:
    - Specs with Tier 2 components (security-critical: auth, crypto, input validation, rate limiting).
    - Root specs whose interfaces are consumed by many downstream specs — a mistake here cascades.
    - Specs where the cost of fixing a downstream consumer is high (e.g., schema changes that break every API endpoint).

    **`standalone`** — Validation is substantial enough to warrant its own spec in the DAG. The validation spec depends on the specs it validates, produces a validation report, and downstream specs consume that report as a trust artifact. Use for:
    - Complex products where validation requires dedicated effort (security audit, performance benchmark, compliance check).
    - When the operator wants a single point of truth for "is the system validated?" before integration work begins.
    - When multiple upstream specs need cross-component validation that can't be done at the unit level.

    **How to choose:**
    - Start with `none` as the default. Escalate to `blocking` only when the spec's risk profile justifies it. Escalate to `standalone` only when the product's complexity justifies a dedicated validation spec.
    - The operator makes the final call. Present the classification with rationale and let them adjust.
    - Over-classifying (everything is `blocking`) creates a bottleneck. Under-classifying (everything is `none`) lets errors cascade. The spec-architect's judgment is the calibration.

    **Impact on delegation:**
    - `none`: producer → (done) → next spec starts immediately. One interpreter involved.
    - `blocking`: producer → validator (different interpreter) → verdict → next spec starts only on approval. Two interpreters involved. The dispatcher enforces distinctness.
    - `standalone`: producer(s) → validation spec (potentially a third interpreter) → validation report → downstream specs. Three interpreters involved for the full chain.

    **If using `standalone`:** create the validation spec in the DAG like any other spec. Its `type` is `validation`. Its `depends_on` lists the specs it validates. Its `produces` is a validation report. Its acceptance criteria are the validation activities (property tests to run, security checks to perform, performance benchmarks to hit).

11. Validate the DAG invariants (PROJECT_MANIFEST.md §C):

    a. **Unique ids.** No two specs share an id.
    b. **Acyclic dependencies.** Topological sort must succeed. If a cycle exists, it's a decomposition error — split a spec or restructure dependencies.
    c. **Interface closure.** Every `consumes` entry references a spec that exists and has that interface in its `produces`. No magic glue.
    d. **Integration coverage.** Every integration spec's `depends_on` includes at least two unit specs.
    e. **No orphan outputs.** Every `produces` entry has at least one consumer, unless it's a deployment-facing leaf (e.g., an API endpoint that users call directly).
    f. **Status consistency.** All specs start as `planned`.

12. **Critical path analysis.** Identify the longest dependency chain in the DAG. This is the critical path — it determines the minimum number of sequential iterations for the project. Account for validation gates:
    - A `blocking` gate adds one iteration (producer completes → validator reviews → approved → downstream begins).
    - A `standalone` validation spec adds its own iteration count to the critical path.
    - Present both the implementation path and the validation overhead to the operator.

13. **Parallelization analysis.** Identify specs that can execute in parallel (their dependencies are satisfied by the same upstream specs). Account for validation gates:
    - Parallel specs with `blocking` gates can have their validation run in parallel too (different validators or same validator reviewing multiple completion reports).
    - Present parallelization opportunities with validation overhead included:
    - "After `storage-schema` is approved by the validator, `shortening-api` and `redirect-service` can execute in parallel. Both have `blocking` gates — their validators can also run in parallel if distinct interpreters are available."
    - Estimate efficiency gain from parallelization, including validation time.

14. Present the DAG to the operator as a table:

    ```
    Spec DAG:
    | id | type | depends_on | validation_gate | produces | consumes |
    |----|------|------------|-----------------|----------|----------|
    | storage-schema | unit | [] | blocking | url_table, click_log_table | [] |
    | shortening-api | unit | [storage-schema] | blocking | POST_/shorten | url_table |
    | redirect-service | unit | [storage-schema] | blocking | GET_/:short_code | url_table, click_log_table |
    | analytics-api | unit | [storage-schema, redirect-service] | none | GET_/stats/:short_code | click_log_table |
    | integration-e2e | integration | [shortening-api, redirect-service, analytics-api] | none | e2e_report | POST_/shorten, GET_/:short_code, GET_/stats/:short_code |

    Critical path: storage-schema →[blocking]→ redirect-service →[blocking]→ analytics-api → integration-e2e (4 sequential, 2 validation gates)
    Parallelization: shortening-api || redirect-service (after storage-schema validation)
    Delegation chain: storage-schema@producer → validator → shortening-api@producer || redirect-service@producer → analytics-api@producer → integration-e2e@producer

    Does this decomposition match your intent? Any missing specs? Any that should be split or merged? Any validation gates to adjust?
    ```

15. Incorporate operator feedback on the DAG. Add, remove, merge, or split specs as requested. Re-validate invariants after every change.

### Phase 3: Spec Drafting

This is where the detailed spec files are written. Each spec must pass the stranger-executable test: a fresh interpreter reading only the spec + manifest + framework docs could execute it without asking for clarification.

16. For each spec in the DAG, write `specs/<spec-id>/spec.md` following SPEC_FORMAT.md §B. All ten required sections, in order. Guidance for each section:

    **Header:** Bind to manifest. `id` must match the manifest entry exactly.

    **Objective:** One to three sentences. States what this spec accomplishes (concrete outcome, not activity) and why it matters in the project context (reference the project-level goal).
    - Bad: "Implement the authentication system."
    - Good: "Issue and verify JWT tokens so that the API endpoints in `api-gateway` can authorize requests. Authentication is the prerequisite for every protected route in the project."

    **Scope:** Two explicit lists.
    - In scope: at least three specific items. Name the actual components, files, endpoints, tables — not categories.
    - Out of scope: at least two explicit deferrals. What someone might assume is in scope but you're deliberately excluding. This prevents scope creep.
    - Bad: "In scope: backend. Out of scope: frontend."
    - Good: "In scope: JWT token generation, token verification middleware, refresh token rotation. Out of scope: social OAuth providers (deferred to `auth-oauth` spec), password reset flow (deferred to v2), rate limiting on login attempts (handled by `api-gateway` spec)."

    **Interfaces:** Full machine-checkable contracts. For each produced interface:
    - Shape: precise type signature, schema, or endpoint contract. No handwaves.
    - Location: exact file path, endpoint URL, or table name.
    - Invariants: properties that always hold (uniqueness, non-null, format constraints).
    - Examples: at least one concrete example with real-looking data.
    - Consumers: which specs consume this (must match manifest).

    For each consumed interface:
    - From: which spec produces it.
    - Shape: what this spec expects (must match the producer's declaration).
    - Usage: how this spec uses it.

    **Acceptance Criteria:** Numbered list. Each criterion must be:
    - Testable: a machine can verify it without ambiguity.
    - Specific: names the exact artifact, file, endpoint, or behavior.
    - Non-overlapping: each criterion adds distinct information.
    - Format: `**<short name>**: <specific condition>. **Verifier:** <how to check — command, file inspection, test to run>.`
    - Bad: "Code is high quality."
    - Good: "**Schema integrity**: Running `sqlite3 data/urls.db '.schema url_table'` returns a schema matching §Interfaces/Produces/url_table. **Verifier:** diff the output against `specs/storage-schema/reference-schema.sql`."
    - Rule of thumb: if the validator can't copy-paste or mechanically execute the verifier, the criterion is too soft.

    **Validation Strategy:** Every spec declares its validation tier. This is not optional — it determines what the producer must deliver beyond the implementation itself. Assess each spec's components against the tier heuristics below and write a Validation Strategy section in the spec.

    **Tier applicability heuristics:**

    _High PBT value (Tier 2 — property-based testing required):_
    - Authentication systems, authorization/access control logic
    - Input validation and sanitization functions
    - Cryptographic operations (encryption, hashing, signing)
    - Rate limiting and throttling mechanisms
    - Data serialization/deserialization with external systems
    - Mathematical calculations where correctness is safety-critical
    - State machines with security-sensitive transitions

    _Medium PBT value (Tier 2 — property-based testing recommended):_
    - Data transformation pipelines
    - API parameter validation
    - Session management logic
    - Audit logging with tamper-detection requirements

    _Low PBT value (Tier 1 — focused testing sufficient):_
    - UI components and layout
    - Integration workflows (covered by integration specs)
    - Business process flows without security surface
    - External service interactions (mocked in testing)
    - Documentation and configuration
    - CRUD endpoints with no authorization logic

    **For specs with Tier 2 components,** include in the Validation Strategy section:

    a. **Which components require PBT** — name the specific functions, modules, or endpoints.
    b. **Security properties to validate** — formal property definitions. Templates for common cases:
    - Input validation: `∀ input: validate(input) → safe_processing(input)` — sanitization prevents XSS, SQL injection, and malformed data.
    - Access control: `∀ user, resource: authorized(user, resource) → can_access(user, resource)` — unauthorized access is always prevented.
    - Data integrity: `∀ data: decrypt(encrypt(data, key), key) = data` — encryption is reversible with correct key, irreversible without.
    - Rate limiting: `∀ requests: within_rate_limit(requests) → all_processed(requests) AND exceeded_limit(requests) → rejected(requests)`.
    - Session security: `∀ session: expired(session) → requires_reauth(session)`.
      c. **PBT test scope** — estimated number of property test cases, what the producer should generate.
      d. **Security audit preparation** — if this spec's output will be part of a security audit, what evidence bundle should the producer create.

    **For specs with Tier 1 components only,** the Validation Strategy section states: "Tier 1 — focused testing sufficient. No PBT-suitable components identified." and lists the components assessed.

    The Validation Strategy feeds into the producer's implementation plan and the validator's evidence review. It is not a separate phase — it is part of the spec's acceptance contract.

    **Implementation Notes:** Advisory guidance for the producer. Not mandatory constraints.
    - Recommended patterns or libraries (per project conventions).
    - Known pitfalls or subtleties.
    - References to existing code to reuse.
    - Trade-offs the producer should be aware of.
    - Do NOT duplicate acceptance criteria here. Notes are advisory; criteria are binding.

    **Failure Modes:** Explicit list of known ways this spec can fail.
    - For each: trigger, expected handling, validator check.
    - Every non-trivial spec should have at least one failure mode. Empty failure modes = under-analyzed.

    **Dependencies:** Narrative version of `depends_on`.
    - For each: what this spec assumes from the dependency, and what breaks if the dependency changes.

    **Consumers:** Narrative version of consumer list.
    - For each: what the consumer needs, and constraints on evolution (what must not change without breaking the consumer).

    **Status:** `planned` initially. Updated by dispatcher during execution.

    **Progress Tracking:** Every spec includes a checklist of its phases. This is the primary progress record — not prose, not summaries, just checkmarks. The producer checks off phases as they complete. The validator verifies all boxes are checked before approving.

    Format:

    ```markdown
    ## Progress Tracking

    - [ ] Phase 1: <phase description>
    - [ ] Phase 2: <phase description>
    - [ ] Phase 3: <phase description>
    - [ ] Phase 4: <tests + documentation>
    ```

    Rules:
    - Each phase maps to a coherent unit of work that one iteration can complete. If a phase requires multiple iterations, split it into sub-phases.
    - Phases are ordered by dependency (Phase 2 may depend on Phase 1's output).
    - The producer checks `- [x]` when the phase is done. Not before. Not "mostly done."
    - If a phase spans multiple sessions, only check it when the full phase is complete. Unchecked phases tell the next session exactly where to resume.
    - The checkmarks are the spec's built-in progress log. They replace the need for verbose "what I did" narratives.

    Optionally, if a phase has non-obvious decisions or deviations, the producer appends an entry to `specs/<id>/phase-log.md`:

    ```markdown
    # Phase Log — <spec-id>

    ## Phase 1 — <description>

    - <YYYY-MM-DD>: <decision or deviation, one line>

    ## Phase 2 — <description>

    - <YYYY-MM-DD>: <decision or deviation, one line>
    ```

    The phase-log is for decisions, not narration. If nothing non-obvious happened, the checkmark is sufficient.

    The completion report's State Management section must include:
    - All progress tracking boxes checked (or list which are incomplete with reason).
    - Phase-log entries exist for phases with decisions/deviations (or "no phase-log needed" if all phases were straightforward).

17. For integration specs, additionally:
    - Scope focuses on compositions, interface compatibility, and emergent behavior — not on any single unit's internals.
    - Acceptance criteria describe scenarios exercising multiple units together. Example: "Request flows end-to-end from POST /shorten through GET /:short_code and produces a click in click_log_table."
    - Failure modes focus on composition failures: interface mismatches, race conditions, shared-state invariant violations, timing issues.
    - Produces is typically a verification report, not new functionality.
    - Validation strategy focuses on composition-level properties: "Does the composed system maintain its invariants when all units are active?"

18. **Security audit preparation assessment.** After all specs are drafted, assess whether the project as a whole has security-critical components:

    a. If one or more specs have Tier 2 components, inform the operator: "This project has security-critical components. The producers will generate PBT evidence bundles for those specs. At project completion, a security audit preparation report can be assembled from those bundles, reducing the auditor's manual work."
    b. If no specs have Tier 2 components, note: "No security-critical components identified. Standard focused testing applies across all specs."
    c. This assessment goes in the PROGRESS.md entry for the planning session, not in individual specs.

19. **Spec quality review — before presenting to operator.** For each spec, run the stranger-executable test (SPEC_FORMAT.md §D):
    - Can a fresh interpreter execute this spec with only the framework docs + manifest + spec file?
    - If the answer is no for any spec, identify what's missing and fix it.
    - Common failures: objective is ambiguous, scope is unbounded, an interface is underspecified, an acceptance criterion is not verifiable, a dependency is implicit, a failure mode is missing.

### Phase 4: Manifest Assembly

19. Assemble `manifest.yml` per PROJECT_MANIFEST.md §B:

    a. `project` block:
    - `name`: kebab-case identifier.
    - `objective`: the operator's goal from intake (one sentence).
    - `created`: today's date.
    - `status`: `planning` (flips to `executing` after operator lock).
    - `operator`: identifier of the human or system.
    - `interpreters`: default producer, validator, arbiter — must be distinct per ARCHITECTURE.md §E.

    b. `specs` array: all spec entries from Phase 2–3.

    c. `milestones` (optional): group specs for reporting boundaries. Ask the operator if they want milestone groupings.

    d. `history`: initial entries — `project_created`, one `spec_added` per spec.

20. Run the full manifest invariant check (PROJECT_MANIFEST.md §C):
    - All seven invariants must pass before the manifest is considered complete.
    - Any violation is a spec-architect error — fix it before presenting.

### Phase 5: Operator Review and Lock

21. Present the complete manifest and spec set to the operator for final review. For each spec, the operator should verify:

    a. **Does the Objective match what I actually want?** Not what sounds reasonable — what I actually want.
    b. **Is the Scope specific enough that I can tell, spec by spec, what I'm getting?** "Authentication" is not specific; "email/password login with JWT session tokens, 24-hour expiry, no social login" is.
    c. **Are the Out-of-scope items what I want deferred?** Scope creep begins when a vague out-of-scope list passes review.
    d. **Do the Acceptance Criteria correspond to things I would check if I were validating personally?** If I read the criteria and think "sure, whatever" — that's too vague.
    e. **Do the Consumers lists look complete?** A spec with no declared consumers is either a leaf node (rare) or has an unstated downstream dependency (usually).

    The operator's job during review is to **not agree too fast**. The default failure mode is the operator nodding along to a manifest that looks reasonable on the surface but does not encode their actual intent.

22. Incorporate operator feedback. Revise specs and manifest as needed. Each revision increments the spec's `version` field and appends a `spec_revised` history entry.

23. When the operator approves:
    a. Update `project.status` to `executing`.
    b. Append `manifest_locked` to history.
    c. From this point, spec changes require explicit history entries per PROJECT_MANIFEST.md §D.
    d. Update `.agents/memory_bank/active/PROGRESS.md` with the planning session entry.
    e. Update `.agents/memory_bank/active/current_focus.md` with the first spec to dispatch.

24. If the operator rejects or requests changes, return to the appropriate phase (2 for DAG changes, 3 for spec changes, 4 for manifest changes). Log the rejection reason.

### Emergent Failure Encoding (When Applicable)

25. If this planning cycle was triggered by deployment feedback:

    a. For each entry in `emergent_failures.md` with `Status: planned`:
    - Read the entry's `Encoded guard` field (or the `Pattern` field if no guard is specified yet).
    - Either create a new spec that encodes the guard, or strengthen an existing spec's acceptance criteria.
      b. Update the emergent failure entry's `Status` to `encoded` and fill in `Encoded in spec` with the spec id.
      c. This step is the feedback loop from ARCHITECTURE.md §D — Locus 3 failures become Locus 1 checks.

### Troubleshooting Common Issues

**Operator gives vague goals.**

- Ask "what does success look like? Describe the moment you know this is working."
- Ask "what would a user do with this on day one?"
- If still vague, propose a concrete interpretation and ask "is this what you mean, or something different?"

**DAG has a cycle.**

- Identify the cycle and present it to the operator.
- Usually caused by two specs that each claim to depend on the other's output.
- Fix: split one spec so its "produces" and "consumes" are separated, or restructure so one spec is clearly upstream.

**Spec is too large.**

- If a spec would produce more than 3–4 interfaces or has more than 10 acceptance criteria, consider splitting.
- Split on interface boundaries: if a spec produces both a database table and an API endpoint, the table is a separate spec.

**Spec is too granular.**

- If a spec produces a single trivial interface and has 2 acceptance criteria, it might not warrant its own spec.
- Merge into the consuming spec's scope, unless the interface is consumed by multiple downstream specs.

**Interface mismatch between producer and consumer specs.**

- The manifest's `produces` and `consumes` must declare the same shape.
- If they disagree, the spec-architect made an error in decomposition. Fix the shape to be consistent.

**Operator wants to skip straight to code.**

- Explain: "The specs are the program being executed. If we skip this step, we're programming without a specification — which means we'll get something, but not necessarily what you want. The time we invest here saves multiples in implementation."
- If the operator insists, document the shortcut in PROGRESS.md with explicit acknowledgment that spec quality was traded for speed.

## Self-Check

Before presenting the manifest to the operator for final review, confirm each of the following. If any answer is No, apply the indicated Fix Action. After three full passes with any check still failing, escalate to the operator with explicit TODOs.

1. **DAG is complete.** Every spec the project needs is in the manifest. No component is missing.
   - If No: return to Phase 2 and identify the gap.

2. **Interface closure holds.** Every `consumes` entry references a `produces` entry that exists.
   - If No: add the missing interface or fix the reference.

3. **Every spec is stranger-executable.** A fresh interpreter reading only the spec + manifest + framework docs could execute it without asking for clarification.
   - If No: tighten the spec's Objective, Scope, Interfaces, or Acceptance Criteria.

4. **Every acceptance criterion has a mechanical verifier.** No "manual inspection", no "looks correct", no vibes-based criteria.
   - If No: rewrite the criterion with a specific command, file check, or test name.

5. **Out-of-scope lists are present and specific.** Every spec has at least two out-of-scope items that are actual deferrals, not "N/A."
   - If No: add the missing items.

6. **Validation strategy declared for every spec.** Each spec has a Validation Strategy section that names its tier and, for Tier 2 specs, names the specific PBT-suitable components and security properties.
   - If No: add the missing Validation Strategy section. Assess the spec's components against the tier heuristics.

7. **Tier 2 specs have formal property definitions.** Every spec with Tier 2 components has at least one formal security property in its Validation Strategy (e.g., `∀ input: validate(input) → safe_processing(input)`).
   - If No: add the property definitions. Use the templates in step 16 as starting points.

8. **Integration specs exist for non-trivial compositions.** If two unit specs share an interface and their composition has emergent behavior, an integration spec covers it.
   - If No: add the missing integration spec.

9. **Emergent failure guards are encoded.** If this cycle was triggered by deployment feedback, every unencoded guard has been addressed.
   - If No: return to step 25.

10. **Manifest invariants pass.** All seven checks from PROJECT_MANIFEST.md §C succeed.
    - If No: fix the specific invariant violation.

11. **Operator reviewed every spec.** The operator has read (or confirmed they've read) every spec file and approved the decomposition.
    - If No: do not lock the manifest. Wait for operator review.

12. **Session manifest complete.** Every field in the Session Manifest section is populated with specific values, not placeholders.
    - If No: populate the missing fields before closing.

## Failure Modes

- **OPERATOR_UNRESPONSIVE** — Operator does not answer intake questions. Action: write deferred items to `open_questions.md` with impact and proposed defaults; proceed with what's available; flag incomplete intake in PROGRESS.md.

- **DAG_CYCLE** — Decomposition produces a dependency cycle. Action: identify the cycle, present it to the operator, propose breaking the cycle by splitting a spec or deferring a feature.

- **INTERFACE_MISMATCH** — A spec's `consumes` references an interface that doesn't exist upstream. Action: caught by self-check item 2. Fix before proceeding.

- **SPEC_TOO_LARGE** — A spec would exceed what an interpreter can hold in context alongside its neighborhood. Action: split the spec into smaller specs with explicit interfaces between them.

- **SPEC_UNDERSPECIFIED** — A spec has vague acceptance criteria, missing interfaces, no failure modes, or no validation strategy. Action: caught by self-check items 3–7. Tighten before presenting.

- **MISSING_VALIDATION_STRATEGY** — A spec has security-critical components but no Tier 2 validation strategy. Action: assess the spec's components against the tier heuristics. If PBT-suitable components exist, add the Validation Strategy with property definitions.

- **EMERGENT_FAILURE_UNENCODABLE** — A deployment failure has no clean encoded guard. Action: write the entry with `Pattern` filled and `Encoded guard: TBD — requires operator input`; escalate to `open_questions.md`.

- **OPERATOR_PREMATURE_APPROVAL** — Operator approves without reading specs. Action: flag the risk — "I need you to read at least the Objective and Scope of each spec. Approving without reading is how faithfully-executed bad specs happen."

- **SELF_CHECK_EXHAUSTED** — Three self-check passes with failures. Action: present the manifest with explicit TODOs on failing checks; operator decides whether to accept partial output or continue iterating.

## Session Manifest

```markdown
## Session Manifest

- Skill: spec-architect@2.0.0
- Interpreter: <interpreter identifier>
- Role: producer
- Planning cycle: <new project | extension | emergent-failure encoding>
- Documents loaded: <list>
- Specs drafted: <count and list of spec ids>
- Integration specs: <count and list>
- Validation specs: <count and list or "none">
- Validation gates: <count> blocking, <count> standalone, <count> none
- Tier 2 specs (PBT): <count and list or "none">
- Tier 1 specs (focused testing): <count and list>
- Critical path: <spec sequence, length, validation gate count>
- Delegation chain: <sequence of producer → validator handoffs>
- Parallelization opportunities: <list or "none">
- Manifest invariants: <passed | list of failures>
- Self-check result: <passed on iteration N | partial with TODOs>
- Operator approval: <approved | pending | rejected with reason>
- Emergent failures encoded: <count or "none applicable">
- Escalations raised: <list or "none">
```
