---
name: spec-producer
version: 0.1.0
role: producer
description: |
  Onboards any capable interpreter into the Orion-OS framework as a producer,
  then executes one assigned spec end to end: dependency preflight, scratch-tree
  implementation with tests and negative controls, concurrent memory-bank
  writes, and a well-formed completion report per VALIDATION_PROTOCOL.md §C.
  Writing the completion report is the only completion signal. This is the
  generic implementation producer that SKILL_AUTHORING.md §E describes.

  USE WHEN: a cold interpreter is dispatched as producer to a spec whose
  status is in_progress in manifest.yml, or the operator says 'implement
  <spec-id>', 'execute the spec', 'produce', or 'onboard as producer'.
loads:
  - AGENTS.md
  - ARCHITECTURE.md
  - PROJECT_MANIFEST.md
  - SPEC_FORMAT.md
  - VALIDATION_PROTOCOL.md
  - MEMORY_FORMATS.md
produces:
  - path: <paths declared in specs/<spec-id>/spec.md Interfaces section>
    format: code
    purpose: implementation artifacts exactly where the spec declares them
  - path: specs/<spec-id>/validation/completion-report.md
    format: markdown
    purpose: producer handoff to validator; writing it is the completion signal
  - path: specs/<spec-id>/phase-log.md
    format: markdown
    purpose: per-phase decisions and deviations; omit only when all phases are straightforward
  - path: .agents/memory_bank/active/PROGRESS.md
    format: markdown
    purpose: appended four-field date entry per MEMORY_FORMATS.md §F
  - path: .agents/memory_bank/active/current_focus.md
    format: markdown
    purpose: updated resumption point with role context per MEMORY_FORMATS.md §G
  - path: specs/<spec-id>/patches/round-<N>.patch
    format: unified diff
    purpose: the patch-under-development — sole mutation channel and complete record of intent
  - path: specs/<spec-id>/validation/pushback-<N>.md
    format: markdown
    purpose: producer contest of a verdict per VALIDATION_PROTOCOL.md §C; written only when contesting
  - path: specs/<spec-id>/validation/verdict-history/
    format: markdown
    purpose: prior verdicts archived here when a needs_revision verdict is accepted; re-entry rounds only
  - path: .agents/memory_bank/active/open_questions.md
    format: markdown
    purpose: appended entries for blockers needing the operator; conditional
  - path: .agents/memory_bank/ARCHITECTURAL_DECISIONS.md
    format: markdown
    purpose: rows for non-obvious decisions using date+slug ids; conditional
  - path: .agents/memory_bank/emergent_failures.md
    format: markdown
    purpose: entries for deployment-like failures discovered during implementation; conditional
  - path: .agents/memory_bank/MASTER_CONTEXT.md
    format: markdown
    purpose: updated only when the run changed project direction; conditional
consumes:
  - path: manifest.yml
    optional: false
  - path: specs/<spec-id>/spec.md
    optional: false
  - path: specs/<dep-id>/validation/resolution-report.md
    optional: false # one per entry in the spec's depends_on
  - path: .agents/memory_bank/active/current_focus.md
    optional: true
  - path: .agents/memory_bank/active/PROGRESS.md
    optional: true
  - path: .agents/memory_bank/MASTER_CONTEXT.md
    optional: true
  - path: .agents/memory_bank/ARCHITECTURAL_DECISIONS.md
    optional: true
  - path: .agents/memory_bank/standing_requirements.md
    optional: true
  - path: .agents/memory_bank/emergent_failures.md
    optional: true
  - path: .agents/memory_bank/active/open_questions.md
    optional: true
  - path: specs/<spec-id>/validation/verdict-<N>.md
    optional: true # present on re-entry rounds only
compatible_interpreters:
  - any
distinctness_requirements: # the dispatcher enforces producer/validator distinctness at dispatch; this skill reports identity honestly, it does not check it
  producer_must_differ_from: []
  validator_must_differ_from: []
supersedes: none
---

# spec-producer

## Purpose

Onboard any interpreter — cold, with no prior Orion-OS session context — into the producer role, and carry one assigned spec from dispatch to a validator-ready completion report. Successful output: implementation artifacts at the spec-declared paths, every acceptance criterion backed by reproducible evidence with negative controls, memory-bank state a stranger can resume from, and a completion report so well-formed the validator never bounces it on shape.

## Role

producer

## When to Run

**Dispatch triggers:**

- The dispatcher (or operator, acting as dispatcher) assigns this skill to a spec whose `depends_on` entries are all `approved` and whose status is `in_progress` in `manifest.yml`.
- Operator says "implement `<spec-id>`", "execute the spec", "produce", or "onboard as producer".

**Re-entry triggers:**

- A prior producer round ended in `needs_revision` and the issues were accepted — a new round runs with the validator's findings as context.
- `current_focus.md` names this spec with role context `producer` at resumption.

**Not for:**

- Planning or revising specs — that is `spec-architect`.
- Writing verdicts or validating your own work — validator role; same-model self-validation is structurally insufficient (AGENTS.md §15).
- Arbitrating disputes — arbiter role.
- Committing to version control — the commit happens only when the spec reaches `approved`, one commit per approved spec (AGENTS.md §03.6).

## Inputs

- `manifest.yml` — project DAG; confirms this spec's status, dependencies, and dispatch assignment.
- `specs/<spec-id>/spec.md` — the spec being executed; source of acceptance criteria, interfaces, failure modes, Progress Tracking.
- `specs/<dep-id>/validation/resolution-report.md` — one per dependency; records the interface shape actually delivered.
- `.agents/memory_bank/active/current_focus.md` — resumption point and role context (optional).
- `.agents/memory_bank/active/PROGRESS.md` — phase headers for orientation (optional).
- `.agents/memory_bank/MASTER_CONTEXT.md` — project conventions, active decisions (optional).
- `.agents/memory_bank/ARCHITECTURAL_DECISIONS.md` — binding decisions that constrain implementation (optional).
- `.agents/memory_bank/standing_requirements.md` — verdict-time rules with provenance; applicable SRs are binding (optional).
- `.agents/memory_bank/emergent_failures.md` — entries whose blast radius includes this spec; their encoded guards become test inputs (optional).
- `.agents/memory_bank/active/open_questions.md` — unresolved questions that may block execution (optional).
- `specs/<spec-id>/validation/verdict-<N>.md` — the validator's latest verdict, re-entry rounds only (optional).

## Outputs

- Implementation artifacts at the paths declared in the spec's Interfaces section — never elsewhere.
- `specs/<spec-id>/validation/completion-report.md` — per VALIDATION_PROTOCOL.md §C; the completion signal.
- `specs/<spec-id>/phase-log.md` — per-phase decisions and deviations; omit only when every phase was straightforward (declare the omission in the completion report's State Management).
- `.agents/memory_bank/active/PROGRESS.md` — appended four-field entry for today.
- `.agents/memory_bank/active/current_focus.md` — updated resumption point naming the validator as the next actor.
- `specs/<spec-id>/patches/round-<N>.patch` — the patch-under-development; the sole mutation channel and complete record of intent.
- Conditional (re-entry rounds): `specs/<spec-id>/validation/pushback-<N>.md` when contesting a verdict; prior verdicts archived to `specs/<spec-id>/validation/verdict-history/` when a `needs_revision` verdict is accepted.
- Conditional: `open_questions.md`, `ARCHITECTURAL_DECISIONS.md`, `emergent_failures.md`, `MASTER_CONTEXT.md` — only when the run produced content that belongs there.

## Process

### Phase 0 — Onboard cold

1. Read `AGENTS.md` in full. It is binding, not advisory. The clauses that will be tested this session: real progress only (§01), commit on validation not before (§03.6), concurrent memory writes (§09), stranger-readable output (§14), never self-validate (§15).
2. Read `ARCHITECTURE.md`. Internalize what you are: a disposable execution context. Continuity lives only in files you write. Your scratch output is a claim, not evidence — the validator reproduces it in a separate verify tree or refutes it (§E).
3. Execute the session-start procedure from `MEMORY_FORMATS.md` §M, in order: `current_focus.md` → `PROGRESS.md` phase headers → `MASTER_CONTEXT.md` → `open_questions.md` → `manifest.yml` → the current spec. If resumption lands mid-validation-cycle, read the spec's `validation/` directory in full.
4. Read `VALIDATION_PROTOCOL.md` §B–§D. Know the handshake you are entering: a different interpreter reads your completion report; you hold push-back rights bounded at two; a post-conflict agreement still triggers an arbiter convergence audit.
5. Record your interpreter identifier. It goes in the completion report header and was recorded in `execution.producer` at dispatch. You do not check distinctness — the dispatcher does — but you report identity honestly.
6. Memorize the producer boundary list. You write: implementation artifacts, `phase-log.md`, `completion-report.md`, memory-bank files. You never write: verdicts, resolution reports, arbiter audits, manifest mutations, status flips, or commits before `approved`. When tempted to "just fix the manifest status", that is a role violation — refuse it.

### Phase 1 — Dispatch verification and spec preflight

1. Open `manifest.yml`. Locate the assigned spec entry. Confirm all three: status is `in_progress`; every `depends_on` id is `approved`; `execution.producer` names this interpreter. Any failure → halt, failure mode NOT_DISPATCHED.
2. Read `specs/<spec-id>/spec.md`. Confirm the Header block is present and the spec version is consistent with the manifest entry. Otherwise → halt, failure mode MALFORMED_SPEC.
3. Extract working lists from the spec:
   - **Acceptance criteria** — numbered, verbatim. This list becomes the per-criterion evidence block.
   - **Interfaces** — (name, declared shape, expected path, consumers) tuples.
   - **Failure modes** — trigger and expected handling for each.
   - **Progress Tracking phases** — the checkboxes you will check off during execution.
   - **Implementation Notes** — conventions, testing tier (focused vs property-based), declared validation gate.
4. For each dependency id: read `specs/<dep-id>/validation/resolution-report.md`. Record the interface shape actually delivered. Where it differs from what this spec's Dependencies narrative expects, resolve in favor of the delivered shape and queue the discrepancy for the completion report's Known Deviations.
5. Read `standing_requirements.md`; note every SR whose scope matches this spec — SRs are binding. Read `ARCHITECTURAL_DECISIONS.md`; note active decisions constraining implementation choices. Read `emergent_failures.md`; entries whose blast radius names this spec or its component class contribute their encoded guards as mandatory test inputs.
6. Run the ambiguity check: every acceptance criterion must reduce to a checkable claim (a file, a command, a shape comparison). Any criterion that cannot → halt, failure mode SPEC_AMBIGUITY, with an `open_questions.md` entry. Do not guess silently — a faithfully-executed guessed criterion passes every gate and ships the guess (ARCHITECTURE.md §C).

### Phase 2 — Scratch tree

1. Establish the scratch tree for this round, derived from exactly `repo@<commit>` + `patch-under-development@<id>`. Mechanical procedure — constraints declared in the manifest or the spec's Implementation Notes override any default here:
   - **Base commit** — read the commit recorded in the manifest's `execution` metadata for this spec; if none is recorded, the repo's current HEAD. Record it; every artifact and report cites it.
   - **Patch** — this round's patch-under-development lives at `specs/<spec-id>/patches/round-<N>.patch` (unified diff). Create it empty at round start; on re-entry rounds, start from the prior round's patch applied.
   - **Tree** — materialize a disposable working copy of the repo at the base commit (e.g., `git worktree add` at that commit) outside the repo directory, with the current patch applied. Never shared with any validator verify tree.
   - **Round end** — export the accumulated diff of your work to the patch file: the patch, not the tree, is the record. Rebuild the tree fresh at the start of every round — prior-round state is drift by definition and must not survive.
2. The repo is read-only to you. The patch is your only mutation channel and the complete record of intent. No out-of-patch mutations, in any posture.
3. Citation discipline: artifacts and reports cite repo paths and patch ids — never sandbox paths. If evidence only exists in the scratch tree, tag it with provenance `Executed in: scratch@<round> (repo@<commit> + patch@<id>)` so the validator knows it is a claim awaiting reproduction.

### Phase 3 — Implement

1. For each interface tuple from Phase 1 step 3: produce the artifact at the spec-declared path, implementing the declared shape. Never relocate — an artifact at a different path is a criterion failure, not a style choice.
2. Author tests as you implement — never blind. Each acceptance criterion maps to at least one named test. Run them in the scratch tree as you write them; a test never executed by its author is a plausible fiction.
3. Negative controls: for every named guarantee, deliberately reintroduce the defect class the guarantee names, confirm the suite fails, revert, and record the sequence (mutation applied → expected failure → observed failure → revert confirmed). Mandatory for property-based/Tier 2 specs — one control per named property; recommended for Tier 1 suites gating a `blocking` spec (VALIDATION_PROTOCOL.md §H).
4. For each failure mode from Phase 1 step 3: confirm a specific code path or test case handles it. An unhandled failure mode is a self-check failure, not a footnote.
5. Match existing conventions: open the two files nearest the new code, identify their common patterns, follow those. Never infer conventions the codebase does not show.
6. Check off Progress Tracking phases as they complete: `- [x]` only when the phase is fully done. If a phase spans sessions, leave it unchecked — the unchecked box is the next session's resume pointer.
7. Maintain `phase-log.md` whenever a phase involves a non-obvious decision or a deviation from the spec's Implementation Notes. Entries capture decisions and deviations, not narration.
8. Revision bound: at most five implement-test-fix cycles in one producer round — one shared budget for the whole round: cycles consumed by returns from Phase 4 self-check failures draw from the same five and do not reset the count. Still red at five → stop, carry explicit TODOs forward. Partial honest output beats fabricated success (AGENTS.md §01); a report claiming green over red code is the exact failure the constitution exists to prevent.

### Phase 4 — Self-check

Run the Self-Check section below in full. Do not write any state file or report until every check passes or the three-pass bound is hit.

### Phase 5 — State writes (concurrent, not deferred)

1. Append today's entry to `.agents/memory_bank/active/PROGRESS.md` with all four fields — Implemented / Decided / Blocked / Next. `none` for confirmed-empty; never blank.
2. Update `.agents/memory_bank/active/current_focus.md`: refresh the focus paragraph, then set the Resumption Point — spec or file, task, blockers, and role context naming `validator` as the next actor.
3. Conditional writes, only when the run produced content that belongs there: `open_questions.md` for blockers needing the operator; `ARCHITECTURAL_DECISIONS.md` for non-obvious decisions, using date+slug ids (`AD-YYYY-MM-DD-<slug>`); `emergent_failures.md` for any deployment-like failure discovered during implementation (MEMORY_FORMATS.md §J); `MASTER_CONTEXT.md` only if project direction changed.

### Phase 6 — Completion report

1. Create `specs/<spec-id>/validation/` if it does not exist. Its creation signals the spec enters the validation phase.
2. Write `completion-report.md` exactly per VALIDATION_PROTOCOL.md §C, with every section: Header (spec_id, producer identifier, timestamps, spec_version) / Artifacts Produced / Acceptance Criteria Self-Check (per-criterion claim + evidence + provenance tag) / Interfaces Delivered (shape comparison against declared) / Known Deviations (empty allowed, missing section not) / State Management (Progress Tracking declaration + Memory Bank declarations + the verbatim Progress Entry text) / Handoff Notes.
3. Writing this file **is** the completion signal. Do not also flip statuses, announce completion in prose, or touch the manifest — the dispatcher reads the report and dispatches the validator from it. A producer that signals completion any other way has violated the protocol.

### Phase 7 — Conditional: push-back

Run only when a verdict lands `needs_revision` and you contest it.

1. Read the verdict in full. For each issue, triage internally — is the finding factually wrong, an interpretation you can rebut with new evidence, or an ambiguity in the spec itself? Map the result onto the push-back's `Category` field, whose enum is VALIDATION_PROTOCOL.md §C's: `factual | interpretive | spec-ambiguity`.
2. Accept path: archive the verdict per protocol, begin the next producer round with the findings as context — return to Phase 2 with a fresh scratch tree.
3. Contest path: write `pushback-01.md` per VALIDATION_PROTOCOL.md §C (Header / Contested Issues with evidence / Uncontested Issues / Requested Outcome). The evidence standard is new fact a stranger arbiter could reproduce — restatement of the original claim is not push-back material.
4. Bounds: at most two push-backs per spec; the second contest fires the arbiter regardless of content. A push-back in the spec-ambiguity category routes directly to the operator — no amount of re-validation resolves an ambiguous spec.
5. Trivial-revision exception: if and only if the contested changes are genuinely trivial (single-line formatting, whitespace, documentation-only), declare the trivial scope in the push-back header; the validator confirms or rejects the claim. Substantive change dressed as trivial is a category violation the arbiter flags.
6. When the spec reaches `approved`: make exactly one commit capturing this spec's work, format per AGENTS.md §03.6, with `.agents/` excluded. No approval, no commit.

## Self-Check

Run before any Phase 5 or Phase 6 write. Maximum three full passes; a check still failing after the third → write partial output with explicit TODOs on the failing checks and escalate (see Failure Modes). Each question answers yes or no — never "mostly". A check that sends you back to Phase 3 does not reset the five-cycle round budget (Phase 3 step 8).

1. **Per-criterion evidence triple.** Does every acceptance criterion from Phase 1 step 3 have an identified (file + line range, or command output, or test name) triple?
   - If No: return to Phase 3 and fill the gap.
2. **Interfaces delivered at declared paths.** Does every interface tuple have an artifact at the spec-declared path implementing a compatible shape?
   - If No: return to Phase 3. If the shape genuinely cannot match the declaration, add a Known Deviation with reasoning rather than silently changing the shape.
3. **No regressions.** Does the full suite pass, including tests that predate this spec?
   - If No: return to Phase 3. Never write a report claiming success over a regression.
4. **Negative controls recorded.** For every named guarantee (all guarantees, if PBT/Tier 2), does the completion report carry the mutation → expected → observed → revert record?
   - If No: run the missing controls in the scratch tree before proceeding.
5. **Failure modes handled.** Does each spec failure mode have a code path or test case?
   - If No: return to Phase 3 step 4.
6. **Deviations documented.** Is every departure from the spec as written — including dependency shape discrepancies from Phase 1 step 4 — in Known Deviations with reasoning?
   - If No: add them before writing the report.
7. **Progress Tracking honest.** Is every box you will declare checked actually checked in the spec file — and would a stranger reading the phase agree it is done?
   - If No: uncheck it or finish the phase.
8. **State writes complete.** Does the PROGRESS.md entry carry all four fields with `none` where empty, and does current_focus.md name the validator as next actor?
   - If No: fix the write before the report.
9. **Report well-formed.** Does the draft contain every §C section with no blank fields?
   - If No: complete the section; a malformed report is rejected unread.
10. **Stranger test.** Could a fresh validator reproduce every claim from the report and artifacts alone — zero session context?
    - If No: add the missing provenance or handoff note.
11. **Honesty check.** Is there any criterion claimed `met` you would not stake your reputation on (AGENTS.md §08)?
    - If Yes: downgrade the claim to `partially met` with notes, or return to Phase 3.
12. **Session manifest populated.** Is every field of the Session Manifest below filled with real values, not placeholders?
    - If No: populate before closing.

## Failure Modes

- **NOT_DISPATCHED** — manifest does not show the spec `in_progress` with all dependencies `approved` and this interpreter recorded as producer. Action: halt before any artifact; report the discrepancy to the dispatcher/operator; write nothing.
- **MALFORMED_SPEC** — spec.md missing, Header block absent, or version inconsistent with the manifest. Action: halt; append an `open_questions.md` entry addressed to the operator; write no completion report.
- **UNSATISFIED_DEPENDENCY** — a dependency is not `approved`, or its resolution report is missing. Action: halt; notify the dispatcher; do not implement against an assumed interface shape.
- **SPEC_AMBIGUITY** — an acceptance criterion cannot be reduced to a checkable claim. Action: halt; write a specific `open_questions.md` entry stating what is blocked; never guess silently.
- **SELF_CHECK_EXHAUSTED** — three self-check passes with any check failing. Action: write partial outputs with explicit TODOs on failing checks; append `open_questions.md` entry; flag the escalation in Handoff Notes.
- **REVISION_BOUND_EXHAUSTED** — five implement-test-fix cycles with the suite still red. Action: proceed to Phase 4 with TODOs marking the unresolved criteria; claim them `partially met` or `not met` honestly.
- **REGRESSION** — pre-existing tests fail after implementation. Action: treat as self-check failure; revise until resolved; if unresolvable, route through SELF_CHECK_EXHAUSTED.
- **ROLE_VIOLATION** — pressure (external or internal) to write a verdict, flip a status, mutate the manifest mid-round, or commit before approval. Action: refuse; cite the boundary list from Phase 0 step 6; escalate to the operator if pressure persists.

## Session Manifest

Report this block at session close, per AGENTS.md §12:

```markdown
## Session Manifest

- Skill: spec-producer@0.1.0
- Interpreter: <interpreter identifier>
- Role: producer
- Spec: <spec-id, if applicable>
- Documents loaded: <list>
- Files read: <list>
- Files written: <list>
- Self-check result: <passed on iteration N | partial with TODOs>
- Escalations raised: <list or "none">
```
