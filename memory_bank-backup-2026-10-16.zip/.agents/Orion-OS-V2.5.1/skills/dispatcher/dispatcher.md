---
name: dispatcher
version: 0.1.0
role: utility
description: |
  Stub for the future automated dispatcher. Currently documents the dispatch
  contract — the state machine that selects which spec to execute, which
  interpreter to assign, and when to invoke validators and arbiters.

  Today the operator performs the dispatcher's role manually per
  OPERATOR_GUIDE.md §D. This skill exists to formalize the contract
  so a future implementation can automate it.

  USE WHEN: reviewing the dispatch contract, or when a dispatcher
  program is being implemented.
loads:
  - AGENTS.md
  - ARCHITECTURE.md
  - PROJECT_MANIFEST.md
  - VALIDATION_PROTOCOL.md
produces:
  - path: <none — this is a reference skill, not an executing one>
    format: n/a
    purpose: documents the dispatch contract
consumes:
  - path: manifest.yml
    optional: false
compatible_interpreters:
  - any
distinctness_requirements: {}
supersedes: none
---

# dispatcher

## Purpose

Document the dispatch contract — the state machine that governs which spec to execute next, which interpreter to assign, and when to transition between production, validation, and arbitration phases. This is the "kernel scheduler" of Orion-OS.

Today, the operator performs this role manually (OPERATOR_GUIDE.md §D). This skill exists so the contract is explicit and a future program can implement it.

## Role

utility

## When to Run

This skill does not execute in the current architecture. It is a reference document for:

- Operators performing manual dispatch (consult the Process section for the dispatch loop).
- Implementers building an automated dispatcher program.
- Auditors verifying that dispatch decisions follow the contract.

## Inputs

- `manifest.yml` — the single source of truth for spec status, dependencies, and execution metadata.

## Outputs

None. This is a reference skill. A future dispatcher implementation would write manifest mutations and history entries.

## Process: The Dispatch Contract

### The Dispatch Loop

At any moment during execution, the dispatcher (human or program) does:

1. **Read the manifest.** Find every spec with `status: planned` whose `depends_on` list contains only specs with `status: approved`.

2. **Select one.** Priority order:
   a. Critical-path specs first (specs on the longest dependency chain).
   b. Specs that unblock the most downstream work (highest consumer count).
   c. Operator preference (if explicitly stated).

3. **Select a producer interpreter.** Consult `project.interpreters.producer` for the default. Override if:
   a. The spec requires specialized capability the default doesn't have.
   b. The default producer has been flagged in `ALIGNMENT_LOG.md` for repeated drift.
   c. The spec is critical-path and the operator wants the most capable available producer.
   Record the override reason in the history event.

4. **Update the manifest:**
   a. `spec.status: planned → in_progress`
   b. `spec.execution.producer: <interpreter-id> @ <timestamp>`
   c. Append to `manifest.history`: `{date, event: spec_started, spec: <id>, role: producer, interpreter: <id>}`

5. **Start the producer session.** Load the producer's session-start stack per ARCHITECTURE.md §I. The producer skill reads the spec and executes.

### Post-Production Dispatch

When the producer writes its completion report:

6. **Read the completion report.** Confirm it exists and is well-formed (VALIDATION_PROTOCOL.md §C). Malformed reports go back to the producer without validator dispatch — do not spend validator time on malformed input.

7. **Check the spec's `validation_gate` field.** This was set during planning by spec-architect. It determines what happens next:

   a. **`none`** — No validator runs. The producer's self-report is trusted. Skip to step 10a (mark as `approved`). Downstream specs with `validation_gate: none` whose dependencies are now all `approved` become dispatchable immediately.

   b. **`blocking`** — A validator must clear this spec before downstream work can begin. Continue to step 8.

   c. **`standalone`** — A dedicated validation spec exists in the DAG that depends on this spec. The dispatcher does not dispatch a validator here; instead, the validation spec will be dispatched when its own dependencies are satisfied. Mark this spec as `approved` (its implementation is done; validation is the validation spec's job). The validation spec's completion is what unblocks downstream.

8. **Select a validator interpreter.** Must be distinct from the producer per VALIDATION_PROTOCOL.md §B. Consult `project.interpreters.validator`; override if distinctness is not satisfied.

9. **Update the manifest:**
   a. `spec.execution.validator: <interpreter-id> @ <timestamp>`
   b. `spec.status: in_progress → in_review`
   c. Append history: `{date, event: spec_produced, spec: <id>}`

10. **Start the validator session.**

### Post-Validation Dispatch

When the validator writes its verdict:

11. **Read the verdict.** Process per VALIDATION_PROTOCOL.md §D:

    a. `approved` → `spec.status: in_review → approved`. Append `spec_approved` history. Check if post-conflict convergence requires arbiter (verdict-history has prior `needs_revision` entries). If yes, dispatch arbiter before marking `approved`. Once `approved`, downstream specs whose dependencies are now all `approved` become dispatchable (return to step 1).

    b. `needs_revision` → `spec.status: in_review → in_progress`. Append `spec_loopback` history. Return to producer dispatch (step 4) with the verdict as context.

    c. `rejected` → `spec.status: in_review → blocked`. Append `spec_blocked` history. Escalate to operator.

### Post-Push-Back Dispatch

When the producer writes a push-back:

12. **Read the push-back.** Confirm it's well-formed.

13. **Dispatch validator for re-review.** Same validator. Record the re-validation in history.

14. **If second push-back:** Dispatch arbiter. This is the deadlock path.

### Post-Arbiter Dispatch

When the arbiter writes its audit:

15. **Read the binding decision:**

    a. `approved` → `spec.status → approved`. Append `spec_arbitrated` history.
    b. `needs_revision` → `spec.status → in_progress`. Append `spec_arbitrated` history. Return to producer.
    c. `escalate_to_operator` → `spec.status → blocked`. Append `spec_arbitrated` history. Route to operator with the arbiter's question.

### Resolution Report

16. When a spec reaches a terminal state (`approved`, `escalated`, or `abandoned`):

    a. Write `specs/<id>/validation/resolution-report.md` per VALIDATION_PROTOCOL.md §C.
    b. Update manifest history with the resolution.
    c. Downstream specs whose dependencies are now all `approved` become dispatchable (return to step 1).

### Concurrency Rules

- Only one producer works on a given spec at a time. The lock is expressed by `spec.execution.producer` being non-null and `spec.status` being `in_progress` or `in_review`.
- Manifest writes are atomic: read → compute → write to `.tmp` → rename.
- Only the dispatcher writes the manifest. Producers, validators, and arbiters never modify `manifest.yml` directly.

## Self-Check

Not applicable — this skill does not execute. A future dispatcher implementation would have self-checks for:

1. Manifest invariant compliance after every mutation.
2. Interpreter distinctness enforcement.
3. History monotonicity.
4. No concurrent writers to the same spec.

## Failure Modes

- **NO_DISPATCHABLE_SPECS** — All remaining specs have unsatisfied dependencies. Action: check for blocked specs; check for circular dependencies; escalate to operator if the DAG has a problem.

- **INTERPRETER_UNAVAILABLE** — The preferred interpreter is not available. Action: use the fallback from the manifest's interpreter block; record the substitution.

- **MALFORMED_COMPLETION_REPORT** — Producer's report is malformed. Action: return to producer without dispatching validator. Do not consume validator time on bad input.

- **DEADLOCK** — Arbiter escalates to operator and the operator is unavailable. Action: spec stays `blocked`; document the blockage in `open_questions.md`.

## Session Manifest

Not applicable for the reference skill. A future dispatcher implementation would report:

```markdown
## Session Manifest

- Skill: dispatcher@<version>
- Interpreter: <interpreter identifier>
- Role: utility (dispatcher)
- Specs dispatched: <count and list>
- Manifest mutations: <count>
- Interpreter assignments: <list of (spec, role, interpreter) tuples>
- Self-check result: <passed | n/a>
- Escalations raised: <list or "none">
```
