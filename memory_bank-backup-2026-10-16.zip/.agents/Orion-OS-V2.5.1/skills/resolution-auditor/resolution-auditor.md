---
name: resolution-auditor
version: 1.0.0
role: arbiter
description: |
  Third-model arbiter. Audits post-conflict resolutions to detect
  reasoning-based collusion, or breaks deadlocks when push-back rounds
  are exhausted. Issues binding decisions per VALIDATION_PROTOCOL.md.

  Must be a different interpreter from both the producer and the validator.

  USE WHEN: (1) post-conflict convergence in a validation cycle — producer
  and validator disagreed then agreed, or (2) deadlock — two push-back
  rounds exhausted without resolution.
loads:
  - AGENTS.md
  - ARCHITECTURE.md
  - VALIDATION_PROTOCOL.md
  - SPEC_FORMAT.md
produces:
  - path: specs/<spec-id>/validation/arbiter-audit.md
    format: markdown
    purpose: binding audit of the validation cycle
consumes:
  - path: specs/<spec-id>/spec.md
    optional: false
  - path: specs/<spec-id>/validation/completion-report.md
    optional: false
  - path: specs/<spec-id>/validation/verdict.md
    optional: false
  - path: specs/<spec-id>/validation/verdict-history/
    optional: true
  - path: specs/<spec-id>/validation/pushback.md
    optional: true
  - path: specs/<spec-id>/validation/pushback-history/
    optional: true
compatible_interpreters:
  - any
distinctness_requirements:
  producer_must_differ_from:
    - <producer interpreter id>
  validator_must_differ_from:
    - <validator interpreter id>
supersedes: none
---

# resolution-auditor

## Purpose

Audit validation cycles where producer and validator have interacted. Two trigger conditions, one artifact format:

1. **Post-conflict convergence** — the producer and validator disagreed, then subsequently agreed. The arbiter checks whether the convergence reflects genuine correction or reasoning-based collusion (two interpreters talking themselves into the same wrong answer).
2. **Deadlock** — push-back rounds exhausted without resolution. The arbiter issues the binding technical verdict.

The arbiter does not produce new implementation. It audits reasoning.

## Role

arbiter

## When to Run

- **Trigger 1 (post-conflict convergence):** The validation cycle includes a `needs_revision` verdict followed by an `approved` verdict (or the producer accepted a revised verdict). The dispatcher invokes the arbiter regardless of the agreement — per VALIDATION_PROTOCOL.md §D, agreement-after-disagreement always triggers the arbiter.
- **Trigger 2 (deadlock):** Two push-back rounds have been exhausted. The producer contested twice, the validator held firm twice. The arbiter issues the binding decision.

**Exception:** Trivial revisions (single-line formatting fixes, whitespace corrections, documentation-only changes explicitly flagged as trivial in the push-back) do not trigger convergence audit. The producer declares triviality in the push-back header; the validator confirms or rejects the claim.

## Inputs

- `specs/<spec-id>/spec.md` — the ground truth.
- `specs/<spec-id>/validation/completion-report.md` — the producer's final output.
- `specs/<spec-id>/validation/verdict.md` — the latest verdict.
- `specs/<spec-id>/validation/verdict-history/` — all prior verdicts (if they exist).
- `specs/<spec-id>/validation/pushback.md` — the latest push-back (if it exists).
- `specs/<spec-id>/validation/pushback-history/` — all prior push-backs (if they exist).
- `.agents/memory_bank/ARCHITECTURAL_DECISIONS.md` — binding decisions.

## Outputs

- `specs/<spec-id>/validation/arbiter-audit.md` — the binding audit.
- `.agents/memory_bank/active/PROGRESS.md` — appended entry.
- `.agents/memory_bank/ARCHITECTURAL_DECISIONS.md` — entry if the arbiter surfaces a new architectural decision.
- `.agents/memory_bank/ALIGNMENT_LOG.md` — entry if drift is observed.

## Process

### Phase 1: Independence Verification

1. Confirm the arbiter is distinct from both the producer and the validator. Read the manifest's `execution` block for this spec. If `arbiter` matches either `producer` or `validator`, abort — this is a protocol violation. Escalate to dispatcher.

2. Record the trigger condition: `post_conflict_convergence` or `deadlock`.

3. Record all artifacts reviewed: completion report, all verdicts, all push-backs.

### Phase 2: Independent Finding (Before Reading Verdicts)

4. **Read the spec and the completion report only.** Do not read the verdicts or push-backs yet.

5. Independently re-evaluate the spec's Acceptance Criteria against the artifacts:

   a. For each criterion, form the arbiter's own finding: `met`, `not met`, or `unverifiable`.
   b. Cite specific evidence (file+line, command output, test result).
   c. This finding is the arbiter's ground truth — formed without influence from the producer's or validator's reasoning.

6. **The independence of this step is critical.** The arbiter's value is that it provides a third perspective untainted by the other two. If the arbiter reads the verdicts first, it becomes a rubber-stamp, not an audit.

### Phase 3: Comparison to Prior Verdicts

7. Now read all verdicts and push-backs.

8. Compare the arbiter's independent finding to:

   a. The producer's completion claim (from the completion report).
   b. The validator's final verdict.
   c. Note: full agreement, partial agreement, or no agreement with each.

9. For **post_conflict_convergence** trigger, assess the convergence:

   a. **Genuine correction** — the producer fixed real issues identified by the validator. The arbiter confirms the fixes. The revised verdict reflects reality.
   b. **Drift** — both interpreters converged on a view the arbiter does not share. Specify where they diverge from the arbiter's independent reading. This is the collusion detection.
   c. **Inconclusive** — the arbiter cannot determine whether the convergence is genuine. Escalate to operator.

10. For **deadlock** trigger, assess the dispute:

    a. For each contested issue, determine whether the producer's or validator's reading is closer to the spec's intent.
    b. If neither reading is correct, state the arbiter's own reading.
    c. If the spec itself is ambiguous (neither reading can be ruled out by the spec text), flag as `spec-ambiguity` — routes to operator.

### Phase 4: Binding Decision

11. Issue the binding decision:

    a. **approved** — the spec is satisfied. All criteria met per the arbiter's independent assessment.
    b. **needs_revision** — the spec is not satisfied. List the issues in the verdict format (severity, location, description, remedy).
    c. **escalate_to_operator** — the dispute is about spec intent, project priority, or resource boundary — not implementation correctness. State the specific question the operator must resolve.

12. The binding decision overrides the validator's final verdict. If the validator said `needs_revision` and the arbiter says `approved`, the spec proceeds. If the validator said `approved` and the arbiter says `needs_revision`, the spec returns to the producer.

    **Scope of "binding" (v1.1).** The decision is binding _for the round_ — it closes the dispute, not the question. It carries exactly the weight of its written reasoning and reproducibility, independent of who wrote it (ARCHITECTURE.md §J commitment 8). New evidence — a later verdict, a deployment failure, a superseding decision — reopens the question through history; the record is append-only, so reopening never erases. The arbiter is a tie-breaker between viewpoints, not an authority over the record.

### Phase 5: Write Audit Report

13. Write `specs/<spec-id>/validation/arbiter-audit.md` per VALIDATION_PROTOCOL.md §C format:

    a. Header with spec_id, arbiter identifier, distinctness confirmations, trigger, timestamp, reviewed artifacts.
    b. Independent Finding — per-criterion with the arbiter's own assessment.
    c. Comparison to Prior Verdicts — agreement levels, convergence assessment (for post-conflict) or dispute analysis (for deadlock).
    d. Binding Decision — `approved`, `needs_revision`, or `escalate_to_operator`.
    e. Rationale — 3–6 sentences, stranger-readable.

14. If the binding decision surfaces a new architectural decision (e.g., the spec was fundamentally flawed in a way that reveals a pattern), append an entry to `.agents/memory_bank/ARCHITECTURAL_DECISIONS.md`.

15. If drift was observed (producer and validator converged on something the arbiter disagrees with), append an entry to `.agents/memory_bank/ALIGNMENT_LOG.md` with category `validation_shortcut` or `role_confusion`.

16. Append a validation entry to `.agents/memory_bank/active/PROGRESS.md`.

## Self-Check

Before writing the arbiter audit, confirm each of the following. If any answer is No, apply the indicated Fix Action. After three full passes with any check still failing, write the audit with explicit TODOs.

1. **Independence confirmed.** The Independent Finding section was written before the Comparison section. The arbiter did not read verdicts or push-backs until Phase 3.
   - If No: restart from Phase 2. Independence is the arbiter's core value.

2. **Per-criterion independent assessment complete.** Every criterion in the spec's Acceptance Criteria has the arbiter's own finding with evidence.
   - If No: return to Phase 2 step 5.

3. **Distinctness verified.** The Header confirms the arbiter differs from both producer and validator.
   - If No: abort — protocol violation.

4. **Convergence assessment present (if applicable).** For post-conflict convergence trigger, the assessment is one of: genuine correction, drift, or inconclusive.
   - If No: add the assessment.

5. **Binding decision is one of the three allowed values.** `approved`, `needs_revision`, or `escalate_to_operator`.
   - If No: correct the decision.

6. **Rationale is stranger-readable.** A fresh interpreter with no context could read the rationale and understand why the decision was made.
   - If No: rewrite the rationale with full context.

7. **Session manifest complete.** Every field in the Session Manifest section is populated.
   - If No: populate the missing fields before closing.

## Failure Modes

- **SAME_INTERPRETER** — Arbiter matches producer or validator. Action: abort; escalate to dispatcher for reassignment.

- **SPEC_AMBIGUITY** — The dispute stems from an ambiguous spec, not implementation quality. Action: binding decision is `escalate_to_operator` with the specific ambiguity named.

- **INDEPENDENCE_VIOLATION** — The arbiter read verdicts before forming its independent finding. Action: restart from Phase 2. Log the violation in ALIGNMENT_LOG.md.

- **INCONCLUSIVE** — The arbiter cannot determine whether convergence is genuine. Action: binding decision is `escalate_to_operator` with the specific uncertainty named.

- **SELF_CHECK_EXHAUSTED** — Three self-check passes with failures. Action: write the audit with explicit TODOs; escalate to operator.

## Session Manifest

```markdown
## Session Manifest

- Skill: resolution-auditor@1.0.0
- Interpreter: <interpreter identifier>
- Role: arbiter
- Spec: <spec-id>
- Trigger: <post_conflict_convergence | deadlock>
- Documents loaded: <list>
- Artifacts reviewed: <count> verdicts, <count> push-backs
- Independent finding: <agrees with producer | agrees with validator | disagrees with both>
- Convergence assessment: <genuine correction | drift | inconclusive | n/a>
- Binding decision: <approved | needs_revision | escalate_to_operator>
- Self-check result: <passed on iteration N | partial with TODOs>
- Escalations raised: <list or "none">
```
