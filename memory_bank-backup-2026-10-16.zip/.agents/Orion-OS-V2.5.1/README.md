# Orion-OS v2.5

A file-native, constitutional framework for composing heterogeneous LLMs into verified pipelines.

## What This Is

Orion-OS is not a multi-agent framework. It is a pipeline architecture where:

- **Interpreters** (any capable LLM) execute **programs** (markdown skill files).
- Communication between stages is **always via the filesystem** — no runtime protocols, no shared memory.
- Reliability comes from **three layers**: spec precision, constitutional integrity, and cross-model validation.
- The **operator** is the human in the loop — dispatcher, triager, and provenance of intent. No participant holds epistemic authority; it lives in the record (ARCHITECTURE.md §J commitment 8).

Each execution is a discrete event. The interpreter reads its inputs, does the work, writes artifacts, and dissolves. Continuity lives only in files. Every output must be **stranger-readable** — a fresh interpreter with no memory of the work that produced it must be able to pick it up and continue.

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        OPERATOR                              │
│          (dispatches, triages, arbitrates intent)            │
└──────────┬──────────────────────────────────────┬───────────┘
           │                                      │
           ▼                                      ▼
┌─────────────────────┐              ┌─────────────────────────┐
│   spec-architect    │              │      manifest.yml       │
│   (planning-time    │──────────────│   (DAG, interfaces,     │
│    producer)        │              │    validation gates)    │
└─────────────────────┘              └────────────┬────────────┘
                                                  │
                    ┌─────────────────────────────┘
                    ▼
    ┌───────────────────────────────────────────────┐
    │              DISPATCH LOOP                     │
    │  For each spec whose dependencies are met:     │
    │                                                │
    │  validation_gate:                              │
    │    none     → producer → approved immediately  │
    │    blocking → producer → validator → approved  │
    │    standalone → producer → (validation spec)   │
    └───────────┬───────────────────────┬───────────┘
                │                       │
                ▼                       ▼
    ┌───────────────────┐    ┌───────────────────┐
    │    PRODUCER       │    │    VALIDATOR       │
    │  (interpreter A)  │    │  (interpreter B)   │
    │                   │    │  must ≠ producer   │
    │  Writes:          │    │                    │
    │  - artifacts      │    │  Writes:           │
    │  - completion     │───▶│  - verdict         │
    │    report         │    │  - memory bank     │
    │  - memory bank    │    │    audit           │
    │    updates        │    │                    │
    └───────────────────┘    └────────┬───────────┘
                                      │
                              ┌───────┴───────┐
                              │               │
                          approved      needs_revision
                              │               │
                              ▼               ▼
                          next spec      producer reworks
                                      (max 2 push-backs)
                                          │
                                    disagreement?
                                          │
                                          ▼
                              ┌───────────────────┐
                              │     ARBITER       │
                              │  (interpreter C)  │
                              │  must ≠ A and ≠ B │
                              │                   │
                              │  binding decision │
                              └───────────────────┘
```

## Navigating the Framework — Instructions for Models

You are an interpreter in a file-native pipeline. There is no runtime, no orchestrator, no shared memory — only files. Your session is disposable; continuity lives entirely in what previous sessions wrote down. These rules tell you how to find your place and which program to run.

### Session start — always

1. Read `AGENTS.md` (constitution, binding) in full, then `ARCHITECTURE.md` (the pattern).
2. Run the session-start procedure from `MEMORY_FORMATS.md` §M, in order: `current_focus.md` → `PROGRESS.md` phase headers → `MASTER_CONTEXT.md` → `open_questions.md` → `manifest.yml` → the current spec. If resumption lands mid-validation-cycle, read the spec's `validation/` directory in full.
3. Identify your role for this session from `current_focus.md`'s **Role context** field (or from the operator's dispatch instruction). If neither names a role, ask the operator — do not guess and do not default to producer.

### Role routing — which skill to run

| You are the… | Load and run | Your one-sentence job |
| --- | --- | --- |
| **Planner** (new or revised project) | `skills/spec-architect/spec-architect.md` | Turn operator intent into a locked manifest + spec set — once per project. |
| **Producer** (dispatched to a spec) | `skills/spec-producer/spec-producer.md` | Execute the spec and write `completion-report.md` — once per spec, per round. |
| **Validator** (spec in `in_review`) | `skills/pm-auditor/pm-auditor.md` | Read the completion report, verify every criterion, write `verdict.md`. |
| **Arbiter** (conflict or convergence) | `skills/resolution-auditor/resolution-auditor.md` | Form an independent finding, compare, issue the binding decision. |

The `dispatcher` skill is a reference contract, not an executing program — the operator performs dispatch manually per `OPERATOR_GUIDE.md` §D.

### Non-negotiables for every role

- **Writing `completion-report.md` is the only completion signal.** No status flips, no manifest writes, no prose announcements.
- **Distinctness is structural.** The validator must be a different interpreter than the producer; the arbiter must differ from both (AGENTS.md §15). If you are asked to validate your own work, refuse.
- **Never commit before `approved`.** One commit per approved spec, `.agents/` excluded (AGENTS.md §03.6).
- **Scratch output is a claim, not evidence.** Validators reproduce in their own verify trees (ARCHITECTURE.md §E).
- **Write memory concurrently.** PROGRESS.md entries and current_focus.md updates are engineering deliverables, not narration (MEMORY_FORMATS.md §L).
- **Every output is stranger-readable.** A fresh interpreter with no session context must be able to pick up your work (AGENTS.md §14).

### If something is missing or contradictory

1. If `manifest.yml` or the spec is missing/malformed, or a criterion cannot be reduced to a checkable claim — halt, write a specific entry in `open_questions.md`, and surface it to the operator. Never guess silently.
2. If two documents conflict, the more specific one wins; if equal, the one later in load order (AGENTS.md §13 resolution order) — and log the conflict in `open_questions.md` so it gets fixed.
3. If the project has no memory bank yet, create the full structure per `MEMORY_FORMATS.md` §O before doing anything else.

## Document Map

| Document                 | Lines | Purpose                                                                                        |
| ------------------------ | ----- | ---------------------------------------------------------------------------------------------- |
| `AGENTS.md`              | 371   | Constitution — behavioral rules every interpreter inherits                                     |
| `ARCHITECTURE.md`        | 249   | The pattern — vocabulary, loci, commitments — incl. execution environments, epistemic flatness |
| `PROJECT_MANIFEST.md`    | 367   | Manifest schema — DAG structure, invariants — incl. `constraint_amended`                       |
| `SPEC_FORMAT.md`         | 423   | Spec contract — incl. two-directional criteria, negative controls                              |
| `VALIDATION_PROTOCOL.md` | 673   | Handshake rules — artifact contracts, verify tree, negative-control mandate                    |
| `MEMORY_FORMATS.md`      | 509   | State operations — incl. standing requirements, date+slug decision ids                         |
| `OPERATOR_GUIDE.md`      | 314   | Human role — intake, arbitration, provenance of intent                                         |
| `SKILL_AUTHORING.md`     | 617   | How to write programs — frontmatter, self-check, session manifest                              |

Line counts drift as documents are edited in place; trust the file, not the table. The v2.6 upgrade (scratch trees, verify trees, negative controls, standing requirements, epistemic flatness, constraint provenance) is integrated into the canonical documents above.

**Read order for newcomers:** ARCHITECTURE.md → AGENTS.md → OPERATOR_GUIDE.md. Then the rest as needed.

## Skills

Five skills form the core program library. Each is a self-contained markdown file that any compatible interpreter can execute.

### spec-architect — Planning-Time Producer

**Role:** producer | **File:** `skills/spec-architect/spec-architect.md` (559 lines)

Transforms operator intent into a committed manifest and spec set. Five phases:

1. **Intake Interview** — structured questions to extract goal, constraints, environment, priorities, non-goals.
2. **Decomposition** — interface-first DAG design with spec sizing heuristics, critical path analysis, parallelization analysis.
3. **Spec Drafting** — writes each spec per SPEC_FORMAT.md with validation strategy assessment (tiered: focused testing vs. property-based testing).
4. **Manifest Assembly** — assembles manifest.yml, validates all seven DAG invariants.
5. **Operator Review and Lock** — presents for approval; locks manifest on approval.

Also handles emergent failure encoding — deployment feedback from MEMORY_FORMATS.md flows back into new or strengthened specs.

### spec-producer — Execution-Time Producer

**Role:** producer | **File:** `skills/spec-producer/spec-producer.md` (274 lines)

Onboards any cold interpreter into the producer role and executes one assigned spec end to end. This is the dispatch-loop producer — where `spec-architect` plans once per project, `spec-producer` runs once per spec, every round. Eight phases:

0. **Onboard Cold** — loads the constitution and architecture, runs the MEMORY_FORMATS.md §M session-start procedure, records interpreter identity, memorizes the producer boundary list (what may be written, what must be refused).
1. **Dispatch Verification & Spec Preflight** — confirms status `in_progress` + dependencies `approved` + assignment; extracts acceptance criteria, interfaces, failure modes, Progress Tracking; reads dependency resolution reports, standing requirements, architectural decisions, emergent-failure guards.
2. **Scratch Tree** — establishes the disposable execution environment derived from `repo@<commit>` + patch-under-development; repo read-only, patch is the only mutation channel.
3. **Implement** — artifacts at spec-declared paths; tests authored alongside (never blind); negative controls per named guarantee; failure modes handled; Progress Tracking checkoffs; five-cycle revision bound.
4. **Self-Check** — 12 checks, three-pass bound.
5. **State Writes** — concurrent PROGRESS.md + current_focus.md updates; conditional memory-bank writes.
6. **Completion Report** — per VALIDATION_PROTOCOL.md §C; writing it is the sole completion signal.
7. **Push-back (conditional)** — contest a `needs_revision` verdict, bounded at two; commit on approval per AGENTS.md §03.6.

### pm-auditor — Locus-1 Validator

**Role:** validator | **File:** `skills/pm-auditor/pm-auditor.md` (248 lines)

Reads a producer's completion report and implementation artifacts, issues a verdict per VALIDATION_PROTOCOL.md. Must be a different interpreter than the producer.

1. **Report Well-Formedness** — rejects malformed reports without reading implementation.
2. **Independent Verification** — reproduces every acceptance criterion check mechanically.
3. **Memory Bank Audit** — verifies the producer updated PROGRESS.md, current_focus.md, and any declared state writes.
4. **Issue Classification** — blocker / major / minor severity.
5. **Verdict Writing** — structured verdict with per-criterion assessment, interface verification, issues found, memory bank audit.

### resolution-auditor — Third-Model Arbiter

**Role:** arbiter | **File:** `skills/resolution-auditor/resolution-auditor.md` (209 lines)

Audits post-conflict resolutions or breaks deadlocks. Must differ from both producer and validator.

- **Post-conflict convergence** — producer and validator disagreed, then agreed. Arbiter checks if convergence is genuine correction or reasoning-based collusion by forming its own independent finding _before_ reading the verdicts.
- **Deadlock** — push-back rounds exhausted. Arbiter issues the binding technical decision.

The independence step is critical: the arbiter reads the spec and completion report, forms its own assessment, then compares to the prior verdicts. This prevents rubber-stamping.

### dispatcher — Dispatch Contract (Stub)

**Role:** utility | **File:** `skills/dispatcher/dispatcher.md` (190 lines)

Documents the state machine that governs dispatch. Currently a reference — the operator performs dispatch manually per OPERATOR_GUIDE.md. A future implementation would automate it.

Key contract: the dispatcher reads `validation_gate` on each spec and routes accordingly:

- `none` → producer self-report trusted, downstream starts immediately
- `blocking` → validator must clear before downstream begins
- `standalone` → dedicated validation spec handles it

## The Three Scopes of Project State

| Scope              | Location               | What belongs here                                                             |
| ------------------ | ---------------------- | ----------------------------------------------------------------------------- |
| **Manifest**       | `manifest.yml`         | DAG, spec status, interface declarations, history                             |
| **Spec artifacts** | `specs/<id>/`          | Spec file, validation directory (completion report, verdict, etc.)            |
| **Memory bank**    | `.agents/memory_bank/` | Development diary, strategic compass, cross-spec decisions, emergent failures |

The manifest is the index. The specs are the chapters. The memory bank is the diary. Each scope has a different primary reader. Writing to the wrong scope is a silent error.

## Validation Gates

Not every spec needs the same validation rigor. Validation posture is decided **at planning time** by the spec-architect, not at runtime:

| Gate         | After producer completes  | Interpreters involved | Use for                                                   |
| ------------ | ------------------------- | --------------------- | --------------------------------------------------------- |
| `none`       | Self-report trusted       | 1                     | Tier 1 specs (UI, config, docs), low-risk work            |
| `blocking`   | Validator must clear      | 2                     | Tier 2 specs (auth, crypto, input validation), root specs |
| `standalone` | Dedicated validation spec | 3                     | Complex products, cross-component validation, compliance  |

The DAG table in the manifest shows the validation gate for each spec. The critical path analysis accounts for validation overhead. The operator sees the full delegation chain — which model runs when — before approving the manifest.

## Memory Bank Enforcement

Memory bank writes are part of the acceptance contract, not a convention:

1. The producer's completion report includes a **State Management** section declaring every memory bank file written.
2. The validator **mechanically verifies** each declared write — PROGRESS.md has today's entry with all four fields, current_focus.md has a resumption point.
3. Missing writes are classified as `major` issues in the verdict.
4. Malformed reports (missing State Management section) are rejected without artifact inspection.

This ensures autonomous operation doesn't silently degrade project continuity.

## Getting Started

### For Operators

1. Read `OPERATOR_GUIDE.md` for your role in the system.
2. Start a project: invoke spec-architect ("Plan [project-name]").
3. Review the manifest and spec set it produces.
4. Approve and let the dispatcher (or you, manually) begin execution.

### For Interpreter Authors

1. Read `SKILL_AUTHORING.md` for how to write new programs.
2. Read an existing skill (start with `spec-architect.md`) as a template.
3. Follow the frontmatter format, include all eight body sections, write a self-check.

### For Auditors

1. Read `VALIDATION_PROTOCOL.md` for the handshake rules.
2. Read `ARCHITECTURE.md` §D for the three validation loci.
3. Check any spec's `validation/` directory for the full artifact trail.

## Extending

Projects extend AGENTS.md via `.agents/AGENTS.project.md` — same inheritance pattern as v2.4. Only list deviations from the base; absence means the base rule applies.

New skills follow `SKILL_AUTHORING.md`. Every skill must declare its role, loads, produces, consumes, and compatibility metadata in YAML frontmatter.

---

_Orion-OS v2.5 — A file-native, constitutional framework for composing heterogeneous LLMs into verified pipelines._
