# ARCHITECTURE.md — Orion-OS v1.0

The framework's pattern document. Read this first to understand what Orion-OS is, how its pieces fit, and which failure modes each layer exists to catch. Other docs in `.agents/` expand individual layers; this document establishes the shape they all fit into.

**Companion files:** `AGENTS.md` (constitution), `MEMORY_FORMATS.md` (state operations), `PROJECT_MANIFEST.md` (DAG schema), `SPEC_FORMAT.md` (spec contract), `VALIDATION_PROTOCOL.md` (handshake rules), `OPERATOR_GUIDE.md` (human role).

---

## §A · What Orion-OS Is

An autonomous multi-model operating system for software development.

**Autonomous** — the operator sets direction and intent; the system executes within layered validation without requiring technical review at every step.

**Multi-model** — different LLMs play different roles in the pipeline. Producer, validator, and arbiter are deliberately distinct interpreters, not personas of one model. Heterogeneity is a reliability property, not overhead.

**Operating system** — Orion-OS is infrastructure for running programs (skills), not the programs themselves. It defines the constitution every interpreter obeys, the format of inter-process communication (files), the validation loci, and the feedback loops. Programs compose on top of this foundation.

It is **not**:

- a runtime (no scheduler, no loop detector, no rate-limit logic — those live below this layer)
- a chat interface or developer tool (the operator can be human or another system)
- a multi-agent coordination framework in the LangGraph/AutoGen sense (no wire protocol, no shared actor runtime)
- a replacement for software engineering judgment (conceptualization remains the highest-value work)

---

## §B · The Core Model

Every other decision in Orion-OS flows from this shape:

```
Interpreter   = any capable LLM (Claude, GPT, Gemini, ...)
Program       = an executable markdown file (a skill)
Spec          = a unit of work declared in the project manifest
Manifest      = the DAG of specs for a project
Constitution  = AGENTS.md — behavioral rules every interpreter inherits
Memory bank   = durable, stranger-readable project state in files
Filesystem    = the shared medium through which programs communicate
```

An interpreter runs a program against a spec. The program reads inputs from the filesystem (prior specs, memory bank, manifest), writes outputs to the filesystem (artifacts, reports, verdicts), and terminates. The next step in the pipeline is another invocation — possibly a different interpreter running a different program — reading those outputs.

**There is no persistent agent.** There are execution contexts that come into being for a single invocation, do their work, leave artifacts, and dissolve. Continuity between invocations lives only in files. This is enforced by the architecture, not by convention.

This is the **stranger principle**, which every artifact in the system must satisfy:

> Every output must be readable by a fresh interpreter with no memory of the work that produced it. If an artifact requires implicit context to understand, the artifact is broken.

The stranger principle is what makes heterogeneous interpreters possible, what makes crash-safety automatic (files survive, context doesn't), and what makes cross-model validation meaningful.

---

## §C · Planning Time vs. Execution Time

Orion-OS separates two activities most agent frameworks blur:

**Planning time** — the operator (with interpreter assistance) decomposes the project into a DAG of specs. Each spec declares its purpose, inputs, outputs, interfaces, acceptance criteria, and position in the graph. Integration specs are planned alongside unit specs. The project manifest is the result.

This is the **highest-leverage work in the system**. The manifest and specs are not documentation about the work — they _are_ the program being executed. The execution layer amplifies whatever is in the specs. Good specs get amplified into good outcomes; bad specs get amplified into bad outcomes with equal fidelity.

Every validation mechanism in Orion-OS can only check execution against the criteria the specs encode. A faithfully-executed bad spec passes every gate. **System reliability is bounded below by spec quality.** Invest accordingly.

**Execution time** — programs walk the DAG. Dispatching (currently by the operator, eventually by a dispatcher program) selects the next spec whose dependencies are satisfied. A producer interpreter runs it. A stranger interpreter validates it. Gates fire, loopbacks occur, completed specs flip status in the manifest, downstream specs become dispatchable. Mechanical.

The separation matters because it names where human effort should concentrate. Planning time is where operator judgment multiplies. Execution time is where the machine layer earns its keep.

---

## §D · Validation Loci

Different failure classes live at different scales. Each has a dedicated mechanism and cannot be caught at any other layer.

### Locus 1 — Unit (per spec)

**Catches:** "Did this spec get implemented correctly as stated?"

**Mechanism:** A stranger interpreter (different LLM than the producer) reads the completed artifacts against the spec's acceptance criteria and issues a verdict. On disagreement between producer and validator, a structured push-back protocol triggers re-evaluation. On post-conflict convergence, a third interpreter audits the resolution to guard against reasoning-based collusion between the first two.

**Machine-sufficient.** Does not require operator judgment.

Detailed in: `VALIDATION_PROTOCOL.md`.

### Locus 2 — Integration (composed specs)

**Catches:** "Do the completed specs actually work together?"

**Mechanism:** Dedicated integration specs in the manifest. Their inputs are already-completed unit specs; their acceptance criteria are about interfaces, compositions, concurrency behavior, and shared-state invariants. An integration spec runs through the same validation pipeline as any other spec — but the emergent properties it tests cannot be checked at the unit locus.

**Machine-sufficient** when integration specs themselves are well-written.

### Locus 3 — Deployment (system meets reality)

**Catches:** "Does this work in the real environment under real conditions?"

**Mechanism:** Actual execution. The operator (or real users) exercise the composed system. Real failures get captured in `memory_bank/emergent_failures.md` with root cause, surfacing point, and the spec pattern that was vulnerable.

**Not machine-sufficient.** This is the ground-truth layer where the system learns its own blind spots.

### The feedback path

Locus-3 failures become inputs to future planning time. A pattern that surfaced in deployment once becomes an explicit check in the next manifest's specs. Over time, this transforms the architecture's known blind spots into encoded precautions — the system learns, not through weight updates, but through the compounding quality of its specs.

---

## §E · Heterogeneous Execution

Roles in the pipeline are filled by distinct interpreters, chosen per role:

### Execution environments

Two vocabulary terms and three rules close a gap the nine-round audit remediation exposed — the framework was silent on whether producers may execute anything, so a dispatch-time directive improvised "fully read-only producer," fusing two independent knobs:

| Knob             | Question                               | Boundary status                                  |
| ---------------- | -------------------------------------- | ------------------------------------------------ |
| Mutation path    | Who can change the repo, how visibly?  | **Security boundary.** Patch-only, reviewable.   |
| Observation path | Who can execute code and see results?  | Not a boundary. Sandbox freely.                  |
| Persistence      | What execution state survives a round? | **Drift boundary.** Nothing — trees are derived. |

- **Scratch tree** — the producer's execution environment. **Derived:** a scratch tree is a function of exactly `repo@<commit>` and `patch-under-development@<id>`; any state not derivable from those inputs is drift by definition. **Disposable:** rebuilt at the start of every producer round, never persisted, never committed, never cited by sandbox path in artifacts — artifacts cite repo paths and patch ids. **Role-scoped:** producer scratch trees and validator verify trees are separate and never shared; roles communicate through files, as ever (Commitment 1 extends to execution environments).
- **Verify tree** — the validator's execution environment. The validator rebuilds from `repo@<commit> + patch@<id>` alone; a claim that fails to reproduce there is refuted regardless of producer scratch output. This rebuild _is_ the mechanical enforcement of "the patch is the complete record" — any out-of-patch mutation either fails to reproduce or is visible in repo state.
- **Mutation boundary unchanged.** The repo is read-only to the producer. The patch is the only mutation channel and the complete record of intent.

**Evidence consequence (per VALIDATION_PROTOCOL.md §H):** scratch-tree output is a _claim, not evidence_. The first-run property decays by construction — after round 1 the producer iterates against validator findings, so the loop is iterated-to-green regardless. The gate's teeth come from validator method (re-derivation, constructed negative cases, traced branches), never from producer blindness.

**Enforcement postures.** The default is **cooperative**: the producer honors the patch-only boundary by convention and the verify-tree rebuild enforces it as a byproduct of validator method. Threat model: fallible, not adversarial. The **adversarial posture** (tool-level fencing — producer tools scoped to the scratch tree) is opt-in per project at intake, correct only when preventive controls are themselves the deliverable (compliance regimes, untrusted external vendor lineages). Invariant across postures: validator method never changes; enforcement, where present, is defense-in-depth _behind_ the method. Method, not mechanism — the same lesson as "method, not personnel" (VALIDATION_PROTOCOL.md v2.1). Any future feature sold as "validators can now relax" is refused by this clause.

**Constraint provenance.** Structural constraints (execution-environment boundaries, mutation policy, evidence formats) are minted at planning time in the manifest and reviewed at operator lock. Dispatch directives may cite constraints; they may not create them. A constraint discovered mid-run is a manifest history event ( `constraint_amended` ), then dispatched against. Directives are ephemeral; the framework's review mechanisms only operate on what is written in files. spec-architect's intake gains a standing question: "What execution-environment constraints does this project need — and why?" The answer is encoded with the vocabulary above. Had the read-only producer constraint been written at intake instead of minted in a directive, the knob fusion would have been visible at operator review.

| Role                 | Task                                    | Typical interpreter            | Why distinct                                              |
| -------------------- | --------------------------------------- | ------------------------------ | --------------------------------------------------------- |
| Producer             | Executes the spec                       | High-capability model          | Needs deep reasoning for implementation                   |
| Stranger / Validator | Reads artifacts, issues verdict         | Different vendor than producer | Different training distribution → independent blind spots |
| Arbiter              | Audits post-conflict resolutions        | Third vendor ideally           | Guards against prover-verifier collusion                  |
| Operator             | Arbitrates non-technical questions only | Human                          | Judges intent, scope, priority                            |

The architecture does not prescribe _which_ LLMs fill which role — that's a cost/capability decision. What the architecture prescribes is that **the roles are filled by interpreters that do not share a training lineage**, to the extent feasible. Producer-validator pairs where both are the same model defeat the purpose of the locus-1 mechanism.

Communication between roles is **always via the filesystem**, never via runtime protocol. This is what allows interpreters from different vendors to cooperate without integration engineering.

---

## §F · Reliability Layers

The full stack, from foundation to top:

| Layer               | Artifact                               | Catches                                               | Fails when                                            |
| ------------------- | -------------------------------------- | ----------------------------------------------------- | ----------------------------------------------------- |
| Constitution        | `AGENTS.md`                            | Behavioral drift (dishonest reports, value shortcuts) | Interpreter ignores or misinterprets the constitution |
| Spec quality        | `manifest.yml` + `specs/`              | Misaligned intent, scope creep, hidden assumptions    | Conceptualization was rushed or incomplete            |
| Stranger validation | `pm-auditor` program                   | Execution drift from spec                             | Producer and validator share the same blind spot      |
| Conflict resolution | Push-back + third-model audit          | Reasoning-based convergence drift                     | All three interpreters share the same blind spot      |
| Integration specs   | Explicit integration specs in manifest | Interface mismatches, emergent composition bugs       | Integration specs miss a composition scenario         |
| Deployment          | Real usage + `emergent_failures.md`    | Everything else                                       | Operator fails to capture or propagate the failure    |

Each layer catches what the layers below miss. Each layer has a failure mode. The combination, not any single mechanism, is what produces reliability.

**There is no layer claiming to catch every failure.** An architecture that overclaims invites the mistake of trusting it in cases it was never designed for.

---

## §G · Document Map

The Orion-OS documentation set, with purpose and primary reader:

| Document                     | Purpose                                                     | Primary reader                         |
| ---------------------------- | ----------------------------------------------------------- | -------------------------------------- |
| `AGENTS.md`                  | Constitution — behavioral rules for all interpreters        | Every interpreter, every session       |
| `MEMORY_FORMATS.md`          | State operations manual — how to read/write the memory bank | Any interpreter touching memory        |
| `ARCHITECTURE.md` (this doc) | The pattern itself — how the pieces fit                     | Onboarding humans, new interpreters    |
| `PROJECT_MANIFEST.md`        | Schema for the project DAG                                  | spec-architect, dispatcher, validators |
| `SPEC_FORMAT.md`             | Contract for what a spec must contain                       | spec-architect, producers, validators  |
| `VALIDATION_PROTOCOL.md`     | Producer/validator/arbiter handshake rules                  | pm-auditor, resolution-auditor         |
| `OPERATOR_GUIDE.md`          | Human role, decision points, escalation handling            | Operator                               |
| `SKILL_AUTHORING.md`         | How to write a new program                                  | Anyone extending the program library   |
| `DISPATCHER_SPEC.md`         | Contract for the dispatcher program                         | Implementers of future dispatchers     |

Every document references this one for architectural context. Every document is self-contained enough that an interpreter loading it alone can perform its role.

---

## §H · Vocabulary

Canonical terms. Other terminology from prior drafts is deprecated; these supersede.

- **Program** — an executable markdown file (a skill). The unit of composition in the program library.
- **Skill** — synonym for program; retained for continuity with existing files.
- **Interpreter** — any LLM running a program. Interchangeable across invocations.
- **Spec** — a unit of work in the project manifest. A node in the DAG.
- **Manifest** — the full project DAG. Single source of truth for status, dependencies, interfaces.
- **Operator** — the human role. Provides direction, arbitrates non-technical disputes, captures deployment failures.
- **Producer** — the interpreter executing a spec.
- **Stranger / Validator** — the interpreter validating a producer's work. Must be a different model than the producer.
- **Arbiter** — the third interpreter auditing post-conflict resolutions. Must differ from both producer and validator.
- **Locus** — a validation layer (unit, integration, deployment). Each locus catches a distinct failure class.
- **Memory bank** — durable project state in files. Stranger-readable.
- **Artifact** — any file produced by a program execution.
- **Gate** — a validation checkpoint; blocks downstream progress until passed.
- **Loopback** — the return path when a gate fails; routes work back to a prior stage for revision.
- **Scratch tree** — the producer's disposable execution environment; derived from `repo@<commit> + patch@<id>`, rebuilt every round.
- **Verify tree** — the validator's execution environment; rebuilt from the record alone, it mechanically enforces the patch-as-complete-record property.

---

## §I · Session Start

When any interpreter begins a session operating under Orion-OS, it loads documents in this order:

1. `AGENTS.md` — constitution (always).
2. This document (`ARCHITECTURE.md`) — architectural context.
3. The program being executed (the specific skill file).
4. `PROJECT_MANIFEST.md` schema + the current project's `manifest.yml`.
5. The current spec being worked on.
6. Relevant memory bank entries (per `MEMORY_FORMATS.md` session start procedure).
7. Role-specific docs as needed: `VALIDATION_PROTOCOL.md` for validators, `OPERATOR_GUIDE.md` for human-facing interactions.

The session manifest block (per `AGENTS.md` §12) reports which of these were loaded, forcing visibility and accountability.

---

## §J · Architectural Commitments

The design choices above were not obvious alternatives among equals; they were chosen to resolve specific failure modes observed in other agent frameworks. Stating them explicitly so the commitments are auditable:

1. **Files over protocols.** Inter-interpreter communication is file-based. Always. This is what enables heterogeneity, crash-safety, glass-box auditability, and cross-vendor portability.

2. **Planning over execution.** Conceptualization is the highest-leverage phase. The framework deliberately makes planning visible and separate from execution.

3. **Heterogeneity as reliability.** Different models at different roles. Same-model self-validation is rejected as structurally insufficient.

4. **Stranger-readable everything.** No hidden context. Every artifact stands alone. Enforced by architectural requirement, not convention.

5. **Layered, honest catching.** Each layer claims only what it can catch. Deployment is the ground-truth layer; no other layer pretends to substitute for it.

6. **Operator as director, not reviewer.** Human time goes to intent and non-technical arbitration; machine time goes to technical validation. Role separation is deliberate.

7. **Feedback over immunity.** The system is designed to learn from deployment failures, not to prevent them all. Captured failures become spec-level precautions for future work.

8. **Epistemic flatness.** No participant — operator, PM, producer, validator, arbiter — holds epistemic authority. Authority lives in three things, all files: code (it runs or it fails), logic (framework rules and established decisions), and objectives (the manifest). Participants are viewpoints, each valuable _because_ distinct. The protocol's hierarchical vocabulary is termination scaffolding, never epistemic rank: the arbiter's "binding" decision and the operator's intent call close a _dispute_ for a round; they do not certify the _conclusion_. New evidence reopens questions through history — append-only, so reopening never erases. A producer's push-back with better evidence out-ranks a validator's verdict; that is why push-back is a first-class move, not an exception.

9. **Constraints are minted in files, not directives.** Structural constraints enter the system at planning time via the manifest and specs, reviewed at lock. Dispatch directives reference them; they cannot create them. The review mechanisms — operator intake review, validator audits, stranger re-reads — only operate on what is written down.

10. **Method, not mechanism.** Enforcement postures exist (cooperative default, adversarial opt-in), but the reliability bet is cross-vendor adversarial method. Mechanism reinforces the bet; it never substitutes for it. Validator method is invariant across postures.

If a future extension violates any of these, it is not an extension — it is a different architecture.

---

_End of ARCHITECTURE.md v1.0_
