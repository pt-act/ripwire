# SKILL_AUTHORING.md — How to Write a Program

Skills — synonym, programs — are the executable units of Orion-OS. An interpreter running a skill against a spec produces artifacts. The architecture's reliability properties depend on skills being written in a consistent, composable, stranger-executable way.

**Companion files:** `ARCHITECTURE.md` (the pattern), `AGENTS.md` (constitution), `VALIDATION_PROTOCOL.md` (handshake rules), `SPEC_FORMAT.md` (spec contract).

**When to load this file:** When writing a new skill, when retrofitting an existing skill to the finalized architecture, or when reviewing a proposed skill for admission into the program library.

---

## §A · What a Skill Is

A skill is an **executable markdown file** — a program that any sufficiently capable interpreter can run. The skill contains the instructions the interpreter follows; the interpreter supplies the reasoning. Running a skill is indistinguishable from any other kind of interpreter session except that the session's behavior is tightly constrained by the skill's contents.

Three properties every skill must have:

1. **Role-scoped.** Each skill declares exactly one role in the validation protocol: producer, validator, arbiter, or utility. A skill that mixes roles is refactored into multiple skills, one per role.

2. **Stranger-executable.** An interpreter loading the skill fresh, with no prior context from the skill's authors, must be able to run it to completion using only the skill itself, the constitution, the architecture document, and the spec being worked on. No implicit dependencies on prior sessions.

3. **Artifact-producing.** The skill's output is one or more files in known locations with known formats. The skill does not produce loose text in the session — it produces files that downstream interpreters read.

A skill is **not**:

- A persona or personality. No "you are a helpful product manager" preambles.
- A prompt template. Templates are filled in by whoever writes them; skills are executed by interpreters reading them directly.
- A wrapper around a runtime service. Skills never depend on external APIs outside the filesystem.

---

## §B · Skill File Structure

Every skill file has two parts: the frontmatter (machine-readable metadata) and the body (interpreter-readable instructions).

```markdown
---
<frontmatter — YAML>
---

# <Skill Name>

## Purpose

<What this skill is for — 1 paragraph>

## Role

<producer | validator | arbiter | utility>

## When to Run

<What trigger conditions invoke this skill>

## Inputs

<Files the skill reads; where they are expected to be>

## Outputs

<Files the skill writes; where and in what format>

## Process

<Numbered steps. The meat of the skill.>

## Self-Check

<How the interpreter verifies its own output before signaling completion>

## Failure Modes

<What can go wrong; how the skill detects and reports each>

## Session Manifest

<What the interpreter reports at session close, per AGENTS.md §12>
```

All sections are required. A skill missing any required section is malformed.

---

## §C · Frontmatter

YAML block at the top of the file. Machine-parseable. Fields:

```yaml
---
name: <kebab-case identifier; must be globally unique>
version: <semver>
role: producer | validator | arbiter | utility
description: |
  <1–3 sentences: what this skill does and when to run it.
   Used by the operator or dispatcher to select the skill.>
loads:
  - AGENTS.md
  - ARCHITECTURE.md
  - <other docs this skill requires loaded before execution>
produces:
  - path: <path template — may include <spec-id> placeholders>
    format: <markdown | yaml | json | code>
    purpose: <one line>
consumes:
  - path: <path template>
    optional: true | false
compatible_interpreters:
  - <list of interpreter identifiers this skill is known to run correctly on;
    or "any" if the skill makes no assumptions>
distinctness_requirements:
  producer_must_differ_from: [] # e.g., for validator skills
  validator_must_differ_from: [] # e.g., for arbiter skills
supersedes: <name of prior skill this replaces, if any>
---
```

### Field notes

- **role** — binding. A skill's role determines which part of the validation protocol it plugs into. Cross-role skills are not allowed.
- **loads** — documents the interpreter must have read before running this skill. At minimum, `AGENTS.md` and `ARCHITECTURE.md`. Validator and arbiter skills also load `VALIDATION_PROTOCOL.md`. Producer skills working on specs also load `SPEC_FORMAT.md`.
- **produces** / **consumes** — file-level IO contract. The dispatcher and downstream skills rely on these paths. Path templates using `<spec-id>` or `<project-root>` are resolved at execution time.
- **compatible_interpreters** — the skill's author tests against a set of interpreters and records which ones produced correct output. An interpreter not on the list is not rejected outright, but running the skill is a known-unknown.
- **distinctness_requirements** — enforces `VALIDATION_PROTOCOL.md` §B. A validator skill declares it must differ from the producer; an arbiter skill declares it must differ from both.

---

## §D · Body Sections

### Purpose

One paragraph. States what the skill accomplishes at the project level. Not what steps it performs — what outcome it produces.

Bad: "This skill walks through an interview, drafts specs, and reviews them with the operator."

Good: "This skill transforms an operator's intent into a committed project manifest and spec set. Its successful output is a manifest the operator would bet on."

### Role

One line. `producer`, `validator`, `arbiter`, or `utility`. Matches the frontmatter `role` field. Redundancy is intentional — the body must be readable standalone when the frontmatter is stripped.

### When to Run

Specific trigger conditions. For operator-invoked skills, the phrases or situations that invoke the skill. For dispatcher-invoked skills, the manifest state that triggers invocation.

Examples:

- Producer skill (planning): "Operator initiates a new project; operator says 'plan', 'spec', or 'design'; or a paused project's first session after resumption."
- Validator skill: "A completion report exists at `specs/<id>/validation/completion-report.md` and no verdict exists yet."
- Arbiter skill: "Post-conflict convergence in a validation cycle (verdict history length ≥ 2 with at least one disagreement), or two push-back rounds exhausted without resolution."

### Inputs

Every file the skill reads, with path and purpose. Optional inputs are flagged. The list must be complete — reading a file not declared in Inputs is a skill violation.

```
- AGENTS.md — constitution
- ARCHITECTURE.md — architectural context
- manifest.yml — project DAG
- specs/<id>/spec.md — the spec being worked on
- specs/<id>/validation/completion-report.md — producer's output (for validator role)
- .agents/memory_bank/emergent_failures.md — deployment feedback (optional, for planning skills)
```

### Outputs

Every file the skill writes, with path, format, and purpose. The list must be complete — writing a file not declared in Outputs is a skill violation.

```
- specs/<id>/validation/verdict.md — the verdict (markdown, per VALIDATION_PROTOCOL.md §C)
- .agents/memory_bank/active/PROGRESS.md — appended entry (markdown, per MEMORY_FORMATS.md §F)
```

### Process

Numbered steps. This is the executable part of the skill. Each step is imperative (do this, write that), not advisory (consider doing this).

Steps should be:

- **Atomic** — one action per step. Steps combining three actions are refactored into three steps.
- **Checkable** — each step produces a visible result the interpreter can verify.
- **Ordered** — the numbering matters; steps execute in order unless explicit branching is noted.

Branching is expressed as nested numbered lists or as explicit `IF <condition> THEN <step>` constructs. Unbounded loops are not allowed. Bounded loops are allowed with an explicit upper bound (e.g., "Repeat steps 4–7 up to three times or until the operator approves").

### Self-Check

Before the skill writes its final output, the interpreter runs through a self-check list derived from the skill's Purpose. The self-check must have:

- **A specific yes/no question per acceptance criterion** — not "is the output good" but "does the verdict contain per-criterion evidence for every criterion in the spec?"
- **A failure action per question** — what the interpreter does if the answer is no. Typically: fix the output and re-check.
- **A termination rule** — the self-check loops at most N times (usually 3); after N, the interpreter writes a partial output with explicit TODOs and escalates.

The self-check is not optional and not a "nice to have." It is the skill's internal validation before the external validation protocol sees the output. Skills without self-check blocks are malformed.

### Failure Modes

Explicit list of things that can go wrong during the skill's execution and what the skill does in each case. At minimum:

- **Missing required input file** — action: halt and report which file is missing.
- **Malformed required input file** — action: halt and report the malformation.
- **Self-check loop exhausted** — action: write partial output with TODOs, flag in memory bank, escalate.
- **Contradictory inputs** — action: halt and escalate to operator.

Role-specific failures belong here too: for validators, "all three criteria are unverifiable"; for producers, "spec requires dependency that is not approved."

### Session Manifest

Per `AGENTS.md` §12, every session concludes with a visible accounting of what the interpreter did. For a skill, this is standardized:

```markdown
## Session Manifest

- Skill: <name>@<version>
- Interpreter: <interpreter identifier>
- Role: <producer | validator | arbiter | utility>
- Spec: <id, if applicable>
- Documents loaded: <list>
- Files read: <list>
- Files written: <list>
- Self-check result: <passed on iteration N | partial with TODOs>
- Escalations raised: <list or "none">
```

Interpreters paste this block into the session close. The operator (or a future audit script) can read it to confirm the skill executed as declared.

---

## §E · The Four Role Categories

Every skill fits into one of four categories. Each has conventions beyond the common structure.

### Producer skills

**Purpose:** implement a spec. Write code, config, migrations, docs, or whatever the spec requires.

**Conventions:**

- Always produce a `completion-report.md` at the end of execution. This is the signal to the dispatcher that the producer is done.
- Never write to the manifest directly. State changes happen via the dispatcher reading the completion report.
- Never write validation verdicts for the work the skill produced. That's the validator's job.
- The self-check mirrors the spec's Acceptance Criteria — the producer checks its own output against those criteria before writing the completion report.

**Canonical example:** `skills/spec-architect.md` (planning-time producer); a generic implementation producer would follow the same structure with different Inputs/Outputs.

### Validator skills

**Purpose:** read a producer's output and issue a verdict per `VALIDATION_PROTOCOL.md`.

**Conventions:**

- Always produce a `verdict.md` (or `verdict-<N>.md` for re-validation rounds).
- Never modify the producer's artifacts. Validator skills are read-only with respect to the producer's work.
- `distinctness_requirements.producer_must_differ_from` is declared in frontmatter — the dispatcher checks this before invoking the skill.
- The self-check confirms the verdict is well-formed per `VALIDATION_PROTOCOL.md` §C before writing.

**Canonical example:** `skills/pm-auditor.md`.

### Arbiter skills

**Purpose:** audit post-conflict resolutions or break deadlocks. Issue binding decisions.

**Conventions:**

- Always produce an `arbiter-audit.md`.
- Reads all prior validation artifacts (completion report, all verdicts, all push-backs).
- Forms an independent finding before reading the validator's final verdict — the self-check explicitly confirms independence.
- Distinctness: must differ from both producer and validator.
- The binding output is one of: `approved`, `needs_revision`, `escalate_to_operator`.

**Canonical example:** `skills/resolution-auditor.md`.

### Utility skills

**Purpose:** everything else. Common cases: memory bank audits, manifest integrity checks, cross-project summaries, archive/restore operations.

**Conventions:**

- No validation-protocol role. Reads and writes files, does not participate in the producer/validator/arbiter handshake.
- May mutate the memory bank or the manifest if the skill's purpose explicitly requires it (e.g., a manifest-linter skill that appends a `manifest_revised` history entry). Such mutations are always explicit in the Outputs section.
- Typically operator-invoked, not dispatcher-invoked.

---

## §F · Writing the Process Section Well

The Process section is where most skill-authoring mistakes happen. Common failure patterns and their fixes:

### Too vague

Bad:

```
1. Understand the spec.
2. Write the implementation.
3. Check your work.
```

Fixed:

```
1. Load and parse specs/<id>/spec.md. Confirm the Header block is present and
   the version matches the manifest entry for this spec id.
2. Extract the Acceptance Criteria as a numbered list. This list will be the
   basis for the completion report's per-criterion evidence block.
3. Read every entry in the spec's Dependencies section. For each dependency
   spec, load its resolution report and note the interface shape delivered.
4. Implement. The implementation artifacts go at the paths declared in the
   spec's Interfaces section. Do not place artifacts elsewhere.
5. For each criterion in the list from step 2, identify the specific file
   and lines that satisfy it. Note the file, line range, and a one-sentence
   justification. This feeds into the completion report.
6. (Self-check — see Self-Check section.)
7. Write completion-report.md per VALIDATION_PROTOCOL.md §C.
```

### Missing branches

Bad:

```
1. Read the spec.
2. Implement it.
```

Missing: what if the spec is malformed? What if a dependency is missing? What if the spec declares an interface impossible to satisfy with the current tech stack?

Fixed (relevant addition):

```
1. Read specs/<id>/spec.md. If the Header block is missing or the spec does
   not parse, halt with failure mode MALFORMED_SPEC and return the spec
   to planning (append an open_questions.md entry addressed to operator).
2. For each dependency in Dependencies, confirm its status is 'approved' in
   manifest.yml. If any dependency is not approved, halt with failure mode
   UNSATISFIED_DEPENDENCY.
...
```

### Unbounded loops

Bad:

```
4. Keep revising until the output is good.
```

Fixed:

```
4. Run the self-check (see Self-Check section). If any check fails, revise
   the relevant output and re-run. Bound: at most 3 revisions. After 3
   revisions with any check still failing, write the output with explicit
   TODOs on the failing checks and proceed to step 5.
```

### Hidden assumptions

Bad:

```
3. Follow the project's coding conventions.
```

The interpreter has no way to know what those conventions are. Fix by either:

- Naming the conventions inline: "use tab indentation, 2-space tab width, no trailing whitespace"
- Loading an explicit conventions file: "load `.agents/conventions.md` and follow its rules"
- Deriving from existing code: "open two files in the existing codebase nearest the new code's location, identify their common patterns, follow those"

Never leave the interpreter to infer.

---

## §G · Self-Check Blocks in Detail

The self-check is the skill's internal validator. Its quality determines whether the external validator catches bugs or spends its round confirming what the self-check should have already caught.

Structure:

```markdown
## Self-Check

Before writing final output, confirm each of the following. If any answer is
No, apply the indicated Fix Action. After three full passes with any check
still failing, escalate (see Failure Modes).

1. **<Specific question>** — <what "yes" looks like, concretely>
   - If No: <specific fix action>

2. **<Next question>** — ...
   - If No: <fix action>

...

N. **Session manifest complete** — Every field in the Session Manifest
section is populated with specific values, not placeholders.

- If No: populate the missing fields before closing.
```

**Good self-check questions:**

- "Does the completion report contain a per-criterion evidence entry for every criterion listed in the spec's Acceptance Criteria section, with each entry naming a specific file and line range?" (Checkable.)
- "Does every interface declared in the spec's Interfaces section have a corresponding implementation at a path matching the spec's expectation?" (Checkable.)

**Bad self-check questions:**

- "Is the implementation correct?" (Not checkable without re-doing validator work.)
- "Does this feel done?" (Vibes-based; not a self-check.)

The self-check's value is purely in its specificity. A self-check that can be passed by a shallow "yes, I think so" is not doing work.

---

## §H · Worked Example — A Minimal Producer Skill

A skill that would take a spec and produce a TypeScript implementation. Shown here in skeleton form; real production versions would be longer.

```markdown
---
name: ts-implementer
version: 0.1.0
role: producer
description: |
  Implements a TypeScript unit spec, producing code artifacts and a
  completion report per VALIDATION_PROTOCOL.md §C. Runs when the dispatcher
  assigns a producer interpreter to a spec whose implementation language
  is TypeScript.
loads:
  - AGENTS.md
  - ARCHITECTURE.md
  - SPEC_FORMAT.md
  - VALIDATION_PROTOCOL.md
produces:
  - path: <per-spec-declared-paths>
    format: code
    purpose: implementation artifacts
  - path: specs/<spec-id>/validation/completion-report.md
    format: markdown
    purpose: producer handoff to validator
consumes:
  - path: specs/<spec-id>/spec.md
    optional: false
  - path: manifest.yml
    optional: false
  - path: specs/<dep-id>/validation/resolution-report.md
    optional: false # one per dependency
compatible_interpreters:
  - any
---

# ts-implementer

## Purpose

Implement a TypeScript unit spec. Produce the implementation artifacts
declared in the spec's Interfaces section and write a completion report
the validator can evaluate against the spec's Acceptance Criteria.

## Role

producer

## When to Run

Dispatcher assigns this skill to an in_progress spec whose implementation
language (declared in the spec's Implementation Notes) is TypeScript.

## Inputs

- specs/<spec-id>/spec.md — the spec being implemented
- manifest.yml — to confirm dependency status
- specs/<dep-id>/validation/resolution-report.md — one per dependency
- .agents/memory_bank/MASTER_CONTEXT.md — project conventions, active decisions
- .agents/memory_bank/ARCHITECTURAL_DECISIONS.md — binding decisions

## Outputs

- Implementation files at paths declared in the spec's Interfaces section
- specs/<spec-id>/validation/completion-report.md

## Process

1. Parse specs/<spec-id>/spec.md. Confirm Header is well-formed and version
   matches manifest. If not: halt, failure mode MALFORMED_SPEC.

2. Extract Acceptance Criteria into a numbered list. Extract Interfaces into
   an (interface name, shape, expected path) tuple list. Extract Failure
   Modes into a checklist.

3. For each dependency in the spec's Dependencies section:
   a. Read specs/<dep-id>/validation/resolution-report.md.
   b. Note the interface shape the dependency delivered (may differ from
   the shape the current spec's Dependencies section expects — resolve
   in favor of what the dependency actually delivered, and record the
   discrepancy in completion report's Known Deviations).

4. Read .agents/memory_bank/ARCHITECTURAL_DECISIONS.md. Note any decisions
   that constrain implementation choices for this spec.

5. Implement:
   a. For each interface in the tuple list from step 2, produce a file at
   the expected path implementing the declared shape.
   b. Write tests adequate to exercise each Acceptance Criterion. Tests
   go at the paths declared in the spec's Implementation Notes or, if
   unspecified, mirror the source tree under a tests/ directory.
   c. For each Failure Mode in the spec, confirm the implementation handles
   it (either a specific code path or an explicit test case).

6. Run the test suite. Capture output. If any test fails, return to step 5
   and revise. Bound: at most 5 implementation revisions. After 5, proceed
   to step 7 with partial output.

7. Self-check (see Self-Check).

8. Write specs/<spec-id>/validation/completion-report.md per
   VALIDATION_PROTOCOL.md §C. Use the Acceptance Criteria list from step 2
   as the basis for the per-criterion evidence block. For each criterion,
   cite the specific file and line range of the implementation and the
   test name exercising it.

9. Write session manifest (see Session Manifest).

## Self-Check

Before writing completion-report.md, confirm:

1. **Per-criterion evidence complete.** Every criterion from step 2 has
   an identified (file, line range, test name) triple.
   - If No: return to step 5 and fill the gap.

2. **Interfaces match.** Every interface in the tuple list from step 2
   has a file at the expected path implementing a compatible shape.
   - If No: return to step 5. If the shape genuinely cannot match the
     spec's declaration, add a Known Deviation to the completion report
     with explicit reasoning rather than silently changing the shape.

3. **Test suite passes.** All tests pass, not just the ones written for
   this spec. If pre-existing tests fail, the implementation regressed
   other code.
   - If No: return to step 5. Do not write a completion report claiming
     success when regressions exist.

4. **Failure modes addressed.** Every item in the spec's Failure Modes
   section has a corresponding code path or test.
   - If No: return to step 5.

5. **Known deviations documented.** Any departure from the spec as
   written is in the Known Deviations section of the completion report
   with reasoning.
   - If No: add the deviation before writing the report.

After three full self-check passes with any answer still No, proceed with
partial output: write the completion report with explicit TODO markers
on the failing criteria. Append an open_questions.md entry for the operator.

## Failure Modes

- MALFORMED_SPEC — spec.md is missing, malformed, or version-mismatched.
  Action: halt; append open_questions.md entry; do not write a
  completion report.

- UNSATISFIED_DEPENDENCY — a dependency spec is not approved.
  Action: halt; append open_questions.md entry; notify dispatcher.

- SELF_CHECK_EXHAUSTED — three self-check passes with failures.
  Action: partial completion report with TODOs, open_questions.md entry,
  explicit escalation to operator.

- REGRESSION — pre-existing tests fail after implementation.
  Action: treat as self-check failure; revise until regressions are
  resolved; if unresolvable, escalate via SELF_CHECK_EXHAUSTED.

## Session Manifest

(Standard block — see SKILL_AUTHORING.md §D.)
```

---

## §I · Retrofitting Existing Skills

Skills authored before this document existed have drift from the protocol. Retrofit process:

1. **Classify the skill's role.** Producer, validator, arbiter, or utility. If the skill mixes roles (common in legacy skills), plan the refactor into multiple skills before the retrofit.

2. **Add or update the frontmatter.** All required fields populated. `version` bumps to mark the retrofit.

3. **Align inputs and outputs to the spec-directory and validation-directory layouts.** Legacy skills often write to ad-hoc paths; retrofit relocates them to `specs/<id>/validation/` or `.agents/memory_bank/` as appropriate.

4. **Replace ad-hoc verdict/report formats with the formats in `VALIDATION_PROTOCOL.md` §C.** Legacy skills may have richer or poorer formats; the protocol's formats are authoritative.

5. **Add the Self-Check section.** If the legacy skill lacked a self-check, this is the retrofit's single biggest quality gain.

6. **Add the Session Manifest section.** Required by constitution; often missing in legacy skills.

7. **Test the retrofit.** Run the retrofitted skill against a known test spec. Confirm the artifacts land at the right paths and match the required formats. Log the retrofit in `ARCHITECTURAL_DECISIONS.md`.

Two retrofits have been completed as part of establishing Orion-OS v1.0: `spec-architect` and `pm-auditor`. Their retrofitted versions live in `skills/`. The legacy versions (under `uploads/`) are preserved for reference but are no longer the active versions.

---

## §J · Testing a New Skill

Before a skill is admitted into the program library:

1. **Dry read.** An interpreter (distinct from the author) loads the skill cold and describes what it would do, step by step, against a hypothetical spec. Gaps in the skill's specificity surface here.

2. **End-to-end run.** The skill is run against a real but low-stakes spec. The artifacts it produces are compared against the Outputs declaration. Discrepancies are skill bugs.

3. **Stranger-executable test.** A second interpreter (different from both the author and the dry-read interpreter) runs the skill fresh. If the second interpreter produces materially different output on the same inputs, the skill is under-specified and must be tightened.

4. **Validation-protocol integration.** For producer/validator/arbiter skills, the artifact flows into the next role's skill. Confirm the downstream skill can parse and act on the upstream skill's output.

5. **Compatibility matrix.** Record which interpreters the skill was tested on. Update `compatible_interpreters` frontmatter accordingly.

Only after passing all five is the skill eligible for addition to the active program library.

---

## §K · Skill Authoring Commitments

Auditable statements of this document's design choices:

1. **One role per skill.** Cross-role skills are refactored before admission. Role discipline is the foundation of the validation protocol.

2. **Frontmatter is binding.** Declared inputs, outputs, and distinctness requirements are contracts the skill keeps. A skill that reads undeclared files or writes undeclared outputs is malformed.

3. **Self-check is mandatory.** Skills without self-check blocks are not admitted. Self-check quality is specificity — shallow checks are worse than no checks because they create false confidence.

4. **Stranger-executable.** An interpreter loading the skill cold, with no context from the authors, must be able to run it. Implicit knowledge is a bug.

5. **Artifacts, not prose.** Skills produce files at known paths. Skills that produce "a summary" in session output but no files are malformed.

6. **Bounded loops only.** Unbounded iteration is not allowed. Self-check passes, implementation revisions, and any other loops declare their upper bound.

7. **Session manifest on every skill.** The close-of-session accounting is required, not optional. It is how the operator and future audits confirm the skill executed as declared.

If a future extension violates any of these, it is not a skill-authoring extension — it is a different authoring model.

---

_End of SKILL_AUTHORING.md v1.0_
