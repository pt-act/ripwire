# Seat Onboarding Protocol — alignment before tasking (standing, operator-mandated)

Every model seat (producer, validator, any future seat) is onboarded in TWO STAGES. No seat
receives its first task directive until Stage 1 is confirmed complete. This is not ceremony:
the memory bank is only load-bearing to a seat that has *internalized* why each rule exists,
and directives alone produce directive-shaped work — aligned seats produce judgment.

## Stage 1 — Orion-OS alignment (comes FIRST, blocking)

Read, in this order, and confirm understanding of each in your own words before proceeding:

1. `.agents/Orion-OS-V2.5.1/AGENTS.md` — the convention map (what lives where)
2. `.agents/Orion-OS-V2.5.1/OPERATOR_GUIDE.md` — how seats are engaged, dispatched, and reported to
3. `.agents/Orion-OS-V2.5.1/VALIDATION_PROTOCOL.md` — the validation contract (§C completion reports,
   §H negative controls; the producer-does-not-self-validate rule)
4. `.agents/Orion-OS-V2.5.1/PROJECT_MANIFEST.md` — manifest grammar and role boundaries (§E vs
   VALIDATION_PROTOCOL step 2 — see open question Q10, unresolved)
5. `.agents/Orion-OS-V2.5.1/SPEC_FORMAT.md` — the 12-heading skeleton (selfcheck-pinned; planning
   material lives INSIDE Scope, never as a new heading)

**Confirmation required:** a written alignment statement — the seat's own summary of the
principles (gate-first, honest output, determinism, disclosure duties, role boundaries), naming
at least one rule it expects to be *tempted to break* and why it will not. The dispatcher
reviews this statement before Stage 2.

## Stage 2 — memory bank immersion (only after alignment is confirmed)

Read, in this order:

1. `.agents/memory_bank/active/current_focus.md` — where the project IS right now
2. `.agents/memory_bank/active/PROGRESS.md` — the full round history (read the LAST ~500 lines first;
   older history on demand)
3. `.agents/memory_bank/standing_requirements.md` — the SR rules (authorship identity, gitignore
   backstop, fresh-build rule, lineage-conflict rule)
4. `.agents/memory_bank/ARCHITECTURAL_DECISIONS.md` — the AD decisions
5. `.agents/memory_bank/active/open_questions.md` — the open Q's (do NOT re-derive recorded facts;
   Q8-Q11 are live)
6. `.agents/ripwire-audit-remediation-specs/manifest.yml` — the DAG state

**Confirmation required:** the seat restates the current project state in ≤10 lines: live PRs,
in-flight specs, its own role, and the next thing it expects to be asked to do.

## Stage 3 — engagement (only now)

From here the dispatcher engages the seat in the operator's voice — full engineering grammar,
complete briefs with binding constraints, acceptance criteria, and provenance. Briefs ALWAYS
carry: the round's scope, the binding constraints (house style, determinism, honesty clauses),
the acceptance criteria the PM will validate, and any standing-rule reminders the round touches.
The seat is engaged as a collaborator who has read the map — never handed directives without context.

## Dispatcher's own duties (the PM, when acting as dispatcher)

- Write briefs the way the operator would if he had the grammar: outcome, constraints, evidence
  expectations, and the WHY behind each constraint (a seat that understands why does not need the
  rule restated).
- Never summarize the bank for a seat — seats read the bank. A summarized bank is a bank nobody
  trusts.
- Verify alignment statements genuinely engage the principles (a seat that parrots is not aligned;
  ask one probing question before accepting).
- Record each seat's onboarding in PROGRESS.md (date, seat, model, alignment statement received).
