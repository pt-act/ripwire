DISPATCH: regex-screen-hardening ROUND 6 — respond to maintainer review on PR #397. You are an onboarded producer seat (Stage 1+2 complete; alignment statement on file). Worktree: this repo, branch lane/regex-screen-round6, base fec98e581 (round-5 rebased head).

MAINTAINER REVIEW (verified independently; three blockers + smaller items). YOUR TASKS, in order, ONE COMMIT EACH:

1. (BLOCKING) Fix the paren-bypass: when a group closes with no quantifier, has its own top-level '|', and that alternation is not proven disjoint, pass the flag up to the parent frame (same mechanism as hasQuantifierInside). Refuse when the parent closes under an unbounded quantifier. Add altCase arms: ((a|aa))+b$ and (?:(?:a|aa))+b$ (must be REFUSED). Keep all currently-refused arms refused and currently-admitted admitted ((a|b)+, (\w|-)+, (\s|,)+, ([a-z]|_)+, (?:[a-z]|\d)+ stay admitted).

2. (BLOCKING) REMOVE the per-file match budget (kRegexFileMatchBudget / RIPWIRE_FAULT_REGEX_BUDGET machinery) from this PR per review: it refuses fast linear answers (^9\d\d$ with --no-prefilter, \d{4}-\d{2}-\d{2} on logs) and bounds nothing new. The residual stays documented in docs/LIMITS.md as regex-screen-multiquantifier (follow-on spec). Adjust regexbombcheck's budget arms accordingly — budget-refusal arms become dead-path-removed assertions or drop them; keep the mixed-cause arms ONLY for engine-abandonment (single cause) if the budget no longer exists, the mixed arms testing budget+engine both must be reworked to engine-only or removed with the budget. BE CAREFUL: gate arms must match the new reality; a gate asserting removed behavior will red.

3. (BLOCKING, mechanical) python3 bench/capsweep/capsweep.py emit — commit the regenerated docs/TUNING.md (161 -> 163 declarations). This fixes the 7 red CI jobs.

4. (NON-BLOCKING, include) First-character-disjoint extension: if every branch has no quantifier and the branches' first-character sets are pairwise disjoint, admit. Must admit: "([^"\\]|\\.)*", "(\r\n|\n)+", (cat|dog)+, (foo|bar)+; must still refuse (a|aa)+, (get|getResponse)+.

5. (NON-BLOCKING, include) Advice message: "a small explicit bound" not "(get|getResponse){1,5}" as the exemplar. Fix wording: CHANGELOG single-cause claim (engine path changed reason+advice on purpose — correct the text), verbs_grep.h:691 comment, search.h:1217 and arch.h:149 stale comments ((a|a)+z no longer passes the screen).

6. Gates: rebuild; regexbombcheck ALL PASS on new arms; regexguardcheck (b2 — use a*a*a*a*a*b as the real-engine vehicle now the wrapped form is refused); regexrefusecheck; hazardpatterncheck; astqueryregexcheck; manifestcheck if you touch test/*.sh; --quality-delta=fec98e581..HEAD gating="0". Determinism check. NO PUSH, no rebase. Full regression CI-only.

7. Completion report: .agents/ripwire-audit-remediation-specs/validation/completion-report-rsr-r6.md — every claim cites command + observed output. Append round record to .agents/memory_bank/active/PROGRESS.md. Marker: ../markers/regex-round6-DONE (report path, commit sha, gate summary). Then Telegram ping (below). STOP.

CONSTRAINTS: house style (Allman, spaced parens, no std::map); ASSUME/DISCLOSE/PANIC; determinism; explicit git add paths; identity pt-act (set). Incremental commits: after each numbered task, commit WIP-prefixed. On (re)start: git log --oneline -8, resume from last commit.

FINAL STEP — Telegram ping (run as-is):
python3 -c "
import os,re,urllib.request,urllib.parse
v=os.environ.get('TELEGRAM_CHAT_ID_R1cAl','')
m=re.search(r'(\d{8,12}):([A-Za-z0-9_-]{30,})',v)
urllib.request.urlopen(urllib.request.Request(f'https://api.telegram.org/bot{m.group(0)}/sendMessage',data=urllib.parse.urlencode({'chat_id':'2146970914','text':'Producer GLM: regex round 6 COMPLETE - awaiting PM validation.'}).encode()),timeout=10)"
