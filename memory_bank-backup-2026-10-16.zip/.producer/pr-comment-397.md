Thank you for the exceptionally thorough review — every blocking item is addressed in 45333d732 (squashed branch history).

**1. Paren bypass (blocking) — fixed.** An unquantified inner group holding an unproven top-level alternation now propagates that flag to the parent frame via the same mechanism as `hasQuantifierInside`; the parent closing under an unbounded quantifier is refused. Verified on the new binary: `((a|aa))+b$`, `(?:(?:a|aa))+b$` and `^(a|aa)+b$` all rc=1 (refused). `altCase` arms added for both wrapped forms.

**2. Per-file match budget (blocking) — removed.** You were right: it counted candidate lines, not engine work, refused fast linear answers and bounded nothing new. The whole budget machinery is gone; a stopped scan has one cause. Verified: your 20,001-line CSV case (`^9\d\d$`) answers rc=0 with the full hit count, with or without `--no-prefilter` (the switch is orthogonal again); the residual stays named in LIMITS.md as `regex-screen-multiquantifier` (follow-on spec, not claimed closed).

**3. docs/TUNING.md (blocking, mechanical) — regenerated.** `capsweep emit` run and committed; `capsweepcheck.sh` ALL PASS on the head tree. This should clear the 7 red shards (the macOS cppqual timeout you diagnosed as a load flake may still flake).

**Smaller items, all included:**
- First-character-disjoint extension: branches that are unquantified width-one sequences with pairwise-disjoint first-character sets are admitted — your full safe list verified admitted (`"([^"\\]|\\.)*"`, `(\r\n|\n)+`, `(::|\.)+`, `(cat|dog)+`, `(foo|bar)+`), while `(a|aa)+` and `(get|getResponse)+` stay refused.
- Advice now says "a small explicit bound".
- Wording corrected: the CHANGELOG single-cause sentence, `verbs_grep.h:691`, `search.h:1217`, `arch.h:149` — the engine-path reason/advice change is now described as intentional, and the `(a|a)+z` comments match reality.
- `regexguardcheck` (b2) re-vehicled on `a*a*a*a*a*b` as the real-engine leg, as you suggested.
- The duplicate alternation-proof logic merged into one selector.

**Verification:** fresh build; `regexbombcheck`, `regexguardcheck`, `regexrefusecheck`, `hazardpatterncheck`, `astqueryregexcheck`, `grepcheck` all ALL PASS; `--quality-delta=fec98e581..HEAD` reports `gating="0"`; determinism byte-identical on repeat runs.

**One honest caveat:** the local ASan smoke run did not complete — the sandbox this was built in cannot sustain a sanitizer build (sustained compiles get killed by the environment, and the box ceiling isn't resizable). The ASan leg rides on CI's sanitizer shard; happy to run it locally on my side and report the numbers if you'd like them before then.
