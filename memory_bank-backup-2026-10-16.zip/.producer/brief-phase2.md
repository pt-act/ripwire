DISPATCH: git-porcelain-framing Phase 2 (worktree: this repo, branch lane/git-porcelain-framing-v2, base d4325a8cc). You are an onboarded producer seat. Spec: .agents/ripwire-audit-remediation-specs/specs/git-porcelain-framing/spec.md. Phase-1 design twice-validated: NUL-delimited git log records via `git -c core.quotepath=false log -z --name-only --format='%x00__C__%x00<fields>'` — empty field = record boundary (paths never empty). KNOWN QUIRK: each commit's FIRST path carries a leading \n after the epoch field's NUL — the parser must consume it. Three command shapes in src/gitmine.h to migrate (~1502 __C__, ~1626/1843/2072 __C__%x20%ct, ~2368/2431 __C__%ae|%at) — ALL five consumers to shared gitLogRecords().

RESILIENCE PROTOCOL: commit WIP-prefixed after each task (git add explicit paths). On (re)start: git log --oneline -8; resume from last commit. Scratch work under ../scratch/ (permitted).

TASKS (commit after each):
1. Prototype the NUL-framed stream in a scratch repo; verify boundaries, the first-path leading-\n quirk, hostile-filename round-trip; record findings in the commit message.
2. Implement shared gitLogRecords(); migrate all five consumers.
3. test/gitframingcheck.sh arms (a)-(e): hostile-name battery (each hostile name sorts BEFORE a later indexed .cpp), forged-attribution refused, quirk-byte pin, git 2.43.0 floor. Hermetic temp-repo pattern per cochangecliocheck.sh. REGISTER in test/regression.sh same commit.
4. CHANGELOG [Unreleased] entry; docs/LIMITS.md if applicable.
5. Build (cmake -S . -B build -j); run your gate + manifestcheck + --quality-delta=d4325a8cc..HEAD (expect gating="0").
6. Completion report: .agents/ripwire-audit-remediation-specs/validation/completion-report-gpf-p2.md (every claim = command + observed output; else "claimed, unverified"). Append round record to .agents/memory_bank/active/PROGRESS.md. Final commit, authored pt-act.
7. Marker: ../markers/porcelain-phase2-DONE (report path, sha, gate summary). Then the Telegram ping below. STOP.

CONSTRAINTS: house style (Allman, spaced parens, no std::map/unordered_map); ASSUME/DISCLOSE/PANIC discipline; determinism; explicit git add paths; identity pt-act; NO PUSH, no rebase; full regression.sh CI-only.

FINAL STEP — Telegram ping (run as-is):
python3 -c "
import os,re,urllib.request,urllib.parse
v=os.environ.get('TELEGRAM_CHAT_ID_R1cAl','')
m=re.search(r'(\d{8,12}):([A-Za-z0-9_-]{30,})',v)
urllib.request.urlopen(urllib.request.Request(f'https://api.telegram.org/bot{m.group(0)}/sendMessage',data=urllib.parse.urlencode({'chat_id':'2146970914','text':'Producer: porcelain Phase 2 COMPLETE - awaiting PM validation.'}).encode()),timeout=10)"
