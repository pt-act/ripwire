**Subject: Sandbox instance replacement is breaking long-running agent work — findings + specific asks**

Hi Ryan,

First: the platform's core model — session-owns-the-VM, cross-thread addressing, managed previews, the project run/setup script hooks — has held up remarkably under heavy use. I've been running a supervised multi-agent pipeline (a PM session orchestrating external CLI coding clients inside the sandbox) across ripwire and related projects, and most of what we needed, the platform provided. This email is about the one thing it didn't, with evidence and specific asks. Everything below is reproducible from my session logs.

**The core problem: the sandbox instance is replaced every 1–2 hours under active use, and nothing inside it survives — not background processes, not `setsid`/`nohup` daemons, not even managed preview processes.**

What we observed (18 hours, 2026-10-14 → 10-15):
- Nine+ instance replacements (confirmed via /proc/uptime resets and snapshot-restore notices). Interval ranged from ~1 to ~8 hours; when a supervised round was actively running, typically 1–2 hours.
- Every replacement kills ALL processes, including: nohup'd background jobs, `setsid` detached sessions, and — most importantly — **managed preview processes** (preview exit provenance shows SIGTERM/127 across events). Preview persistence survives turn boundaries; it does not survive instance replacement.
- The workspace restores from a snapshot that can be hours stale: on 2026-10-14 the restore was from ~18:46 while the current time was ~20:54. Git branch refs, `/tmp` state, and config files outside the persistent workspace root rolled back with it. We lost committed work once (a branch ref reset), and `/tmp` scratch repeatedly.
- Net effect: a 30–60 minute supervised coding round took 17+ hours of wall-clock across relaunches. Nothing durable was lost (we built an incremental-commit resume protocol), but the duty cycle was ~20%.

**What we'd ask for, in priority order:**

1. **A durable execution surface.** The single highest-value fix: let a session's sandbox host processes that survive instance replacement — either (a) make instance replacement preserve the process tree, (b) provide a platform-managed "job" primitive (submit a command; it runs to completion across replacement events, with logs and exit state retrievable), or (c) at minimum, ensure managed previews are re-launched automatically after replacement (the project run-script hook already exists — right now the replacement kills the preview and nothing restarts it until the agent manually calls preview_start).

2. **A documented persistence contract.** We reverse-engineered by experiment: the persistent workspace root survives; `/tmp` does not; snapshot age varies; branch refs in the main repo's .git are at risk; global config dirs (~/.config) sometimes survive, sometimes don't. A one-page document stating exactly what persists, for how long, and across which events would have saved us a day.

3. **Instance-replacement notifications.** The session should see a structured event ("instance replaced at T, restored from snapshot S, age A") rather than having to infer it from uptime resets and stale mtimes. Agents can self-heal from almost anything they can observe; silent replacement is the one thing we can't.

4. **A trigger to wake/resume a session on completion.** If a job primitive (ask #1) is out of scope, then a file-appearance or webhook trigger that re-activates the thread when a marker appears — we built the marker/heartbeat/notify machinery already; it just needs the platform's listener to close the loop.

For context, this is the same workflow gap class as the earlier feedback (session↔client bridging, cross-thread transfer, bidirectional pairing). We're not blocked — we've worked around every instance of it — but the workarounds are the difference between this platform being where long-running multi-agent work *happens* versus where it *starts and then gets finished somewhere else*.

Happy to demo the pipeline, share session logs, or test any of these on a branch of the platform before general release. The pipeline is running live in this sandbox right now.

RA
